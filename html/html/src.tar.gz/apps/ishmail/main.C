/*
 * $Id: main.C,v 1.1 1998/06/24 01:32:30 lang Exp $
 *
 * Copyright (c) 1993 HAL Computer Systems International, Ltd.
 * 
 *          HAL COMPUTER SYSTEMS INTERNATIONAL, LTD.
 *                  1315 Dell Avenue
 *                  Campbell, CA  95008
 *
 * Author: Greg Hilton
 * Contributors: Tom Lang, Frank Bieser, and others
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * http://www.gnu.org/copyleft/gpl.html
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#include "IshAppC.h"
#include "ShellExp.h"
#include "ImapMisc.h"

#include <new.h>

/*---------------------------------------------------------------
 *  New handler
 */

void
OutOfMemory()
{
   ishApp->PopupMessage
	       ("The application has run out of memory\nand cannot continue");
   exit(1);
}

/*---------------------------------------------------------------
 *  Main program
 */

#ifdef OSF1
void
#else
int
#endif
main(int argc, char **argv)
{
//
// Print version and exit
//
   if ( argc > 1 && strcmp(argv[1], "-v") == 0 ) {
      cout <<version <<endl;
      exit(0);
   }

   set_new_handler(OutOfMemory);

//
// Start helper process for expanding shell variables
//
   BuildImapPat();
   InitShellExpand();

//
// Create application object.  This initializes X-Windows and reads user
//    preferences.
//
   IshAppC	*app = new IshAppC(&argc, argv, "ishmail", "Ishmail");

//
// Start looping
//
   if ( debuglev > 0 ) cout <<"MainLoop" <<endl;
   app->MainLoop();		// This never returns

   exit(0);

} // End main
