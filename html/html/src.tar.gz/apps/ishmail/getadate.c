/*
 * $Id: getadate.c,v 1.1 1998/06/24 01:32:30 lang Exp $
 *
 * Copyright (c) 1993 HAL Computer Systems International, Ltd.
 * 
 *          HAL COMPUTER SYSTEMS INTERNATIONAL, LTD.
 *                  1315 Dell Avenue
 *                  Campbell, CA  95008
 *
 * Author: Greg Hilton
 * Contributors: Tom Lang, Frank Bieser, and others
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * http://www.gnu.org/copyleft/gpl.html
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#include <stdio.h>
#include <time.h>
#include <sys/time.h>

#if defined(SUN_OS) || defined(BSDI)
# define HAS_TIMEZONE	0
# define HAS_DAYLIGHT	0
# define HAS_TZNAME	0
#else
# define HAS_TIMEZONE	1
# define HAS_DAYLIGHT	1
# define HAS_TZNAME	1
#endif

#if HAS_TIMEZONE
extern long	timezone;
#endif

#if HAS_DAYLIGHT
extern int	daylight;
#endif

#if HAS_TZNAME
extern char	*tzname[2];
#endif

char *days[]   = {"Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"};
char *months[] = {"Jan", "Feb", "Mar", "Apr", "May", "Jun",
		  "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"};

extern int	debuglev;

char *
get_822_date()
{
   struct timeval	tv;
   struct timezone	tz;
   struct tm		*t;
   int			dstflag;
   int			zone;
   char			*zonename;
   static char		buffer[BUFSIZ];	/* static character buffer       */

   gettimeofday(&tv, &tz);
   t = localtime(&tv.tv_sec);
   tzset();

#if HAS_DAYLIGHT
   if ( debuglev > 1 ) printf("daylight: %d\n", daylight);
   if ( debuglev > 1 ) printf("tm_isdst: %d\n", t->tm_isdst);
   dstflag  = daylight ? t->tm_isdst : 0;
#else
   if ( debuglev > 1 ) printf("tm_isdst: %d\n", t->tm_isdst);
   dstflag  = t->tm_isdst ? 1 : 0;
#endif
   if ( debuglev > 1 ) printf("dstflag: %d\n", dstflag);

#if HAS_TIMEZONE
   if ( debuglev > 1 ) printf("timezone: %d\n", timezone);
   zone = (dstflag * 60) - (timezone / 60);
#else
   if ( debuglev > 1 ) printf("tm_gmtoff: %d\n", t->tm_gmtoff);
   zone = (int)t->tm_gmtoff / (int)60;
#endif
   if ( debuglev > 1 ) printf("zone: %d\n", zone);

#if HAS_TZNAME
   zonename = tzname[dstflag];
#else
   zonename = t->tm_zone;
#endif
   if ( debuglev > 1 ) printf("zonename: %s\n", zonename);

   sprintf(buffer, "%s, %d %s %d %02d:%02d:%02d %+03d%02d (%s)\n",
           days[t->tm_wday],
	   t->tm_mday,
	   months[t->tm_mon],
	   t->tm_year+1900,
	   t->tm_hour,
	   t->tm_min,
	   t->tm_sec,
	   zone/60,
	   abs(zone) % 60,
	   zonename);

   if ( debuglev > 1 ) printf("date string: %s\n", buffer);
   return buffer;

} /* End get_822_date */
