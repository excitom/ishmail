/*
 * $Id: genkey.C,v 1.1 1998/06/24 01:32:30 lang Exp $
 *
 * Copyright (c) 1994 HAL Computer Systems International, Ltd.
 * 
 *          HAL COMPUTER SYSTEMS INTERNATIONAL, LTD.
 *                  1315 Dell Avenue
 *                  Campbell, CA  95008
 *
 * Author: Greg Hilton
 * Contributors: Tom Lang, Frank Bieser, and others
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * http://www.gnu.org/copyleft/gpl.html
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#include "checksum.h"
#include "MailFile.h"

#include <hgl/HalAppC.h>
#include <hgl/HalMainWinC.h>
#include <hgl/WArgList.h>
#include <hgl/RowColC.h>
#include <hgl/rsrc.h>
#include <hgl/StringListC.h>
#include <hgl/SysErr.h>

#include <Xm/Form.h>
#include <Xm/Label.h>
#include <Xm/Frame.h>
#include <Xm/ToggleB.h>
#include <Xm/TextF.h>
#include <Xm/PushB.h>

#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <time.h>
#include <string.h>
#include <errno.h>

enum {
   SINGLE_USER = 1,
   MULTI_USER,
   UNLIMITED_USER,
   NODE_LOCKED
};

static char	*nonMimeString =
"*************************************************************************\n\
* This message has been encoded using the Multipurpose Internet Mail\n\
* Extensions (MIME) format.  The mail reader you are using does not\n\
* support MIME.  To display the non-text portions of this message you\n\
* will need a MIME-capable mail reader such as Ishmail (info@ishmail.com).\n\
*************************************************************************";

static char	*licenseAgreeString =
"This message includes a license file which lets you use Ishmail.\n\
\n\
The next body part contains the Ishmail License Agreement.  You must read\n\
this agreement before saving the license file.  If you are currently running\n\
Ishmail, simply click on the icon below with the left mouse button to read\n\
the agreement.";

static char	*demoLicenseAgreeString =
"This message includes a license file which lets you use and evaluate\n\
Ishmail for 30 days.\n\
\n\
The next body part contains the Ishmail License Agreement.  You must read\n\
this agreement before saving the license file.  If you are currently running\n\
Ishmail, simply click on the icon below with the left mouse button to read\n\
the agreement.";

static char	*licenseFileString =
"\nThe next body part contains your Ishmail license.  Save this information\n\
to a file named \"license\" in the \"bin\" subdirectory of where you installed\n\
Ishmail.  If you are currently running Ishmail, the easiest way to do this\n\
is to move the mouse cursor over the file's icon, press and hold the right\n\
button and select \"save\" from the pop-up menu.  If you did not install\n\
Ishmail in the default location, you will have a chance to provide the name\n\
of the directory you used.\n\
\n\
You may see a warning message, asking to confirm if you want to overwrite\n\
an existing license file.  Answer \"Yes\" to this question.";

static char	*demoLicenseFileString =
"\nThe next body part contains your 30-day demo license.  Save this information\n\
to a file named \"license\" in the \"bin\" subdirectory of where you installed\n\
Ishmail.  If you are currently running Ishmail, the easiest way to do this\n\
is to move the mouse cursor over the file's icon, press and hold the right\n\
button and select \"save\" from the pop-up menu.  If you did not install\n\
Ishmail in the default location, you will have a chance to provide the name\n\
of the directory you used.\n\
\n\
You may see a warning message, asking to confirm if you want to overwrite\n\
an existing license file.  Answer \"Yes\" to this question.\n\
\n\
If you decide to purchase Ishmail, please use the File->Comment feature to\n\
send us mail or call us at 1-800-382-7332 or 1-512-257-2450 to order\n\
a permanent license.";

extern int	debug1, debug2;
Boolean	demo = False;

/*-----------------------------------------------------------------------
 * Function to mail license to a user
 */

static char	errmsg[32768];

int
MailLicense(char *buf, StringC recip, char *licName)
{
//
// Build a MIME message
//
   StringC	bound = "-----" + recip + "-boundary-----";

   StringC	body = "To: " + recip + "\n";
   if ( demo ) body += "Subject: Ishmail Demo License\n";
   else	       body += "Subject: Ishmail Permanent License\n";
   body += "From: support@ishmail.com (Ishmail Software Support)\n";
   body += "MIME-Version: 1.0\n";
   body += "Content-Type: multipart/mixed;\n";
   body += "\tboundary=\"" + bound + "\"";
   while ( !body.EndsWith("\n\n") ) body += "\n";

   body += nonMimeString;
   while ( !body.EndsWith("\n\n") ) body += "\n";

   body += "--" + bound + "\n\n";

   if ( demo ) body += demoLicenseAgreeString;
   else	       body += licenseAgreeString;
   while ( !body.EndsWith("\n\n") ) body += "\n";

   body += "--" + bound + "\n";

   body += "Content-Disposition: attachment\n";
   body += "Content-Description: Ishmail License Agreement\n\n";

   StringC	licStr;
   if ( !licStr.ReadFile("README.license") ) {
      StringC	msg = "I could not read the \"README.license\" file.\n";
      msg += SystemErrorMessage(errno);
      strcpy(errmsg, msg);
      return 1;
   }

   body += licStr;
   while ( !body.EndsWith("\n\n") ) body += "\n";

   body += "--" + bound + "\n\n\n";

   if ( demo ) body += demoLicenseFileString;
   else	       body += licenseFileString;
   while ( !body.EndsWith("\n\n") ) body += "\n";

   body += "--" + bound + "\n";

   body += "Content-Type: application/octet-stream\n";
   body += "Content-Description: Ishmail license\n";
   body += "Content-Disposition: attachment";
   if ( strlen(licName) > 0 ) {
      body += "; filename=";
      body += licName;
   }

   while ( !body.EndsWith("\n\n") ) body += "\n";
   body += buf;
   while ( !body.EndsWith("\n\n") ) body += "\n";

   body += "--" + bound + "--\n\n";

   if ( recip == "stdout" ) {
      cout <<body <<endl;
   }
   else {
//
// Open temporary file for storing message
//
      char	*cs = tempnam(NULL, "gen.");
      StringC	file(cs);
      free(cs);

      if ( !body.WriteFile(file) ) {
	 unlink(file);
	 StringC	msg = "I could not create a temporary file for mailing.\n";
	 msg += SystemErrorMessage(errno);
	 strcpy(errmsg, msg);
	 return 1;
      }

      StringListC	recipList;
      recipList.add(recip);
      recip = "support@ishmail.com";
      recipList.add(recip);
      if ( MailFile(file, recipList, "/usr/lib/sendmail", True) ) {
	 errmsg[0] = 0;
      }
      else {
	 strcpy(errmsg, "License NOT sent");
	 return 1;
      }

   } // End if mailing

   return 0;

} // End MailLicense

/*-----------------------------------------------------------------------
 * Main program for command line version
 */

#ifdef S
   extern "C" int	getopt(int, char**, char*);
#endif
   extern "C" char	*optarg;
   extern "C" int	optind, opterr;

int
cli_main(int argc, char **argv)
{
   int		type;
   char		prod[256];
   char		ver[256];
   int		length;
   time_t	startTime;
   time_t	endTime;
   char		addr[256];
   int		userCount;
   char		userFile[256];
   char		mailTo[256];
   int		c;

   type        = 0;
   prod[0]     = 0;
   ver[0]      = 0;
   length      = -1;
   addr[0]     = 0;
   userCount   = 1;
   userFile[0] = 0;
   mailTo[0]   = 0;
   opterr      = 0;

/*
 * Read command line arguments
 */
   while ( (c=getopt(argc, argv, "?t:p:v:l:a:u:f:m:")) != EOF ) {

      switch (c) {

	 case 't':
	    type = atoi(optarg);
	    break;

	 case 'p':
	    strcpy(prod, optarg);
	    break;

	 case 'v':
	    strcpy(ver, optarg);
	    break;

	 case 'l':
	    length = atoi(optarg);
	    break;

	 case 'a':
	    strcpy(addr, optarg);
	    break;

	 case 'u':
	    userCount = atoi(optarg);
	    break;

	 case 'f':
	    strcpy(userFile, optarg);
	    break;

	 case 'm':
	    strcpy(mailTo, optarg);
	    break;

	 case '?':
	    opterr = 1;
	    break;
      }

   } /* End for each argument */

   if ( opterr ) {
      cerr <<"Usage: " <<argv[0];
      cerr <<" [-t type] [-p product-name] [-v version] [-l lifetime]" <<endl;
      cerr <<"       [-a host-address] [-u user-count] [-m mail-to-user] [-f user-file-name]" <<endl;
      return 1;
   }

/*
 * Read type if necessary
 */
   while ( type < 1 || type > 4 ) {
      fprintf(stderr, "What type of license should I create?\n");
      fprintf(stderr, "1) Single User\n");
      fprintf(stderr, "2) Multi User\n");
      fprintf(stderr, "3) Unlimited User\n");
      fprintf(stderr, "4) Node Locked\n");
      fprintf(stderr, "> ");
      scanf("%d", &type);
      fprintf(stderr, "\n");
   }

/*
 * Read product name if necessary
 */
   while ( strlen(prod) == 0 ) {
      fprintf(stderr, "What is the product name?\n");
      fprintf(stderr, "> ");
      scanf("%s", prod);
      fprintf(stderr, "\n");
   }

/*
 * Read version if necessary
 */
   while ( strlen(ver) == 0 ) {
      fprintf(stderr, "What is the product version number?\n");
      fprintf(stderr, "> ");
      scanf("%s", ver);
      fprintf(stderr, "\n");
   }

/*
 * Read lifetime if necessary
 */
   while ( length < 0 ) {
      fprintf(stderr, "What is the duration of this license (in days)?\n");
      fprintf(stderr, "> ");
      scanf("%d", &length);
      fprintf(stderr, "\n");
   }

#define	DAYLENGTH	(60*60*24)

   if ( length > 0 ) {
      startTime = time(0);
      endTime   = startTime + DAYLENGTH*(length+1);
   }
   else {
      startTime = endTime = 0;
   }

/*
 * Read host address if necessary
 */
   while ( strlen(addr) == 0 ) {
      fprintf(stderr, "What is the IP address of the host on which this license will be installed?\n");
      fprintf(stderr, "> ");
      scanf("%s", addr);
      fprintf(stderr, "\n");
   }

/*
 * Read user count if necessary
 */
   if ( type == MULTI_USER ) {
      while ( userCount < 2 ) {
	 fprintf(stderr, "How many users are authorized?\n");
	 fprintf(stderr, "> ");
	 scanf("%d", &userCount);
	 fprintf(stderr, "\n");
      }
   }

   else if ( type == UNLIMITED_USER ) {
      userCount = 0;
   }

   else if ( type == NODE_LOCKED ) {
      userCount = -1;
   }

   else {
      userCount = 1;
   }

//
// If the address is just a number, it's a host id and this should be a
//    node-locked license
//
   StringC	addrStr(addr);
   if ( addrStr.size() > 0 && !addrStr.Contains('.') ) {
      type      = NODE_LOCKED;
      userCount = -1;
   }

   demo = (length > 0);

//
//  Generate the key
//
   StringC	buf;
   buf = prod;
   buf += ver;
   buf += (int)startTime;
   buf += (int)endTime;
   buf += addr;
   buf += userCount;

   int	key = checkSum((unsigned char*)(char*)buf, buf.size());

//
//  Build a string for the license file
//
   buf.Clear();
   buf += key;			buf += "\n";
   buf += prod;			buf += "\n";
   buf += ver;			buf += "\n";
   buf += (int)startTime;	buf += "\n";
   buf += (int)endTime;		buf += "\n";
   buf += addr;			buf += "\n";
   buf += userCount;		buf += "\n";
   buf += "----- Make no changes above this line.  Add authorized users below. -----\n";

   if ( strlen(mailTo) > 0 ) {
      if ( MailLicense(buf, mailTo, userFile) != 0 )
	 cerr <<errmsg <<endl;
   }
   else {
      cout <<buf <<endl;
   }

   return 0;

} // End cli_main

static HalMainWinC	*mainWin;
static Widget		demoTB;
static Widget		singleTB;
static Widget		nameLabel;
static Widget		nameTF;
static Widget		multiTB;
static Widget		countLabel;
static Widget		countTF;
static Widget		nolimitTB;
static Widget		nodelockTB;
static Widget		neverTB;
static Widget		expTB;
static Widget		expTF;
static Widget		expLabel;
static Widget		mailTB;
static Widget		mailTF;
static Widget		licTF;
static Widget		fileTB;
static Widget		fileTF;
static Widget		showTB;
static Widget		prodTF;
static Widget		verTF;
static Widget		hostTF;

/*-----------------------------------------------------------------------
 * Callbacks
 */

void
ToggleDemo(Widget, XtPointer, XmToggleButtonCallbackStruct *tb)
{
   if ( tb->set ) {
      XmToggleButtonSetState(singleTB,   False, True);
      XmToggleButtonSetState(multiTB,    False, True);
      XmToggleButtonSetState(nolimitTB,  False, True);
      XmToggleButtonSetState(nodelockTB, False, True);
      XmToggleButtonSetState(expTB,      True,  True);
      XmTextFieldSetString(expTF, "30");
   }
}

void
ToggleSingle(Widget, XtPointer, XmToggleButtonCallbackStruct *tb)
{
   if ( tb->set ) {
      XmToggleButtonSetState(demoTB,     False, True);
      XmToggleButtonSetState(multiTB,    False, True);
      XmToggleButtonSetState(nolimitTB,  False, True);
      XmToggleButtonSetState(nodelockTB, False, True);
   }

   XtSetSensitive(nameLabel, tb->set);
   set_sensitivity(nameTF,   tb->set);
}

void
ToggleMulti(Widget, XtPointer, XmToggleButtonCallbackStruct *tb)
{
   if ( tb->set ) {
      XmToggleButtonSetState(demoTB,     False, True);
      XmToggleButtonSetState(singleTB,   False, True);
      XmToggleButtonSetState(nolimitTB,  False, True);
      XmToggleButtonSetState(nodelockTB, False, True);
   }

   XtSetSensitive(countLabel, tb->set);
   set_sensitivity(countTF,    tb->set);
}

void
ToggleNolimit(Widget, XtPointer, XmToggleButtonCallbackStruct *tb)
{
   if ( tb->set ) {
      XmToggleButtonSetState(demoTB,     False, True);
      XmToggleButtonSetState(singleTB,   False, True);
      XmToggleButtonSetState(multiTB,    False, True);
      XmToggleButtonSetState(nodelockTB, False, True);
   }
}

void
ToggleNodelock(Widget, XtPointer, XmToggleButtonCallbackStruct *tb)
{
   if ( tb->set ) {
      XmToggleButtonSetState(demoTB,    False, True);
      XmToggleButtonSetState(singleTB,  False, True);
      XmToggleButtonSetState(multiTB,   False, True);
      XmToggleButtonSetState(nolimitTB, False, True);
   }
}

void
ToggleNever(Widget, XtPointer, XmToggleButtonCallbackStruct *tb)
{
   if ( tb->set ) {
      XmToggleButtonSetState(expTB, False, True);
   }
}

void
ToggleExp(Widget, XtPointer, XmToggleButtonCallbackStruct *tb)
{
   if ( tb->set ) {
      XmToggleButtonSetState(neverTB, False, True);
   }

   set_sensitivity(expTF,    tb->set);
   XtSetSensitive(expLabel, tb->set);
}

void
ToggleMail(Widget, XtPointer, XmToggleButtonCallbackStruct *tb)
{
   if ( tb->set ) {
      XmToggleButtonSetState(fileTB, False, True);
      XmToggleButtonSetState(showTB, False, True);
   }

   set_sensitivity(mailTF, tb->set);
   set_sensitivity(licTF,  tb->set);
}

void
ToggleFile(Widget, XtPointer, XmToggleButtonCallbackStruct *tb)
{
   if ( tb->set ) {
      XmToggleButtonSetState(mailTB, False, True);
      XmToggleButtonSetState(showTB, False, True);
   }

   set_sensitivity(fileTF, tb->set);
}

void
ToggleShow(Widget, XtPointer, XmToggleButtonCallbackStruct *tb)
{
   if ( tb->set ) {
      XmToggleButtonSetState(mailTB, False, True);
      XmToggleButtonSetState(fileTB, False, True);
   }
}

void
Generate(Widget, XtPointer, XtPointer)
{
   mainWin->ClearMessage();

//
// Check for errors
//
   if ( XmTextFieldGetLastPosition(prodTF) == 0 ) {
      set_invalid(prodTF, True, True);
      StringC	msg = "Please enter a product name.";
      mainWin->PopupMessage(msg);
      return;
   }

   if ( XmTextFieldGetLastPosition(verTF) == 0 ) {
      set_invalid(verTF, True, True);
      StringC	msg = "Please enter a product version number.";
      mainWin->PopupMessage(msg);
      return;
   }

   if ( XmToggleButtonGetState(multiTB) ) {

      if ( XmTextFieldGetLastPosition(countTF) == 0 ) {
	 set_invalid(countTF, True, True);
	 StringC msg ="The user count is required for a multiple user license.";
	 mainWin->PopupMessage(msg);
	 return;
      }

      char	*cs = XmTextFieldGetString(countTF);
      int	num = atoi(cs);
      XtFree(cs);

      if ( num <= 0 ) {
	 set_invalid(countTF, True, True);
	 StringC msg ="A user count greater than 0 is required for a multiple user license.";
	 mainWin->PopupMessage(msg);
	 return;
      }

   } // End if multi-user license is selected

   if ( XmToggleButtonGetState(expTB) ) {

      if ( XmTextFieldGetLastPosition(expTF) == 0 ) {
	 set_invalid(expTF, True, True);
	 StringC msg ="A number of days is required for an expiring license.";
	 mainWin->PopupMessage(msg);
	 return;
      }

      char	*cs = XmTextFieldGetString(expTF);
      int	num = atoi(cs);
      XtFree(cs);

      if ( num <= 0 ) {
	 set_invalid(expTF, True, True);
	 StringC msg ="A number of days than 0 is required for an expiring license.";
	 mainWin->PopupMessage(msg);
	 return;
      }

   } // End if license expires

   if ( XmTextFieldGetLastPosition(hostTF) == 0 ) {
      set_invalid(hostTF, True, True);
      StringC	msg = "Please enter an IP address for the user's host.";
      mainWin->PopupMessage(msg);
      return;
   }

   if ( XmToggleButtonGetState(mailTB) &&
        XmTextFieldGetLastPosition(mailTF) == 0 ) {
      set_invalid(mailTF, True, True);
      StringC	msg = "Please enter an e-mail address.";
      mainWin->PopupMessage(msg);
      return;
   }

   if ( XmToggleButtonGetState(fileTB) &&
        XmTextFieldGetLastPosition(fileTF) == 0 ) {
      set_invalid(fileTF, True, True);
      StringC	msg = "Please enter a file name.";
      mainWin->PopupMessage(msg);
      return;
   }

//
// Gather the data
//
   demo = XmToggleButtonGetState(demoTB);

   int		userCount;
   StringC	userName;
   if ( demo || XmToggleButtonGetState(nolimitTB) ) {
      userCount = 0;
   }
   else if ( XmToggleButtonGetState(singleTB) ) {
      userCount = 1;
      char	*cs = XmTextFieldGetString(nameTF);
      userName = cs;
      userName.Trim();
      XtFree(cs);
   }
   else if ( XmToggleButtonGetState(multiTB) ) {
      char	*cs = XmTextFieldGetString(countTF);
      userCount = atoi(cs);
      XtFree(cs);
   }
   else if ( XmToggleButtonGetState(nodelockTB) ) {
      userCount = -1;
   }

   char	*cs = XmTextFieldGetString(prodTF);
   StringC	prod(cs);
   prod.Trim();
   XtFree(cs);

   cs = XmTextFieldGetString(verTF);
   StringC	ver(cs);
   ver.Trim();
   XtFree(cs);

   time_t	startTime = 0;
   time_t	endTime   = 0;
   int		days      = 0;
   if ( XmToggleButtonGetState(expTB) ) {

      cs = XmTextFieldGetString(expTF);
      days = atoi(cs);
      XtFree(cs);

      startTime = time(0);
      endTime   = startTime + DAYLENGTH*(days+1);
   }

   cs = XmTextFieldGetString(hostTF);
   StringC	addr(cs);
   addr.Trim();
   XtFree(cs);

//
//  Generate the key
//
   StringC	buf;
   buf = prod + ver;
   buf += (int)startTime;
   buf += (int)endTime;
   buf += addr;
   buf += userCount;

   int	key = checkSum((unsigned char*)(char*)buf, buf.size());

//
//  Build a string for the license file
//
   buf.Clear();
   buf += key;			buf += "\n";
   buf += prod;			buf += "\n";
   buf += ver;			buf += "\n";
   buf += (int)startTime;	buf += "\n";
   buf += (int)endTime;		buf += "\n";
   buf += addr;			buf += "\n";
   buf += userCount;		buf += "\n";
   buf += "----- Make no changes above this line.  Add authorized users below. -----\n";
   if ( userName.size() > 0 ) {
      buf += userName;		buf += "\n";
   }

   StringC	recip;
   if ( XmToggleButtonGetState(mailTB) ) {

      cs = XmTextFieldGetString(mailTF);
      recip = cs;
      recip.Trim();
      XtFree(cs);

      cs = XmTextFieldGetString(licTF);
      StringC	licName(cs);
      licName.Trim();
      XtFree(cs);

      if ( MailLicense(buf, recip, licName) != 0 )
	 mainWin->PopupMessage(errmsg);
      else {
	 StringC	msg("License sent to ");
	 msg += recip;
	 mainWin->Message(msg);
      }

   } // End if mailing license

   else if ( XmToggleButtonGetState(fileTB) ) {

      cs = XmTextFieldGetString(fileTF);
      StringC	file(cs);
      file.Trim();
      XtFree(cs);

      if ( !buf.WriteFile(file) ) {
	 StringC msg = "I could not create the file: " + file + ".\n";
	 msg += SystemErrorMessage(errno);
	 mainWin->PopupMessage(msg);
	 return;
      }

      StringC	msg("License saved to ");
      msg += file;
      mainWin->Message(msg);

   } // End if saving to file

   else {

      mainWin->PopupMessage(buf, XmDIALOG_INFORMATION);

   } // End if just displaying

#if 0
   if      ( userCount < 0  ) cout <<"Node-locked";
   else if ( userCount == 0 ) cout <<"Unlimited-user";
   else if ( userCount > 0  ) cout <<userCount <<"-user";

   cout <<" license for host " <<addr;

   if ( XmToggleButtonGetState(mailTB) ) cout <<" mailed to " <<recip;
   else					 cout <<" generated";

   time_t	curTime = time(0);
   StringC	tstr = (char*)ctime(&curTime);
   tstr.Trim();

   cout <<" on " <<tstr;

   if ( days > 0 ) cout <<", expiring in " <<days <<" days";
   cout <<"." <<endl;
#endif

} // End Generate

/*-----------------------------------------------------------------------
 * Function used to build the widgets for the main window
 */

void
BuildWidgets()
{
   mainWin->AddExitButton();
   mainWin->AddButtonBox();
   mainWin->ShowInfoMsg();

//
// Create appForm children
//
// appForm
//   Frame	typeFrame
//   Form	prodForm
//   Frame	dateFrame
//   Form	hostForm
//   Frame	mailFrame
//
   Widget	appForm = mainWin->AppForm();
   WArgList	args;
   Widget	wlist[16];

   args.Reset();
   args.LeftAttachment(XmATTACH_FORM);
   args.RightAttachment(XmATTACH_FORM);
   args.TopAttachment(XmATTACH_FORM);
   args.BottomAttachment(XmATTACH_NONE);
   Widget	typeFrame = XmCreateFrame(appForm, "typeFrame", ARGS);

   args.TopAttachment(XmATTACH_WIDGET, typeFrame);
   Widget	prodForm = XmCreateForm(appForm, "prodForm", ARGS);

   args.TopWidget(prodForm);
   Widget	dateFrame = XmCreateFrame(appForm, "dateFrame", ARGS);

   args.TopWidget(dateFrame);
   Widget	hostForm = XmCreateForm(appForm, "hostForm", ARGS);

   args.TopWidget(hostForm);
   Widget	mailFrame = XmCreateFrame(appForm, "mailFrame", ARGS);

//
// Create typeFrame children
//
// typeFrame
//   Label		typeLabel
//   RowColC		typeRC
//      ToggleButton	demoTB
//      ToggleButton	singleTB
//      Label		nameLabel
//      TextField	nameTF
//      ToggleButton	multiTB
//      Label		countLabel
//      TextField	countTF
//      ToggleButton	nolimitTB
//      ToggleButton	nodelockTB
//
   args.Reset();
   args.ChildType(XmFRAME_TITLE_CHILD);
   args.ChildHorizontalAlignment(XmALIGNMENT_BEGINNING);
   Widget	typeLabel = XmCreateLabel(typeFrame, "typeLabel", ARGS);

   RowColC	*typeRC = new RowColC(typeFrame, "typeRC", 0,0);

   args.Reset();
   args.IndicatorType(XmONE_OF_MANY);
   demoTB     = XmCreateToggleButton(*typeRC, "demoTB",     ARGS);
   singleTB   = XmCreateToggleButton(*typeRC, "singleTB",   ARGS);
   nameLabel  = XmCreateLabel       (*typeRC, "nameLabel",  0,0);
   nameTF     = XmCreateTextField   (*typeRC, "nameTF",     0,0);
   multiTB    = XmCreateToggleButton(*typeRC, "multiTB",    ARGS);
   countLabel = XmCreateLabel       (*typeRC, "countLabel", 0,0);
   countTF    = XmCreateTextField   (*typeRC, "countTF",    0,0);
   nolimitTB  = XmCreateToggleButton(*typeRC, "nolimitTB",  ARGS);
   nodelockTB = XmCreateToggleButton(*typeRC, "nodelockTB", ARGS);

   typeRC->Defer(True);
   typeRC->SetOrientation(RcROW_MAJOR);
   typeRC->SetUniformRows(True);
   typeRC->SetColCount(3);
   typeRC->SetColResize(0, False);
   typeRC->SetColResize(1, False);
   typeRC->SetColResize(2, True);
   typeRC->SetColAlignment(0, XmALIGNMENT_BEGINNING);
   typeRC->SetColAlignment(1, XmALIGNMENT_END);
   typeRC->SetColWidthAdjust(2, RcADJUST_ATTACH);

   wlist[ 0] = demoTB;
   wlist[ 1] = NULL;
   wlist[ 2] = NULL;
   wlist[ 3] = singleTB;
   wlist[ 4] = nameLabel;
   wlist[ 5] = nameTF;
   wlist[ 6] = multiTB;
   wlist[ 7] = countLabel;
   wlist[ 8] = countTF;
   wlist[ 9] = nolimitTB;
   wlist[10] = NULL;
   wlist[11] = NULL;
   wlist[12] = nodelockTB;
   wlist[13] = NULL;
   wlist[14] = NULL;
   typeRC->SetChildren(wlist, 15);	// typeRC children

   typeRC->Defer(False);

   wlist[0] = typeLabel;
   wlist[1] = *typeRC;
   XtManageChildren(wlist, 2);	// typeFrame children

//
// Create prodForm children
//
// prodForm
//   Label		prodLabel
//   TextField		prodTF
//   Label		verLabel
//   TextField		verTF
//
   args.Reset();
   args.LeftAttachment(XmATTACH_FORM);
   args.RightAttachment(XmATTACH_NONE);
   args.TopAttachment(XmATTACH_FORM);
   args.BottomAttachment(XmATTACH_FORM);
   Widget	prodLabel = XmCreateLabel(prodForm, "prodLabel", ARGS);

   args.LeftAttachment(XmATTACH_WIDGET, prodLabel);
   args.RightAttachment(XmATTACH_POSITION, 50);
   prodTF = XmCreateTextField(prodForm, "prodTF", ARGS);

   args.LeftAttachment(XmATTACH_POSITION, 50);
   args.RightAttachment(XmATTACH_NONE);
   args.TopAttachment(XmATTACH_FORM);
   args.BottomAttachment(XmATTACH_FORM);
   Widget	verLabel = XmCreateLabel(prodForm, "verLabel", ARGS);

   args.LeftAttachment(XmATTACH_WIDGET, verLabel);
   args.RightAttachment(XmATTACH_FORM);
   verTF = XmCreateTextField(prodForm, "verTF", ARGS);

   wlist[0] = prodLabel;
   wlist[1] = prodTF;
   wlist[2] = verLabel;
   wlist[3] = verTF;
   XtManageChildren(wlist, 4);	// prodForm children

//
// Create dateFrame children
//
// dateFrame
//   RowColC		dateRC
//      ToggleButton	neverTB
//      ToggleButton	expTB
//      TextField	expTF
//      Label		expLabel
//
   RowColC	*dateRC = new RowColC(dateFrame, "dateRC", 0,0);

   args.Reset();
   args.IndicatorType(XmONE_OF_MANY);
   neverTB  = XmCreateToggleButton(*dateRC, "neverTB",  ARGS);
   expTB    = XmCreateToggleButton(*dateRC, "expTB",    ARGS);
   expTF    = XmCreateTextField   (*dateRC, "expTF",    0,0);
   expLabel = XmCreateLabel       (*dateRC, "expLabel", 0,0);

   dateRC->Defer(True);
   dateRC->SetOrientation(RcROW_MAJOR);
   dateRC->SetUniformRows(True);
   dateRC->SetColCount(3);
   dateRC->SetColResize(0, False);
   dateRC->SetColResize(1, True);
   dateRC->SetColResize(2, False);
   dateRC->SetColAlignment(0, XmALIGNMENT_BEGINNING);
   dateRC->SetColAlignment(2, XmALIGNMENT_BEGINNING);
   dateRC->SetColWidthAdjust(1, RcADJUST_ATTACH);

   wlist[0] = neverTB;
   wlist[1] = NULL;
   wlist[2] = NULL;
   wlist[3] = expTB;
   wlist[4] = expTF;
   wlist[5] = expLabel;
   dateRC->SetChildren(wlist, 6);	// dateRC children

   dateRC->Defer(False);
   XtManageChild(*dateRC);		// dateFrame children

//
// Create hostForm children
//
// hostForm
//   Label		hostLabel
//   TextField		hostTF
//
   args.Reset();
   args.LeftAttachment(XmATTACH_FORM);
   args.RightAttachment(XmATTACH_NONE);
   args.TopAttachment(XmATTACH_FORM);
   args.BottomAttachment(XmATTACH_FORM);
   Widget	hostLabel = XmCreateLabel(hostForm, "hostLabel", ARGS);

   args.LeftAttachment(XmATTACH_WIDGET, hostLabel);
   args.RightAttachment(XmATTACH_FORM);
   hostTF = XmCreateTextField(hostForm, "hostTF", ARGS);

   wlist[0] = hostLabel;
   wlist[1] = hostTF;
   XtManageChildren(wlist, 2);	// hostForm children

//
// Create mailFrame children
//
// mailFrame
//   RowColC		mailRC
//      ToggleButton	mailTB
//      TextField	mailTF
//      Label		licLabel
//      TextField	licTF
//      ToggleButton	fileTB
//      TextField	fileTF
//      ToggleButton	showTB
//
   RowColC	*mailRC = new RowColC(mailFrame, "mailRC", 0,0);

   args.Reset();
   args.IndicatorType(XmONE_OF_MANY);
   mailTB = XmCreateToggleButton(*mailRC, "mailTB", ARGS);
   mailTF = XmCreateTextField   (*mailRC, "mailTF", 0,0);
   licTF  = XmCreateTextField   (*mailRC, "licTF",  0,0);
   fileTB = XmCreateToggleButton(*mailRC, "fileTB", ARGS);
   fileTF = XmCreateTextField   (*mailRC, "fileTF", 0,0);
   showTB = XmCreateToggleButton(*mailRC, "showTB", ARGS);
   Widget licLabel = XmCreateLabel(*mailRC, "licLabel", 0,0);

   mailRC->Defer(True);
   mailRC->SetOrientation(RcROW_MAJOR);
   mailRC->SetUniformRows(True);
   mailRC->SetColCount(2);
   mailRC->SetColResize(0, False);
   mailRC->SetColResize(1, True);
   mailRC->SetColAlignment(0, XmALIGNMENT_BEGINNING);
   mailRC->SetColWidthAdjust(1, RcADJUST_ATTACH);

   wlist[0] = mailTB;
   wlist[1] = mailTF;
   wlist[2] = licLabel;
   wlist[3] = licTF;
   wlist[4] = fileTB;
   wlist[5] = fileTF;
   wlist[6] = showTB;
   wlist[7] = NULL;
   mailRC->SetChildren(wlist, 7);	// mailRC children

   mailRC->Defer(False);
   XtManageChild(*mailRC);		// mailFrame children

   wlist[0] = typeFrame;
   wlist[1] = prodForm;
   wlist[2] = dateFrame;
   wlist[3] = hostForm;
   wlist[4] = mailFrame;
   XtManageChildren(wlist, 5);	// appForm children

//
// Create buttonBox children
//
// ButtonBox
//    PushButton	genPB
//
   Widget	genPB = XmCreatePushButton(mainWin->ButtonBox(), "genPB", 0,0);
   XtManageChild(genPB);

   XtVaSetValues(appForm, XmNdefaultButton, genPB, NULL);

//
// Add callbacks
//
   XtAddCallback(demoTB, XmNvalueChangedCallback,
   		 (XtCallbackProc)ToggleDemo, NULL);
   XtAddCallback(singleTB, XmNvalueChangedCallback,
   		 (XtCallbackProc)ToggleSingle, NULL);
   XtAddCallback(multiTB, XmNvalueChangedCallback,
   		 (XtCallbackProc)ToggleMulti, NULL);
   XtAddCallback(nolimitTB, XmNvalueChangedCallback,
   		 (XtCallbackProc)ToggleNolimit, NULL);
   XtAddCallback(nodelockTB, XmNvalueChangedCallback,
   		 (XtCallbackProc)ToggleNodelock, NULL);

   XtAddCallback(neverTB, XmNvalueChangedCallback,
   		 (XtCallbackProc)ToggleNever, NULL);
   XtAddCallback(expTB, XmNvalueChangedCallback,
   		 (XtCallbackProc)ToggleExp, NULL);

   XtAddCallback(mailTB, XmNvalueChangedCallback,
   		 (XtCallbackProc)ToggleMail, NULL);
   XtAddCallback(fileTB, XmNvalueChangedCallback,
   		 (XtCallbackProc)ToggleFile, NULL);
   XtAddCallback(showTB, XmNvalueChangedCallback,
   		 (XtCallbackProc)ToggleShow, NULL);

   XtAddCallback(genPB, XmNactivateCallback, (XtCallbackProc)Generate, NULL);

   XtSetSensitive(nameLabel,  False);
   set_sensitivity(nameTF,     False);
   XtSetSensitive(countLabel, False);
   set_sensitivity(countTF,    False);
   set_sensitivity(expTF,      True);
   XtSetSensitive(expLabel,   True);
   set_sensitivity(mailTF,     True);
   set_sensitivity(licTF,      True);
   set_sensitivity(fileTF,     False);

   XmToggleButtonSetState(demoTB, True, True);
   XmToggleButtonSetState(expTB,  True, True);
   XmToggleButtonSetState(mailTB, True, True);

} // End BuildWidgets

/*-----------------------------------------------------------------------
 * Main program for GUI version
 */

int
gui_main(int argc, char **argv)
{
//
// Create application object.  This initializes X-Windows.
//
   HalAppC *app = new HalAppC(&argc, argv, "genkey", "Genkey", NULL);

//
// Build main window
//
   mainWin = new HalMainWinC("mainWin", *app);
   BuildWidgets();
   mainWin->Show();

   app->MainLoop();

   return 0;

} // End gui_main

/*-----------------------------------------------------------------------
 * Main program
 */

#ifdef OSF1
void
#else
int
#endif
main(int argc, char **argv)
{
   if ( argc > 1 ) exit(cli_main(argc, argv));
   else		   exit(gui_main(argc, argv));
}
