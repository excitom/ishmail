/*
 *  $Id: ImapFolderC.C,v 1.1 1998/06/24 01:32:30 lang Exp $
 *  
 *  Copyright (c) 1994 HAL Computer Systems International, Ltd.
 * 
 *          HAL COMPUTER SYSTEMS INTERNATIONAL, LTD.
 *                  1315 Dell Avenue
 *                  Campbell, CA  95008
 *
 * Author: Greg Hilton
 * Contributors: Tom Lang, Frank Bieser, and others
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * http://www.gnu.org/copyleft/gpl.html
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
#include "ImapFolderC.h"
#include "ImapServerC.h"
#include "ImapMsgC.h"
#include "FileMisc.h"
#include "IshAppC.h"
#include "AppPrefC.h"
#include "MainWinC.h"
#include "UndelWinC.h"
#include "SortMgrC.h"
#include "ImapMisc.h"
#include "MsgListC.h"
#include "MsgItemC.h"

#include <hgl/RegexC.h>
#include <hgl/CharC.h>
#include <hgl/StringListC.h>
#include <hgl/VBoxC.h>

#include <time.h>

extern int	debuglev;

/*------------------------------------------------------------------------
 * ImapFolderC constructor
 */

ImapFolderC::ImapFolderC(const char *n, Boolean create)
: FolderC(n, IMAP_FOLDER, create)
{
   server = NULL;
   opened = False;

//
// Get server name and folder name
//
   serverName = ImapServerPart(name);
   folderName = ImapPathPart(name);
   if ( isInBox ) folderName = "INBOX";

//
// Connect to the server
//
#ifdef SHARE_IMAP_SERVER
   server = FindImapServer(serverName);
#else
   server = new ImapServerC(serverName);
#endif

   if ( !server ) return;

#ifndef SHARE_IMAP_SERVER
   if ( !server->connected ) {
      delete server;
      server = NULL;
      return;
   }
#endif

//
// Create the folder if necessary
// We can't try to create INBOX
//
    if ( !isInBox && create && !server->Exists(folderName) ) {

	StringListC	output;
	if ( !server->Create(folderName, output) ) return;

// Check response

	u_int	count = output.size();
	int i;
	for (i=0; i<count; i++) {
	    CharC	resp = *output[i];
	    if ( resp.StartsWith("NO ") ) return;
	}
   }

   opened = True;

} // End ImapFolderC constructor

/*------------------------------------------------------------------------
 * ImapFolderC destructor
 */

ImapFolderC::~ImapFolderC()
{
   if ( delFiles && server ) {
      StringListC	output;
      server->Delete(folderName, output);
   }

#ifndef SHARE_IMAP_SERVER
   delete server;
#endif
}

/*------------------------------------------------------------------------
 * Method to build message list
 */

Boolean
ImapFolderC::Scan()
{
   if ( !server ) return False;

   time_t       timeIn = 0;
   if ( debuglev > 0 ) {
      cout <<"Entering ImapFolderC(" <<BaseName(folderName) <<")::Scan" <<endl;
      timeIn = time(0);
   }

//
// Select the folder
//
   msgCount = 0;
   //int	newCount = 0;

   StringListC	output;
   if ( !server->Select(folderName, output) ) return False;

   scanned = True;

//
// Read SELECT responses
//
   u_int	count = output.size();
   int i=0; for (i=0; i<count; i++) {

      CharC	resp = *output[i];
      if ( resp.StartsWith("* ") ) {
	 resp.CutBeg(2);
	 resp.Trim();
      }

      if ( resp.StartsWith("FLAGS", IGNORE_CASE) ||
	   resp.StartsWith("NO", IGNORE_CASE) )
	 ;
      else if ( resp.EndsWith("EXISTS", IGNORE_CASE) ) {
	 resp.CutEnd(6);
	 resp.Trim();
	 StringC	num = resp;
	 msgCount = atoi(num);
      }

      else if ( resp.EndsWith("RECENT", IGNORE_CASE) ) {
	 resp.CutEnd(6);
	 resp.Trim();
	 StringC	num = resp;
	 //newCount = atoi(num);
      }

      else if ( resp.StartsWith("OK", IGNORE_CASE) ) {
	 resp.CutBeg(2);
	 resp.Trim();
	 writable = !resp.Contains("[READ-ONLY]", IGNORE_CASE);
      }

      else {
	 server->Unexpected(resp);
      }

   } // End for each reply

   StringC	statusStr;
#if 0
   Boolean	showCount = (ishApp->mainWin->IsShown() &&
   			    !ishApp->mainWin->IsIconified());
#else
//
// This change was made to make the message status information show
// up while the folder is being opened at start-up time. There ought to
// be a better way...
//
   Boolean	showCount = True;
#endif

//
// Get message information
//
   fetchNeeded = True;
   for (i=0; i<msgCount; i++) {

//
// Update progress message if necessary
//
      if ( showCount ) {
	 statusStr = abbrev;
	 statusStr += " - Scanning messages: ";
	 statusStr += (int)msgList->size() + 1;
	 ishApp->mainWin->Message(statusStr);
      }

//
// Add a message to the list
//
      ImapMsgC	*msg = new ImapMsgC(this, server, i+1);
      msgList->add(msg);
   }

//
// Update progress message if necessary
//
   if ( showCount ) {
      statusStr = abbrev;
      statusStr += " - Scanning messages: ";
      statusStr += (int)msgList->size();
      ishApp->mainWin->Message(statusStr);
   }

//
// Clean up
//
   server->FetchFlush( fetchTag );
   SetChanged(False);
   UpdateIcon();

   ishApp->mainWin->ClearMessage();

   if ( debuglev > 0 ) {
      time_t	timeOut = time(0);
      cout <<"Leaving ImapFolderC(" <<BaseName(folderName) <<")::Scan after "
      	   <<(timeOut-timeIn) <<" seconds" <<endl;
   }

   return True;

} // End Scan

/*------------------------------------------------------------------------
 * Method to save the folder.  Used to get rid of deleted messages and
 *    renumber remaining ones.
 */

Boolean
ImapFolderC::Save()
{
   if ( !server ) return False;

   StringListC	output;

#ifdef SHARE_IMAP_SERVER
   StringC	saveFolder;
   if ( server->folder != folderName ) {
      saveFolder = server->folder;
      if ( !server->Select(folderName, output) ) return False;
   }
#endif

   if ( !server->Expunge(output) ) return False;

   if ( active && !ishApp->exiting ) ishApp->mainWin->MsgVBox().Defer(True);

//
// Remove deleted messages from display
//
   if ( active && !ishApp->exiting ) {
      ishApp->mainWin->MsgVBox().RemoveItems(*delItemList);
      if ( ishApp->undelWin ) ishApp->undelWin->Clear();
   }

//
// Loop through message list and remove any deleted messages
//
   u_int	count  = msgList->size();
   u_int	number = 1;
   int i=0; for (i=0; i<count; i++) {

      ImapMsgC	*msg = (ImapMsgC*)(*msgList)[i];
      if ( msg->IsDeleted() ) {
	 delete msg;
	 msgList->replace(NULL, i);
      }

      else {

	 msg->SetNumber(number);
	 number++;

	 if ( msg->IsNew() && ishApp->appPrefs->markNewAsUnread )
	    msg->ClearNew();

      }

   } // End for each message

   msgList->removeNulls();
   delItemList->removeAll();

//
// Update display
//
   if ( active && !ishApp->exiting ) {
      if ( SortMgr()->Threaded() ) ishApp->mainWin->MsgVBox().Sort();
      ishApp->mainWin->MsgVBox().Defer(False);
   }

#ifdef SHARE_IMAP_SERVER
   if ( saveFolder.size() > 0 ) {
      if ( !server->Select(saveFolder, output) ) return False;
   }
#endif

   SetChanged(False);
   UpdateIcon();

   return True;

} // End Save

/*------------------------------------------------------------------------
 * Method to check for new mail
 */

Boolean
ImapFolderC::NewMail()
{
   if ( !server ) return False;

#ifdef SHARE_IMAP_SERVER
    StringC	saveFolder;
    if ( server->folder != folderName ) {
	saveFolder = server->folder;
	StringListC	output;
	if ( !server->Select(folderName, output) ) return False;
    }
#endif

   int		newCount = 0;
   Boolean	newMail  = False;

//
// Send NOOP command
//
   StringListC	output;
   server->Noop(output);

   u_int	count = output.size();
   msgCount =	msgList->size();
   int i=0; for (i=0; i<count; i++) {

      CharC	resp = *output[i];
      if ( resp.StartsWith("* ") ) {
	 resp.CutBeg(2);
	 resp.Trim();
      }

      if ( resp.StartsWith("FLAGS", IGNORE_CASE) ||
	   resp.StartsWith("NO", IGNORE_CASE) )
	 ;

      else if ( resp.EndsWith("EXISTS", IGNORE_CASE) ) {
	 resp.CutEnd(6);
	 resp.Trim();
	 StringC	num = resp;
	 msgCount = atoi(num);
      }

      else if ( resp.EndsWith("RECENT", IGNORE_CASE) ) {
	 resp.CutEnd(6);
	 resp.Trim();
	 StringC	num = resp;
	 newCount = atoi(num);
      }

      else if ( !resp.StartsWith("OK", IGNORE_CASE) ) {
	 server->Unexpected(resp);
      }

   } // End for each reply

    if ( msgCount == msgList->size() ) {
	if ( saveFolder.size() > 0 ) {
	    StringListC	output;
	    server->Select(saveFolder, output);
	}
	return False;
    }

//
// See if the mailbox shrunk
//
   if ( msgCount < msgList->size() ) {

      StringC	errmsg = "Mail folder ";
      errmsg += name;
      errmsg += " has shrunk from ";
      errmsg += (int)msgList->size();
      errmsg += " messages to ";
      errmsg += msgCount;
      errmsg += " messages.";
      halApp->PopupMessage(errmsg, XmDIALOG_WARNING);

      Rescan();
   }

//
// See if the mailbox grew
//
   else {

      VBoxC&	vbox      = ishApp->mainWin->MsgVBox();
      MsgItemC	*firstNew = NULL;
      MsgItemC	*lastNew  = NULL;
      if ( active ) vbox.Defer(True);

//
// Get message information
//
      fetchNeeded = True;
      for (i=msgList->size(); i<msgCount; i++) {

	 ImapMsgC	*msg = new ImapMsgC(this, server, i+1);
	 msgList->add(msg);

//
// Create a message icon for this message
//
	 if ( active ) {

	    msg->CreateIcon();
	    InsertInThread(msg->icon);

	    msgItemList->add(msg->icon);
	    vbox.AddItem(*msg->icon);

            if ( !firstNew ) firstNew = msg->icon;
	    lastNew = msg->icon;

	 } // End if folder is active

//
// If this is a partial message, process it
//
         if ( msg->IsPartial() ) AddPartial(msg);

      } // End for each new message

      scanned = True;
      server->FetchFlush( fetchTag );

      if ( active ) {

//
// Scroll to the last then the first to display as many new messages
//    as possible
//
	 if ( lastNew && ishApp->appPrefs->scrollToNew ) {
	    vbox.View()->ScrollToItem(*lastNew);
	    vbox.View()->ScrollToItem(*firstNew);
	 }

	 vbox.Defer(False);
      }

   } // End if mailbox grew

   newMail = (newCount > 0);
   if ( newMail && !ishApp->exiting ) UpdateIcon();
   if ( saveFolder.size() > 0 ) server->Select(saveFolder, output);

   return newMail;

} // End NewMail

/*------------------------------------------------------------------------
 * Method to copy the specified message into this folder
 */

Boolean
ImapFolderC::AddMessage(MsgC *msg)
{
   if ( !server ) return False;

   StringListC	output;

//
// If the source message is in an IMAP folder on the same server, we can use
//    the copy command.
//
   if ( msg->type == IMAP_MSG ) {

      ImapFolderC	*srcFolder = (ImapFolderC*)msg->folder;
      if ( srcFolder->server->name == server->name ) {

#ifdef SHARE_IMAP_SERVER
//
// Select source folder if necessary
//
	 StringC	saveFolder;
	 if ( server->folder != srcFolder->folderName ) {
	    saveFolder = server->folder;
	    if ( !server->Select(srcFolder->folderName, output) ) return False;
	 }

//
// Send COPY command
//
	 if ( !server->Copy(msg->Number(), folderName, output) ) return False;

	 if ( saveFolder.size() > 0 ) {
	    if ( !server->Select(saveFolder, output) ) return False;
	 }
#else
//
// Send COPY command
//
	 if ( !srcFolder->server->Copy(msg->Number(), folderName, output) )
	    return False;
#endif
//
// Make sure the folder's message list is up to date
//
         if (scanned) {
           Rescan();
//
// Make sure the folder is marked as needing to be saved
//
           Changed();
         }

	 return True;

      } // End if message is on same server as this folder

   } // End if adding an IMAP message

//
// We must use the APPEND command for non-IMAP messages or messages that are
//    on a different IMAP server
//
   StringC	data;
   msg->GetHeaderText(data);
   data += '\n';
   msg->GetBodyText(data);

   if ( !server->Append(folderName, data, output) ) return False;
//
// Make sure the folder's message list is up to date
//
   if (scanned) {
     Rescan();
//
// Make sure the folder is marked as needing to be saved
//
     Changed();
   }

   return True;

} // End AddMessage

/*------------------------------------------------------------------------
 * Method to copy the specified message into this folder
 */

Boolean
ImapFolderC::AddMessage(StringListC& headList, char *bodyFile)
{
   if ( !server ) return False;

//
// We must use the APPEND command
//
   StringListC	output;
   if ( !server->Append(folderName, headList, bodyFile, output) )
      return False;
//
// Make sure the folder's message list is up to date
//
   if (scanned) {
     Rescan();
//
// Make sure the folder is marked as needing to be saved
//
     Changed();
   }

   return True;

} // End AddMessage

/*------------------------------------------------------------------------
 * Activate folder on Imap server
 */
 
Boolean
ImapFolderC::Select()
{
   if ( !server ) return False;

   StringListC  output;
   if ( !server->Select(folderName, output) ) {

      StringC	errmsg = "Mail folder: ";
      errmsg += folderName;
      errmsg += " on IMAP server: ";
      errmsg += serverName;
      errmsg += " could not be selected.";
      halApp->PopupMessage(errmsg, XmDIALOG_WARNING);

      return False;
   }

   return True;

} // End Select
