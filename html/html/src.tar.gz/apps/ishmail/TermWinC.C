/*
 *  $Id: TermWinC.C,v 1.1 1998/06/24 01:32:30 lang Exp $
 *  
 *  Copyright (c) 1994 HAL Computer Systems International, Ltd.
 * 
 *          HAL COMPUTER SYSTEMS INTERNATIONAL, LTD.
 *                  1315 Dell Avenue
 *                  Campbell, CA  95008
 *
 * Author: Greg Hilton
 * Contributors: Tom Lang, Frank Bieser, and others
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * http://www.gnu.org/copyleft/gpl.html
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
#include "TermWinC.h"

#include <hgl/WArgList.h>
#include <hgl/TermC.h>
#include <hgl/HalAppC.h>

#include <Xm/PushB.h>

/*---------------------------------------------------------------------
 *  Constructor
 */

TermWinC::TermWinC(const char *name, Widget parent) : HalDialogC(name, parent)
{
   done      = False;
   cancelled = False;

   WArgList	args;
   args.LeftAttachment(XmATTACH_FORM);
   args.TopAttachment(XmATTACH_FORM);
   args.RightAttachment(XmATTACH_FORM);
   args.BottomAttachment(XmATTACH_FORM);
   term = new TermC(appForm, "term");
   XtSetValues(term->Form(), ARGS);
   term->AddShellExitCallback((CallbackFn *)ExitShell, this);

   AddButtonBox();

   Widget okPB   = XmCreatePushButton(buttonRC, "okPB",     0,0);
   cancelPB      = XmCreatePushButton(buttonRC, "cancelPB", 0,0);
   Widget helpPB = XmCreatePushButton(buttonRC, "helpPB",   0,0);
   XtManageChild(okPB);
   XtManageChild(cancelPB);
   XtManageChild(helpPB);

   XtAddCallback(okPB,     XmNactivateCallback, (XtCallbackProc)DoOk, this);
   XtAddCallback(cancelPB, XmNactivateCallback, (XtCallbackProc)DoCancel,
   		 this);
   XtAddCallback(helpPB,   XmNactivateCallback, (XtCallbackProc)HalAppC::DoHelp,
   		 "helpcard");

   HandleHelp();

} // End constructor

/*---------------------------------------------------------------------
 *  Destructor
 */

TermWinC::~TermWinC()
{
   delete term;
}

/*---------------------------------------------------------------------
 *  Called when terminal shell process exits.  Assume result was OK.
 */

void
TermWinC::ExitShell(TermC*, TermWinC *This)
{
   DoOk(NULL, This, NULL);
}

/*---------------------------------------------------------------------
 *  Called when user presses "ok" button
 */

void
TermWinC::DoOk(Widget, TermWinC *This, XtPointer)
{
   This->done      = True;
   This->cancelled = False;
   This->Hide();
}

/*---------------------------------------------------------------------
 *  Called when user presses "cancel" button
 */

void
TermWinC::DoCancel(Widget, TermWinC *This, XtPointer)
{
   This->done      = True;
   This->cancelled = True;
   This->Hide();
}

/*---------------------------------------------------------------------
 *  Method to run a command
 */

Boolean
TermWinC::Exec(const char *cmd, Boolean wait)
{
   Show();
   term->Exec(cmd);

   if ( !wait ) return True;

   while ( !done ) {
      XtAppProcessEvent(halApp->context, XtIMAll);
      XSync(halApp->display, False);
   }

   return !cancelled;

} // End Exec

/*---------------------------------------------------------------------
 *  Methods to show/hide cancel button
 */

void
TermWinC::ShowCancel()
{
   XtManageChild(cancelPB);
}

void
TermWinC::HideCancel()
{
   XtUnmanageChild(cancelPB);
}

/*---------------------------------------------------------------------
 *  Method to clear screen
 */

void
TermWinC::Clear()
{
   term->Clear();
}
