/*
 * $Id: License.C,v 1.2 1998/06/24 03:01:23 lang Exp $
 *
 * Copyright (c) 1994 HAL Computer Systems International, Ltd.
 * 
 *          HAL COMPUTER SYSTEMS INTERNATIONAL, LTD.
 *                  1315 Dell Avenue
 *                  Campbell, CA  95008
 *
 * Author: Greg Hilton
 * Contributors: Tom Lang, Frank Bieser, and others
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * http://www.gnu.org/copyleft/gpl.html
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#include "checksum.h"
#include "License.h"
#include "IshAppC.h"

#include <hgl/StrCase.h>
#include <hgl/SignalRegistry.h>
#include <hgl/CharC.h>
#include <hgl/SysErr.h>

#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#if defined OSF1 || MIPS
extern "C" {
#endif
#include <netdb.h>
#if defined OSF1 || MIPS
}
#endif
#include <netinet/in.h>
#include <pwd.h>
#include <unistd.h>
#include <sys/stat.h>
#include <errno.h>
#include <fcntl.h>
#include <dirent.h>
#include <signal.h>

#if (defined SOLARIS || defined SVR4) && !defined SGI
# include <sys/mnttab.h>
#elif (defined OSF1 || defined BSDI)
#elif defined AIX
# include <sys/mntctl.h>
# include <sys/vmount.h>
  extern "C" mntctl(int, int, char*);
#else
# include <mntent.h>
#endif

#if defined SOLARIS || defined MIPS
# include <sys/utsname.h>
# include <sys/systeminfo.h>
#endif

#if !defined HPUX && !defined LINUX
   extern "C" int	gethostname(char*, int);
#endif

#ifdef SUN_OS
   extern "C" int	gethostid();
#endif

/*------------------------------------------------------------------------
 * License info constructor
 */

LicInfoC::LicInfoC(const char *filename)
{
   file   = filename;
   status = LIC_OK;
   msg    = "";
   host   = "";
   userList.AllowDuplicates(FALSE);
   userList.SetSorted(FALSE);

#ifdef NO_LICENSE
   needsLicense = false;
   status = LIC_OK;
   return;
#else

#ifdef SOLARIS
//
// Hal machines don't need a license
//
   struct utsname	udata;
   CharC		mach;
   if ( uname(&udata) >= 0 ) mach = udata.machine;
   needsLicense = ((mach != "sun4h") && (mach != "sun4H"));
   if ( !needsLicense ) {
      status = LIC_OK;
      return;
   }
#else
   needsLicense = True;
#endif

//
// See if the license file is writable
//
   readOnly = (access(file, W_OK) != 0);

//
// Get the name of this user
//
   struct passwd	*pent;
   if ( (pent=getpwuid(getuid())) == NULL ) {

      char	*pptr = getenv("USER");
      if ( pptr ) user = pptr;
      else {
	 status = LIC_BAD_USER;
	 msg = "I could not determine your login id.\n";
	 msg += "Please set the USER variable in your environment.\n \n";
	 msg += ishApp->supportMsg;
	 return;
      }
   }

   else {
      user = pent->pw_name;
   }

   Init();
#endif	// Needs license

} // End constructor

/*------------------------------------------------------------------------
 * Initialize file data
 */

void
LicInfoC::Init()
{
   status = LIC_OK;

   if ( !needsLicense ) return;

//
// Get the name of the host containing the license file
//
   GetHostName();
   if ( status != LIC_OK ) return;

//
// Read the license file
//
   ReadFile();
   if ( status != LIC_OK ) return;

//
// Make sure the license file is installed on the correct host
//
///// Moved to IshAppP::CheckLicense to allow date check to preceed it.
//   CheckHost(host);
//   if ( status != LIC_OK ) return;

//
// Add the user name to the file if possible
//
   while ( !readOnly &&
           (userCount == 0 || userCount > userList.size()) &&
      	   !userList.includes(user) ) {

      FILE	*fp = fopen(file, "a");
      if ( !fp ) return;

      if ( fwrite((const char*)user, 1, user.size(), fp) != user.size() ||
	   fwrite("\n", 1, 1, fp) != 1 ) {
	 fclose(fp);
	 return;
      }

      fclose(fp);

//
// Read the file again to make sure the name got added.  Someone else could
//    have written the file at the same time.
//
      ReadFile();
      if ( status != LIC_OK ) return;

   } // End while user name not added

} // End Init

/*------------------------------------------------------------------------
 * Callback to handle alarms.  This is to keep the stat call from hanging
 */

static
void HandleAlarm(void*, void*)
{
   if ( debuglev > 1 ) cout <<"Got alarm" <<endl;
}

/*------------------------------------------------------------------------
 * Method to find the name of the host on which the license file lives
 */

void
LicInfoC::GetHostName()
{
   if ( !needsLicense ) return;

#ifdef BSDI
   host = ishApp->host;
   return;
#endif

   if ( debuglev > 1 ) cout <<"Looking for file: " <<file <<endl;

//
// Open the license file, or create an empty file if it doesn't exist.
//
   int lfd;
   if ((lfd = open( file, O_CREAT | O_RDWR, 0666)) == -1) {
       status = LIC_SYSERR;
       msg = "I could not create the license file: " + file;
       msg += ".\n";
       msg += SystemErrorMessage(errno);
       msg += "\n \n";
       msg += ishApp->supportMsg;
       return;
   }
   close(lfd);	// was only opened to cause creation if missing

//
// Get the device number for the file
//
   struct stat	sbuf;
   if ( stat(file, &sbuf) != 0 ) {
      if ( errno == ENOENT ) {
	 status = LIC_NO_FILE;
	 msg = "The license file: \"" + file;
	 msg += "\" does not exist.\n \n";
	 msg += ishApp->supportMsg;
      }
      else {
	 status = LIC_SYSERR;
	 msg = "I could not stat the license file: " + file;
	 msg += ".\n";
	 msg += SystemErrorMessage(errno);
	 msg += "\n \n";
	 msg += ishApp->supportMsg;
      }
      return;
   }

   off_t	fileSize = sbuf.st_size;
   dev_t	filedev  = sbuf.st_dev;

#if defined AIX
   dev_t	devmaj = major(filedev);
   dev_t	devmin = minor(filedev);
   if ( debuglev > 1 )
      cout <<"Device number is: " <<devmaj <<", " <<devmin <<endl;

#define REMOTE_DEVICE	32768

   int	isRemote = (devmaj == REMOTE_DEVICE);

//
// See how many bytes we need
//
   int	bufsize;
   if ( mntctl(MCTL_QUERY, sizeof(bufsize), (char*)&bufsize) < 0 ) {
      status = LIC_SYSERR;
      msg = "I could not get the size of the vmount table.\n";
      msg += SystemErrorMessage(errno) + "\n \n" + ishApp->supportMsg;
      return;
   }

//
// query the real stuff
//
   char	*buffer = new char[bufsize];
   int	count = mntctl(MCTL_QUERY, bufsize, buffer);
   if ( count < 0 ) {
      status = LIC_SYSERR;
      msg = "I could not read the vmount table.\n";
      msg += SystemErrorMessage(errno) + "\n \n" + ishApp->supportMsg;
      return;
   }

//
// Loop through entries
//
   struct vmount	*vent = (struct vmount*)buffer;
   struct vmount	*fent = NULL;
   struct vmt_data	*data;
   if ( debuglev > 1 ) {
      cout <<"          Object     Mounted-Over Major Minor VFS-Num" <<endl;
      cout <<"---------------- ---------------- ----- ----- -------" <<endl;
   }

   while ( !fent && count > 0 ) {

      dev_t	fsdev;
      if ( isRemote ) fsdev = vent->vmt_vfsnumber;
      else	      fsdev = vent->vmt_fsid.fsid_dev;

      if ( debuglev > 1 ) {

	 StringC	object;
	 data = &vent->vmt_data[VMT_OBJECT];
	 if ( data->vmt_size > 0 ) {
	    char	*cs = (char*)((ulong)vent + (ulong)data->vmt_off);
	    object = cs;
	 }

	 StringC	stub;
	 data = &vent->vmt_data[VMT_STUB];
	 if ( data->vmt_size > 0 ) {
	    char	*cs = (char*)((ulong)vent + (ulong)data->vmt_off);
	    stub = cs;
	 }

	 cout <<str(object,16) <<" " <<str(stub,16) <<" "
	      <<dec(major(vent->vmt_fsid.fsid_dev),5) <<" "
	      <<dec(minor(vent->vmt_fsid.fsid_dev),5) <<" "
	      <<dec(vent->vmt_vfsnumber,7) <<endl;
      }

      if ( ( isRemote && fsdev == devmin) ||
	   (!isRemote && fsdev == filedev) ) fent = vent;

//
// Advance to next structure
//
      vent = (struct vmount*)((ulong)vent + vent->vmt_length);
      count--;

   } // End for each vmount entry

//
// Look up host name
//
   if ( fent ) {

      data = &fent->vmt_data[VMT_HOST];
      if ( data->vmt_size > 0 ) {
	 char	*cs = (char*)((ulong)fent + (ulong)data->vmt_off);
	 host = cs;
      }
      else {
	 data = &fent->vmt_data[VMT_HOSTNAME];
	 if ( data->vmt_size > 0 ) {
	    char	*cs = (char*)((ulong)fent + (ulong)data->vmt_off);
	    host = cs;
	 }
      }

      if ( debuglev > 1 && host.size() > 0 )
	 cout <<"Host name is \"" <<host <<"\" from mount table" <<endl;
   }

   delete buffer;

   if ( host.size() == 0 || host == "-" ) {
      char	buf[256];
      if ( gethostname(buf, 255) == 0 ) {
	 host = buf;
	 if ( debuglev > 1 )
	    cout <<"Host name is \"" <<host <<"\" from gethostname()" <<endl;
      }
      else {
	 host = "localhost";
	 if ( debuglev > 1 )
	    cout <<"Host name is \"localhost\" by default" <<endl;
      }
   }

#else	// Not AIX

   if ( debuglev > 1 ) cout <<"Device number is: " <<filedev <<endl;

//
// Loop through the mount table
//
   char		*mfile;
   FILE		*fp;
   StringC	fsname;

#if (defined SOLARIS || defined SVR4) && !defined SGI
   mfile = MNTTAB;
   fp = fopen(mfile, "r");
#elif (defined OSF1 || defined BSDI)
#elif defined HPUX
   mfile = MNT_MNTTAB;
   fp = setmntent(mfile, "r");
#else
   mfile = MOUNTED;
   fp = setmntent(mfile, "r");
#endif

#if !(defined OSF1 || defined BSDI)
   if ( !fp ) {
      status = LIC_SYSERR;
      msg = "I could not open the mount table file: "; msg += mfile;
      msg += ".\n" + SystemErrorMessage(errno) + "\n \n" + ishApp->supportMsg;
      return;
   }
#endif

   AddSignalCallback(SIGALRM, (CallbackFn*)HandleAlarm, NULL);

#if (defined SOLARIS || defined SVR4) && !defined SGI

   struct mnttab	ment;
   struct mnttab	*fent = NULL;
   while ( !fent && getmntent(fp, &ment) == 0 ) {

//
// Skip automount entries
//
      if ( strcasecmp(ment.mnt_fstype, "autofs") == 0 ||
	   strcasecmp(ment.mnt_fstype, "ignore") == 0 )
	 continue;

      if ( debuglev > 1 ) cout <<"Checking filesystem " <<ment.mnt_special
			       <<" mounted on " <<ment.mnt_mountp <<flush;

      alarm(5); // Set an alarm so that the stat call won't hang

//
// Get the device number of the mount point of this file system
//
      if ( stat(ment.mnt_mountp, &sbuf) == 0 ) {

	 alarm(0);
	 if ( debuglev > 1 ) cout <<" with device: " <<sbuf.st_dev <<endl;

	 if ( sbuf.st_dev == filedev ) {

#if 0
//
// If this is automounted, try something to get the real mount added to
//    the table.
//
	    if ( strcasecmp(ment.mnt_fstype, "autofs") == 0 ||
		 strcasecmp(ment.mnt_fstype, "ignore") == 0 ) {

//
// Read an entry from the directory
//
	       if ( debuglev > 1 ) cout <<"   tweaking automounter" <<endl;
	       DIR	*dirp = opendir(ment.mnt_mountp);
	       if ( dirp ) {
		  struct dirent *dent = readdir(dirp);
		  closedir(dirp);

//
// Stat the file again to see if the device number changed
//
		  if ( stat(file, &sbuf) == 0 ) {
		     fileSize = sbuf.st_size;
		     if ( debuglev > 1 && sbuf.st_dev != filedev )
			cout <<"Device number changed to " <<filedev <<endl;
		     filedev  = sbuf.st_dev;
		  }
	       }

	    } // End if this is an automount

	    else
#endif
	       fent = &ment;

	 } // End if device number matches

      } // End if mount point stat'd ok

      else {

	 alarm(0);
	 if ( debuglev > 1 ) cout <<endl;

	 if ( errno == EINTR )
	    cerr <<ment.mnt_mountp <<" not responding" <<endl;

	 else if ( debuglev > 1 )
	    perror("Could not stat");
      }

   } // End for each mount table entry

   if ( fent ) fsname = fent->mnt_special;

#elif (defined OSF1 || defined BSDI)

   fsname = osf1_match(filedev);

#else

   struct mntent	*ment;
   struct mntent	*fent = NULL;
   while ( !fent && (ment=getmntent(fp)) != NULL ) {

//
// Skip automount entries
//
      if ( strcasecmp(ment->mnt_type, "autofs") == 0 ||
	   strcasecmp(ment->mnt_type, "ignore") == 0 )
	 continue;

      if ( debuglev > 1 ) cout <<"Checking filesystem " <<ment->mnt_fsname
			       <<" mounted on " <<ment->mnt_dir <<flush;

      alarm(5); // Set an alarm so that the stat call won't hang

//
// Get the device number of the mount point of this file system
//
      if ( stat(ment->mnt_dir, &sbuf) == 0 ) {

	 alarm(0);
	 if ( debuglev > 1 ) cout <<" with device: " <<sbuf.st_dev <<endl;

	 if ( sbuf.st_dev == filedev ) {

#if 0
//
// If this is automounted, try something to get the real mount added to
//    the table.
//
	    if ( strcasecmp(ment->mnt_type, "autofs") == 0 ||
		 strcasecmp(ment->mnt_type, "ignore") == 0 ) {

//
// Read an entry from the directory
//
	       if ( debuglev > 1 ) cout <<"   tweaking automounter" <<endl;
	       DIR	*dirp = opendir(ment->mnt_dir);
	       if ( dirp ) {

		  struct dirent *dent = readdir(dirp);
		  closedir(dirp);

//
// Stat the file again to see if the device number changed
//
		  if ( stat(file, &sbuf) == 0 ) {
		     fileSize = sbuf.st_size;
		     if ( debuglev > 1 && sbuf.st_dev != filedev )
			cout <<"Device number changed to " <<filedev <<endl;
		     filedev  = sbuf.st_dev;
		  }
	       }

	    } // End if this is an automount

	    else
#endif
	       fent = ment;

	 } // End if device matches

      } // End if file stat'd ok

      else {

	 alarm(0);
	 if ( debuglev > 1 ) cout <<endl;

	 if ( errno == EINTR )
	    cerr <<ment->mnt_dir <<" not responding" <<endl;

	 else if ( debuglev > 1 )
	    perror("Could not stat");
      }

   } // End for each mount entry

   if ( fent ) fsname = fent->mnt_fsname;

#endif	// Not SOLARIS or SVR4 or MIPS

   RemoveSignalCallback(SIGALRM, (CallbackFn*)HandleAlarm, NULL);

#if !(defined OSF1 || defined BSDI)
   fclose(fp);
#endif

   if ( fsname.size() == 0 ) {
      status = LIC_NO_MOUNT;
      msg = "I could not find a mount entry for the license file: " + file;
      msg += ".\n \n";
      msg += ishApp->supportMsg;
      return;
   }

//
// Look for host name.  First look for "server:filesystem" format
//
   host = fsname;
   char		*cs;
   if ( (cs=strchr((char*)host, ':')) != NULL ) {
      int	pos = cs - (char*)host;
      host.Clear(pos);
      if ( debuglev > 1 && host.size() > 0 )
	 cout <<"Host name is \"" <<host <<"\" from mount table" <<endl;
   }

#if (defined OSF1 || defined BSDI)
//
// Under OSF/1 we could also have "filesystem@server" format
//
   else if ( (cs=strchr((char*)host, '@')) != NULL ) {
      host = cs+1;
      if ( debuglev > 1 && host.size() > 0 )
	 cout <<"Host name is \"" <<host
	      <<"\" from mount table with fs@host format" <<endl;
   }
#endif

   else {
      char	buf[256];
      if ( gethostname(buf, 255) == 0 ) {
	 host = buf;
	 if ( debuglev > 1 )
	    cout <<"Host name is \"" <<host <<"\" from gethostname()" <<endl;
      }
      else {
	 host = "localhost";
	 if ( debuglev > 1 )
	    cout <<"Host name is \"localhost\" by default" <<endl;
      }
   }

#endif	// Not AIX

   if ( fileSize == 0 ) {
      status = LIC_NO_FILE;
      msg = "The license file: \"" + file;
      msg += "\" does not exist.\n \n";
      msg += ishApp->supportMsg;
   }

   return;

} // End GetHostName

/*------------------------------------------------------------------------
 * Function to read the license file
 */

void
LicInfoC::ReadFile()
{
   if ( !needsLicense ) return;

   struct stat	sbuf;
   if ( stat(file, &sbuf) != 0 ) {
      if ( errno == ENOENT ) {
	 status = LIC_NO_FILE;
	 msg = "The license file: \"" + file;
	 msg += "\" does not exist.\n \n";
	 msg += ishApp->supportMsg;
      }
      else {
	 status = LIC_SYSERR;
	 msg = "I could not stat the license file: " + file;
	 msg += ".\n" + SystemErrorMessage(errno) + "\n \n";
	 msg += ishApp->supportMsg;
      }
      return;
   }

   else if ( sbuf.st_size == 0 ) {
      status = LIC_NO_FILE;
      msg = "The license file: \"" + file;
      msg += "\" does not exist.\n \n";
      msg += ishApp->supportMsg;
      return;
   }

//
// Open the license file
//
   FILE	*fp = NULL;
   if ( readOnly ) fp = fopen(file, "r");
   else		   fp = fopen(file, "r+");
   if ( !fp ) {
      if ( errno == ENOENT ) {
	 status = LIC_NO_FILE;
	 msg = "The license file: \"" + file;
	 msg += "\" does not exist.\n \n";
	 msg += ishApp->supportMsg;
      }
      else {
	 status = LIC_SYSERR;
	 msg = "I could not open the license file: " + file;
	 msg += ".\n" + SystemErrorMessage(errno) + "\n \n";
	 msg += ishApp->supportMsg;
      }
      return;
   }

//
// Read checksum
//
   StringC	line;
   if ( line.GetLine(fp) == EOF || line.size() == 0 ) {
      status = LIC_EOF;
      msg = "I could not read the license file: " + file;
      msg += ".\nPremature end-of-file.\n \n";
      msg += ishApp->supportMsg;
      return;
   }
   line.Trim();
   key = atoi(line);

//
// Read product and version
//
   prod.Clear();
   if ( prod.GetLine(fp) == EOF || prod.size() == 0 ) {
      status = LIC_EOF;
      msg = "I could not read the license file: " + file;
      msg += ".\nPremature end-of-file.\n \n";
      msg += ishApp->supportMsg;
      return;
   }
   prod.Trim();

   ver.Clear();
   if ( ver.GetLine(fp) == EOF || ver.size() == 0 ) {
      status = LIC_EOF;
      msg = "I could not read the license file: " + file;
      msg += ".\nPremature end-of-file.\n \n";
      msg += ishApp->supportMsg;
      return;
   }
   ver.Trim();

//
// Read start time
//
   line.Clear();
   if ( line.GetLine(fp) == EOF || line.size() == 0 ) {
      status = LIC_EOF;
      msg = "I could not read the license file: " + file;
      msg += ".\nPremature end-of-file.\n \n";
      msg += ishApp->supportMsg;
      return;
   }
   line.Trim();
   startTime = atoi(line);

//
// Read end time
//
   line.Clear();
   if ( line.GetLine(fp) == EOF || line.size() == 0 ) {
      status = LIC_EOF;
      msg = "I could not read the license file: " + file;
      msg += ".\nPremature end-of-file.\n \n";
      msg += ishApp->supportMsg;
      return;
   }
   line.Trim();
   endTime = atoi(line);

//
// Read installed host address(es)
//
   addr.Clear();
   if ( addr.GetLine(fp) == EOF || addr.size() == 0 ) {
      status = LIC_EOF;
      msg = "I could not read the license file: " + file;
      msg += ".\nPremature end-of-file.\n \n";
      msg += ishApp->supportMsg;
      return;
   }
   addr.Trim();

//
// Read user count
//
   line.Clear();
   if ( line.GetLine(fp) == EOF || line.size() == 0 ) {
      status = LIC_EOF;
      msg = "I could not read the license file: " + file;
      msg += ".\nPremature end-of-file.\n \n";
      msg += ishApp->supportMsg;
      return;
   }
   line.Trim();
   userCount = atoi(line);

//
// Read user names
//
   userList.removeAll();
   int	hitLimit = 0;
   line.Clear();
   while ( !hitLimit && line.GetLine(fp) != EOF ) {

      line.Trim();
      if ( line.size() > 0 && !line.StartsWith("-----") ) {

	 userList.add(line);
	 if ( userCount > 0 && userList.size() >= userCount )
	    hitLimit = 1;
      }
      line.Clear();
   }

//
// Truncate the file if there are extra names.
//
   if ( hitLimit && !readOnly ) {

      long	curOff = ftell(fp);
      fseek(fp, 0, SEEK_END);
      long	endOff = ftell(fp);
      if ( curOff != endOff )
	 ftruncate(fileno(fp), curOff);
   }

   fclose(fp);

//
// Check the key
//
   CheckKey();

} // End ReadFile

/*------------------------------------------------------------------------
 * Function to verify the checksum
 */

void
LicInfoC::CheckKey()
{
   if ( !needsLicense ) return;

   StringC	buf(prod);
   buf += ver;
   buf += (int)startTime;
   buf += (int)endTime;
   buf += addr;
   buf += userCount;

   int	sum = checkSum((unsigned char*)(char*)buf, buf.size());

   if ( sum != key ) {
      status = LIC_BAD_SUM;
      msg = "The key in the license file \"" + file + "\"\n";
      msg += "does not appear to be valid.\n";
      msg += "Please make sure that the key has been entered correctly and\n";
      msg += "the file has not been modified except to change user names.\n \n";
      msg += ishApp->supportMsg;
   }

} // End CheckKey

/*------------------------------------------------------------------------
 * Function to verify the product and version
 */

void
LicInfoC::CheckProd(const char *pstr, const char *vstr)
{
   if ( !needsLicense ) return;

   if ( prod != pstr ) {
      status = LIC_WRONG_PROD;
      msg = "The license file: \"" + file + "\"\n";
      msg += " does not contain a license for ";
      msg += pstr;
      msg += ".\n \n";
      msg += ishApp->supportMsg;
   }

   if ( ver == vstr ) return;

//
// The version didn't match so check the major numbers
//
   StringC	verStr = ver;
   StringC	chkStr = vstr;
   char		*verMaj = strtok(verStr, ".");
   char		*chkMaj = strtok(chkStr, ".");
   int		verNum = atoi(verMaj);
   int		chkNum = atoi(chkMaj);

//
// Allow any version older than the licensed version
//
   if ( chkNum <= verNum ) return;

   status = LIC_WRONG_PROD;
   msg = "The license file: \"" + file + "\"\n";
   msg += " does not contain a license for version ";
   msg += vstr;
   msg += " of ";
   msg += pstr;
   msg += ".\n \n";
   msg += ishApp->supportMsg;

} // End CheckProd

/*------------------------------------------------------------------------
 * Function to verify the date
 */

void
LicInfoC::CheckDate(time_t checkTime)
{
   if ( !needsLicense ) return;

#ifdef RELAX_LICENSE
   //
   // If this is a permanent license, relax the checking criteria. Set
   // flag indicating that a license isn't needed. This prevents checks
   // from failing if IP address or host ID doesn't match. We don't care
   // any more for permanent licenses.
   //
   if ( startTime == 0 && endTime == 0 ) {
      needsLicense = False;
      return;
   }
#endif RELAX_LICENSE

   if ( startTime > 0 && checkTime < startTime ) {
      status = LIC_BAD_DATE;
      msg = "The license for " + prod + " is only valid after ";
      msg += (char*)ctime(&startTime);
      msg += ".\n \n";
      msg += ishApp->supportMsg;
   }

   else if ( endTime > 0 ) {

      if ( checkTime > endTime ) {
	 status = LIC_BAD_DATE;
	 msg = "The license for " + prod + " has expired.\n \n";
	 msg += ishApp->supportMsg;
      }

      else {

#define DAYLENGTH	(60*60*24)

	 long	secLeft  = endTime - checkTime;
	 long	daysLeft = (secLeft/DAYLENGTH);
	 if ( (daysLeft*DAYLENGTH) < secLeft ) daysLeft++;
	 if ( daysLeft <= 30 ) {
	    status = LIC_WARNING;
	    msg = "The license for " + prod + " will expire in ";
	    msg += (int)daysLeft;
	    msg += " days.";
	 }

      } // End if license hasn't yet expired

   } // End if there is an expiration date

} // End CheckDate

/*------------------------------------------------------------------------
 * Function to see if this host address matches one of the ones in the
 *    license file
 */

void
LicInfoC::CheckHost(const char *hostname)
{
   if ( !needsLicense ) return;

#if defined SVR4 || defined LINUX || defined SUN_OS || defined SOLARIS || defined BSDI || defined SOLARISx86
   if ( userCount < 0 ) {	// It's node locked

# if defined LINUX || defined BSDI || defined SOLARISx86
//
// Node locked licenses on x86 machines don't need IP addresses.  We checksum
//    the BIOS instead.
//
#define MEMSIZE	0xFFFF
#define BUFSIZE	(MEMSIZE*2)

      char	*buffer = new char[BUFSIZE+1];
#if 1
//
// node lock checking is disabled on x86 machines. there's just no good way
// to do it, that doesn't change over time (especially PCI bus machines).
// so, license checking is relaxed. node locked licenses on x86 don't check
// any node id.
      memset(buffer, 0, BUFSIZE);
      strcpy(buffer, "DEADBEEF");
#else
      FILE	*fp     = fopen("/dev/mem", "r");
      if ( fp ) {

	 fseek(fp, 0xC0000L, SEEK_SET);
	 fread(buffer, 1, MEMSIZE, fp);
	 fseek(fp, 0xF0000L, SEEK_SET);
	 fread(buffer+MEMSIZE, 1, MEMSIZE, fp);
	 fclose(fp);

	 buffer[BUFSIZE] = 0;
      }

      else {
	 status = LIC_SYSERR;
	 msg = "I could not read /dev/mem to compute the license key.\n";
	 msg += SystemErrorMessage(errno);
	 msg += "\n \n";
	 msg += ishApp->supportMsg;
	 delete buffer;
	 return;
      }
#endif
      int	sum       = checkSum((u_char*)buffer, BUFSIZE);
      int	storedSum = atoi(addr);

      if ( sum != storedSum ) {
         status = LIC_WRONG_HOST;
         msg = "The key for the host on which the license file\n\"";
         msg += file;
         msg += "\" is installed (";
         msg += host;
         msg += ": ";
         msg += sum;
         msg += ")\ndoes not match the key specified in the license file (";
         msg += storedSum;
         msg += ").\nPlease make sure your license file is installed on the correct host.\n \n";
         msg += ishApp->supportMsg;
         delete buffer;
         return;
      }
      delete buffer;
      status = LIC_OK;

#elif defined SUN_OS

//
// Node locked licenses on SunOS and Solaris machines can use the host id
//
      long	id       = gethostid();
      long	storedId = atol(addr);

      if ( id != storedId ) {
	 status = LIC_WRONG_HOST;
	 msg = "The id for the host on which the license file\n\"";
	 msg += file;
	 msg += "\" is installed (";
	 msg += host;
	 msg += ": ";
	 msg += (int)id;
	 msg += ")\ndoes not match the id specified in the license file (";
	 msg += (int)storedId;
	 msg += ").\nPlease make sure your license file is installed on the correct host.\n \n";
	 msg += ishApp->supportMsg;
	 return;
      }

#else // SOLARIS

      StringC	storedAddr;
      char	*buffer = new char[256];
      sysinfo(SI_HW_PROVIDER, buffer, 256);
      storedAddr += buffer;
      sysinfo(SI_HW_SERIAL,   buffer, 256);
      storedAddr += buffer;

      if ( addr != storedAddr ) {
	 status = LIC_WRONG_HOST;
	 msg = "The id for the host on which the license file\n\"";
	 msg += file;
	 msg += "\" is installed (";
	 msg += host;
	 msg += ": ";
	 msg += addr;
	 msg += ")\ndoes not match the id specified in the license file (";
	 msg += storedAddr;
	 msg += ").\nPlease make sure your license file is installed on the correct host.\n \n";
	 msg += ishApp->supportMsg;
	 return;
      }
#endif // SOLARIS

   } // End if node locked license

   else {
#endif

//
// Get ip address of host
//
#if defined SVR4 || defined MIPS
   struct hostent	*hent = gethostbyname((char*)hostname);
#else
   struct hostent	*hent = gethostbyname((const char*)hostname);
#endif
   if ( !hent ) {
      status = LIC_BAD_HOST;
      msg = "I could not find a host entry for: ";
      msg += hostname;
      msg += ".\n \n";
      msg += ishApp->supportMsg;
      return;
   }

//
// See if address matches one stored in file
//
   char		*hp = hent->h_addr_list[0];
   int		i = 1;
   StringC	checkAddr;
   int		addrOk = 0;
   while ( hp && !addrOk ) {

      checkAddr.Clear();
      int j=0; for (j=0; j<hent->h_length; j++) {
	 if ( j>0 ) checkAddr += ".";
	 unsigned char	c = hp[j];
	 checkAddr += (int)c;
      }

      if ( debuglev > 1 )
	 cout <<"Address is: " <<checkAddr <<" from host table" <<endl;

//
// Loop through valid addresses
//
      u_int	offset = 0;
      CharC	entry = addr.NextWord(offset, ", \t");
      while ( !addrOk && entry.Length() > 0 ) {
	 addrOk = (checkAddr == entry);
	 offset = entry.Addr() - (char*)addr + entry.Length();
	 entry = addr.NextWord(offset, ", \t");
      }

      hp = hent->h_addr_list[i++];

   } // End for each host address

   if ( !addrOk ) {
      status = LIC_WRONG_HOST;
      msg = "The IP address of the host on which the license file\n";
      msg += "\"" + file + "\"";
      msg += " is installed (" + host + ": " + checkAddr + ")\n";
      msg += "does not match the IP address specified in the license file ";
      msg += "(" + addr + ").\n";
      msg += "Please make sure your license file is installed on the correct host.\n \n";
      msg += ishApp->supportMsg;
   }

#if defined SVR4 || defined LINUX || defined SUN_OS || defined SOLARIS || defined SOLARISx86 || defined BSDI
   } // End if not node locked
#endif

} // End CheckHost

/*------------------------------------------------------------------------
 * Function to verify the current user
 */

int
LicInfoC::UserOk()
{
   if ( !needsLicense ) return 1;

//
// Reread the license file to see if it's still valid
//
   ReadFile();
   if ( status != LIC_OK ) return 0;

   if ( userCount < 0 ) {	// Node locked license
      char	host[256];
      if ( gethostname(host, 255) != 0 ) strcpy(host, "localhost");
      CheckHost(host);
      if ( status != LIC_OK ) return 0;
   }

//
// User name must appear if it's not an unlimited license (userCount==0)
//
   else if ( userCount > 0 && !userList.includes(user) ) {

      status = LIC_WRONG_USER;
      msg = "The user account \"" + user + "\" is not licensed to run " + prod;
      msg += ".\nPlease ask your system administrator to add this account\n";
      msg += "to the license file: " + file + ".\n \n";
      msg += ishApp->supportMsg;
      return 0;
   }

   return 1;

} // End UserOk

/*------------------------------------------------------------------------
 * Function to determine whether this is a demo license
 */

int
LicInfoC::IsDemo()
{
   return (needsLicense && (status != LIC_OK || endTime > 0));
}
