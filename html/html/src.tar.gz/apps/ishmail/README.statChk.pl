The statChk.pl program is provided as a simple tool for checking if
mail folders have changed. It is meant to be run on a periodic basis,
for example, for a cron job.

It is useful if you are using the "Automatic Filing" feature. Incoming
mail can be copied to various folders, and deleted automatically from
the In-Box folder, and you may not be aware that it has happened.

The statChk.pl program lets you scan periodically for folders which have
changed.
