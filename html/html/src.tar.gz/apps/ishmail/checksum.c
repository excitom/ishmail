/*
 * $Id: checksum.c,v 1.1 1998/06/24 01:32:30 lang Exp $
 *
 * Copyright (c) 1994 HAL Computer Systems International, Ltd.
 * 
 *          HAL COMPUTER SYSTEMS INTERNATIONAL, LTD.
 *                  1315 Dell Avenue
 *                  Campbell, CA  95008
 *
 * Author: Greg Hilton
 * Contributors: Tom Lang, Frank Bieser, and others
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * http://www.gnu.org/copyleft/gpl.html
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#define	SEED	0x2113

#ifdef AIX
#ifndef _ALL_SOURCE
#define _ALL_SOURCE
#endif
#endif

#include <sys/types.h>
#include <netinet/in.h>

#ifdef BSDI
#include <sys/param.h>
#endif
#ifdef OSF1
#include <nfs/pathconf.h>
#endif
#if (defined OSF1 || defined BSDI)
#include <sys/mount.h>
#include <sys/stat.h>
#include <stdio.h>
#include <errno.h>
#endif

unsigned short  sumArray[] = { 0x2146, 0x311a, 0x75b1, 0x2a75, 0x4f64,
			       0x7453, 0x13fc, 0x33a4, 0x4e05, 0x6dad,
			       0x0810, 0x2271, 0x3cd3, 0x6708, 0x016b };

extern int	debuglev;

int
checkSum(unsigned char *buf, int byteCount)
{
   unsigned int		sum = SEED;
   unsigned char	*cp;
   int			index = 0;
   unsigned short	val;
   unsigned char	byte1, byte2;

   cp = buf;
   while( byteCount >= 2 ) {

      byte1 = *cp++;
      byte2 = *cp++;
      byteCount -= 2;

      val = (byte1<<sizeof(char)) + byte2;
      sum += (val ^ sumArray[index%sizeof(sumArray)]);
   }

/*
 * odd number of bytes in the array
 */
   if ( byteCount > 0 ) {

      byte1 = *cp;
      byte2 = 0;

      val = (byte1<<sizeof(char)) + byte2;
      sum += (val ^ sumArray[index%sizeof(sumArray)]);
   }

   return sum;
}

#if (defined OSF1 || defined BSDI)
char	*osf1_match(dev_t filedev)
{
   static char	fsname[MAXPATHLEN];

   struct statfs *ment;
   struct statfs *fent = NULL;
   struct stat	sbuf;
   int		mntsize, bufsize, flags;
   int		count;
   int		i;

   mntsize = bufsize = 0;
   ment    = NULL;
   flags   = MNT_NOWAIT;

   count = getmntinfo(&ment, flags);

   for (i=0; !fent && i<count; i++) {

      if ( debuglev > 1 ) {
	 printf("Checking filesystem %s of type %d mounted on %s",
			ment->f_mntfromname, ment->f_type, ment->f_mntonname);
	 fflush(stdout);
      }

      alarm(5); /* Set an alarm so that the stat call won't hang */

      if ( stat(ment->f_mntonname, &sbuf) == 0 ) {

	 alarm(0);
         if ( debuglev > 1 ) printf(" with device: %d\n", sbuf.st_dev);

	 if ( sbuf.st_dev == filedev ) fent = ment;
      }

      else {

	 alarm(0);
	 if ( debuglev > 1 ) printf("\n");

	 if ( errno == EINTR )
	    printf("%s not responding\n", ment->f_mntonname);

	 else if ( debuglev > 1 )
	    perror("Could not stat");
      }

      ment++;

   } /* End for each mount entry */

   if ( fent ) strcpy(fsname, fent->f_mntfromname);
   else        strcpy(fsname, "");

   return fsname;
}
#endif
