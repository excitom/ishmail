/*
 *  $Id: ImapMisc.C,v 1.1 1998/06/24 01:32:30 lang Exp $
 *  
 *  Copyright (c) 1994 HAL Computer Systems International, Ltd.
 * 
 *          HAL COMPUTER SYSTEMS INTERNATIONAL, LTD.
 *                  1315 Dell Avenue
 *                  Campbell, CA  95008
 *
 * Author: Greg Hilton
 * Contributors: Tom Lang, Frank Bieser, and others
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * http://www.gnu.org/copyleft/gpl.html
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
#include "IshAppC.h"
#include "AppPrefC.h"
#include "FolderPrefC.h"

#include <hgl/CharC.h>
#include <hgl/RegexC.h>

RegexC	*imapPat = NULL;
RegexC	*imapPat2 = NULL;

#define	SERV_PART	1
#define	PATH_PART	2

/*---------------------------------------------------------------
 *  Function to build the regular expression
 */

void
BuildImapPat()
{
   if ( !imapPat ) {
      imapPat = new RegexC("{\\([^{}]+\\)}\\(.*\\)");
      imapPat2 = new RegexC("\\(INBOX.*\\)");
   }
}

/*---------------------------------------------------------------
 *  Function to determine if a name is an IMAP name: "{server}path"
 */

Boolean
IsImapName(CharC name)
{
//
// If we're not using IMAP folders, return False;
//
   if ( !ishApp->appPrefs->usingImap )
      return False;

//
// If we're not using local folders, return True
//
   if ( !ishApp->folderPrefs->UsingLocal() )
      return True;

//
// If we're using both IMAP and local folders, look for the pattern
//
   if (imapPat->match(name)) return True;

   return imapPat2->match(name);

} // End IsImap

/*---------------------------------------------------------------
 *  Function to extract the server part from an IMAP name: "{server}path"
 */

CharC
ImapServerPart(CharC name)
{
   if ( imapPat->match(name) )
      return name((*imapPat)[SERV_PART]);
   else
      return ishApp->appPrefs->imapServer;
}

/*---------------------------------------------------------------
 *  Function to extract the path part from an IMAP name: "{server}path"
 */

CharC
ImapPathPart(CharC name)
{
   if ( imapPat->match(name) )
      return name((*imapPat)[PATH_PART]);
   else
      return name;
}

