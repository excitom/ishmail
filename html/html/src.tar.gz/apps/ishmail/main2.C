/*
 * $Id: main2.C,v 1.1 1998/06/24 01:32:30 lang Exp $
 *
 * Copyright (c) 1993 HAL Computer Systems International, Ltd.
 * 
 *          HAL COMPUTER SYSTEMS INTERNATIONAL, LTD.
 *                  1315 Dell Avenue
 *                  Campbell, CA  95008
 *
 * Author: Greg Hilton
 * Contributors: Tom Lang, Frank Bieser, and others
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * http://www.gnu.org/copyleft/gpl.html
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#include "FileMsgC.h"
#include "AddressC.h"
#include "HeaderValC.h"
#include "MhFolderC.h"
#include "MmdfFolderC.h"
#include "UnixFolderC.h"
#include "ImapFolderC.h"
#include "MsgPartC.h"

#ifndef NO_MOTIF
#include <hgl/HalAppC.h>
#else
int	debug1 = 0, debug2 = 0, debuglev = 0;
#endif

#include <new.h>

//
// Global objects
//
extern int debug1, debug2;

/*---------------------------------------------------------------
 *  New handler
 */

void
new_handler()
{
   StringC errmsg("The application has run out of memory\nand cannot continue");
#ifndef NO_MOTIF
   halApp->PopupMessage(errmsg);
#else
   cerr <<errmsg <<endl;
#endif
   exit(1);
}

/*---------------------------------------------------------------
 *  Function to print summary line for a message
 */

void
PrintSummary(MsgC *msg)
{
   StringC	val;
   cout <<dec(msg->Number(),5);

   msg->GetStatusString(val);
   val.Clear(4);
   cout <<str(val,5);

   msg->GetFromName(val);
   val.Clear(16);
   cout <<str(val,17);

   msg->GetSubjectText(val);
   val.Clear(37);
   cout <<str(val,38);

   cout <<" (" <<dec(msg->BodyBytes(),6) <<" bytes)" <<endl;
}

/*---------------------------------------------------------------
 *  Main program
 */

#ifdef OSF1
void
#else
int
#endif
main(int argc, char **argv)
{
   CharC	arg;
   StringC	folderName;

#ifndef NO_MOTIF
//
// Create application object.  This initializes X-Windows.
//
   HalAppC	*app = new HalAppC(&argc, argv, "ishmail", "Ishmail");

//
// Open messages
//
   for (int i=0; i<halApp->argCount; i++) {

      arg = halApp->argVec[i];
#else
   for (int i=1; i<argc; i++) {

      arg = argv[i];
#endif

      if ( arg.Equals("-D") ) {
	 i++;
	 debuglev = atoi(argv[i]);
	 if ( debuglev > 0 ) debug1 = 1;
	 if ( debuglev > 1 ) debug2 = 1;
      }

      else {
	 folderName = arg;
      }
   }

//
// Loop on user input
//
   char		command[256];
   const int	buflen = 255;
   Boolean	done = False;
   CharC	cmd;
   FolderC	*curFolder = NULL;
   MsgC		*curMsg    = NULL;

   cout <<"What? " <<flush;
   cin.getline(command, buflen);
   while ( !cin.eof() && !done ) {

      cmd = command;

      if ( cmd.Equals("quit", IGNORE_CASE) ||
	   cmd.Equals('q',    IGNORE_CASE) ||
	   cmd.Equals("exit", IGNORE_CASE) ||
	   cmd.Equals('x',    IGNORE_CASE) ) {
	 delete curFolder;
	 done = True;
      }

      else if ( cmd.StartsWith("mh ",   IGNORE_CASE) ||
		cmd.StartsWith("mmdf ", IGNORE_CASE) ||
		cmd.StartsWith("unix ", IGNORE_CASE) ||
		cmd.StartsWith("imap ", IGNORE_CASE) ) {

	 if ( curFolder ) delete curFolder;

	 if ( cmd.StartsWith("mh ", IGNORE_CASE) ) {
	    cmd.CutBeg(3);
	    cmd.Trim();
	    if ( cmd.Length() > 0 )
	       curFolder = new MhFolderC(cmd.Addr());
	    else
	       curFolder = new MhFolderC(folderName);
	 }
	 else if ( cmd.StartsWith("mmdf ", IGNORE_CASE) ) {
	    cmd.CutBeg(5);
	    cmd.Trim();
	    if ( cmd.Length() > 0 )
	       curFolder = new MmdfFolderC(cmd.Addr());
	    else
	       curFolder = new MmdfFolderC(folderName);
	 }
	 else if ( cmd.StartsWith("imap ", IGNORE_CASE) ) {
	    cmd.CutBeg(5);
	    cmd.Trim();
	    if ( cmd.Length() > 0 )
	       curFolder = new ImapFolderC(cmd.Addr());
	    else
	       curFolder = new ImapFolderC(folderName);
	 }
	 else {	// Unix
	    cmd.CutBeg(5);
	    cmd.Trim();
	    if ( cmd.Length() > 0 )
	       curFolder = new UnixFolderC(cmd.Addr());
	    else
	       curFolder = new UnixFolderC(folderName);
	 }

	 curFolder->Scan();
	 int	msgCount = curFolder->MsgCount();
	 int	newCount = curFolder->NewMsgCount();
	 cout <<msgCount;
	 if ( msgCount ==1 ) cout <<" message";
	 else		     cout <<" messages";
	 if ( newCount > 0 ) cout <<" (" <<newCount <<" new)";
	 cout <<endl;
      }

      else if ( cmd.Equals("check", IGNORE_CASE) ) {

	 if ( !curFolder ) cout <<"No open folder" <<endl;
	 else {

	    int	oldCount = curFolder->MsgCount();
	    if ( curFolder->NewMail() ) {

	       int	msgCount = curFolder->MsgCount();
	       for (int i=oldCount; i<msgCount; i++) {
		  MsgC		*msg  = curFolder->MsgWithIndex(i);
		  PrintSummary(msg);
	       }
	    }
	    else
	       cout <<"No new mail." <<endl;
	 }
      }

      else if ( cmd.Equals("list", IGNORE_CASE) ) {

	 if ( !curFolder ) cout <<"No open folder" <<endl;
	 else {

	    u_int	count = curFolder->MsgCount();
	    for (int i=0; i<count; i++) {
	       MsgC		*msg  = curFolder->MsgWithIndex(i);
	       PrintSummary(msg);
	    }
	 }
      }

      else if ( cmd.Equals("save", IGNORE_CASE) ) {

	 if ( !curFolder ) cout <<"No open folder" <<endl;
	 else		   curFolder->Save();
      }

      else if ( cmd.StartsWith("msg ", IGNORE_CASE) ) {

	 if ( !curFolder ) cout <<"No open folder" <<endl;
	 else {

	    cmd.CutBeg(4);
	    cmd.Trim();
	    int		num  = atoi((char*)cmd.Addr());
	    curMsg = curFolder->MsgWithNumber(num);
	    if ( !curMsg ) cout <<"No such message" <<endl;
	    else {

	       StringC	val;

	       AddressC	*addr = curMsg->From();
	       if ( addr ) cout <<"   From: " <<addr->full <<endl;

	       addr = curMsg->To();
	       if ( addr ) cout <<"     To: " <<addr->full <<endl;

	       addr = curMsg->Cc();
	       if ( addr ) cout <<"     Cc: " <<addr->full <<endl;

	       val.Clear();
	       curMsg->GetSubjectText(val);
	       cout <<"Subject: " <<val <<endl;

	       HeaderValC	*date = curMsg->Date();   
	       if ( date ) {
		  val.Clear();
		  date->GetValueText(val);
		  cout <<"   Date: " <<val <<endl;
	       }

	       MsgPartC	*body = curMsg->Body();
	       cout <<*body <<endl;
	    }
	 }
      }

      else if ( cmd.StartsWith("del ", IGNORE_CASE) ) {

	 if ( !curFolder ) cout <<"No open folder" <<endl;
	 else {

	    cmd.CutBeg(4);
	    cmd.Trim();
	    int		num  = atoi((char*)cmd.Addr());
	    MsgC	*msg = curFolder->MsgWithNumber(num);
	    if ( !msg ) cout <<"No such message" <<endl;
	    else	curFolder->DeleteMsg(msg);
	 }
      }

      else if ( cmd.StartsWith("part ", IGNORE_CASE) ) {

	 if ( !curMsg ) cout <<"No current message" <<endl;
	 else {
	    cmd.CutBeg(5);
	    cmd.Trim();
	    MsgPartC	*part = curMsg->Part(cmd);
	    if ( !part ) cout <<"No such part" <<endl;
	    else {
	       StringC	text(curMsg->PartBodyText(part), (Boolean)True/*own*/);
	       cout <<text <<endl;
	    }
	 }
      }

      else if ( cmd.Length() > 0 ) {
	 cout <<"Unrecognized command: " <<command <<endl;
      }

      if ( !done ) {
	 cout <<"What? " <<flush;
	 cin.getline(command, buflen);
      }

   } // End input loop
   cout <<endl;

#ifndef NO_MOTIF
   delete halApp;
#endif
   exit(0);

} // End main
