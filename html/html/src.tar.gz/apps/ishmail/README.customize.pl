The customize.pl script is provided to allow you to change identities
easily when sending mail. For example, you handle e-mail on behalf of
different clients. It's all delivered to the same mail folder, but when
you respond you want your mail to appear as if sent from one client's
domain or another. Another example, you handle personal e-mail and business
e-mail from the same mail tool. You want your responses to have either
your "work" personality or your "home" personality.

Ishmail sends mail by building a message in two temporary files, one for
the headers and one for the message body. These files are then given to
the mail transport system for delivery. Here is the default command:

  /usr/lib/sendmail -oi -oem 'recipient_address' < /tmp/headers < /tmp/body

You can modify this command in the Mail Preferences window. There is a
field called "Mail delivery command" and it's default value is 
"/usr/lib/sendmail". (Note that the '-oi -oem' and the rest of the command
are not specified in this field)

You can replace the command with:

  /usr/local/ishmail/bin/customize.pl

(Note that the path name should correspond to the directory where you
installed Ishmail)

The customize.pl file will look for a message header such as this:

  X-Identity: xxxx

If none is found, the headers and message are passed through to 
/usr/lib/sendmail unchanged and the program has no effect on the message.

If a header like this is found, it will be removed (since it's not needed
in the oitgoing message) and the message will be further modified as
follows:

If a directory $HOME/xxxx exists (note that 'xxxx' in this case is
the parameter following 'X-Identity:') and it contains a file '.from', the
contents of the file are passed to sendmail with a '-f' flag. This causes
sendmail to modified the "From" information in the message to match the
parameter value. The '.from' file should contain the e-mail address you
want to appear in the "From" information.

If a file $HOME/xxxx/.headers exists, its contents are assumed to be extra
headers you want to add to the message, such as:

  From:
  Reply-To:

If the file $HOME/xxxx/.signature exists, its contents are used as a 
signature at the end of the message body.

You can have multiple directories corresponding to multiple "personalities"
you want to use.

NOTE: YOU ARE RESPONSIBLE FOR MAKING SURE VALID INFORMATION IS IN THESE
FILES. 

You add the "X-Identity:" header to an outgoing message by adding this
information to the "Additional Mail Headers" field in the Mail Preferences
window.

In the Composition Window Preferences, turn on the "Other Headers" field,
so that you can add the appropriate parameter to the X-Identity: header
for each outgoing message.
