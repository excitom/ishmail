/*
 *  $Id: ImapServerC.C,v 1.3 1998/06/24 02:35:19 lang Exp $
 *  
 *  Copyright (c) 1994 HAL Computer Systems International, Ltd.
 * 
 *          HAL COMPUTER SYSTEMS INTERNATIONAL, LTD.
 *                  1315 Dell Avenue
 *                  Campbell, CA  95008
 *
 * Author: Greg Hilton
 * Contributors: Tom Lang, Frank Bieser, and others
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * http://www.gnu.org/copyleft/gpl.html
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
#include "IshAppC.h"
#include "MainWinC.h"
#include "FolderPrefC.h"
#include "ImapServerC.h"
#include "ImapFolderC.h"
#include "MsgStatus.h"
#include "LoginWinC.h"
#include "Query.h"

#include <hgl/HalAppC.h>
#include <hgl/StringC.h>
#include <hgl/SysErr.h>
#include <hgl/PtrListC.h>
#include <hgl/StringListC.h>
#include <hgl/CharC.h>
#include <hgl/WArgList.h>
#include <hgl/WXmString.h>
#include <hgl/IntListC.h>

#include <Xm/MessageB.h>
#include <Xm/Protocols.h>
#include <Xm/AtomMgr.h>

#include <X11/Intrinsic.h>

#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <sys/time.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>

#ifdef AIX
#include <sys/select.h>
#include <strings.h>
#endif

#if defined OSF1 || MIPS
extern "C" {
#endif
#include <netdb.h>
#if defined OSF1 || MIPS
}
#endif

#define MAXLINE	255

extern int	debuglev;
extern Boolean	socketIO;	// flag for SIGPIPE handler

static PtrListC	*serverList = NULL;

/*------------------------------------------------------------------------
 * Constructor to open a connection to an imap server
 */

ImapServerC::ImapServerC(const char *hostname)
{
   name      = hostname;	// save hostname in server object

//
// Connect to the server
//
   connected = Connect();
   if (!connected) return;

//
// Determine capabilities of the server
//
   GetServerType();

//
// Add this server to the list
//
   if ( !serverList ) serverList = new PtrListC;

   void	*tmp = (void*)this;
   serverList->add(tmp);

} // End constructor

/*------------------------------------------------------------------------
 * Destructor
 */

ImapServerC::~ImapServerC()
{
   if ( !connected ) return;

   StringListC	output;
   Logout(output);

//
// Remove this server from the list
//
   if ( serverList ) {
      void	*tmp = (void*)this;
      serverList->remove(tmp);
   }

} // End destructor

/*------------------------------------------------------------------------
 * Method to connect a socket to an IMAP server
 * - this is called from the constructor, and also to re-connect if
 *   the connection drops for some reason.
 */
Boolean
ImapServerC::Connect()
{

   StringC	errmsg;

   sock      = 0;
   connected = False;

//
// Get host name
//
#ifdef SVR4
   host = gethostbyname((char*)name);
#else
   host = gethostbyname(name);
#endif
   if ( !host ) {
      int	err = errno;
      errmsg = "Could not find entry for host: ";
      errmsg += name;
      errmsg += ".\n" + SystemErrorMessage(err);
      halApp->PopupMessage(errmsg);
      return False;
   }

//
// Create socket
//
   sock = socket(AF_INET, SOCK_STREAM, 0);
   if ( sock <= 0 ) {
      int	err = errno;
      errmsg = "Could not create socket.\n";
      errmsg += SystemErrorMessage(err);
      halApp->PopupMessage(errmsg);
      return False;
   }

//
// Open connection
//
   struct sockaddr_in	sin;
   long			port = IMAP_SERVER_PORT;

   memset((char*)&sin, 0, sizeof(sin));
   sin.sin_family = AF_INET;
   sin.sin_port   = (u_short)htons(port);
   memcpy((char*)&sin.sin_addr, host->h_addr, host->h_length);
   if ( connect(sock, (struct sockaddr*)&sin, sizeof(sin)) < 0 ) {
      int	err = errno;
      errmsg = "Could not connect to host: ";
      errmsg += name;
      errmsg += ".\n" + SystemErrorMessage(err);
      halApp->PopupMessage(errmsg);
      close(sock);
      return False;
   }

//
// Wait for the server's response to see if the user must log in
//
   StringC	line;
   if ( !GetLine(line) ) {
      close(sock);
      return False;
   }

   if ( line.StartsWith("ld.so:") ) { // Ignore this one
      if ( !GetLine(line) ) {
	 close(sock);
	 return False;
      }
   }

   if ( line.StartsWith("* OK ") ) { // Need to log in

      Boolean		done = False;
      while ( !done ) {

//
// Get user id and password
//
	 if ( !GetLogin(name, user, pass) ) {
	    // User cancelled
	    close(sock);
	    return False;
	 }

//
// Send login command
//
	 StringListC	output;
	 if ( !Login(user, pass, output) ) {
	    // Command failed
	    close(sock);
	    return False;
	 }

//
// Check responses
//
	 u_int	count = output.size();
	 for (int i=0; i<count; i++) {

	    CharC	resp = *output[i];
	    if ( resp.StartsWith("NO") ) {

	       InvalidateLogin(name);

	       resp.CutBeg(2);
	       resp.Trim();
	       errmsg = "The IMAP server on host ";
	       errmsg += name;
	       errmsg += "\ndenied access for the following reason:\n\n";
	       errmsg += resp;
	       errmsg += "\n\nRetry?";

	       if ( !RetryLogin(errmsg) ) {
		  close(sock);
		  return False;
	       }
	    }

	    else if ( resp.StartsWith("BAD") ) {

	       InvalidateLogin(name);

	       resp.CutBeg(3);
	       resp.Trim();
	       errmsg = "The IMAP server on host ";
	       errmsg += name;
	       errmsg += "\ncould not complete the login for the following reason:\n";
	       errmsg += resp;
	       errmsg += "\n\nRetry?";

	       if ( !RetryLogin(errmsg) ) {
		  close(sock);
		  return False;
	       }
	    }

	    else if ( !resp.StartsWith("OK") ) {
	       InvalidateLogin(name);
	       Unexpected(resp);
	    }

	    else
	       done = True;

	 } // End for each login response line

      } // End while not logged in

   } // End if login needed

   else if ( line.StartsWith("* BYE") ) { // Not accepted
      line.CutBeg(5);
      line.Trim();
      errmsg = "The IMAP server on host ";
      errmsg += name;
      errmsg += "\nwould not accept a connection:\n\n";
      errmsg += line;
      halApp->PopupMessage(errmsg);
      close(sock);
      return False;
   }

   else if ( !line.StartsWith("* PREAUTH") ) {
      Unexpected(line);
      close(sock);
      return False;
   }

   return True;
}

/*------------------------------------------------------------------------
 * Method to reconnect to the IMAP server
 */

Boolean
ImapServerC::ReConnect()
{
   if ( Connect() ) {
      ishApp->mainWin->curFolder->Rescan();
      return True;
   } else
      return False;
}

/*------------------------------------------------------------------------
 * Method to determine the IMAP server type
 */

void
ImapServerC::GetServerType()
{
   type = 2;	// Default

//
// Issue the CAPABILITY command
//
   StringListC	output;
   if ( RunCommand("CAPABILITY", output) ) {

//
// Loop through the output looking for BAD response.  If not found, this is
//   an IMAP 4 server.
//
      u_int	count = output.size();
      for (int i=0; i<count; i++) {
	 StringC	*line = output[i];
	 if ( line->StartsWith("BAD", IGNORE_CASE) )
	    return; // Stick with 2
      }
   }

//
// If we reach this point we have an IMAP 4 server
//
   type = 4;

} // End GetServerType

/*------------------------------------------------------------------------
 * Function to find or open a connection to the specified IMAP server
 */

ImapServerC*
FindImapServer(char *hostname)
{
#ifdef SHARE_IMAP_SERVER
//
// See if this one is already connected
//
   if ( !serverList ) serverList = new PtrListC;

   u_int	count = serverList->size();
   for (int i=0; i<count; i++) {
      ImapServerC	*server = (ImapServerC*)*(*serverList)[i];
      if ( server->name == hostname ) return server;
   }
#endif

//
// Create a new server object
//
   ImapServerC	*server = new ImapServerC(hostname);

   return server;

} // End FindImapServer

/*------------------------------------------------------------------------
 * Function to close the connections to all IMAP servers
 */

void
CloseImapServerConnections()
{
   if ( !serverList ) return;

   u_int	count = serverList->size();
   for (int i=count-1; i>=0; i--) {
      ImapServerC	*server = (ImapServerC*)*(*serverList)[i];
      delete server;
   }
   
   serverList->removeAll();
   delete serverList;

} // CloseImapServerConnections

/*------------------------------------------------------------------------
 * Function to return the next line from the server
 */

Boolean
ImapServerC::GetLine(StringC& line)
{
   StringC		errmsg;
   static char		buf[MAXLINE+1];
   static char		lastbuf[MAXLINE+1];
   static StringListC	*lineList = NULL;
   if ( !lineList ) {
      lineList = new StringListC;
      lineList->AllowDuplicates(TRUE);
      buf[0]     = 0;
      lastbuf[0] = 0;
   }

//
// Return the first line in the list
//
   if ( lineList->size() > 0 ) {
      line = *(*lineList)[0];
      lineList->remove((u_int)0);
      if ( debuglev > 1 ) cout <<"<< [" <<line <<"]" <<endl;
      return True;
   }

   line.Clear();

//
// Read lines until we find a match
//
   fd_set	readSet;
   FD_ZERO(&readSet);

   struct timeval	timeout;

   StringC	curLine(lastbuf);
   CharC	bufStr;

   socketIO = True;		// flag for SIGPIPE handler

   while ( True ) {

//
// Check the socket
//
      int rc;
      while (True) {
         FD_SET(sock, &readSet);
         timeout.tv_sec  = 10;
         timeout.tv_usec = 0;
         rc = select(sock+1/*width*/, &readSet, NULL, NULL, &timeout);
	 //
	 // data is available on some socket
	 //
	 if ( rc > 0 )
		break;

	 //
	 // error occurred
	 //
         else if ( rc < 0) {
            if ( errno == EINTR ) {
		if (debuglev > 0) cout << "Select got SIGINTR, retrying" << endl;
	    } else {
	 	StringC	errmsg;
	 	int	err = errno;
	 	errmsg = "Could not select socket ";
	 	errmsg += sock;
	 	errmsg += " for IMAP server ";
	 	errmsg += name;
	 	errmsg += ".\n" + SystemErrorMessage(err);
	 	halApp->PopupMessage(errmsg);
		socketIO = False;
	 	return False;
	    }
	 }

	 //
	 // timeout
	 //
         else if ( rc == 0 ) {
		close(sock);
		errmsg = "Timeout trying to select the IMAP server\n";
	 	errmsg += "\n\nRetry?";
	 	if ( RetryLogin(errmsg) ) {
	           //
	           // Try to reconnect. Regardless of whether it works, return
	           // "False" here so the the operation will be re-tried from
	           // the beginning.
	           //
   		   connected = ReConnect();
	 	}
		socketIO = False;
		return False;
	 }
      }

//
// See if there is data for us
//
      if ( !FD_ISSET(sock, &readSet) ) continue;

      int readCount;
      readCount = read(sock, buf, MAXLINE);
      if ( readCount == 0 ) {
	  close(sock);
	  errmsg = "Timeout trying to select the IMAP server\n";
	  errmsg += "\n\nRetry?";
	  if ( RetryLogin(errmsg) ) {
	     //
	     // Try to reconnect. Regardless of whether it works, return
	     // "False" here so the the operation will be re-tried from
	     // the beginning.
	     //
   	     connected = ReConnect();
	  }
	  socketIO = False;
	  return False;
      }
      else if ( readCount < 0 ) {
	 StringC	errmsg;
	 int	err = errno;
	 errmsg = "Could not read socket ";
	 errmsg += sock;
	 errmsg += " for IMAP server ";
	 errmsg += name;
	 errmsg += ".\n" + SystemErrorMessage(err);
	 halApp->PopupMessage(errmsg);
	 socketIO = False;
	 return False;
      }

      buf[readCount] = 0;
      if ( debuglev > 2 ) cout <<"Buffer [" <<buf <<"]" <<endl;
      bufStr = buf;

//
// If there's no newline, save this buffer and read some more
//
      int	pos = bufStr.PosOf('\n');
      if ( pos < 0 ) {
	 curLine += bufStr;
	 bufStr.CutBeg(bufStr.Length());
      }

//
// Extract lines from the buffer
//
      else while ( pos >= 0 ) {

	 curLine += bufStr(0,pos);	// Copy up to newline
	 if ( curLine.EndsWith('\r') ) curLine.CutEnd(1);

//
// See if this line is to be returned
//
	 if ( line.size() == 0 )
	    line = curLine;
	 else
	    lineList->add(curLine);

//
// Look for another line
//
	 lastbuf[0] = 0;
	 bufStr.CutBeg(pos+1);

	 curLine.Clear();

	 pos = bufStr.PosOf('\n');

      } // End for each newline in buffer

//
// If we found a match, we're done
//
      if ( line.size() > 0 ) {
	 if ( debuglev > 1 ) cout <<"<< [" <<line <<"]" <<endl;
         strcpy(lastbuf, bufStr.Addr());
	 socketIO = False;
	 return True;
      }

//
// Copy whatever's left into lastbuf
//
      //strcpy(lastbuf, bufStr.Addr());
      if (bufStr.Length() > 0)
         curLine += bufStr(0,bufStr.Length());

   } // End while no matching line has been read

} // End GetLine

/*------------------------------------------------------------------------
 * Function to send a command to the server
 */

Boolean
ImapServerC::PutLine(CharC line, Boolean terminate)
{
   StringC		errmsg;
   if ( debuglev > 0 ) {
      int	pos = -1;
      if ( line.Contains(" LOGIN ") ) pos = line.RevPosOf(' ');
      if ( pos >= 0 )
	 cout <<"[1m>> [" <<line(0,pos) <<"][0m" <<endl;
      else
	 cout <<"[1m>> [" <<line <<"][0m" <<endl;
   }

   fd_set	writeSet;
   FD_ZERO(&writeSet);

   struct timeval timeout;

   if ( terminate && line.EndsWith('\n') ) line.CutEnd(1);

   socketIO = True;		// flag for SIGPIPE handler

   while ( line.Length() > 0 ) {

//
// See if the socket is available
//
      int rc;
      while (True) {
         FD_SET(sock, &writeSet);
         timeout.tv_sec  = 5;
         timeout.tv_usec = 0;
         rc = select(sock+1, NULL, &writeSet, NULL, &timeout);
	 //
	 // a socket is available for writing
	 //
	 if ( rc > 0 )
		break;

	 //
	 // error occurred
	 //
         else if ( rc < 0) {
            if ( errno == EINTR ) {
		if (debuglev > 0) cout << "Select got SIGINTR, retrying" << endl;
	    } else {
	 	StringC	errmsg;
	 	int	err = errno;
	 	errmsg = "Could not select socket ";
	 	errmsg += sock;
	 	errmsg += " for writing to the IMAP server ";
	 	errmsg += name;
	 	errmsg += ".\n" + SystemErrorMessage(err);
	 	halApp->PopupMessage(errmsg);
		socketIO = False;
	 	return False;
	    }
	 }

	 //
	 // timeout
	 //
         else if ( rc == 0 ) {
		errmsg = "Timeout trying to select the IMAP server\n";
	 	errmsg += "\n\nRetry?";
	 	if ( !RetryLogin(errmsg) ) {
		  close(sock);
		  socketIO = False;
		  return False;
	 	}
   		if ( !(connected = ReConnect()) ) {
		  socketIO = False;
		  return False;
		}
	 }
      }

      int writeCount;
      while ( True ) {
         writeCount = write(sock, line.Addr(), line.Length());
         if ( writeCount <= 0 ) {
            if ( errno == EPIPE) {
		errmsg = "Lost connection to the IMAP server\n";
	 	errmsg += "\n\nTry to re-connect ?";
	 	if ( !RetryLogin(errmsg) ) {
		  close(sock);
		  socketIO = False;
		  return False;
	 	}
   		if ( !(connected = ReConnect()) ) {
		  socketIO = False;
		  return False;
		}
	    } else {
	 	StringC	errmsg;
	 	int	err = errno;
	 	errmsg = "Could not write socket ";
	 	errmsg += sock;
	 	errmsg += " for IMAP server ";
	 	errmsg += name;
	 	errmsg += ".\n" + SystemErrorMessage(err);
	 	halApp->PopupMessage(errmsg);
	 	socketIO = False;
	 	return False;
	   }
        } else {
	   break;	// write succeeded
	}
      }
      line.CutBeg(writeCount);

   } // End while all bytes not written

//
// Add CRLF if necessary
//
   if ( terminate ) {

//
// See if the socket is available
//
      int rc = 0;
      while (rc == 0) {
         FD_SET(sock, &writeSet);
         timeout.tv_sec  = 5;
         timeout.tv_usec = 0;
         rc = select(sock+1, NULL, &writeSet, NULL, &timeout);
         if ( rc < 0 ) {
            if ( errno == EINTR ) {
		if (debuglev > 0) cout << "Select got SIGINTR, retrying" << endl;
	    } else {

	 	StringC	errmsg;
	 	int	err = errno;
	 	errmsg = "Could not select socket ";
	 	errmsg += sock;
	 	errmsg += " for writing to IMAP server ";
	 	errmsg += name;
	 	errmsg += ".\n" + SystemErrorMessage(err);
	 	halApp->PopupMessage(errmsg);
		socketIO = False;
	 	return False;
            }
         }
      }

      int	writeCount = write(sock, "\r\n", 2);
      if ( writeCount < 2 ) {
	 StringC	errmsg;
	 int	err = errno;
	 errmsg = "Could not write socket ";
	 errmsg += sock;
	 errmsg += " for IMAP server ";
	 errmsg += name;
	 errmsg += ".\n" + SystemErrorMessage(err);
	 halApp->PopupMessage(errmsg);
	 socketIO = False;
	 return False;
      }

   } // End if terminating

   socketIO = False;
   return True;

} // End PutLine

/*------------------------------------------------------------------------
 * Method to generate a unique tag
 */

void
ImapServerC::GenTag(StringC& tag)
{
   static int	count = 0;
   tag = "ISH";
   tag += count++;
   tag += " ";
}

/*------------------------------------------------------------------------
 * Method to display an error message about an unexpected reply
 */

void
ImapServerC::Unexpected(CharC str)
{
   StringC	errmsg = "Unexpected reply from IMAP server ";
   errmsg += name;
   errmsg += ":\n\"";
   errmsg += str;
   errmsg += "\"\n";
#if 0
   halApp->PopupMessage(errmsg);
#endif
   // Rather than hang the program waiting for a user response,
   // just splat these messages to standard error.

   cerr << errmsg;
}

/*------------------------------------------------------------------------
 * Function to run a command command and wait for the response.
 */

Boolean
ImapServerC::RunCommand(CharC cmd, StringListC& output)
{
   StringC	tag;
   GenTag(tag);

   StringC	cmdline(tag);
   cmdline += cmd;

   if ( !PutLine(cmdline) ) return False;

   if ( !GetLine(cmdline) ) return False;
   while ( !cmdline.StartsWith(tag) ) {
      output.add(cmdline);
      if ( !GetLine(cmdline) ) return False;
   }

   cmdline.CutBeg(tag.size());
   output.add(cmdline);

   return True;

} // End RunCommand

/*------------------------------------------------------------------------
 * Function to send NOOP command and wait for response.
 */

Boolean
ImapServerC::Noop(StringListC& output)
{
   return RunCommand("NOOP", output);
}

/*------------------------------------------------------------------------
 * Function to send LOGIN command and wait for response.
 */

Boolean
ImapServerC::Login(CharC user, CharC pass, StringListC& output)
{
   StringC	cmd = "LOGIN ";
   cmd += user;
   cmd += " \"";
   cmd += pass;
   cmd += "\"";

   return RunCommand(cmd, output);
}

/*------------------------------------------------------------------------
 * Function to send LOGOUT command and wait for response.
 */

Boolean
ImapServerC::Logout(StringListC& output)
{
   return RunCommand("LOGOUT", output);
}

/*------------------------------------------------------------------------
 * Function to send CREATE command and wait for response.
 */

Boolean
ImapServerC::Create(CharC mailbox, StringListC& output)
{
   StringC	cmd = "CREATE ";
   cmd += mailbox;

   return RunCommand(cmd, output);
}

/*------------------------------------------------------------------------
 * Function to send DELETE command and wait for response.
 */

Boolean
ImapServerC::Delete(CharC mailbox, StringListC& output)
{
   StringC	cmd = "DELETE ";
   cmd += mailbox;

   return RunCommand(cmd, output);
}

/*------------------------------------------------------------------------
 * Function to send RENAME command and wait for response.
 */

Boolean
ImapServerC::Rename(CharC oldname, CharC newname, StringListC& output)
{
   StringC	cmd = "RENAME ";
   cmd += oldname;
   cmd += " ";
   cmd += newname;

   Boolean	success = RunCommand(cmd, output);
   if ( success && oldname == folder ) folder = newname;

   return success;
}

/*------------------------------------------------------------------------
 * Function to send SELECT command and wait for response.
 */

Boolean
ImapServerC::Select(CharC mailbox, StringListC& output)
{
   StringC	cmd = "SELECT ";
   cmd += mailbox;

   Boolean	success = RunCommand(cmd, output);
   if ( success ) folder = mailbox;

   return success;
}

/*------------------------------------------------------------------------
 * Function to send EXPUNGE command and wait for response.
 */

Boolean
ImapServerC::Expunge(StringListC& output)
{
   return RunCommand("EXPUNGE", output);
}

/*------------------------------------------------------------------------
 * Function to send FETCH command and wait for response.
 */

Boolean
ImapServerC::Fetch(int msgnum, CharC key, char **output, char **flags,
		   StringC& response)
{
   *output = NULL;
   *flags  = NULL;
   response.Clear();

//
// Build the command we will send
//
   StringC	tag;
   GenTag(tag);

   StringC	cmd(tag);
   cmd += "FETCH ";
   cmd += msgnum;
   cmd += " ";
   cmd += key;

//
// Send the command and wait for the response
//
   if ( !PutLine(cmd) ) return False;
   if ( !GetLine(response) ) return False;

   StringC	expect("* ");
   expect += msgnum;
   expect += " FETCH ";
   while ( !response.StartsWith(expect, IGNORE_CASE) &&
      	   !response.StartsWith(tag) ) {

      Unexpected(response);

      if ( !GetLine(response) ) return False;
      if ( response.StartsWith(tag) ) {
	 response.CutBeg(tag.size());
	 return False;
      }
   }

//
// Parse the response
//
   if ( response.StartsWith(expect, IGNORE_CASE) )
       response.CutBeg(expect.size());
   else if ( response.StartsWith(tag) )
       response.CutBeg(tag.size()); 
   if ( response.StartsWith('(') ) response.CutBeg(1);
   response.Trim();

//
// These commands send the total size in the first line
//
   if ( response.StartsWith("INTERNALDATE ",	IGNORE_CASE) ||
	response.StartsWith("RFC822.HEADER ",	IGNORE_CASE) ||
	response.StartsWith("RFC822.SIZE ",	IGNORE_CASE) ||
	response.StartsWith("UID ",		IGNORE_CASE) ||
	response.StartsWith("BODY[",		IGNORE_CASE) ||
	response.StartsWith("RFC822 ",		IGNORE_CASE) ||
	response.StartsWith("RFC822.TEXT ",	IGNORE_CASE) ) {

//
// See if there is a length present
//
      int	pos = response.PosOf(' ');
      if ( pos >= 0 ) response.CutBeg(pos+1);
      response.Trim();

      if ( response.StartsWith('{') ) {

	 char	*lenp = response;
	 char	*cp = ++lenp;
	 while ( *cp != '}' ) cp++;
	 *cp = 0;          // Temporary
	 int	len = atoi(lenp);

//
// Allocate buffer of specified length
//
	 *output = new char[len+1];
	 **output = 0;

//
// Read until buffer is filled
//
	 int	readlen = 0;
	 while ( readlen < len && GetLine(response) &&
	         !response.StartsWith(tag) ) {
	    int	space = len - readlen;
	    if ( response.size() >= space ) {
	       strncat(*output, response, space);
	       (*output)[len] = 0;
	       response.CutBeg(space);
	       readlen = len;
	    }
	    else {
	       strcat(*output, response);
	       strcat(*output, "\n");
	       readlen += response.size() + 2;	// CRLF was stripped
	    }
	 }

//
// There can also be FLAGS
//
	 response.Trim();
	 if ( response.StartsWith("FLAGS ", IGNORE_CASE) ) {
	    response.CutBeg(6);
	    if ( response.EndsWith(')') ) response.CutEnd(1);
	    *flags = new char[response.size()+1];
	    **flags = 0;
	    strcpy(*flags, response);
	    response.Clear();
	 }

      } // End if length is known
      
//
// If the length is not known, the length is whatever's left in the response
//   line.
//
      else if ( !response.StartsWith("NIL") ) {
	 if ( response.EndsWith(')') ) response.CutEnd(1);
	 *output = new char[response.size()+1];
	 **output = 0;
	 strcpy(*output, response);
	 response.Clear();
      }

   } // End if the command is recognized

//
// These commands can contain many sized literals
//
   else if ( response.StartsWith("BODY ",		IGNORE_CASE) ||
	     response.StartsWith("BODYSTRUCTURE ",	IGNORE_CASE) ||
	     response.StartsWith("ENVELOPE ",		IGNORE_CASE) ) {

      int	pos = response.PosOf(' ');
      response.CutBeg(pos+1);
      response.Trim();

//
// Read lines until we get the tag
//
      StringC	buffer = response;
      if ( !GetLine(response) ) return False;
      while ( !response.StartsWith(tag) ) {

//
// Check for FLAGS
//
	 response.Trim();
	 if ( response.StartsWith("FLAGS ", IGNORE_CASE) ) {
	    response.CutBeg(6);
	    if ( response.EndsWith(')') ) response.CutEnd(1);
	    *flags = new char[response.size()+1];
	    **flags = 0;
	    strcpy(*flags, response);
	    response.Clear();
	 }
	 else
	    buffer += response;

	 if ( !GetLine(response) ) return False;

      } // End for each line up to tag

      *output = new char[buffer.size()+1];
      **output = 0;
      strcpy(*output, buffer);

   } // End if BODYSTRUCTURE or ENVELOPE command

//
// Check for flags only
//
   else if ( response.StartsWith("FLAGS ", IGNORE_CASE) ) {

      response.CutBeg(6);
      if ( response.EndsWith(')') ) response.CutEnd(1);
      *flags = new char[response.size()+1];
      **flags = 0;
      strcpy(*flags, response);
      response.Clear();
   }

   else {
      Unexpected(response);
   }

//
// Continue reading until we get the tag
//
   while ( !response.StartsWith(tag) ) {
      if ( !GetLine(response) ) return False;
   }

   response.CutBeg(tag.size());

   return True;

} // End Fetch

/*------------------------------------------------------------------------
 * Function to send FETCH command to get a sequence of 1 or more 
 * message headers.
 */

Boolean
ImapServerC::FetchHdrs(int msgnum, ImapFolderC *fld, int *bytes,
		char **output, char **flags, StringC& response)
{
   int pos;
   *output = NULL;
   *flags  = NULL;
   response.Clear();

//
// First time through, build the FETCH command we will send.
// Save the "tag" prefix in the folder object, so that after the
// last message is fetched we can find the trailing tag.
//
   if ( fld->fetchNeeded ) {

      fld->fetchNeeded = False;
      GenTag(fld->fetchTag);

      StringC	cmd(fld->fetchTag);
      cmd += "FETCH ";
      cmd += msgnum;
      cmd += ":";
      cmd += fld->msgCount;
      cmd += " (FLAGS RFC822.SIZE";

//
// For max compatibility with function of other folder types, we want
// all the headers. However, the tradeoff is performance. Decision: The
// Message-ID and Received headers are least useful, and can take up a 
// lot of lines, so don't fetch them. Get everything else, though.
//
      //cmd += " RFC822.HEADER.LINES.NOT (MESSAGE-ID RECEIVED))";
      cmd += " RFC822.HEADER)";

//
// Send the command and wait for the response
//
      if ( !PutLine(cmd) ) return False;
   }

   if ( !GetLine(response) ) return False;

   StringC	expect("* ");
   expect += msgnum;
   expect += " FETCH ";
   while ( !response.StartsWith(expect, IGNORE_CASE) &&
      	   !response.StartsWith(fld->fetchTag) ) {

      Unexpected(response);

      if ( !GetLine(response) ) return False;
      if ( response.StartsWith(fld->fetchTag) ) {
	 response.CutBeg(fld->fetchTag.size());
	 return False;
      }
   }

//
// Parse the response
//
   if ( response.StartsWith(expect, IGNORE_CASE) )
       response.CutBeg(expect.size());
   else if ( response.StartsWith(fld->fetchTag) )
       response.CutBeg(fld->fetchTag.size()); 
   if ( response.StartsWith('(') ) response.CutBeg(1);
   response.Trim();

//
// The first thing in the response line should be the flags
//
    if ( response.StartsWith("FLAGS ", IGNORE_CASE) ) {
      response.CutBeg(6);

      StringC flgs(response);
      pos = flgs.PosOf(')');
      if ( pos >=0 ) flgs.CutEnd(flgs.size()-pos-1);
      *flags = new char[flgs.size()+1];
      **flags = 0;
      strcpy(*flags, flgs);

      //
      // Skip over the flags
      //
      pos = response.PosOf(')');
      if ( pos >= 0 ) response.CutBeg(pos+1);
      response.Trim();
   } else {
      Unexpected(response);
      return False;
   }

//
// Next should be the size of the message
//
   if ( response.StartsWith("RFC822.SIZE", IGNORE_CASE) ) {
      pos = response.PosOf(' ');
      if ( pos >= 0 ) response.CutBeg(pos+1);
      response.Trim();

      StringC msgSize(response);
      pos = msgSize.PosOf(' ');
      if ( pos >= 0 ) msgSize.CutEnd(msgSize.size()-pos-1);
      msgSize.Trim();
      *bytes = atoi(msgSize);

      //
      // Skip over the size info
      //
      pos = response.PosOf(' ');
      if ( pos >= 0 ) response.CutBeg(pos+1);
      response.Trim();
   } else {
      Unexpected(response);
      return False;
   }

//
// Next should be the header info, with length of headers enclosed
// in curly braces. The headers will follow on subsequent lines.
//
   if ( response.StartsWith("RFC822.HEADER", IGNORE_CASE)) {
      pos = response.PosOf(' ');
      if ( pos >= 0 ) response.CutBeg(pos+1);
      response.Trim();
   } else {
      Unexpected(response);
      return False;
   }

//
// See if there is a length present
//
   Boolean seenEnd = False;	// flag: closing parenthesis found

   if ( response.StartsWith('{') ) {

      char	*lenp = response;
      char	*cp = ++lenp;
      while ( *cp != '}' ) cp++;
      *cp = 0;          // Temporary
      int	len = atoi(lenp);

//
// Allocate buffer of specified length
//
      *output = new char[len+1];
      **output = 0;

//
// Read until buffer is filled
//
      int	readlen = 0;
      while ( readlen < len && GetLine(response) ) {

	 //
	 // This means that the header length was too big - seems
	 // to happen sometimes...
	 //
         if (response.StartsWith(')') ) {
	    seenEnd = True;
	    break;
	 }

	 //
	 // Shouldn't see these yet...
	 //
	 if (response.StartsWith('*')  ||
	     response.StartsWith(fld->fetchTag) ) {
		Unexpected(response);
		return False;
	 }

         int	space = len - readlen;
         if ( response.size() >= space ) {
            strncat(*output, response, space);
            (*output)[len] = 0;
            response.CutBeg(space);
            readlen = len;
         }
         else {
            strcat(*output, response);
            strcat(*output, "\n");
            readlen += response.size() + 2;	// CRLF was stripped
         }
      }

  } else {
      Unexpected(response);
      return False;
  }
      
//
// The last response should have ended with a close parenthesis, indicating
// end of the FETCH data. If we haven't seen it yet, it should be on the
// next line.
//
  if (!seenEnd) {
    response.Trim();
    if (!response.EndsWith(')')) {
	GetLine(response);
	if (!response.EndsWith(')')) {
	  Unexpected(response);
	  return False;
	}
    }
  }
  return True;

} // End FetchHdrs

/*------------------------------------------------------------------------
 * Function to flush trailing output from a FETCH command, after
 * processing one or more headers.
 */

void
ImapServerC::FetchFlush( StringC& tag )
{

//
// If last message in the folder, continue reading until we get the tag
//
    StringC response;
    while ( !response.StartsWith(tag) ) {
      if (!GetLine(response)) return;
    }
    return;

} // End FetchFlush


/*------------------------------------------------------------------------
 * Function to send STORE FLAGS command and wait for response.
 */

Boolean
ImapServerC::SetFlags(int msgnum, u_int state)
{
   StringC	cmd = "STORE ";
   cmd += msgnum;
   cmd += " FLAGS (";

   Boolean	needSpace = False;
   if ( state & MSG_READ ) {
      if ( needSpace ) cmd += ' ';
      cmd += "\\Seen";
      needSpace = True;
   }
   if ( state & MSG_DELETED ) {
      if ( needSpace ) cmd += ' ';
      cmd += "\\Deleted";
      needSpace = True;
   }
   if ( state & MSG_REPLIED ) {
      if ( needSpace ) cmd += ' ';
      cmd += "\\Answered";
      needSpace = True;
   }
   if ( state & MSG_FLAGGED ) {
      if ( needSpace ) cmd += ' ';
      cmd += "\\Flagged";
      needSpace = True;
   }

#if 0
   if ( state & MSG_NEW ) {
      if ( needSpace ) cmd += ' ';
      cmd += "\\Recent";
      needSpace = True;
   }
   if ( state & MSG_SAVED ) {
      if ( needSpace ) cmd += ' ';
      cmd += "Saved";
      needSpace = True;
   }
   if ( state & MSG_FORWARDED ) {
      if ( needSpace ) cmd += ' ';
      cmd += "Forwarded";
      needSpace = True;
   }
   if ( state & MSG_RESENT ) {
      if ( needSpace ) cmd += ' ';
      cmd += "Resent";
      needSpace = True;
   }
   if ( state & MSG_PRINTED ) {
      if ( needSpace ) cmd += ' ';
      cmd += "Printed";
      needSpace = True;
   }
   if ( state & MSG_FILTERED ) {
      if ( needSpace ) cmd += ' ';
      cmd += "Filtered";
      needSpace = True;
   }
#endif

   cmd += ')';

   StringListC	output;
   return RunCommand(cmd, output);

} // End SetFlags

/*------------------------------------------------------------------------
 * Function to send COPY command and wait for response.
 */

Boolean
ImapServerC::Copy(int msgnum, CharC mailbox, StringListC& output)
{
   StringC	cmd = "COPY ";
   cmd += msgnum;
   cmd += ' ';
   cmd += mailbox;

   return RunCommand(cmd, output);
}

/*------------------------------------------------------------------------
 * Function to send APPEND command and wait for response.
 */

Boolean
ImapServerC::Append(CharC mailbox, CharC data, StringListC& output)
{
   StringC	tag;
   GenTag(tag);

   StringC	cmd = tag;
   cmd += " APPEND ";
   cmd += mailbox;
   cmd += " {";
   cmd += (int)data.Length();
   cmd += "}";

   if ( !PutLine(cmd) ) return False;

   if ( !GetLine(cmd) ) return False;
   while ( !cmd.StartsWith('+') && !cmd.StartsWith(tag) ) {
      output.add(cmd);
      if ( !GetLine(cmd) ) return False;
   }

//
// See if server is ready for data
//
   if ( !cmd.StartsWith('+') ) {
      cmd.CutBeg(tag.size());
      output.add(cmd);
      return False;
   }

//
// Send data
//
   if ( !PutLine(data) ) return False;

//
// Wait for tagged response
//
   if ( !GetLine(cmd) ) return False;
   while ( !cmd.StartsWith(tag) ) {
      output.add(cmd);
      if ( !GetLine(cmd) ) return False;
   }
   cmd.CutBeg(tag.size());
   output.add(cmd);

   return True;

} // End Append

/*------------------------------------------------------------------------
 * Function to send APPEND command and wait for response.
 */

Boolean
ImapServerC::Append(CharC mailbox, StringListC& headList, char *bodyFile,
		    StringListC& output)
{
//
// Open body file
//
   FILE	*fp = fopen(bodyFile, "r");
   if ( !fp ) {
      StringC	errmsg("Could not open file \"");
      errmsg += bodyFile;
      errmsg += "\"\n";
      errmsg += SystemErrorMessage(errno);
      halApp->PopupMessage(errmsg);
      return False;
   }

//
// Get size of data
//
   int		size = 0;
   u_int	count = headList.size();
   StringC	*headStr;
   int	i;
   for (i=0; i<count; i++) {
      headStr = headList[i];
      size += headStr->size();
   }
   size++;	// Blank line

   fseek(fp, 0, SEEK_END);
   size += (int)ftell(fp);
   fseek(fp, 0, SEEK_SET);

//
// Build command
//
   StringC	tag;
   GenTag(tag);

   StringC	cmd = tag;
   cmd += " APPEND ";
   cmd += mailbox;
   cmd += " {";
   cmd += size;
   cmd += "}";

   Boolean	error = !PutLine(cmd);

   if ( !error ) error = !GetLine(cmd);
   while ( !error && !cmd.StartsWith('+') && !cmd.StartsWith(tag) ) {
      output.add(cmd);
      error = !GetLine(cmd);
   }

//
// See if server is ready for data
//
   if ( !error && !cmd.StartsWith('+') ) {
      cmd.CutBeg(tag.size());
      output.add(cmd);
      error = True;
   }

//
// Send headers
//
   count = headList.size();
   for (i=0; !error && i<count; i++) {
      headStr = headList[i];
      error = !PutLine(*headStr, /*terminate=*/False);
   }

//
// Send blank line
//
   error = !PutLine("\n", /*terminate=*/False);

//
// Send body
//
#define BUFLEN	1024

   char	buffer[BUFLEN];
   buffer[0] = 0;

   if ( !error ) count = fread(buffer, 1, BUFLEN-1, fp);
   while ( !error && count > 0 ) {
      buffer[count] = 0;
      error = !PutLine(buffer, /*terminate=*/False);
      if ( !error ) count = fread(buffer, 1, BUFLEN-1, fp);
   }

   fclose(fp);

//
// Send termination
//
   if ( !error ) error = !PutLine("\n");

//
// Wait for tagged response
//
   if ( !error ) error = !GetLine(cmd);
   while ( !error && !cmd.StartsWith(tag) ) {
      output.add(cmd);
      error = !GetLine(cmd);
   }
   cmd.CutBeg(tag.size());
   output.add(cmd);

   return !error;

} // End Append

/*------------------------------------------------------------------------
 * Function to send FIND MAILBOXES command and wait for response.
 */

Boolean
ImapServerC::ListMailboxes(CharC pattern, StringListC& mailboxes,
					  StringListC& output)
{
   StringC	cmd = "FIND ALL.MAILBOXES ";
   cmd += pattern;

   Boolean	success = RunCommand(cmd, output);
   if ( !success ) return False;

//
// Loop through output and get names
//
   u_int	count = output.size();
   StringC	tmp;
   int	i;
   for (i=0; i<count; i++) {
      CharC	name = *output[i];
      if ( name.StartsWith("* MAILBOX ", IGNORE_CASE) ) {
	 name.CutBeg(10); 
	 name.Trim();
	 tmp = name;
	 mailboxes.add(tmp);
      }
   }

//
// Remove names from output
//
   count = output.size();
   for (i=count-1; i>=0; i--) {
      CharC	name = *output[i];
      if ( name.StartsWith("* MAILBOX ", IGNORE_CASE) )
	 output.remove(i);
   }

   return True;

} // End ListMailboxes

/*------------------------------------------------------------------------
 * Function to see if a mailbox exists
 */

Boolean
ImapServerC::Exists(CharC name)
{
   StringC	cmd = "FIND ALL.MAILBOXES ";
   cmd += name;

   StringListC	output;
   Boolean	success = RunCommand(cmd, output);
   if ( !success ) return False;

//
// Loop through output and check for name
//
   u_int	count = output.size();
   int	i;
   for (i=0; i<count; i++) {
      CharC	line = *output[i];
      if ( line.StartsWith("* MAILBOX ", IGNORE_CASE) ) {
	 line.CutBeg(10); 
	 line.Trim();
	 if ( line.Equals(name, IGNORE_CASE) ) return True;
      }
   }

   return False;

} // End Exists

/*---------------------------------------------------------------
 *  Method to ask user if they want to retry the login
 */

Boolean
ImapServerC::RetryLogin(char *msgStr)
{
   static QueryAnswerT	answer;

//
// Create the dialog if necessary
//
   static Widget	dialog = NULL;
   if ( !dialog ) {

      halApp->BusyCursor(True);

      WArgList	args;
      args.DialogStyle(XmDIALOG_FULL_APPLICATION_MODAL);
      if ( halApp->questionPM ) args.SymbolPixmap(halApp->questionPM);
      dialog = XmCreateQuestionDialog(*halApp, "retryLoginWin", ARGS);

      XtAddCallback(dialog, XmNokCallback, (XtCallbackProc)AnswerQuery,
		    (XtPointer)&answer);
      XtAddCallback(dialog, XmNcancelCallback,
		    (XtCallbackProc)AnswerQuery, (XtPointer)&answer);

//
// Trap window manager close function
//
      XmAddWMProtocolCallback(XtParent(dialog), halApp->delWinAtom,
			      (XtCallbackProc)WmClose,
			      (caddr_t)&answer);

      halApp->BusyCursor(False);

   } // End if query dialog not created

//
// Display the message
//
   WXmString    wstr = msgStr;
   XtVaSetValues(dialog, XmNmessageString, (XmString)wstr, NULL);

//
// Show the dialog
//
   XtManageChild(dialog);
   XMapRaised(halApp->display, XtWindow(XtParent(dialog)));

//
// Simulate the main event loop and wait for the answer
//
   answer = QUERY_NONE;
   while ( answer == QUERY_NONE ) {
      XtAppProcessEvent(halApp->context, XtIMXEvent);
      XSync(halApp->display, False);
   }

   XtUnmanageChild(dialog);
   XSync(halApp->display, False);
   XmUpdateDisplay(dialog);

   return (answer == QUERY_YES);

} // End RetryLogin

/*---------------------------------------------------------------
 *  Method to perform wildcard expansions on the names in a list.
 *  Any new names are added to the list.
 */

void
ImapServerC::ExpandList(StringListC& list, StringListC& output)
{
//
// Loop through strings
//
   u_int	count = list.size();
   for (int i=0; i<count; i++) {

      StringC	*name = list[i];

//
// If there are any wildcards in the name, ask the server to expand them
//
      if ( name->Contains('*') ||
	   name->Contains('%') ||
	   name->Contains('?') ) {

	 StringListC	nameList;
	 if ( ListMailboxes(*name, nameList, output) && nameList.size() > 0 ) {

//
// Add these names to the end of the list and remove the original pattern.
//
	    list.remove(i);
	    list += nameList;
	    count = list.size();
	    i--; // Since pattern was removed
	 }

      } // End if the name is a pattern

   } // End for each name

} // End ExpandList

/*------------------------------------------------------------------------

 * Function to send SEARCH command and wait for response.
 */

Boolean
ImapServerC::Search(CharC pattern, IntListC& numbers, StringListC& output)
{
   StringC	cmd = "SEARCH ";
   cmd += pattern;

   Boolean	success = RunCommand(cmd, output);
   if ( !success ) return False;

//
// Loop through output and get numbers
//
   u_int	count = output.size();
   StringC	tmp;
   char		numStr[16];
   int		num;
   int	i;
   for (i=0; i<count; i++) {

      CharC	line = *output[i];
      if ( line.StartsWith("* SEARCH ", IGNORE_CASE) ) {

	 line.CutBeg(9); 
	 line.Trim();

//
// Loop through numbers and add to list
//
	 u_int		offset = 0;
	 CharC		word = line.NextWord(offset);
	 while ( word.Length() > 0 ) {

	    strncpy(numStr, word.Addr(), word.Length());
	    numStr[word.Length()] = 0;

	    num = atoi(numStr);
	    numbers.add(num);

	    offset = word.Addr() - line.Addr() + word.Length();
	    word   = line.NextWord(offset);
	 }

      } // End if line is search result

   } // End for each output line

//
// Remove numbers from output
//
   count = output.size();
   for (i=count-1; i>=0; i--) {
      CharC	line = *output[i];
      if ( line.StartsWith("* SEARCH ", IGNORE_CASE) )
	 output.remove(i);
   }

   return True;

} // End Search

