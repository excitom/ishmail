#!/usr/bin/perl
#
# Function: Update offsets and pointers in the help card database file.
#	This is done after strings are changed in the help cards, thus 
#	invalidating the existing tables.
#
# Tom Lang 6/95

open(OLD, "<$ARGV[0]") || die "Can't open input file: $ARGV[0]\n";
open(NEW, ">$ARGV[0].new") || die "Can't create output file: $ARGV[0].new\n";

#
# Extract help cards into an associative array, %cards
#
$title_count = 0;
print "Extracting help cards...\n";
while(<OLD>) {
	last if(/^\[VERSION\]/);
	if (/^\[TITLE\]/) {
		($junk, $title) = split(/:/);
		chop $title;
		$card = "";
		$title_count++;
		next;
	}
	next if(/^\[BEGIN-TEXT\]/);
	if (/^\[END-TEXT\]/) {
		$cards{$title} = $card;
	}
	else {
		$card = $card . $_;
	}
}

$version = $_;
while(<OLD>) {
	last if(/^\[BEGIN-TABLE\]/);
	if (/NUM-HELP/) {
		$num_cards_line = $_;
		($junk, $num_cards) = split(/:/);
		chop $num_cards;
	}
}
print "Expect $num_cards cards, found $title_count\n";
die "Table is corrupt\n" if ($num_cards != $title_count);

#
# Extract table entries. This would not be needed, since the table is
# rebuilt, except that we want to preserve the order. Perl associative arrays
# are somewhat randomized, so the order of table entries is read into a
# numerically indexed array.
#
$i = 0;
while (<OLD>) {
	last if (/^\[END-TABLE\]/);
	($tab[$i++], $junk) = split(/:/);
	die "Too many table entries...\n" if $i > $num_cards;
}

#
# Extract index entries
#
print "Extracting index...\n";
$index_count = 0;
while(<OLD>) {
	next if (/^\[BEGIN-INDEX\]/);
	last if (/^\[END-INDEX\]/);
	($title, $name) = split(/:/);
	chop $name;
	$titles{$name} = $title;
	$names[$index_count++] = $name;
}
print "Expect $num_cards index entries, found $index_count\n";
die "Table is corrupt\n" if ($num_cards != $index_count);

#
# Extract the help card file names (not sure why this is useful....)
#
while(<OLD>) {
	if (/HELPFILES/) {
		$files = $_;
		last;
	}
}
#
# Rebuild the helpcards
#
print "Rebuilding help cards...\n";
$offset = 0;
$x1 = "[TITLE]:";
$x2 = "[BEGIN-TEXT]\n";
$x3 = "[END-TEXT]\n";
$l1 = length($x1);
$l2 = length($x2);
$l3 = length($x3);
foreach (@tab) {
	$name = $_;
	$title = $titles{$name};
	print NEW $x1 . $title . "\n" . $x2;
	$length = length($cards{$title});
	print NEW $cards{$title} . $x3;
	$table{$name} = $name . ":" . $offset . "::" . $length . "\n";
	$offset += $length;
	$offset = $offset + $l1 + $l2 + $l3 + length("$title\n");
}

#
# Rebuild the table
#
print "Rebuilding table...\n";
print NEW $version;
print NEW $num_cards_line;
print NEW "[BEGIN-TABLE]\n";

foreach (@tab) {
	print NEW $table{$_};
}
print NEW "[END-TABLE]\n[BEGIN-INDEX]\n";

#
# Rebuild the index
#
print "Rebuilding index...\n";
foreach (@names) {
	print NEW "$titles{$_}:$_\n";
}
print NEW "[END-INDEX]\n$files";
print NEW "[TABLE-OFFSET]:$offset\n";
