#!/usr/bin/perl
#
# Update company-specific information in the resource files.
#
open(CHANGES, "$ARGV[0]") || die "Can't open file containing changes: $ARGV[0]\n";
chdir $ARGV[1] || die "Can't find dirctory $ARGV[1]\n";
@files = `ls Ish*`;

#
# Read resources to be changed from the input file. An assocaitive array
# is built, keyed by the resource name.
#
while(<CHANGES>) {
	next if (/^\s*$/);
	$resource = $_;
	while ( $resource =~ /\\[	 ]*$/) {
		$resource = $resource . <CHANGES>;
	}
	($key, $value) = split(/:/, $resource, 2);
	$changes{$key} = $resource;
}
close(CHANGES);

#
# For each resource file, copy to a temp file, substituting from the
# list of changes as required. Then, delete the original and rename the
# temporary file.
#
foreach $file (@files) {
	chop $file;
	next unless(open(IN,"$file"));
	print "Updating $file ...\n";
	open(OUT, ">$file.new") || die "Can't open output file\n";

	while(<IN>) {
		($k, $v) = split(/:/, $_, 2);
		if (defined($changes{$k})) {
			print "   changing $k\n";
			print OUT $changes{$k};
		}
		else {
			print OUT;
		}
	}
	close (IN);
	close (OUT);
	unlink ($file);
	rename ("$file.new", $file) || die "Problem renaming $file\n";
}
