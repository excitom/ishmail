/*
 *  $Id: IshAppP.C,v 1.1 1998/06/24 01:32:30 lang Exp $
 *  
 *  Copyright (c) 1994 HAL Computer Systems International, Ltd.
 * 
 *          HAL COMPUTER SYSTEMS INTERNATIONAL, LTD.
 *                  1315 Dell Avenue
 *                  Campbell, CA  95008
 *
 * Author: Greg Hilton
 * Contributors: Tom Lang, Frank Bieser, and others
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * http://www.gnu.org/copyleft/gpl.html
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
#include "IshAppP.h"
#include "IshAppC.h"
#include "License.h"
#include "SigPrefC.h"
#include "MailPrefC.h"
#include "MailFile.h"
#include "AlertPrefC.h"
#include "AppPrefC.h"
#include "FolderC.h"
#include "FolderPrefC.h"
#include "MainWinC.h"
#include "Query.h"
#include "ReadWinC.h"
#include "SendWinC.h"
#include "CompPrefC.h"
#include "checksum.h"

#include "ishmail.xpm"
#include "ishmail_info.xpm"
#include "ishmail_question.xpm"
#include "ishmail_warning.xpm"
#include "ishmail_error.xpm"

#include <hgl/CharC.h>
#include <hgl/StringC.h>
#include <hgl/StringListC.h>
#include <hgl/PixmapC.h>
#include <hgl/WXmString.h>
#include <hgl/WArgList.h>
#include <hgl/RowColC.h>
#include <hgl/SysErr.h>
#include <hgl/TextMisc.h>
#include <hgl/rsrc.h>
#include <hgl/VBoxC.h>

#include <Xm/MessageB.h>
#include <Xm/SelectioB.h>
#include <Xm/Label.h>
#include <Xm/Protocols.h>
#include <Xm/TextF.h>
#include <Xm/RowColumn.h>
#include <Xm/Frame.h>
#include <Xm/ToggleB.h>
#include <Xm/AtomMgr.h>
#include <Xm/PushB.h>

#include <unistd.h>
#include <errno.h>

#if defined OSF1 || MIPS
extern "C" {
#endif
#include <netdb.h>
#if defined OSF1 || MIPS
}
#endif

#ifdef SOLARIS
# include <sys/utsname.h>
# include <sys/systeminfo.h>
#endif

#if defined AIX || defined HPUX
# include <sys/utsname.h>
#endif

#if !defined HPUX && !defined LINUX
   extern "C" int	gethostname(char*, int);
#endif

#ifdef SUN_OS
   extern "C" int	gethostid();
#endif

/*----------------------------------------------------------------------
 * Constructor
 */

IshAppP::IshAppP(IshAppC *ia)
{
   pub              = ia;

   messagePM        = NULL;
   warningPM        = NULL;
   questionPM       = NULL;
   errorPM          = NULL;
   checkTimer       = (XtIntervalId)NULL;
   lastMailCheck    = 0;
   lastLicenseCheck = 0;

} // End constructor

/*----------------------------------------------------------------------
 * Destructor
 */

IshAppP::~IshAppP()
{
   delete messagePM;
   delete warningPM;
   delete questionPM;
   delete errorPM;
}

/*---------------------------------------------------------------
 * See if "Ishmail" needs to be added to beginning of resources.  Prior to
 *    version 1.1 we thought we didn't need it, but it looks like we really
 *    do.
 * Also check for duplicate lines.  If there are any, keep the last.
 */  

void
IshAppP::FixIshmailrc()
{
   StringC	data;
   if ( !data.ReadFile(pub->resFile) ) return;

//
// See if we need to add the "Ishmail*" prefix
//
   Boolean	addPrefix  = !data.Contains("\nIshmail*");

//
// See if we need to fix the "Ishmail**" prefix
//
   Boolean	fixPrefix  = data.Contains("\nIshmail**");

//
// See if we need to remove width and height resources
//
   Boolean	fixSize = (data.Contains("mainShell.width:")	||
			   data.Contains("mainShell.height:")	||
			   data.Contains("viewDA.width:")	||
			   data.Contains("viewDA.height:")	||
			   data.Contains("sendWin.width:")	||
			   data.Contains("sendWin.height:")	||
			   data.Contains("readWin.width:")	||
			   data.Contains("readWin.height:")	||
			   data.Contains("msgBox*scrollForm.height:")	||
			   data.Contains("msgBox*taskVBox.height:"));

//
// See if we need to change from font to fontList in the viewDA
//
   Boolean	fixFont  = !data.Contains("viewDA.fontList:");

//
// See if we need to remove duplicate lines
//
   Boolean	removeDups = HasDuplicateLines(data);

   if ( !addPrefix && !fixPrefix && !fixSize && !removeDups && !fixFont )
      return;

//
// Break the resources into lines
//
   StringListC	lineList;
   GetResLines(data, lineList, removeDups);

//
// Remove all .width and .height resources for main windows
//
   if ( fixSize ) {

      if ( debuglev > 0 )
	 cout <<"Removing bogus width and height resources." <<endl;

      u_int	count = lineList.size();
      int i=count-1; for (i=count-1; i>=0; i--) {
	 StringC	*line = lineList[i];
	 if ( (line->Contains(".width:") || line->Contains(".height:")) &&
	      (line->Contains("mainShell.width:")	||
	       line->Contains("mainShell.height:")	||
	       line->Contains("viewDA.width:")		||
	       line->Contains("viewDA.height:")		||
	       line->Contains("sendWin.width:")		||
	       line->Contains("sendWin.height:")	||
	       line->Contains("readWin.width:")		||
	       line->Contains("readWin.height:")	||
	       line->Contains("msgBox*scrollForm.height:")	||
	       line->Contains("msgBox*taskVBox.height:")) ) {
	    lineList.remove(i);
	 }
      }
   }

   if ( addPrefix ) {

      if ( debuglev > 0 ) cout <<"Adding Ishmail* prefix" <<endl;

//
// Add "Ishmail" to the beginning of any lines that don't have it
//
      u_int	count = lineList.size();
      int i=0; for (i=0; i<count; i++) {

	 StringC	*line = lineList[i];

//
// See if the line needs to be updated
//
	 if ( line->StartsWith("*") )
	    (*line)(0,0) = "Ishmail";
      }

   } // End if prefix needed

   if ( fixPrefix ) {

      if ( debuglev > 0 ) cout <<"Adding Ishmail* prefix" <<endl;

//
// Change "Ishmail**" to "Ishmail*"
//
      u_int	count = lineList.size();
      int i=0; for (i=0; i<count; i++) {

	 StringC	*line = lineList[i];

//
// See if the line needs to be updated
//
	 if ( line->StartsWith("Ishmail**") )
	    (*line)(7,1) = "";
      }

   } // End if prefix fix needed

   if ( fixFont ) {

      if ( debuglev > 0 )
	 cout <<"Changing viewDA.font to viewDA.fontList" <<endl;

//
// Change "viewDA.font:" to "viewDA.fontList:"
//
      u_int	count = lineList.size();
      int i=0; for (i=0; i<count; i++) {

	 StringC	*line = lineList[i];

//
// See if the line needs to be updated
//
	 if ( line->StartsWith("Ishmail*viewDA.font:") )
	    (*line)(19,0) = "List";
      }

   } // End if font fix needed

//
// Write out the resources
//
   WriteResFile(lineList);

} // End FixIshmailrc

/*---------------------------------------------------------------
 * See if mapped resource file contains any duplicate lines
 */  

Boolean
IshAppP::HasDuplicateLines(CharC data)
{
//
// Loop through lines
//
   u_int	offset = 0;
   CharC	line = data.NextWord(offset, "\n");
   while ( line.Length() > 0 ) {

      offset = line.Addr() - data.Addr() + line.Length();
      if ( line.StartsWith('*') || line.StartsWith("Ishmail*") ) {

//
// Remove the value portion of the resource 
//
	 int	pos = line.PosOf(':');
	 if ( pos >= 0 ) {

	    line = line(0,pos+1);

//
// Now look from here to the end to see if there is any copy of this line
//
	    pos = data.PosOf(line, offset);
	    if ( pos > 0 && data[pos-1] == '\n' )
	       return True;
	 }
      }

//
// Read the next line
//
      line = data.NextWord(offset, "\n");

   } // End for each line in file
   
   return False;

} // End HasDuplicateLines

/*---------------------------------------------------------------
 *  Function to read the resource lines from the given text data
 */

void
IshAppP::GetResLines(CharC data, StringListC& lineList, Boolean removeDups)
{
   if ( debuglev > 0 && removeDups ) cout <<"Removing duplicate lines" <<endl;

   lineList.removeAll();
   lineList.AllowDuplicates(TRUE);

   StringC	line;
   CharC	word;
   u_int	offset = 0;
   int		pos = data.PosOf('\n', offset);
   while ( pos >= 0 ) {

      word = data(offset, (u_int)pos-offset);
      offset = pos + 1;

//
// If the newline is escaped, read some more.
//
      if ( word.EndsWith("\\") ) {
	 word.CutEnd(1);
	 line += word;
      }
      else {
	 line += word;
	 if ( removeDups ) {
	    StringC	*lineP = FindLine(lineList, line);
	    if ( lineP ) *lineP = line;
	    else	 lineList.add(line);
	 }
	 else
	    lineList.add(line);
	 line.Clear();
      }

      pos = data.PosOf('\n', offset);

   } // End for each line in file

} // End GetResLines

/*---------------------------------------------------------------
 *  Function to see if the specified line already exists in the line list
 */

StringC*
IshAppP::FindLine(StringListC& list, CharC res)
{
   if ( !res.StartsWith('*') && !res.StartsWith("Ishmail*") ) return NULL;

//
// Remove the value portion of the resource 
//
   int	pos = res.PosOf(':');
   if ( pos < 0 ) return NULL;

   res = res(0,pos+1);

//
// Loop through the line list and see if any line starts with this resource
//
   u_int	count = list.size();
   int i=0; for (i=0; i<count; i++) {
      StringC	*line = list[i];
      if ( line->StartsWith(res) ) return line;
   }

   return NULL;

} // End FindLine

/*---------------------------------------------------------------
 *  Function to write the .ishmailrc file from a list of lines
 */

Boolean
IshAppP::WriteResFile(StringListC& lineList)
{
   if ( debuglev > 0 ) cout <<"Writing resource file: " <<pub->resFile <<endl;

//
// Write the information back to the file
//
   FILE *fp = fopen(pub->resFile, "w");
   if ( !fp ) {
      StringC	errmsg = "Could not open resource file: ";
      errmsg += pub->resFile;
      errmsg += '\n';
      errmsg += SystemErrorMessage(errno);
      halApp->PopupMessage(errmsg);
      return False;
   }

   CharC	nl("\n");
   unsigned	count = lineList.size();
   Boolean	error = False;
   int i=0; for (i=0; !error && i<count; i++) {

      StringC	*line = lineList[i];

//
// See if the line needs to be split
//
      if ( line->StartsWith("Ishmail*alerts:")		||
	   line->StartsWith("Ishmail*icons:")		||
	   line->StartsWith("Ishmail*saveRules:")	||
	   line->StartsWith("Ishmail*folderSortKeys:")	||
	   line->StartsWith("Ishmail*automaticFilingRules:") )
	 error = !WriteRules(fp, *line);
      else
	 error = !line->WriteFile(fp);

      if ( !error ) error = !nl.WriteFile(fp);
   }

   if ( !error ) error = (fclose(fp) != 0);

   if ( error ) {
      StringC	errmsg = "Could not write resource file: ";
      errmsg += pub->resFile;
      errmsg += '\n';
      errmsg += SystemErrorMessage(errno);
      halApp->PopupMessage(errmsg);
   }

   return !error;

} // End WriteResFile

/*---------------------------------------------------------------
 *  Write a resource that represents a rule dictionary and add line breaks.
 */

Boolean
IshAppP::WriteRules(FILE *fp, StringC& line)
{
//
// Add a newline after the first : and then after each successive ;
//
   char		*start = line;
   char		*end   = start + line.size();
   char		*cp    = strchr(start, ':');
   Boolean	error  = False;
   while ( !error && cp ) {

//
// Skip found character and following whitespace
//
      cp++;
      while ( cp < end && isspace(*cp) ) cp++;
      int	len = cp - start;

//
// Write up to this point, then write an escaped newline if there's more
//    text to come
//
      error = (fwrite(start, 1, len, fp) != len);
      if ( !error && cp < end ) error = (fwrite("\\\n", 1, 2, fp) != 2);

      start = cp;
      cp = strchr(start, ';');

   } // End for each ';'

   return !error;

} // End WriteRules

/*---------------------------------------------------------------
 *  Create ishmail pixmaps
 */

void
IshAppP::CreatePixmaps()
{
   Window	appWin = XtWindow(pub->appShell);
   Screen	*scr   = pub->screen;
   Pixel	black = BlackPixelOfScreen(scr);
   Pixel	white = WhitePixelOfScreen(scr);

   pub->ishmailPM = new PixmapC(ishmail_xpm, appWin);
   if ( !pub->ishmailPM->reg )
      pub->ishmailPM->Set("ishmail.xbm", black, white, white, black, scr,
      			  appWin);
   if ( pub->ishmailPM->reg == XmUNSPECIFIED_PIXMAP )
      pub->ishmailPM->reg = (Pixmap)NULL;

   messagePM = new PixmapC(ishmail_info_xpm, appWin);
   if ( !messagePM->reg )
      messagePM->Set("ishmail_info.xbm", black, white, white, black, scr,
		     appWin);
   if ( messagePM->reg == XmUNSPECIFIED_PIXMAP ) messagePM->reg = (Pixmap)NULL;

   questionPM = new PixmapC(ishmail_question_xpm, appWin);
   if ( !questionPM->reg )
      questionPM->Set("ishmail_question.xbm", black, white, white, black, scr,
		      appWin);
   if ( questionPM->reg == XmUNSPECIFIED_PIXMAP )
      questionPM->reg = (Pixmap)NULL;

   warningPM = new PixmapC(ishmail_warning_xpm, appWin);
   if ( !warningPM->reg )
      warningPM->Set("ishmail_warning.xbm", black, white, white, black, scr,
		     appWin);
   if ( warningPM->reg == XmUNSPECIFIED_PIXMAP ) warningPM->reg = (Pixmap)NULL;

   errorPM = new PixmapC(ishmail_error_xpm, appWin);
   if ( !errorPM->reg )
      errorPM->Set("ishmail_error.xbm", black, white, white, black, scr,
		   appWin);
   if ( errorPM->reg == XmUNSPECIFIED_PIXMAP ) errorPM->reg = (Pixmap)NULL;

} // End CreatePixmaps

/*---------------------------------------------------------------
 *  Initialize license
 */

void
IshAppP::InitLicense(CharC licDir)
{
   Boolean	needsLicense = True;
#ifdef SOLARIS
//
// Hal machines don't need a license
//
   struct utsname	udata;
   CharC		mach;
   if ( uname(&udata) >= 0 ) mach = udata.machine;
   needsLicense = ((mach != "sun4h") && (mach != "sun4H"));
#endif

//
// Get name of directory containing executable and initialize the
//    license manager.
//
   StringC	file;
   char		*cs;
   if ( needsLicense ) {

      cs = getenv("ISHMAILLIC");
      if ( cs ) {
	 file = cs;
      }
      else {

	 cs = getenv("ISHBIN");
	 if ( cs ) {
	    file = cs;
	    if ( !file.EndsWith('/') ) file += '/';
	    file += "license";
	 }
	 else {

	    cs = getenv("ISHDIR");
	    if ( cs ) {
	       file = cs;
	       if ( !file.EndsWith('/') ) file += '/';
	       file += "bin/license";
	    }

	    else if ( licDir.Length() > 0 ) {

	       file = licDir;
	       file += "/license";

	    } // End if ISHDIR not defined

	 } // End if ISHBIN not defined

      } // End if ISHMAILLIC not defined

      if ( file.size() == 0 ) {

	 StringC	msg;
	 msg = "I could not determine the name of the license file.\n";
	 msg += "Please specify a file name using either ISHMAILLIC or\n";
	 msg += "ISHDIR in your environment.\n \n";
	 msg += pub->supportMsg;
	 msg += "\n \nSending and saving messages has been disabled,\n";
	 msg += "but you may still use the File->Comment feature.";

	 pub->PopupMessage(msg);
      }

   } // End if a license is needed

//
// Initialize license manager
//
   if ( !needsLicense || file.size() > 0 ) {

      pub->licInfo = new LicInfoC(file);
      if ( pub->licInfo->status == LicInfoC::LIC_OK ) {

//
// Check product license
//
	 StringC	ver = version;
	 cs = strtok(ver, "-");
	 pub->licInfo->CheckProd("Ishmail", cs);

//
// Check license dates
//
	 if ( pub->licInfo->status == LicInfoC::LIC_OK )
	    pub->licInfo->CheckDate(time(0));

//
// Check for installation on correct host 
//
	 if ( pub->licInfo->status == LicInfoC::LIC_OK )
           pub->licInfo->CheckHost(pub->licInfo->host);

      }

//
// Check license status
//
      if ( pub->licInfo->status != LicInfoC::LIC_OK ) {

//
// Allow the user to request a license if there is no file
//
	 StringC	msg;
	 if ( pub->licInfo->status == LicInfoC::LIC_NO_FILE )
	    msg = "No license file could be found for Ishmail.";
	 else
	    msg = pub->licInfo->msg;

	 if ( pub->licInfo->status != LicInfoC::LIC_WARNING ) {
	    msg += "\n \nSending and saving messages has been disabled,";
	    msg += "\nbut you may still use the File->Comment feature.";
	 }

	 if ( pub->licInfo->status == LicInfoC::LIC_NO_FILE ) {
	 msg += "\n \nYou may request a demo license by entering your host's\n";
	 msg += "IP address and your e-mail address in the fields below and\n";
	 msg += "pressing the \"request\" button.\n \n";
	 msg += "A message will be sent to Ishmail Technical Support and a\n";
	 msg += "demo license file specific to your machine will be mailed\n";
	 msg += "back to you.\n \n";
	 msg += pub->alsoCallMsg;
	 msg += "\n";
	    NoLicenseMessage(msg);
	 }

	 else {

	    if ( pub->licInfo->status == LicInfoC::LIC_WARNING ) {
	       pub->licInfo->status = LicInfoC::LIC_OK;
	       pub->PopupMessage(msg, XmDIALOG_WARNING);
	    }
	    else
	       pub->PopupMessage(msg);

	 }

      } // End if license status not ok

   } // End if license file name determined

   pub->licenseOk = (pub->licInfo && pub->licInfo->status == LicInfoC::LIC_OK);
   lastLicenseCheck = time(0);

} // End InitLicense

/*---------------------------------------------------------------
 *  Callback to handle user request of license
 */

static Boolean	answered;
static Widget	ipTF;
static Widget	mailTF;
#ifndef OSF1
static Widget	ipVarTB;
#endif

static void
AcknowledgePopup(Widget, XtPointer, XtPointer)
{
   answered = True;
}

void
IshAppP::RequestLicense(Widget w, IshAppP *This, XtPointer)
{
#ifndef OSF1
   if ( !XmToggleButtonGetState(ipVarTB) &&
	XmTextFieldGetLastPosition(ipTF) == 0 )
#else
   if ( XmTextFieldGetLastPosition(ipTF) == 0 )
#endif
   {
      set_invalid(ipTF, True, True);
      StringC	msg = "Please enter an IP address for your host.\n";
      This->pub->PopupMessage(msg, w);
      return;
   }

   if ( XmTextFieldGetLastPosition(mailTF) == 0 ) {
      set_invalid(mailTF, True, True);
      StringC	msg = "Please enter an e-mail address for yourself.\n";
      This->pub->PopupMessage(msg, w);
      return;
   }

//
// Create a temporary file to hold the request
//
   char	*file = tempnam(NULL, "lic.");
   FILE	*fp = fopen(file, "w");
   if ( !fp ) {
      StringC	msg = "I could not create a temporary file for the request.\n";
      msg += SystemErrorMessage(errno);
      This->pub->PopupMessage(msg, w);
      return;
   }

   char	*cs = XmTextFieldGetString(ipTF);
   StringC	ipStr(cs);
   XtFree(cs);

   cs = XmTextFieldGetString(mailTF);
   StringC	mailStr(cs);
   XtFree(cs);

   StringC	mailer("Ishmail-demo-"); mailer += version;
   StringC	recip = get_string(*ishApp, "commentTo",
					    "support@ishmail.com");

//
// Prepare mail headers
//
   StringC	head;

   head = "To: " + recip + "\n";
   head += "Subject: Ishmail Demo License Request\n";
   head += "Reply-To: " + mailStr + "\n";
   head += "Sender: " + mailer + "@" + This->pub->domain + "\n";
   head += "X-Mailer: " + mailer + "\n";
   head += "\n";

//
// Prepare message body.  See if host checksum should be used rather than IP.
//
   StringC	body;
   body = "Host address: ";

#ifndef OSF1
   if ( XmToggleButtonGetState(ipVarTB) ) {

      if ( debuglev > 0 ) cout <<"Generating request for node-locked license" <<endl;

#if defined SOLARISx86 || defined LINUX || defined BSDI
#define MEMSIZE	0xFFFF
#define BUFSIZE	(MEMSIZE*2)

      char	*buffer = new char[BUFSIZE+1];
#if 1
// punt on the checksum stuff for PCs - what once was ROM sometimes is RAM...
      memset(buffer, 0, BUFSIZE);
      strcpy(buffer, "DEADBEEF");
      int sum = checkSum((u_char*)buffer, BUFSIZE);
      body += sum;
#else

      FILE	*fp     = fopen("/dev/mem", "r");
      if ( fp ) {

	 fseek(fp, 0xC0000L, SEEK_SET);
	 fread(buffer, 1, MEMSIZE, fp);
	 fseek(fp, 0xF0000L, SEEK_SET);
	 fread(buffer+MEMSIZE, 1, MEMSIZE, fp);
	 fclose(fp);

	 buffer[BUFSIZE] = 0;
	 int	sum = checkSum((u_char*)buffer, BUFSIZE);

	 body += sum;
      }

      else {
	 StringC	msg = "I could not open /dev/mem for reading.\n\n";
	 msg += SystemErrorMessage(errno);
	 msg += "\n\nTo request a license for a variable IP address,";
	 msg += "\n/dev/mem must be readable.  This can be accomplished";
	 msg += "\nby changing the permissions on /dev/mem or by running";
	 msg += "\nIshmail as root.";
	 This->pub->PopupMessage(msg, w);
	 unlink(file);
	 free(file);
	 delete buffer;
	 return;
      }
#endif
      delete buffer;

#elif defined SUN_OS

      char	*buffer = new char[64];
      sprintf(buffer, "%ld", gethostid());
      body += buffer;

#elif defined SOLARIS

      char	*buffer = new char[256];
      sysinfo(SI_HW_PROVIDER, buffer, 256);
      body += buffer;
      sysinfo(SI_HW_SERIAL,   buffer, 256);
      body += buffer;

#elif defined AIX

      struct utsname	data;
      uname(&data);
      body += data.machine;

#elif defined HPUX

      struct utsname	data;
      uname(&data);
      body += data.idnumber;

#endif
   }
   else
#endif
   body += ipStr;

   body += "\nUser address: ";
   body += mailStr;
   body += "\n   File name: ";
   body += This->pub->licInfo->file;
   body += "\n\n";
   body += This->pub->sigPrefs->Sig();
   body += "\n";

//
// Write info to file
//
   if ( !head.WriteFile(fp) || !body.WriteFile(fp) ) {
      fclose(fp);
      unlink(file);
      free(file);
      StringC	msg = "I could not create a temporary file for the request.\n";
      msg += SystemErrorMessage(errno);
      This->pub->PopupMessage(msg, w);
      return;
   }

   fclose(fp);

//
// Now send the file
//
   MailFile(file, recip, This->pub->mailPrefs->SendmailCmd());
   //Send file does this: unlink(file);

   free(file);
   answered = True;

} // End RequestLicense

/*---------------------------------------------------------------
 *  Display request-license screen
 */

void
IshAppP::NoLicenseMessage(const char *msg)
{
   WXmString	str(msg);
   WArgList	args;
   //args.DialogStyle(XmDIALOG_FULL_APPLICATION_MODAL);
   args.AutoUnmanage(False);
   args.MessageString((XmString)str);
   if ( pub->ishmailPM->reg ) args.SymbolPixmap(pub->ishmailPM->reg);
   Widget	dialog = XmCreateMessageDialog(*pub, "noLicenseWin", ARGS);

//
// Create entry widgets
//
   RowColC	*rc       = new RowColC(dialog, "entryRC", 0,0);
   Widget	ipLabel   = XmCreateLabel(*rc, "ipLabel",   0,0);
   Widget	mailLabel = XmCreateLabel(*rc, "mailLabel", 0,0);

   ipTF   = CreateTextField(*rc, "ipTF",   0,0);
   mailTF = CreateTextField(*rc, "mailTF", 0,0);

//
// On x86 machines we can handle variable IP addresses
//
#ifndef OSF1
   ipVarTB = XmCreateToggleButton(*rc, "ipVarTB", 0,0);
#endif

//
// Get default host address and e-mail address
//
#if defined SVR4 || MIPS
   struct hostent	*hent = gethostbyname((char*)pub->licInfo->host);
#else
   struct hostent	*hent = gethostbyname((const char*)pub->licInfo->host);
#endif
   if ( hent ) {

//
// Get address
//
      char	*hp = hent->h_addr_list[0];
      if ( hp ) {

         StringC	addr;
	 for (int i=0; i<hent->h_length; i++) {
	    if ( i>0 ) addr += ".";
	    unsigned char	c = hp[i];
	    addr += (int)c;
	 }

	 XmTextFieldSetString(ipTF, addr);
      }
   }

   XmTextFieldSetString(mailTF, pub->userAtHostDomain);

   rc->Defer(True);
   rc->SetOrientation(RcROW_MAJOR);
#ifndef OSF1
   rc->SetColCount(3);
#else
   rc->SetColCount(2);
#endif
   rc->SetColResize(False);
   rc->SetColResize(1, True);
   rc->SetColAlignment(0, XmALIGNMENT_END);
   rc->SetColWidthAdjust(1, RcADJUST_ATTACH);
   rc->AddChild(ipLabel);
   rc->AddChild(ipTF);
#ifndef OSF1
   rc->AddChild(ipVarTB);
#endif
   rc->AddChild(mailLabel);
   rc->AddChild(mailTF);
#ifndef OSF1
   rc->AddChild(NULL);
#endif
   rc->Defer(False);

   XtManageChild(*rc);

   XtAddCallback(dialog, XmNokCallback, (XtCallbackProc)RequestLicense, this);
   XtAddCallback(dialog, XmNcancelCallback, (XtCallbackProc)AcknowledgePopup,
		 NULL);
   XtAddCallback(dialog, XmNhelpCallback, (XtCallbackProc)HalAppC::DoHelp,
		 (XtPointer)"helpcard");

//
// Trap window manager close function
//
   XmAddWMProtocolCallback(XtParent(dialog), pub->delWinAtom,
			   (XtCallbackProc)AcknowledgePopup, NULL);

   XtManageChild(dialog);
   XMapRaised(pub->display, XtWindow(XtParent(dialog)));

//
// Wait for the popup to be acknowledged
//
   answered = False;
   while ( !answered ) {
      XtAppProcessEvent(pub->context, XtIMXEvent);
      XSync(pub->display, False);
   }

   XtUnmanageChild(dialog);
   XtDestroyWidget(dialog);
   delete rc;

} // End NoLicenseMessage

/*---------------------------------------------------------------
 *  Timer proc to check for new mail
 */

void
IshAppP::CheckForNewMail(IshAppP *This, XtIntervalId*)
{
//
// Do this to protect against multiple threads.  This can happen if we
//    detect an external mod, are waiting for user acknowledgement and
//    VerifyMailCheck thinks the timer proc has gone south.
//
   static Boolean	inCheck = False;

   if ( inCheck ) return;
   inCheck = True;

   This->lastMailCheck = time(0);
   This->checkTimer    = (XtIntervalId)NULL;

   This->pub->mainWin->MsgVBox().Defer(True);

//
// Check system folder
//
   if ( This->pub->systemFolder->NewMail() )
      This->pub->mainWin->GetNewMail(This->pub->systemFolder);

//
// Check all folders if showing status
//
    if ( ishApp->folderPrefs->showStatus ) {
	FolderListC	list  = ishApp->folderPrefs->OpenFolders();
	u_int		count = list.size();
	for (int i=0; i<count; i++) {
	    FolderC	*folder = list[i];
	    if ( folder->NewMail() ) This->pub->mainWin->GetNewMail(folder);
	}
    }

//
// Check current folder if other than system
//
   else if ( This->pub->mainWin->curFolder != This->pub->systemFolder &&
	     This->pub->mainWin->curFolder->NewMail() )
      This->pub->mainWin->GetNewMail(This->pub->mainWin->curFolder);

   This->pub->mainWin->MsgVBox().Defer(False);

   inCheck = False;

//
// Start another timer
//
   if ( This->pub->appPrefs->checkInterval > 0 )
      This->checkTimer =
	 XtAppAddTimeOut(This->pub->context,
	 		 This->pub->appPrefs->checkInterval*1000,
			 (XtTimerCallbackProc)CheckForNewMail,
			 (XtPointer)This);

} // End CheckForNewMail

/*---------------------------------------------------------------
 *  Method to re-open a dialog if the user closes it with the window
 *     manager close button
 */

void
IshAppP::PreventClose(Widget shell, Widget dialog, XtPointer)
{
   XtManageChild(dialog);
   XMapRaised(halApp->display, XtWindow(shell));
}

/*---------------------------------------------------------------
 *  Method to ask the user if they will be using an IMAP server
 */

void
IshAppP::QueryImap()
{
//
// See if this information is available in the in-box name
//
   if ( pub->inBox.StartsWith('{') ) {

      int	pos = pub->inBox.PosOf('}');
      if ( pos > 0 ) {
	 StringC	server = pub->inBox(1,pos-1);
	 pub->appPrefs->usingImap  = True;
	 pub->appPrefs->imapServer = server;
	 pub->appPrefs->WriteDatabase();
	 pub->appPrefs->WriteFile();
	 return;
      }
   }

   QueryAnswerT  answer;

//
// Ask if they will be using an IMAP server
//
   WArgList	args;
   args.DialogStyle(XmDIALOG_FULL_APPLICATION_MODAL);
   if ( halApp->questionPM ) args.SymbolPixmap(halApp->questionPM);
   Widget	dialog = XmCreateQuestionDialog(*pub, "queryImapWin", ARGS);

   XtAddCallback(dialog, XmNokCallback, (XtCallbackProc)AnswerQuery,
			 (XtPointer)&answer);
   XtAddCallback(dialog, XmNcancelCallback, (XtCallbackProc)AnswerQuery,
			 (XtPointer)&answer);
   XtAddCallback(dialog, XmNhelpCallback, (XtCallbackProc)HalAppC::DoHelp,
			 "helpcard");

//
// Don't allow window manager close function
//
   XmAddWMProtocolCallback(XtParent(dialog), halApp->delWinAtom,
			   (XtCallbackProc)PreventClose, dialog);

   XtManageChild(dialog);
   XMapRaised(halApp->display, XtWindow(XtParent(dialog)));

//
// Simulate the main event loop and wait for the answer
//
   answer = QUERY_NONE;
   while ( answer == QUERY_NONE ) {
      XtAppProcessEvent(halApp->context, XtIMXEvent);
      XSync(halApp->display, False);
   }

   XtUnmanageChild(dialog);
   XSync(halApp->display, False);
   XmUpdateDisplay(dialog);

//
// Delete the dialog
//
   XtDestroyWidget(dialog);

   if ( answer == QUERY_YES ) {

//
// Get the name of the IMAP server
//
      args.Reset();
      args.DialogStyle(XmDIALOG_FULL_APPLICATION_MODAL);
      args.AutoUnmanage(False);
      dialog = XmCreatePromptDialog(*pub, "queryImapServerWin", ARGS);

      XtAddCallback(dialog, XmNokCallback, (XtCallbackProc)AnswerQuery,
			    (XtPointer)&answer);
      XtAddCallback(dialog, XmNcancelCallback, (XtCallbackProc)AnswerQuery,
			    (XtPointer)&answer);
      XtAddCallback(dialog, XmNhelpCallback, (XtCallbackProc)HalAppC::DoHelp,
			    "helpcard");

      Widget	serverTF = XmSelectionBoxGetChild(dialog, XmDIALOG_TEXT);

//
// Don't allow window manager close function
//
      XmAddWMProtocolCallback(XtParent(dialog), halApp->delWinAtom,
			      (XtCallbackProc)PreventClose, dialog);

      XtManageChild(dialog);
      XMapRaised(halApp->display, XtWindow(XtParent(dialog)));

//
// Loop until a name is entered or the dialog is cancelled
//
      Boolean	done = False;
      while ( !done ) {

//
// Simulate the main event loop and wait for the answer
//
	 answer = QUERY_NONE;
	 while ( answer == QUERY_NONE ) {
	    XtAppProcessEvent(halApp->context, XtIMXEvent);
	    XSync(halApp->display, False);
	 }

	 if ( answer == QUERY_CANCEL ) {
	    pub->appPrefs->usingImap = False;
	    done = True;
	 }

	 else {
	    char	*cs = XmTextFieldGetString(serverTF);
	    CharC	server(cs);
	    server.Trim();
	    if ( server.Length() == 0 ) {
	       set_invalid(serverTF, True, True);
	       pub->PopupMessage("Please enter the host name of your IMAP server.");
	    }
	    else {
	       pub->appPrefs->usingImap  = True;
	       pub->appPrefs->imapServer = cs;
	       done = True;
	    }
	    XtFree(cs);
	 }

      } // End while not done

      XtUnmanageChild(dialog);
      XSync(halApp->display, False);
      XmUpdateDisplay(dialog);

//
// Delete the dialog
//
      XtDestroyWidget(dialog);

   } // End if using an imap server

   else {	// Not using an IMAP server
      pub->appPrefs->usingImap = False;
   }

   pub->appPrefs->WriteDatabase();
   pub->appPrefs->WriteFile();

} // End QueryImap

/*---------------------------------------------------------------
 *  Method to ask the user if they will be using a POP server
 */

void
IshAppP::QueryPop()
{
   QueryAnswerT  answer;

//
// Ask if they will be using a POP server
//
   WArgList	args;
   args.DialogStyle(XmDIALOG_FULL_APPLICATION_MODAL);
   if ( halApp->questionPM ) args.SymbolPixmap(halApp->questionPM);
   Widget	dialog = XmCreateQuestionDialog(*pub, "queryPopWin", ARGS);

   XtAddCallback(dialog, XmNokCallback, (XtCallbackProc)AnswerQuery,
			 (XtPointer)&answer);
   XtAddCallback(dialog, XmNcancelCallback, (XtCallbackProc)AnswerQuery,
			 (XtPointer)&answer);
   XtAddCallback(dialog, XmNhelpCallback, (XtCallbackProc)HalAppC::DoHelp,
			 "helpcard");

//
// Don't allow window manager close function
//
   XmAddWMProtocolCallback(XtParent(dialog), halApp->delWinAtom,
			   (XtCallbackProc)PreventClose, dialog);

   XtManageChild(dialog);
   XMapRaised(halApp->display, XtWindow(XtParent(dialog)));

//
// Simulate the main event loop and wait for the answer
//
   answer = QUERY_NONE;
   while ( answer == QUERY_NONE ) {
      XtAppProcessEvent(halApp->context, XtIMXEvent);
      XSync(halApp->display, False);
   }

   XtUnmanageChild(dialog);
   XSync(halApp->display, False);
   XmUpdateDisplay(dialog);

//
// Delete the dialog
//
   XtDestroyWidget(dialog);

   if ( answer == QUERY_YES ) {

//
// Get the name and type of the POP server and the path to the "popclient"
//   command
//
      args.Reset();
      args.DialogStyle(XmDIALOG_FULL_APPLICATION_MODAL);
      args.AutoUnmanage(False);
      args.Add(XmNchildPlacement, XmPLACE_BELOW_SELECTION);
      dialog = XmCreatePromptDialog(*pub, "queryPopServerWin", ARGS);

      XtAddCallback(dialog, XmNokCallback, (XtCallbackProc)AnswerQuery,
			    (XtPointer)&answer);
      XtAddCallback(dialog, XmNcancelCallback, (XtCallbackProc)AnswerQuery,
			    (XtPointer)&answer);
      XtAddCallback(dialog, XmNhelpCallback, (XtCallbackProc)HalAppC::DoHelp,
			    "helpcard");

      Widget	serverTF = XmSelectionBoxGetChild(dialog, XmDIALOG_TEXT);

//
// Create a form for other choices
//
      args.Reset();
      args.Orientation(XmVERTICAL);
      args.Packing(XmPACK_TIGHT);
      Widget	popRC = XmCreateRowColumn(dialog, "popRC", ARGS);

//
// Add the POP2/POP3 choice buttons
//
      Widget	popTypeLabel = XmCreateLabel(popRC, "popTypeLabel", 0,0);
      Widget	popTypeFrame = XmCreateFrame(popRC, "popTypeFrame", 0,0);

      args.Reset();
      args.Orientation(XmHORIZONTAL);
      args.Packing(XmPACK_TIGHT);
      Widget	popTypeRadio = XmCreateRadioBox(popTypeFrame, "popTypeRadio",
      						ARGS);

      Widget popType2TB = XmCreateToggleButton(popTypeRadio, "popType2TB", 0,0);
      Widget popType3TB = XmCreateToggleButton(popTypeRadio, "popType3TB", 0,0);
      XtManageChild(popType2TB);
      XtManageChild(popType3TB);
      XtManageChild(popTypeRadio);

//
// Add the popclient command name
//
      Widget	popCmdLabel = XmCreateLabel    (popRC, "popCmdLabel", 0,0);
      Widget	popCmdTF    = XmCreateTextField(popRC, "popCmdTF",    0,0);

      XmTextFieldSetString(popCmdTF, pub->appPrefs->popclientCmd);

      XtManageChild(popTypeLabel);
      XtManageChild(popTypeFrame);
      XtManageChild(popCmdLabel);
      XtManageChild(popCmdTF);

      XtManageChild(popRC);

//
// Don't allow window manager close function
//
      XmAddWMProtocolCallback(XtParent(dialog), halApp->delWinAtom,
			      (XtCallbackProc)PreventClose, dialog);

      XtManageChild(dialog);
      XMapRaised(halApp->display, XtWindow(XtParent(dialog)));

//
// Loop until a name is entered or the dialog is cancelled
//
      Boolean	done = False;
      while ( !done ) {

//
// Simulate the main event loop and wait for the answer
//
	 answer = QUERY_NONE;
	 while ( answer == QUERY_NONE ) {
	    XtAppProcessEvent(halApp->context, XtIMXEvent);
	    XSync(halApp->display, False);
	 }

	 if ( answer == QUERY_CANCEL ) {
	    pub->appPrefs->usingPop = False;
	    done = True;
	 }

	 else {

	    char	*cs = XmTextFieldGetString(serverTF);
	    CharC	server(cs);
	    server.Trim();

	    if ( server.Length() == 0 ) {
	       set_invalid(serverTF, True, True);
	       pub->PopupMessage("Please enter the host name of your POP server.");
	    }
	    else {

	       pub->appPrefs->usingPop  = True;
	       pub->appPrefs->popServer = cs;
	       XtFree(cs);

	       cs = XmTextFieldGetString(popCmdTF);
	       CharC	cmd(cs);
	       cmd.Trim();
	       if ( cmd.Length() > 0 )
		  pub->appPrefs->popclientCmd = cmd;
	       else
		  pub->appPrefs->popclientCmd = "popclient -3";

	       if ( XmToggleButtonGetState(popType2TB) )
		  pub->appPrefs->popclientCmd.Replace(" -3", " -2");
	       else
		  pub->appPrefs->popclientCmd.Replace(" -2", " -3");

	       done = True;
	    }

	    XtFree(cs);
	 }

      } // End while not done

      XtUnmanageChild(dialog);
      XSync(halApp->display, False);
      XmUpdateDisplay(dialog);

//
// Delete the dialog
//
      XtDestroyWidget(dialog);

   } // End if using a pop server

   else {	// Not using a POP server
      pub->appPrefs->usingPop = False;
   }

   pub->appPrefs->WriteDatabase();
   pub->appPrefs->WriteFile();

} // End QueryPop

/*---------------------------------------------------------------
 *  Callback to auto-deselect a toggle button
 */

static void
AutoDeselect(Widget, Widget dst, XmToggleButtonCallbackStruct *src)
{
   if ( src->set )
      XmToggleButtonSetState(dst, False, False);
}

/*---------------------------------------------------------------
 *  Method to ask the user what folder type(s) they will be using
 */

void
IshAppP::QueryFolderType()
{
   QueryAnswerT  answer;

   WArgList	args;
   args.DialogStyle(XmDIALOG_FULL_APPLICATION_MODAL);
   args.AutoUnmanage(False);
   if ( halApp->questionPM ) args.SymbolPixmap(halApp->questionPM);
   Widget dialog = XmCreateQuestionDialog(*pub, "queryFolderTypeWin", ARGS);

   XtAddCallback(dialog, XmNokCallback, (XtCallbackProc)AnswerQuery,
			 (XtPointer)&answer);
   XtUnmanageChild(XmMessageBoxGetChild(dialog, XmDIALOG_CANCEL_BUTTON));
   XtAddCallback(dialog, XmNhelpCallback, (XtCallbackProc)HalAppC::DoHelp,
			 "helpcard");

//
// Don't allow window manager close function
//
   XmAddWMProtocolCallback(XtParent(dialog), halApp->delWinAtom,
			   (XtCallbackProc)PreventClose, dialog);

//
// Add toggle buttons for folder type choices
//
   Widget	typeFrame = XmCreateFrame(dialog, "typeFrame", 0,0);

//
// Set up typeRC for 1 row with equal sized columns
//
   RowColC	*typeRC = new RowColC(typeFrame, "typeRC", ARGS);

   typeRC->Defer(True);
   typeRC->SetOrientation(RcCOL_MAJOR);
   typeRC->SetRowCount(1);
   typeRC->SetColAlignment(XmALIGNMENT_CENTER);
   typeRC->SetColWidthAdjust(RcADJUST_NONE);
   typeRC->SetColResize(True);
   typeRC->SetUniformCols(True);

   Widget	unixTB = XmCreateToggleButton(*typeRC, "unixTB", 0,0);
   Widget	mhTB   = XmCreateToggleButton(*typeRC, "mhTB",   0,0);
   Widget	mmdfTB = XmCreateToggleButton(*typeRC, "mmdfTB", 0,0);
   Widget	noneTB = XmCreateToggleButton(*typeRC, "noneTB", 0,0);

   AddValueChanged(noneTB, AutoDeselect, unixTB);
   AddValueChanged(noneTB, AutoDeselect, mhTB);
   AddValueChanged(noneTB, AutoDeselect, mmdfTB);
   AddValueChanged(unixTB, AutoDeselect, noneTB);
   AddValueChanged(mmdfTB, AutoDeselect, noneTB);
   AddValueChanged(mhTB,   AutoDeselect, noneTB);

   typeRC->AddChild(unixTB);
   typeRC->AddChild(mhTB);
   typeRC->AddChild(mmdfTB);
   if ( pub->appPrefs->usingImap ) typeRC->AddChild(noneTB);

   typeRC->Defer(False);

   XtManageChild(*typeRC);
   XtManageChild(typeFrame);

//
// Display the appropriate message
//
   StringC	msgStr;
   if ( pub->appPrefs->usingImap )
      msgStr = get_string(dialog, "imapMessageString",
	     "Which folder type(s) will you be using on your local machine?");
   else
      msgStr = get_string(dialog, "messageString",
				  "Which folder type(s) will you be using?");

   WXmString	wstr = (char*)msgStr;
   XtVaSetValues(dialog, XmNmessageString, (XmString)wstr, NULL);

   XtManageChild(dialog);
   XMapRaised(halApp->display, XtWindow(XtParent(dialog)));

//
// Loop until at least one type is selected
//
   int		typeCount = 0;
   while ( typeCount == 0 ) {

//
// Simulate the main event loop and wait for the answer
//
      answer = QUERY_NONE;
      while ( answer == QUERY_NONE ) {
	 XtAppProcessEvent(halApp->context, XtIMXEvent);
	 XSync(halApp->display, False);
      }

      Boolean	usingUnix = XmToggleButtonGetState(unixTB);
      Boolean	usingMh   = XmToggleButtonGetState(mhTB);
      Boolean	usingMmdf = XmToggleButtonGetState(mmdfTB);

      typeCount = (usingMh		    ? 1 : 0)
		+ (usingUnix		    ? 1 : 0)
		+ (usingMmdf		    ? 1 : 0)
		+ (pub->appPrefs->usingImap ? 1 : 0);
      if ( typeCount == 0 )
	 pub->PopupMessage("Please select at least one folder type.");
      else {
	 pub->folderPrefs->usingUnix = usingUnix;
	 pub->folderPrefs->usingMh   = usingMh;
	 pub->folderPrefs->usingMmdf = usingMmdf;
      }

   } // End while not done

   XtUnmanageChild(dialog);
   XSync(halApp->display, False);
   XmUpdateDisplay(dialog);

//
// Delete the dialog
//
   delete typeRC;
   XtDestroyWidget(dialog);

//
// If there was more than one type selected, find out which one will be
//    the default type
//
   if ( typeCount > 1 ) {

      Widget	unixTB = NULL;
      Widget	mhTB   = NULL;
      Widget	mmdfTB = NULL;
      Widget	imapTB = NULL;

      args.Reset();
      args.DialogStyle(XmDIALOG_FULL_APPLICATION_MODAL);
      args.AutoUnmanage(False);
      if ( halApp->questionPM ) args.SymbolPixmap(halApp->questionPM);
      dialog = XmCreateQuestionDialog(*halApp, "defFolderTypeWin", ARGS);

//
// Add buttons for folder type
//
      Widget frame = XmCreateFrame   (dialog, "typeFrame", 0,0);
      Widget radio = XmCreateRadioBox(frame,  "typeRadio", 0,0);

      if ( pub->appPrefs->usingImap ) {
	 imapTB = XmCreateToggleButton(radio, "imapTB", 0,0);
	 XtManageChild(imapTB);
      }

      if ( pub->folderPrefs->usingUnix ) {

	 unixTB = XmCreateToggleButton(radio, "unixTB", 0,0);
	 XtManageChild(unixTB);

	 if ( pub->appPrefs->usingImap )
	    msgStr = get_string(unixTB, "imapLabelString",
	    				"Unix on local machine");
	 else
	    msgStr = get_string(unixTB, "labelString", "Unix");

	 wstr = (char*)msgStr;                      
	 XtVaSetValues(unixTB, XmNlabelString, (XmString)wstr, NULL);
      }

      if ( pub->folderPrefs->usingMh ) {

	 mhTB   = XmCreateToggleButton(radio, "mhTB",   0,0);
	 XtManageChild(mhTB);

	 if ( pub->appPrefs->usingImap )
	    msgStr = get_string(mhTB, "imapLabelString",
				      "MH on local machine");
	 else
	    msgStr = get_string(mhTB, "labelString", "MH");

	 wstr = (char*)msgStr;                      
	 XtVaSetValues(mhTB, XmNlabelString, (XmString)wstr, NULL);
      }

      if ( pub->folderPrefs->usingMmdf ) {

	 mmdfTB = XmCreateToggleButton(radio, "mmdfTB", 0,0);
	 XtManageChild(mmdfTB);

	 if ( pub->appPrefs->usingImap )
	    msgStr = get_string(mmdfTB, "imapLabelString",
	    				"MMDF on local machine");
	 else
	    msgStr = get_string(mmdfTB, "labelString", "MMDF");

	 wstr = (char*)msgStr;                      
	 XtVaSetValues(mmdfTB, XmNlabelString, (XmString)wstr, NULL);
      }

      if ( pub->appPrefs->usingImap )
	 XmToggleButtonSetState(imapTB, True, True);
      else if ( pub->folderPrefs->usingUnix )
	 XmToggleButtonSetState(unixTB, True, True);
      else if ( pub->folderPrefs->usingMh )
	 XmToggleButtonSetState(mhTB, True, True);
      else
	 XmToggleButtonSetState(mmdfTB, True, True);

      XtManageChild(radio);
      XtManageChild(frame);

      XtAddCallback(dialog, XmNokCallback, (XtCallbackProc)AnswerQuery,
		    (XtPointer)&answer);
      XtUnmanageChild(XmMessageBoxGetChild(dialog, XmDIALOG_CANCEL_BUTTON));
      XtAddCallback(dialog, XmNhelpCallback,
		    (XtCallbackProc)HalAppC::DoHelp, "helpcard");

//
// Trap window manager close function
//
      XmAddWMProtocolCallback(XtParent(dialog), halApp->delWinAtom,
			      (XtCallbackProc)WmClose,
			      (caddr_t)&answer);

//
// Show the dialog
//
      XtManageChild(dialog);
      XMapRaised(halApp->display, XtWindow(XtParent(dialog)));

//
// Loop until a type is selected
//
      Boolean	done = False;
      while ( !done ) {

//
// Simulate the main event loop and wait for the answer
//
	 answer = QUERY_NONE;
	 while ( answer == QUERY_NONE ) {
	    XtAppProcessEvent(halApp->context, XtIMXEvent);
	    XSync(halApp->display, False);
	 }

	 Boolean	useImap = imapTB && XmToggleButtonGetState(imapTB);
	 Boolean	useUnix = unixTB && XmToggleButtonGetState(unixTB);
	 Boolean	useMh   = mhTB   && XmToggleButtonGetState(mhTB);
	 Boolean	useMmdf = mmdfTB && XmToggleButtonGetState(mmdfTB);

	 done = True;
	 if ( pub->folderPrefs->usingMh && useMh )
	    pub->folderPrefs->defFolderType = MH_FOLDER;
	 else if ( pub->folderPrefs->usingUnix && useUnix )
	    pub->folderPrefs->defFolderType = UNIX_FOLDER;
	 else if ( pub->folderPrefs->usingMmdf && useMmdf )
	    pub->folderPrefs->defFolderType = MMDF_FOLDER;
	 else if ( pub->appPrefs->usingImap && useImap )
	    pub->folderPrefs->defFolderType = IMAP_FOLDER;
	 else {
	    pub->PopupMessage("Please select a folder type.");
	    done = False;
	 }

      } // End while not done

      XtUnmanageChild(dialog);
      XSync(halApp->display, False);
      XmUpdateDisplay(dialog);

      XtDestroyWidget(dialog);

   } // End if we need to ask for the default folder type

   else {

      if ( pub->appPrefs->usingImap )
	 pub->folderPrefs->defFolderType = IMAP_FOLDER;
      else if ( pub->folderPrefs->usingMh )
	 pub->folderPrefs->defFolderType = MH_FOLDER;
      else if ( pub->folderPrefs->usingMmdf )
	 pub->folderPrefs->defFolderType = MMDF_FOLDER;
      else
	 pub->folderPrefs->defFolderType = UNIX_FOLDER;
   }

   pub->folderPrefs->WriteDatabase();
   pub->folderPrefs->WriteFile();

} // End QueryFolderType

/*---------------------------------------------------------------
 *  Method to return a usable reading window
 */

ReadWinC*
IshAppP::GetReadWin()
{
//
// First look for a displayed, unpinned window
//
   ReadWinC	*readWin = NULL;
   unsigned	count = pub->readWinList.size();
   Boolean	found = False;
   int i=0; for (i=0; !found && i<count; i++) {

      readWin = (ReadWinC*)*pub->readWinList[i];
      if ( readWin->IsShown() && !readWin->Pinned() ) {
	 if ( !readWin->IsIconified() )
	    readWin->HalTopLevelC::Show();	// Pop it to the top
	 found = True;
      }

   } // End for each existing composition window

//
// Then look for an undisplayed window
//
   for (i=0; !found && i<count; i++) {
      readWin = (ReadWinC*)*pub->readWinList[i];
      found = !readWin->IsShown();
   }

//
// If we didn't find a window, we need to create a new one
//
   if ( !found ) {
      pub->BusyCursor(True);
      if ( debuglev > 0 ) cout <<"Creating reading window" NL;
      readWin = new ReadWinC("readWin", *halApp);
      void	*tmp = (void*)readWin;
      pub->readWinList.add(tmp);
      pub->BusyCursor(False);
   }

   return readWin;

} // End GetReadWin

/*---------------------------------------------------------------
 *  Method to see if the user want's to restart any crashed edits.
 */

void
IshAppP::EditSavedCompositions()
{
   int		count = compFileList.size();
   if ( count < 1 ) return;

   WArgList	args;
   args.DialogStyle(XmDIALOG_FULL_APPLICATION_MODAL);
   args.AutoUnmanage(True);
   if ( halApp->questionPM ) args.SymbolPixmap(halApp->questionPM);
   Widget dialog = XmCreateQuestionDialog(*pub, "queryEditCompWin", ARGS);

   XtAddCallback(dialog, XmNokCallback, (XtCallbackProc)FinishEditSavedComp,
			 this);
   XtAddCallback(dialog, XmNcancelCallback, (XtCallbackProc)DeleteSavedComp,
			 this);
   XtAddCallback(dialog, XmNhelpCallback, (XtCallbackProc)HalAppC::DoHelp,
			 "helpcard");

   Widget	noPB = XmCreatePushButton(dialog, "noPB", 0,0);
   AddActivate(noPB, CancelEditSavedComp, this);
   XtManageChild(noPB);

   StringC	label = get_string(dialog, XmNmessageString,
				  "Resume edit of composition(s) in progress?");
   StringC	countStr;
   countStr += (int)compFileList.size();
   label.Replace("$COUNT", countStr);

   WXmString	wstr = (char*)label;
   XtVaSetValues(dialog, XmNmessageString, (XmString)wstr, NULL);

   XtManageChild(dialog);

} // End EditSavedCompositions

/*---------------------------------------------------------------
 *  Callback to reopen user's crashed edits.
 */

void
IshAppP::FinishEditSavedComp(Widget dialog, IshAppP *This, XtPointer)
{
   u_int	count = This->compFileList.size();
   StringC	file;
   int i=0; for (i=0; i<count; i++) {

      file = ishApp->compPrefs->AutoSaveDir();
      if ( !file.EndsWith('/') ) file += '/';
      file += *This->compFileList[i];

      SendWinC	*win  = This->pub->GetSendWin();
      win->LoadFile(file);
      win->SetAutoSaveFile(file);
      win->Show();
   }
   This->compFileList.removeAll();

   XtDestroyWidget(dialog);

} // End FinishEditSavedComp

/*---------------------------------------------------------------
 *  Callback to deleted user's crashed edits.
 */

void
IshAppP::DeleteSavedComp(Widget dialog, IshAppP *This, XtPointer)
{
   u_int	count = This->compFileList.size();
   StringC	file;
   int i=0; for (i=0; i<count; i++) {

      file = ishApp->compPrefs->AutoSaveDir();
      if ( !file.EndsWith('/') ) file += '/';
      file += *This->compFileList[i];

      unlink(file);
   }
   This->compFileList.removeAll();

   XtDestroyWidget(dialog);

} // End DeleteSavedComp

/*---------------------------------------------------------------
 *  Callback to delay user's crashed edits.
 */

void
IshAppP::CancelEditSavedComp(Widget dialog, IshAppP*, XtPointer)
{
   XtDestroyWidget(dialog);
}

