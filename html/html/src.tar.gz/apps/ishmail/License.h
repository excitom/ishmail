/*
 * $Id: License.h,v 1.1 1998/06/24 01:32:30 lang Exp $
 *
 * Copyright (c) 1994 HAL Computer Systems International, Ltd.
 * 
 *          HAL COMPUTER SYSTEMS INTERNATIONAL, LTD.
 *                  1315 Dell Avenue
 *                  Campbell, CA  95008
 *
 * Author: Greg Hilton
 * Contributors: Tom Lang, Frank Bieser, and others
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * http://www.gnu.org/copyleft/gpl.html
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#ifndef _License_h_
#define _License_h_

#define RELAX_LICENSE 1

#include <hgl/StringListC.h>

#include <time.h>

class LicInfoC {

public:

   enum LicErrT {

      LIC_OK = 0,
      LIC_NO_FILE,
      LIC_EOF,
      LIC_SYSERR,
      LIC_NO_MOUNT,
      LIC_BAD_SUM,
      LIC_BAD_HOST,
      LIC_WRONG_HOST,
      LIC_WRONG_PROD,
      LIC_BAD_DATE,
      LIC_BAD_USER,
      LIC_WRONG_USER,
      LIC_WARNING
   };

   Boolean	needsLicense;	// False on HaL machines
   int		key;		// Checksum
   StringC	prod;		// Name of licensed product
   StringC	ver;		// licensed Version number
   time_t	startTime;	// Date after which license is valid
   time_t	endTime;	// Date after which license is invalid
   StringC	addr;		// IP address of host on which license file
				// is valid
   int		userCount;	// Number of allowed users
   StringListC	userList;	// Names of allowed users
   StringC	file;		// Name of license file
   StringC	host;		// Host on which file resides
   StringC	user;		// Current user
   int		readOnly;	// If file is read-only

   LicErrT	status;		// Status of most recent operation
   StringC	msg;		// Text of most recent error

   LicInfoC(const char*);	// Constructor

   void		CheckDate(time_t);
   void		CheckHost(const char*);
   void		CheckKey();
   void		CheckProd(const char*, const char*);
   void		GetHostName();
   void		Init();
   int		IsDemo();
   void		ReadFile();
   int		UserOk();

};

#endif // _License_h_
