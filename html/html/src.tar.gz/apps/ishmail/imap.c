#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <netinet/in.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <errno.h>
#include <string.h>

#define BSIZE 8192

struct reply
{
   char otag[128];		/*the orignal tag sent with the reply*/
   char tag[128];		/*the tag returned from imap*/
   int count;			/*the amount in buf*/
   char buf[BSIZE];		/*the full text of reply*/
   char* ptr;			/*pointer to buf, used to step thru buf*/
};

struct mailbox
{
   char host[64];
   char box[64];
};

struct message
{
   char* header;
   char* text;
   int text_size;
   int total_size;
};

struct reply msg;
struct mailbox box_info; 
struct message mail;

unsigned long tag=0;
int sock;

void do_cmd(void);
void login(void);
void write_sock(char*);
void read_sock(void);
void print_help(void);
void open_mailbox(char*);
void open_server(char*);
void list_mailboxes(char*);
int parse_mbox(char*);
int open_sock(char*);
void parse_reply(struct reply*);
char* getline(struct reply*);
void parse_line(char*);
void parse_unsolicited(char*);
void parse_fetched(char*);
void parse_flags(void);

/**************************************************/
void main()
{
   do_cmd();
}

/**************************************************/
void
do_cmd()
{
   char command[512];
   char x[8];
   char tmp[128];
   char tmp2[128];

   print_help();
   do
   {
      printf("\nEnter command: ");
      scanf("%s",x); 
      switch (*x)
      {
	 case 's':
	    printf("server: ");
	    scanf("%s", tmp);
	    open_server(tmp);
	    break;

	 case 'l':
	    printf("pattern: ");
	    scanf("%s", tmp);
	    list_mailboxes(tmp);
	    break;

	 case 'o':
	    printf("mailbox: ");
	    scanf("%s", tmp);
	    open_mailbox(tmp);
	    break;

         case 'q':
            if(sock)
	    {
	       sprintf(command,"LOGOUT"); 
	       write_sock(command);
	       read_sock();
               parse_reply(&msg);
               close(sock);
	    }
	    break;

	 case 'n':
	    sprintf(command,"NOOP");
	    write_sock(command);
	    read_sock();
            parse_reply(&msg);
	    break;

	 case 'f':
	    printf("Enter the number of the message to fetch, and what to fetch\n");
	    printf("(# part): ");
	    scanf("%s %s", tmp, tmp2);
	    sprintf(command,"FETCH %s %s", tmp, tmp2);
	    write_sock(command);
	    read_sock();
            parse_reply(&msg);
	    break;

         case '?':
	    print_help();
	    break;   

	 default:
	    printf("????I don't know what that means????\n");
      }
   }
   while( strcmp(x,"q") );
}

/**************************************************/
void
parse_reply(struct reply* msg)
{
#if 0
   char* line;
   char* word;

   while ( msg->count > 0 )
   {
      line = getline(msg);
      printf("+++ %s\n", line);
/*      parse_line(line);
*/

      if( word = strtok(line, " ") )		/*get the first word*/
      {
         strcpy(msg->tag, word);

         if ( *msg->tag == '*' )
	    parse_unsolicited(strtok(NULL, "\0") );
         else if ( !strcmp(msg->tag, msg->otag) )
         {
            if ( !strcmp( strtok(NULL, " "), "OK") )
	       printf("Solicited reply OK\n");
	    else
	    {
	       printf("Solicited reply is strange, error is\n");
	       printf("!!!!%s\n", strtok(NULL, "\0") );  /*print the error message*/
            }
         }
         else 
            printf("!!!!imap sent a reply that I don't understand!!!!\n");
      }
   }
#endif
}

/**************************************************/
void
parse_unsolicited(char* str)
{
   char* tmp;
   char* s;
   long msg_num;

   msg_num = strtol( tmp = strtok(str, " "), &s, 10);
   if (*s)					/*not a number*/
   {
      if ( !strcmp(tmp, "OK") )
	 printf("UNsolicited reply OK\n");
      else if (!strcmp(tmp, "FLAGS") )
	 parse_flags();
      else if (!strcmp(tmp, "MAILBOX") )
	 ;
      else if (!strcmp(tmp, "BYE") )
      {
         printf("UNsolicited reply BYE\n");
	 sock = NULL;
      } 
      else
	 printf("!!!!UNsolicited reply not OK\n");
   }
   else						/*is a number*/
   {
      if ( !strcmp(tmp = strtok(NULL, " "), "EXISTS") )
	 printf("UNsolicited reply is EXISTS\n"); 
      else if ( !strcmp(tmp, "RECENT") ) printf("UNsolicited reply is RECENT\n");
      else if ( !strcmp(tmp, "EXPUNGE") ) printf("UNsolicited reply is EXPUNGE\n");
      else if ( !strcmp(tmp, "FETCH") ) parse_fetched(NULL);
      else printf("!!!!UNsolicited, Don't know the word after the reply number\n");
   }
}

/**************************************************/
void
parse_fetched(char* str)
{
   char* tmp;
   char* tmp2;
   long num;

   tmp = strtok( NULL, " " );		/*look for the next word, which should tell*/
					/*what is being fetched*/

   if ( *tmp == '(' )			/*remove the "(" from beginning of string*/
      tmp++;
   
   if ( !strcmp( tmp, "RFC822.TEXT" ) )	/*see what is being fetched*/
   {
      tmp  = strtok( NULL, " " );	/*get the next word; should be the size, and*/
      tmp2 = ++tmp;			/*skip over first char, which should be "{"*/
      while ( *(tmp2++) != '}' );	/*find the ending "}"*/
      *tmp2 = '\0';			/*tie-off string*/

      num = strtol( tmp, &tmp2, 10 );	/*change the string to a number*/

      mail.text = (char*)malloc(num+1);		/*allocate memory for the message text*/
      mail.text[num] = '\0';                    /*tie-off*/

      tmp = mail.text;
      while ( num > msg.count-3)		/*message is too big, need to read*/
      {						/*more from socket*/
         strncpy( tmp, msg.ptr, msg.count );	/*copy the text*/
         tmp += msg.count;			/*save the end of this part of msg*/
	 num -= msg.count;
	 read_sock();
      }
      strncpy( tmp, msg.ptr, num );	/*copy the text*/

printf("mail.text =%s=\n",mail.text);

      msg.count -= num;				/*increment message.count and ptr*/
      msg.ptr += num;				/*to point to end of message text*/
printf("msg.count =%d\n",msg.count);
printf("msg.ptr =%s=\n",msg.ptr);

	/*see if there is anything else tacked on to the end of this unsolicited reply*/
/*   while( *(msg.ptr++) == ' ' );	skip over any blank space
   if( *msg.ptr == ')' )
*/
      tmp = getline(&msg);
      if ( tmp2 = strtok(tmp, " " ) )
      {
        if ( !strcmp( tmp2, "FLAGS" ) )
           parse_flags();
      }
   }
}

/**************************************************/
void
parse_flags(void)
{

printf("entering parse_flags\n");

}

/**************************************************/
char*
getline(struct reply* msg)
{
   char* tmp = msg->ptr;

   while( msg->count > 0 )
   {
      while ( (msg->count > 0) && (*msg->ptr != '\015') )
      {
         msg->count--;
         msg->ptr++;
      }
      if ( *(msg->ptr+1) == '\012' )
      {
         *(msg->ptr) = '\0';		/*tie-off*/
	 msg->ptr += 2;			/*increment pointer to next line*/
	 msg->count -= 2;
         return(tmp);
      }
   }
printf("!!!!imapd sent a badly formatted reply!!!!\n");
/*     read_sock();
*/
}

/**************************************************/
void
parse_line(char* ptr)
{
   char* tmp;

   tmp = ptr;
   while ( *ptr != ' ' )
   {
      if( *ptr == '\0' )
      {
        printf("One word =%s=\n",tmp);
	strcpy(msg.tag, "junk");
        return;
      }
      ptr++;
   }
   *ptr++ = '\0'; 

   strcpy(msg.tag,tmp);
printf("tag =%s=  rest =%s=\n", msg.tag, ptr);
}

/**************************************************/
void
login(void)
{
   char userid[64];
   char password[64];
   char command[512];

   printf("userid: ");
   scanf("%s", userid);
   printf("password: ");
   scanf("%s", password);
   sprintf(command,"LOGIN %s %s", userid, password);

   write_sock(command);
   read_sock();
   parse_reply(&msg);
}

/**************************************************/
void
open_server(char* serv)
{
   char command[512];

   if( open_sock(serv) < 0 ) return;
   read_sock();
   parse_reply(&msg);
   login();
}

/**************************************************/
void
list_mailboxes(char *pat)
{
   char command[512];

   sprintf(command,"FIND ALL.MAILBOXES %s", pat);
   write_sock(command);
   read_sock();
   parse_reply(&msg);
}

/**************************************************/
void
open_mailbox(char* mbox)
{
   char command[512];

   sprintf(command,"SELECT %s", mbox);
   write_sock(command);
   read_sock();
   parse_reply(&msg);
}

/**************************************************/
int
parse_mbox(char* mbox)
{
   long i;
   char* s;
   char* t;

   if( !( *mbox == '{' && (t = strchr(s=mbox+1,'}')) && (i = t - s )) )
   {
      printf("!!!!mailbox format wrong\n");
      return (-1);
   }
   else
   {
      strncpy(box_info.host, s, i);  /* copy host name */
      box_info.host[i] = '\0';       /* tie off name */
      strcpy(box_info.box, t+1);     /* copy mailbox name */
   }
   return(1);
}

/**************************************************/
void
read_sock()
{
   char*	ptr=msg.buf;
   int		i, nread=0;
   fd_set	fds;
   struct timeval timeout;
	
   if(!sock) return;
   FD_ZERO(&fds);

   timeout.tv_sec = 5;
   timeout.tv_usec = 0;

   msg.count = 0;
   while ( nread < 1 )
   {
      FD_SET(sock, &fds);
      i = select(sock+1, &fds, (fd_set*)0, (fd_set*)0, &timeout);
      if ( i == 0 )
      {
	 printf("!!!!!!read select() timed out!!!!\n");
	 return;
      }
      nread = read( sock, ptr, BSIZE );
      if ( nread > 4090 )
	 printf("!!!!reply is bigger than max size!!!!\n");
      if ( nread < 0 ) 
      {
	 printf("!!!!!!!couldn't read from socket!!!!\n");
         return;
      }
      msg.count += nread;
      ptr += nread;
      *ptr = '\0';      /*tie-off string with null*/
   }

   msg.ptr = msg.buf;

   i=msg.count;
   ptr=msg.buf;
/*   while ( i-- >= 0 )
   {  
      printf(" %d", *ptr++);
   }
   printf("\n%s\n", msg.buf);
*/
   printf("%s\n", msg.buf);
}

/**************************************************/
void
write_sock(char* cmd)
{
   int		i, size, nwrite=0;
   fd_set	fds;
   struct timeval timeout;
   char ccmd[512];

   if(!sock) return;

   sprintf(msg.otag, "A%05ld", tag++); 
   sprintf(ccmd,"%s %s\n", msg.otag, cmd);

   size = strlen(ccmd);

   FD_ZERO(&fds);

   timeout.tv_sec = 5;
   timeout.tv_usec = 0;

   while ( size > 1 )
   {
      FD_SET(sock, &fds);
      i = select(sock+1, (fd_set*)0, &fds, (fd_set*)0, &timeout);
      if ( i == 0 )
      {
	 printf("!!!!write select() timed out!!!!\n");
	 return;
      }
      printf("--> %s\n", ccmd);
      nwrite = write( sock, ccmd, size );
      if ( nwrite < 0 ) 
      {
	 printf("!!!!couldn't write to socket!!!!\n");
         return;
      }
   size -= nwrite;
   }
}

/**************************************************/
int 
open_sock(char* hname)
{
   struct sockaddr_in sin;
   struct hostent *host_name;
   long  port = 143;
   char** listptr;
   struct in_addr *ptr;

   if( !(host_name = gethostbyname(hname)) )
   {
      printf("!!!!invalid host name\n");
      return(-1);
   }

/*printf("ip of %s====%s====\n", hname, inet_ntoa(*host_name->h_addr_list) );
*/
   bzero((char*)&sin, sizeof(sin));
   sin.sin_family = AF_INET;
   sin.sin_port = htons(port);
   bcopy(host_name->h_addr, (char*)&sin.sin_addr, host_name->h_length);

   if (( sock = socket(AF_INET, SOCK_STREAM, 0)) < 0)
   {
      printf("failed to create TCP socket\n");
      sock = NULL;
      return(-1);
   }
   printf("opened socket\n");

   if( connect(sock, (struct sockaddr*)&sin, sizeof(sin))  < 0)
   {
      printf("!!!!failed to connect to socket!!!!\n");
      printf("errno = %d",errno);
      sock = NULL;
      return(-1);
   }
   printf("connected to socket\n");

   return(1);
}

/**************************************************/
void
print_help()
{
   printf("------------------------------------------------\n");
   printf("  ENTER:	\"q\" to quit\n");
   printf("		\"s\" to connect to a server\n");	
   printf("		\"l\" to list mailboxes\n");	
   printf("		\"o\" to select a mailbox\n");	
   printf("		\"m\" to list messages\n");	
   printf("		\"n\" to do the NOOP command\n");	
   printf("		\"f\" to fetch some mail\n");	
   printf("		\"?\" for help\n");	
   printf("------------------------------------------------\n");
}
 * 
 *          HAL COMPUTER SYSTEMS INTERNATIONAL, LTD.
 *                  1315 Dell Avenue
 *                  Campbell, CA  95008
 *
 * Author: Greg Hilton
 * Contributors: Tom Lang, Frank Bieser, and others
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * http://www.gnu.org/copyleft/gpl.html
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
