/*
 *  $Id: ImapServerC.h,v 1.1 1998/06/24 01:32:30 lang Exp $
 *  
 *  Copyright (c) 1994 HAL Computer Systems International, Ltd.
 * 
 *          HAL COMPUTER SYSTEMS INTERNATIONAL, LTD.
 *                  1315 Dell Avenue
 *                  Campbell, CA  95008
 *
 * Author: Greg Hilton
 * Contributors: Tom Lang, Frank Bieser, and others
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * http://www.gnu.org/copyleft/gpl.html
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
#ifndef _ImapServerC_h_
#define _ImapServerC_h_

#include <hgl/StringC.h>

class CharC;
class StringListC;
class IntListC;
class ImapFolderC;

#define SHARE_IMAP_SERVER

class ImapServerC {

   Boolean	RetryLogin(char*);
   void		GetServerType();

public:

   StringC	name;
   StringC	user;
   StringC	pass;
   int		type;
   int		sock;
   Boolean	connected;
   StringC	folder;
   struct hostent	*host;

   ImapServerC(const char*);
   ~ImapServerC();

   Boolean	Append(CharC, CharC, StringListC&);
   Boolean	Append(CharC, StringListC&, char*, StringListC&);
   Boolean      Connect();
   Boolean	Copy(int, CharC, StringListC&);
   Boolean	Create(CharC, StringListC&);
   Boolean	Delete(CharC, StringListC&);
   Boolean	Exists(CharC);
   Boolean	Expunge(StringListC&);
   void		ExpandList(StringListC&, StringListC&);
   Boolean	FetchHdrs(int, ImapFolderC*, int*, char**, char**, StringC&);
   void		FetchFlush( StringC& );
   Boolean	Fetch(int, CharC, char**, char**, StringC&);
   void		GenTag(StringC&);
   Boolean	GetLine(StringC&);
   Boolean	ListMailboxes(CharC, StringListC&, StringListC&);
   Boolean	Login(CharC, CharC, StringListC&);
   Boolean	Logout(StringListC&);
   Boolean	Noop(StringListC&);
   Boolean	PutLine(CharC, Boolean terminate=True);
   Boolean      ReConnect();
   Boolean	Rename(CharC, CharC, StringListC&);
   Boolean	RunCommand(CharC, StringListC&);
   Boolean	Search(CharC, IntListC&, StringListC&);
   Boolean	Select(CharC, StringListC&);
   Boolean	SetFlags(int, u_int);
   void		Unexpected(CharC);
};

#define IMAP_SERVER_PORT	143

extern ImapServerC	*FindImapServer(char*);
extern void		 CloseImapServerConnections();

#endif // _ImapServerC_h_
