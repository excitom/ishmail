/*
 * $Id: GraphC.C,v 1.1 1998/06/24 01:29:07 lang Exp $
 *
 * Copyright (c) 1993 HAL Computer Systems International, Ltd.
 * 
 *          HAL COMPUTER SYSTEMS INTERNATIONAL, LTD.
 *                  1315 Dell Avenue
 *                  Campbell, CA  95008
 *
 * Author: Greg Hilton
 * Contributors: Tom Lang, Frank Bieser, and others
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * http://www.gnu.org/copyleft/gpl.html
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#include "HalAppC.h"
#include "GraphC.h"
#include "rsrc.h"

#include <Xm/DrawingA.h>

Pixmap		GraphC::pixmap       = (Pixmap)NULL;
int		GraphC::pixmapRefCnt = 0;
Dimension	GraphC::pixmapWd     = 0;
Dimension	GraphC::pixmapHt     = 0;

/*----------------------------------------------------------------------
 * GraphC constructor
 */

GraphC::GraphC(Widget parent, const char *name, ArgList argv, Cardinal argc)
{
   da = XmCreateDrawingArea(parent, (char *)name, argv, argc);
   Init();
}

GraphC::GraphC(Widget _da)
{
   da = _da;
   Init();
}

void
GraphC::Init()
{
   win = (Window)NULL;
   gc  = NULL;

//
// Add callbacks to detect exposures and resizes
//
   XtAddCallback(da, XmNexposeCallback, (XtCallbackProc)ExposeCB,
		 (XtPointer)this);
   XtAddCallback(da, XmNresizeCallback, (XtCallbackProc)ResizeCB,
		 (XtPointer)this);

//
// Add event handler to detect visibility changes
//
   obscured = True;
   XtAddEventHandler(da, VisibilityChangeMask, False,
		     (XtEventHandler)HandleVisChange, (XtPointer)this);

//
// Read attributes
//
   deferred   = get_boolean("GraphC", da, "deferred", False);
   deferCount = deferred ? 1 : 0;

   XtVaGetValues(da, XmNmarginWidth, &marginWd, XmNmarginHeight, &marginHt, 0);

   return;

} // End GraphC Init

/*----------------------------------------------------------------------
 * Graphc destructor
 */

GraphC::~GraphC()
{
   if ( !halApp->xRunning ) return;

   if ( gc ) {
      XtReleaseGC(da, gc);
      if ( pixmapRefCnt > 0 ) {
	 pixmapRefCnt--;
	 if ( pixmapRefCnt == 0 ) {
	    XFreePixmap(halApp->display, pixmap);
	    pixmap = (Pixmap)NULL;
	 }
      }
   }

   XtDestroyWidget(da);
}

/*----------------------------------------------------------------------
 * Callback to handle expose
 */

void
GraphC::ExposeCB(Widget, GraphC *This, XmDrawingAreaCallbackStruct *db)
{
   XExposeEvent *ev = (XExposeEvent*)db->event;

   if ( ev->count > 0 ) return;		// Wait for last event

   if ( !This->gc ) {
//
// Create graphics context
//
      This->win = XtWindow(This->da);

      XtGCMask	fixMask = 0;
      XtGCMask	naMask  = 0;

      XtGCMask	modMask = GCFunction | GCPlaneMask | GCForeground
			| GCBackground | GCLineWidth | GCLineStyle | GCCapStyle
			| GCJoinStyle | GCFillStyle | GCFillRule | GCTile
			| GCStipple | GCTileStipXOrigin | GCTileStipYOrigin
			| GCFont | GCSubwindowMode | GCGraphicsExposures
			| GCClipXOrigin | GCClipYOrigin | GCClipMask
			| GCDashOffset | GCDashList | GCArcMode;

      XGCValues fixVals;
      This->gc = XtAllocateGC(This->da, 0, fixMask, &fixVals, modMask, naMask);

//
// Read the current size and set it to the size the user really wants
//
      XtVaGetValues(This->da, XmNwidth, &This->daWd, XmNheight, &This->daHt, 0);
      This->daWd = get_int(This->da, XmNwidth,  This->daWd);
      This->daHt = get_int(This->da, XmNheight, This->daHt);
      XtVaSetValues(This->da, XmNwidth, This->daWd, XmNheight, This->daHt, 0);

//
// Create off-screen pixmap to be used for drawing.  One pixmap is shared by
//    all graphs
//
      if ( !pixmap ) {

	 unsigned depth = DefaultDepth(halApp->display,
				       DefaultScreen(halApp->display));
	 pixmapWd = (This->daWd > pixmapWd) ? This->daWd : pixmapWd;
	 pixmapHt = (This->daHt > pixmapHt) ? This->daHt : pixmapHt;
	 pixmap =
	    XCreatePixmap(halApp->display, This->win, pixmapWd, pixmapHt,depth);
      }
      
//
// Re-create pixmap if size has increased
//
      else if ( This->daWd > pixmapWd || This->daHt > pixmapHt ) {

	 XFreePixmap(halApp->display, pixmap);
	 unsigned depth = DefaultDepth(halApp->display,
				       DefaultScreen(halApp->display));
	 pixmapWd = (This->daWd > pixmapWd) ? This->daWd : pixmapWd;
	 pixmapHt = (This->daHt > pixmapHt) ? This->daHt : pixmapHt;
	 pixmap =
	    XCreatePixmap(halApp->display, This->win, pixmapWd, pixmapHt,depth);
      }

      pixmapRefCnt++;

#if 0
// If you use backing store, the window manager refresh function doesn't work

//
// Turn on backing store
//
      unsigned long	winMask = CWBackingStore;
      XSetWindowAttributes winVals;
      winVals.backing_store = WhenMapped;
      XChangeWindowAttributes(halApp->display, This->win, winMask, &winVals);
#endif

   } // End if need gc

   This->Draw();

} // End GraphC ExposeCB

/*----------------------------------------------------------------------
 * Callback to handle resize
 */

void
GraphC::ResizeCB(Widget, GraphC *This, XtPointer)
{
   if ( !This->gc ) return;

//
// Get the size of the counter
//
   XtVaGetValues(This->da, XmNwidth, &This->daWd, XmNheight, &This->daHt, NULL);

//
// Re-create pixmap if size has increased
//
   if ( This->daWd > pixmapWd || This->daHt > pixmapHt ) {

      XFreePixmap(halApp->display, pixmap);
      unsigned  depth = DefaultDepth(halApp->display,
				     DefaultScreen(halApp->display));
      pixmapWd =  (This->daWd > pixmapWd) ? This->daWd : pixmapWd;
      pixmapHt =  (This->daHt > pixmapHt) ? This->daHt : pixmapHt;
      pixmap = XCreatePixmap(halApp->display, This->win, pixmapWd, pixmapHt,
			     depth);
   }

//
// Redraw
//
   This->Draw();

} // End GraphC ResizeCB

/*-----------------------------------------------------------------------
 *  Event handler for visibility changes
 */

void
GraphC::HandleVisChange(Widget, GraphC *This, XVisibilityEvent *ev, Boolean*)
{
   Boolean	obscured;
   obscured = (ev->state == VisibilityFullyObscured);

   if ( This->obscured != obscured ) {
      This->obscured = obscured;
      if ( !obscured ) This->Draw();
   }

} // End GraphC HandleVisChange

/*-----------------------------------------------------------------------
 *  Method to set deferral mode
 */

void
GraphC::Defer(Boolean on)
{
   if      ( on )       deferCount++;
   else if ( deferred ) deferCount--;

   deferred = (deferCount > 0);

   if ( !deferred && gc ) Draw();

} // End GraphC Defer

/*----------------------------------------------------------------------
 * Method to return the margin width and height
 */

void
GraphC::GetMargins(Dimension *wd, Dimension *ht) const
{
   *wd = marginWd;
   *ht = marginHt;
   return;
}

/*----------------------------------------------------------------------
 * Method to set the margin width and height
 */

void
GraphC::SetMargins(Dimension wd, Dimension ht)
{
   if ( wd != marginWd || ht != marginHt ) {
      marginWd = wd;
      marginHt = ht;
      if ( !deferred && gc ) Draw();
   }

   return;
}

