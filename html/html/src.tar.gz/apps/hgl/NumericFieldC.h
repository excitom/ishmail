/*
 * $Id: NumericFieldC.h,v 1.1 1998/06/24 01:29:07 lang Exp $
 *
 * Copyright (c) 1992 HAL Computer Systems International, Ltd.
 * 
 *          HAL COMPUTER SYSTEMS INTERNATIONAL, LTD.
 *                  1315 Dell Avenue
 *                  Campbell, CA  95008
 *
 * Author: Greg Hilton
 * Contributors: Tom Lang, Frank Bieser, and others
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * http://www.gnu.org/copyleft/gpl.html
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#ifndef _NumericFieldC_h
#define _NumericFieldC_h

#include <X11/Intrinsic.h>
#include <Xm/Xm.h>
#include <Xm/TextF.h>

#include "Base.h"

class NumericFieldC
{

   public:
      enum Format { INT, HEX, FLOAT };
 
//
// The private parts.
//
   private:

      Widget            textField;
      float		value;
      enum Format	format;
      int		precis;
      float  		min;
      float  		max;
      XmTextPosition    textPos;
      Boolean		checkMin;
      Boolean		checkMax;
      Boolean		checkPrec;

//
// The callbacks.
//
   private:

      static void DoProcessInput (Widget, NumericFieldC*, XtPointer);
      static void DoCheckValue   (Widget, NumericFieldC*, XtPointer);
      static void DoActivate     (Widget, NumericFieldC*, XtPointer);

//
// The private methods.
//
   private:

      void	Build(Widget, char*, Arg*, Cardinal);
      void	InitValue();
      Boolean	ProcessFloatInput();
      Boolean	ProcessHexInput();
      Boolean	ProcessIntInput();

//
// The constructors & destructor.
//
   public:

      NumericFieldC(Widget parent, char*, Arg*, Cardinal);
      NumericFieldC(Widget parent, char*, Arg*, Cardinal, int min, int max);
      NumericFieldC(Widget parent, char*, Arg*, Cardinal, unsigned int min, unsigned int max);
      NumericFieldC(Widget parent, char*, Arg*, Cardinal, float min, float max);
      NumericFieldC(Widget parent, char*, Arg*, Cardinal, float min, float max, int prec);
     ~NumericFieldC();

//
// The public methods.
//
   public:

      inline float 	GetMax() 	  const { return min; }
      inline float 	GetMin()  	  const { return min; }
      inline float      GetValue()        const { return (float)value; }
      inline int 	Precision() 	  const { return precis; }
      void		CheckValue();
      void		CheckMin(Boolean);
      void		CheckMax(Boolean);
      void		CheckPrecision(Boolean);
      void		ProcessInput();
      void		SetMax(float);
      inline void	SetMax(int v)           { SetMax((float)v); }
      inline void	SetMax(unsigned int v)  { SetMax((float)v); }
      void		SetMin(float);
      inline void	SetMin(int v)           { SetMin((float)v); }
      inline void	SetMin(unsigned int v)  { SetMin((float)v); }
      void		SetPrecision(int);
      void		SetValue(char*);
      void		SetValue(float);
      inline void	SetValue(int v)         { SetValue((float)v); }
      void              SetFormat(enum Format);
      void              SetFormat(enum Format, int prec);

//
//    Set the value.
//
      inline void       operator=(float    v) { SetValue(v); }
      inline void       operator=(int      v) { SetValue(v); }
      inline void       operator=(char*    v) { SetValue(v); }
      inline void       operator=(long     v) { SetValue((float)v); }
      inline void       operator=(double   v) { SetValue((float)v); }
      inline void       operator=(unsigned v) { SetValue((float)v); }

//
//    Get the value.
//
      inline operator  float()    const { return value;           }
      inline operator  int()      const { return (int)value;      }
      inline operator  long()     const { return (long)value;     }
      inline operator  double()   const { return (double)value;   }
      inline operator  unsigned() const { return (unsigned)value; }
      inline operator  char*()    const { return XmTextFieldGetString(textField); }
      inline operator  Widget()   const { return textField; }

      MEMBER_QUERY (Widget, 	TextField,	textField);

};

#endif
