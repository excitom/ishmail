/*
 *  $Id: TermC-hp.C,v 1.1 1998/06/24 01:29:07 lang Exp $
 *  
 *  Copyright (c) 1994 HAL Computer Systems International, Ltd.
 * 
 *          HAL COMPUTER SYSTEMS INTERNATIONAL, LTD.
 *                  1315 Dell Avenue
 *                  Campbell, CA  95008
 *
 * Author: Greg Hilton
 * Contributors: Tom Lang, Frank Bieser, and others
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * http://www.gnu.org/copyleft/gpl.html
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

   signal(SIGCHLD, SIG_DFL);	// We're not particularly interested

   setpgrp();			// First time for luck

//
// Close everything in sight
//
#ifndef NFILES
#define NFILES	64
#endif

   for (int i=0; i<NFILES; i++) close(i);

//
// Open /dev/tty and disassociate ourselves from it
//
   int	fd;
#ifdef TIOCNOTTY
   fd = open("/dev/tty", O_RDWR, 0);
   if ( fd >= 0 ) {
      ioctl(fd, TIOCNOTTY, 0);
      close(fd);
   }
#endif

//
// Make the pty be the controlling terminal of the process.
//
   setpgrp();

//
// Open the slave side for stdin and dup twice for stdout and stderr.
// We need to open all fd's read/write since some weird applications
// (like "more") READ from stdout/stderr or WRITE to stdin!
// Ack, bletch, barf.
//
// This should also take care of the controlling TTY. I hope.
//
   fd = open(name, O_RDWR, 0);		// 0
   dup(fd);				// 1
   dup(fd);				// 2
   if ( debuglev > 1 ) cout <<"Opened stdin in child: " <<fd <<endl;

//
// Now open the tty for our new process group
//
   fd = open("/dev/tty", O_RDWR, 0);
   if ( fd >= 0 ) close(fd);

//
// It's MINE, I tell you! Mine! Mine! Mine!
//
   chown(name, uid, gid);
   chmod(name, 0622);

//
// set various signals to non annoying (for SYSV) values
//
   if ( getpgrp() == getpid() ) {
      signal(SIGINT,  exit);
      signal(SIGQUIT, exit);
      signal(SIGTERM, exit);
   }
   else {
      signal(SIGINT,  SIG_IGN);
      signal(SIGQUIT, SIG_IGN);
      signal(SIGTERM, SIG_IGN);
   }
   signal(SIGPIPE, exit);

#if 0
/* Now is the time to add the utmp entry */
   tty_add_utmp(w);
#endif

//
// since we may be setuid root (for utmp), be safe
//
   setuid(uid);
   setgid(gid);

#ifdef HPUX_PIPE
//
// Close the parent sides
//
   close(outputFd);
   close(inputFd);

//
// Set the effective group id to the real group id.  We don't want to
//    run any child processes with the setgid permissions on.
//
   setresgid(gid, gid, gid);

//
// Attach the child input pipe to standard input
//
   close(0);	// stdin
   fcntl(child_in, F_DUPFD, 0);

//
// Make stdout and stderr point to the child output pipe
//
   close(1);	// stdout
   close(2);	// stderr
   fcntl(child_out, F_DUPFD, 1);
   fcntl(child_out, F_DUPFD, 2);

   setsid();
#endif
