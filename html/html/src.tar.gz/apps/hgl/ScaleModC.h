/*
 * $Id: ScaleModC.h,v 1.1 1998/06/24 01:29:07 lang Exp $
 *
 * Copyright (c) 1992 HAL Computer Systems International, Ltd.
 * 
 *          HAL COMPUTER SYSTEMS INTERNATIONAL, LTD.
 *                  1315 Dell Avenue
 *                  Campbell, CA  95008
 *
 * Author: Greg Hilton
 * Contributors: Tom Lang, Frank Bieser, and others
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * http://www.gnu.org/copyleft/gpl.html
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#ifndef _ScaleModC_h_
#define _ScaleModC_h_

#include "ScaleC.h"
#include "ModFormC.h"
#include "ValueC.h"

#include <Xm/Xm.h>

class FormatModC;
class ShadowModC;
class OrientModC;
class ColorModC;

class ScaleModC : public ModFormC {

   Widget	minLabel;
   Widget	minTF;
   Widget	maxLabel;
   Widget	maxTF;
   FormatModC	*formatForm;
   ShadowModC	*barShadowForm;
   ShadowModC	*troughShadowForm;
   OrientModC	*orientForm;
   Widget	sizeLabel;
   Widget	sizeTF;
   Widget	pixelLabel;
   ColorModC	*colorForm[ScaleC::COLOR_ATTR_COUNT];
   ScaleC	*scale;

//
// Initial values
//
   struct {
      ValueC		minVal;
      ValueC		maxVal;
      int		prefSize;
   } init;

//
// Auto apply callbacks
//
   void		EnableAutoApply();
   void 	DisableAutoApply();
   void 	ChangeColor(ScaleC::ScaleColorAttr);

   static void	ChangeRange             (Widget, ScaleModC*, XtPointer);
   static void	ChangeFormat	        (Widget, ScaleModC*,
                                         XmToggleButtonCallbackStruct*);
   static void	ChangeFormatPrecis      (Widget, ScaleModC*, XtPointer);
   static void	ChangeBarShadow	        (Widget, ScaleModC*,
                                         XmToggleButtonCallbackStruct*);
   static void	ChangeBarShadowThick    (Widget, ScaleModC*, XtPointer);
   static void	ChangeTroughShadow      (Widget, ScaleModC*,
                                         XmToggleButtonCallbackStruct*);
   static void	ChangeTroughShadowThick (Widget, ScaleModC*, XtPointer);
   static void	ChangeOrient            (Widget, ScaleModC*, XtPointer);
   static void	ChangeTroughSize        (Widget, ScaleModC*, XtPointer);
   static void	ChangeBackground        (Widget, ScaleModC*, XtPointer);
   static void	ChangeBarColor          (Widget, ScaleModC*, XtPointer);
   static void	ChangeTroughColor       (Widget, ScaleModC*, XtPointer);
   static void	ChangeValueColor        (Widget, ScaleModC*, XtPointer);
   static void	ChangeLabelColor        (Widget, ScaleModC*, XtPointer);
   static void	ChangeMarkColor         (Widget, ScaleModC*, XtPointer);
   static void	ChangeBarTopShadow      (Widget, ScaleModC*, XtPointer);
   static void	ChangeBarBottomShadow   (Widget, ScaleModC*, XtPointer);
   static void	ChangeTroughTopShadow   (Widget, ScaleModC*, XtPointer);
   static void	ChangeTroughBottomShadow(Widget, ScaleModC*, XtPointer);

public:

// Methods

   ScaleModC(Widget, const char*, ArgList argv=NULL, Cardinal argc=0);
   ~ScaleModC();

   MEMBER_QUERY(Widget,      MinLabel,          minLabel)
   MEMBER_QUERY(Widget,      MinTF,             minTF)
   MEMBER_QUERY(Widget,      MaxLabel,          maxLabel)
   MEMBER_QUERY(Widget,      MaxTF,             maxTF)
   MEMBER_QUERY(Widget,      SizeLabel,         sizeLabel)
   MEMBER_QUERY(Widget,      SizeTF,            sizeTF)
   MEMBER_QUERY(Widget,      PixelLabel,        pixelLabel)
   MEMBER_QUERY(FormatModC&, FormatForm,       *formatForm)
   MEMBER_QUERY(ShadowModC&, BarShadowForm,    *barShadowForm)
   MEMBER_QUERY(ShadowModC&, TroughShadowForm, *troughShadowForm)
   MEMBER_QUERY(OrientModC&, OrientForm,       *orientForm)

   void		Apply(ScaleC&);
   void		Init(ScaleC&);
   void		Reset();
};

#endif // _ScaleModC_h_
