/*
 * $Id: ValueC.C,v 1.1 1998/06/24 01:29:07 lang Exp $
 *
 * Copyright (c) 1992 HAL Computer Systems International, Ltd.
 * 
 *          HAL COMPUTER SYSTEMS INTERNATIONAL, LTD.
 *                  1315 Dell Avenue
 *                  Campbell, CA  95008
 *
 * Author: Greg Hilton
 * Contributors: Tom Lang, Frank Bieser, and others
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * http://www.gnu.org/copyleft/gpl.html
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#include "ValueC.h"

#define MAX_CHARS_IN_NUMBER	64	// Arbitrary

/*----------------------------------------------------------------------
 * Method to convert value into string
 */

ValueC::operator StringC () const
{
   long lval = (long)(val + ((val>0.0) ? 0.5 : -0.5));
   char		temp[MAX_CHARS_IN_NUMBER];

   switch (format) {

      case (INT):
	 sprintf(temp, "%ld", lval);
	 break;

      case (HEX):
	 if ( lval < 0 ) sprintf(temp, "-%lX", -lval);
	 else		 sprintf(temp, "%lX",   lval);
	 break;

      case (FLOAT):
	 sprintf(temp, "%.*f", precis, val);
	 break;
   }

   return temp;

} // End ValueC operator StringC

/*----------------------------------------------------------------------
 * Method to return ascii representation of format
 */

StringC
ValueC::FormatName() const
{
#ifdef AIX
   StringC retval;
   switch (format) {
      case (INT):	retval = "Int";
      case (HEX):	retval = "Hex";
      case (FLOAT):	retval = "Float";
   }
   return retval;
#else
   switch (format) {
      case (INT):	return "Int";
      case (HEX):	return "Hex";
      case (FLOAT):	return "Float";
   }
#endif
}

/*----------------------------------------------------------------------
 * Method to set the format using the ascii representation
 */

void
ValueC::SetFormat(StringC text)
{
   text.toLower();

   if      ( text == "int"   ) format = INT;
   else if ( text == "hex"   ) format = HEX;
   else if ( text == "float" ) format = FLOAT;
}
