/*
 * $Id: OutlineLayoutC.C,v 1.1 1998/06/24 01:29:07 lang Exp $
 *
 * Copyright (c) 1993 HAL Computer Systems International, Ltd.
 * 
 *          HAL COMPUTER SYSTEMS INTERNATIONAL, LTD.
 *                  1315 Dell Avenue
 *                  Campbell, CA  95008
 *
 * Author: Greg Hilton
 * Contributors: Tom Lang, Frank Bieser, and others
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * http://www.gnu.org/copyleft/gpl.html
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#ifdef ICL
#include <stddef.h>
#endif

#include "OutlineLayoutC.h"
#include "HalTreeC.h"
#include "HalTreeNodeC.h"
#include "rsrc.h"

#include <Xm/Xm.h>


// =====================================================================
// The constructor for the outline form of a tree layout.
// =====================================================================
OutlineLayoutC::OutlineLayoutC(HalTreeC* t, char* name)
: LayoutC(t, name)
{
   lineOffset = get_int(t->WidgetParent(), "lineOffset", 0);
}


// =====================================================================
// The destructor.
// =====================================================================
OutlineLayoutC::~OutlineLayoutC()
{
}


void
OutlineLayoutC::Redraw()
{
   redrawing = TRUE;
   tree->numNodesVisible = 0;
   PositionNode(tree->TopLevelNode(), 0);
   redrawing = FALSE;
}


// =====================================================================
// This routine is used to layout the widgets for an outline display.
// =====================================================================
void
OutlineLayoutC::Draw()
{
//
// Initialize the size of the drawing area.
//
   int old_world_wd = tree->world_wd;
   int old_world_ht = tree->world_ht;
   tree->world_wd = tree->daWd;
   tree->world_ht = tree->daHt;
   redrawing = FALSE;

//
// This routine sets the positions of all the nodes and calculates
// all the fun stuff..
//
   int start_x = tree->marginWd;
   int start_y = tree->marginHt;
   ArrangeNodes(tree->TopLevelNode(), 0, &start_x, &start_y);

//
// Update the scroll bars if we need to.
//
   if ( old_world_wd != tree->world_wd || old_world_ht != tree->world_ht ){
      tree->UpdateScrollBars();
   }

//
// Move each widget into place.
//
   tree->numNodesVisible = 0;
   PositionNode(tree->TopLevelNode(), 0);
}



// =====================================================================
// This is the routine that is used to layout a node in an outline
// display format.
// =====================================================================
void
OutlineLayoutC::ArrangeNodes (HalTreeNodeC* node, int level, int *x, int *y)
{
//
// If the depth is zero then we are not going to draw this level.
//
   node->depth = level;
   if ( level > 0 ) {
//
//    Set the node position and update the running y position.
//
      node->x     = *x;
      node->y     = *y;
      *y += node->ht;

//
//    See if we need to expand the world because of this node.
//
      int wd = node->x + node->wd + tree->marginWd;
      int ht = *y + tree->marginHt;
      if ( wd > tree->world_wd)
         tree->world_wd = wd;
      if ( ht > tree->world_ht )
         tree->world_ht = ht;
      *y += siblingSpace;
   }

   node->regWd = node->wd;
   node->regHt = node->ht;

//
// If this node has children then recursively arrange them.
//
   int num_children = node->NumChildren();
   if ( num_children ) {
      HalTreeNodeListC& children = node->Children();
//
//    Indent these children with the child spacing.
//
      if ( level > 0 )
         *x += childSpace;

      HalTreeNodeC* last_child = NULL;
      for ( register int i=0; i<num_children; i++ ) {
         HalTreeNodeC* child = children[i];

         if ( child->Shown() ) {
	    last_child = child;
            ArrangeNodes(child, level+1, x, y);
	    int tmp = child->regWd + childSpace;
	    if ( tmp > node->regWd ) node->regWd = tmp;
         }
      }
      if ( last_child ) {
         //SKB node->regHt = last_child->y + last_child->regHt - node->y;
         node->regHt += last_child->regHt + siblingSpace;
      }

//
//    Move the x position back to its previous position.
//
      if ( level > 0 )
         *x -= childSpace;
   }
}


// =====================================================================
// The of the positions are determined during the layout phase
// and then this is called to physically plop the widgets.
// =====================================================================
void
OutlineLayoutC::PositionNode (HalTreeNodeC* node, int level)
{
   if ( !node->Shown() ) return;

//
// See if the node is visible within the display window.
//
   //int node_visible = TRUE;
   int num_children = node->NumChildren();
   Boolean children_visible = FALSE;
   if ( num_children )
      children_visible = TRUE;
   int world_xmax;
   int world_ymax;
   int node_xmax;
   int node_ymax;

//
// See if this node is visible or not and draw it or erase it.
//
   if ( level > 0 ) {

      world_xmax = tree->world_x + tree->daWd;
      world_ymax = tree->world_y + tree->daHt;
      node_xmax  = node->x + node->wd;
      node_ymax  = node->y + node->ht;

      if ( (node->x > world_xmax) || (node->y > world_ymax) ||
           (node_xmax < tree->world_x) || (node_ymax < tree->world_y)) {
         node->Erase();
      }
      else {
         node->Draw();
         tree->numNodesVisible++;
      }
   }

//
// Process the children of this node.  NOTE: If the nodes are
// comprised of widgets then we have to continue processing
// since all the nodes out of the view area must be erased.
//
   if ( level > 0 && !tree->hasWidgetNodes ) {
      if ((node->x   + childSpace   > world_xmax)    ||
          (node_ymax + siblingSpace > world_ymax)    ||
          (node->x   + node->regWd  < tree->world_x) ||
          (node->y   + node->regHt  < tree->world_y)  )
         children_visible = FALSE; 
   }

   if ( children_visible ) {
      //int lw = node->lineWidth/2;
      HalTreeNodeC* child;
      HalTreeNodeC* last_child = NULL;
      HalTreeNodeListC& children = node->Children();
      int org_x = node->x + lineOffset;
      int org_y = node->y + node->ht;
      int dst_y;
      for ( register int i=0; i<num_children; i++ ) {
         child = children[i];
         if ( child->Shown() ) {
            if ( level > 0 ) {
               last_child = child;
               dst_y = child->y + child->ht/2;
               DrawLine(node, org_x, dst_y, child->x-1, dst_y);
            }
            PositionNode(child,level+1);
         }
      }

      if ( last_child ) {
         DrawLine(node, org_x, org_y, org_x, dst_y);
      }
   }
}


// =====================================================================
// This sets the distance with which to horizontally offset the starting
// position of the lines from a parent to a child.  This offset cannot
// go passed the parent/child spacing or it gets wierd.
// =====================================================================
void
OutlineLayoutC::SetLineOffset(int offset)
{
   int tmp = childSpace - 1;
   if ( offset <= tmp )
      lineOffset = offset;
   else
      lineOffset = tmp;
   tree->Erase();
   Redraw();
}
