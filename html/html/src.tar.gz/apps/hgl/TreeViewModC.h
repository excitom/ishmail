/*
 *  $Id: TreeViewModC.h,v 1.1 1998/06/24 01:29:07 lang Exp $
 *  
 *  Copyright (c) 1994 HAL Computer Systems International, Ltd.
 * 
 *          HAL COMPUTER SYSTEMS INTERNATIONAL, LTD.
 *                  1315 Dell Avenue
 *                  Campbell, CA  95008
 *
 * Author: Greg Hilton
 * Contributors: Tom Lang, Frank Bieser, and others
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * http://www.gnu.org/copyleft/gpl.html
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
#ifndef _TreeViewModC_h_
#define _TreeViewModC_h_

#include "TreeViewC.h"
#include "ModFormC.h"

class NumericFieldC;
class RowColC;

// =====================================================================


// =====================================================================

class TreeViewModC : public ModFormC {

public:

   RowColC		*paramRC;
   Widget		treeAngleTB;
   Widget		treeSquareTB;
   Widget		treeOutlineTB;
   Widget		rootNorthTB;
   Widget		rootWestTB;
   Widget		lineFlatTB;
   Widget		lineInTB;
   Widget		lineOutTB;
   Widget		lineSolidTB;
   Widget		lineDashTB;
   Widget		compressTB;

   NumericFieldC	*genSpaceNF;
   NumericFieldC	*sibSpaceNF;
   NumericFieldC	*lineWidthNF;

   TreeViewC		*treeView;

//
// Initial values
//
   struct {

      TreeStyleT		treeStyle;
      int			rootGravity;
      int			genSpacing;
      int			sibSpacing;
      int			lineStyle;
      int			lineWidth;
      Boolean			compress;

   } init;

//
// Auto update callbacks
//
   void EnableAutoApply();
   void DisableAutoApply();

   static void	ChangeTreeStyle (Widget, TreeViewModC*,
   					 XmToggleButtonCallbackStruct*);
   static void	ChangeLineStyle (Widget, TreeViewModC*,
   					 XmToggleButtonCallbackStruct*);
   static void	ChangeRootGrav  (Widget, TreeViewModC*,
   					 XmToggleButtonCallbackStruct*);
   static void	ChangeGenSpacing(Widget, TreeViewModC*, XtPointer);
   static void	ChangeSibSpacing(Widget, TreeViewModC*, XtPointer);
   static void	ChangeLineWidth (Widget, TreeViewModC*, XtPointer);
   static void	ChangeCompress  (Widget, TreeViewModC*,
   					 XmToggleButtonCallbackStruct*);

   TreeViewModC(Widget, char*, ArgList argv=NULL, Cardinal argc=0);
  ~TreeViewModC();

   void		Apply(TreeViewC&);
   void		Init(TreeViewC&);
   void		Reset();
};

#endif // _TreeViewModC_h_
