/*
 * $Id: PieChartC.C,v 1.1 1998/06/24 01:29:07 lang Exp $
 *
 * Copyright (c) 1992 HAL Computer Systems International, Ltd.
 * 
 *          HAL COMPUTER SYSTEMS INTERNATIONAL, LTD.
 *                  1315 Dell Avenue
 *                  Campbell, CA  95008
 *
 * Author: Greg Hilton
 * Contributors: Tom Lang, Frank Bieser, and others
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * http://www.gnu.org/copyleft/gpl.html
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#include  <math.h>
#ifdef ICL
#include <stddef.h>
#endif

#include  "PieChartC.h"

#include  "rsrc.h"
#include  <X11/Xlib.h>
#include  <Xm/Xm.h>
#include  <Xm/DrawingA.h>

#define EXTERNAL_PIXMAP
#ifdef EXTERNAL_PIXMAP
#define CANVAS pixmap
#else
#define CANVAS window
#endif
// #define debug
#define  Eprintf(a) printf a 
#ifdef debug
#define  Dprintf(a) printf a 
#else
#define  Dprintf(a)
#endif


// ---------------------------------------------------------------------
// ---------------------------------------------------------------------
#define  RAD_TO_DEG             (180.0/M_PI)
#define  DEG_TO_RAD             (M_PI/180.0)
#define  RADIANS(a)             (a*DEG_TO_RAD)
#define  DEGREES(a)             (a*RAD_TO_DEG)
#define  BLACK 			XBlackPixel(display,0)
#define  WHITE 			XWhitePixel(display,0)
#define  MIN_PIE_WIDTH		20
#define  MIN_PIE_HEIGHT		20

/*
 * Some of the trig functions work wierdly because the
 * coordinate system of XWindows is not the same as
 * the trig functions...
 */
#define  SIN(a)      (-(float)sin((double)(a)))
#define  COS(a)        (float)cos((double)(a))
#define  DEG_SIN(a)  (-(float)sin((double)((double)a*DEG_TO_RAD)))
#define  DEG_COS(a)  (float)cos((double)((double)a*DEG_TO_RAD))
#define  ATAN2(a,b)  (-(float)atan2((double)(a),(double)(b)))

#define  MAX_ARC_POINTS		100
#define  TWO_PI			M_PI*2.0
#define  ONE_OVER_TWO_PI	(1.0/(M_PI*2.0))
#define  MAX_PIE_POINTS  	(MAX_ARC_POINTS+2)

#define  M_MIN(a,b) ( a<b ? a : b )
#define  ABS(a) ( a<0 ? -a : a )

Pixmap		PieChartC::pixmap       = (Pixmap)NULL;
int		PieChartC::pixmapRefCnt = 0;
Dimension	PieChartC::pixmapWd 	= 0;
Dimension	PieChartC::pixmapHt 	= 0;


// =====================================================================
//  PieSliceListC
// =====================================================================
const int PieSliceListC::allocSize = 16;

PieSliceListC::PieSliceListC () {
    _listSize = 0;
    _nItems = 0;
    _items = 0;
}

PieSliceListC::PieSliceListC (const PieSliceListC &til) {
    _listSize = til._listSize;
    _nItems = til._nItems;
    _items = 0;
    if (_listSize) {
	_items = new PieSliceC *[_listSize];
	for (int i = 0; i < _nItems; i ++)
	    _items[i] = til._items[i];
    }
}

PieSliceListC::~PieSliceListC () {
    delete _items;
}

void
PieSliceListC::add (const PieSliceC *item)
{
   if (_nItems == _listSize) {
	PieSliceC **newItems = new PieSliceC *[_listSize += allocSize];
	for (int i = 0; i < _nItems; i ++)
	    newItems[i] = _items[i];
	    delete _items;
	    _items = newItems;
   }
   _items[_nItems ++] = (PieSliceC *) item;
}

void
PieSliceListC::removeAll()
{
    _nItems = 0;
}

void
PieSliceListC::remove (const int index)
{
   if ( index >= 0 && index < _nItems && index )
   {
      for (int i=index; i<_nItems; i++)
         _items[i-1] = _items[i];
      _nItems--;
   }
}

void
PieSliceListC::remove (const PieSliceC *item) {
    for (int i = 0; i < _nItems; i ++)
	if (_items[i] == item)
	    break;
    for (i ++; i < _nItems; i ++)
	_items[i - 1] = _items[i];
    _nItems --;
}

unsigned int
PieSliceListC::size() const {
    return _nItems;
}

Boolean
PieSliceListC::inList (const PieSliceC *item) const {
    for (int i = 0; i < _nItems; i ++)
	if (_items[i] == item)
	    return True;
    return False;
}

PieSliceC *
PieSliceListC::operator [] (const int i) const {
    if (i < 0 || i >= _nItems)
	return 0;
    return _items[i];
}

PieSliceC *
PieSliceListC::lookup (const char* name) {
   for (int i=0; i<_nItems; i++) {
	if ( strcmp(_items[i]->Name(),name) == 0 )
	    return _items[i];
   }
   return 0;
}


// =====================================================================
// Define the constructor for the pie chart.
// =====================================================================
PieChartC::PieChartC(Widget parent, char *pie_name, ArgList argv, Cardinal argc)
{
   Dprintf(("**************************\n"));
   Dprintf(("Entering PieChartC\n"));
   Dprintf(("  parent: %d %s\n", parent, XtName(parent)));
   Dprintf(("  name %s\n", pie_name));

//
// Initialize the data.
//
   gc             = NULL;
   obscured       = False;
   name 	  = pie_name;
   destroyingSelf = False;
   defer          = False;
   deferCount     = 0;
   apprx          = MAX_ARC_POINTS;

//
// Create a drawing area for the pie chart.
//
   da = XmCreateDrawingArea(parent, pie_name, argv, argc);

   XtAddCallback(da, XmNexposeCallback, (XtCallbackProc)ExposeCB,
                 (XtPointer)this);

//
// Get the X attribute stuff we need from the drawing area widget.
//
   display = XtDisplay(da);
   context  = XtWidgetToApplicationContext(parent);

//
// Read the attributes we need to know about.
//
   Dimension marginWd, marginHt;
   XtVaGetValues(da, XmNbackground,   &background,
                     XmNmarginWidth,  &marginWd,
                     XmNmarginHeight, &marginHt,
                     NULL);

   marginLeft   = marginWd;
   marginRight  = marginWd;
   marginTop    = marginHt;
   marginBottom = marginHt;

//
// Init the minimum values.
//
   minWd = get_int ("PieChartC", da, "minimumWidth",  MIN_PIE_WIDTH);
   minHt = get_int ("PieChartC", da, "minimumHeight", MIN_PIE_HEIGHT);
   if ( minWd < MIN_PIE_WIDTH  ) minWd = MIN_PIE_WIDTH;
   if ( minHt < MIN_PIE_HEIGHT ) minHt = MIN_PIE_HEIGHT;

//
// Initialize the pie chart values.
//
   title 	        = get_string("PieChartC", da, "pieName", pie_name);
   startAngle		= (float)get_int ("PieChartC", da, "startAngle",    0);
   endAngle		= (float)get_int ("PieChartC", da, "endAngle",    360);
   total		= 0;
// total		= get_int ("PieChartC", da, "total",    100);
// radius		= get_int ("PieChartC", da, "radius",  100);

   legendLabelSpacing	= get_int ("PieChartC", da, "legendLabelSpacing", 5);
   pieThickness		= get_int ("PieChartC", da, "pieThickness", 40);
   declination		= get_int ("PieChartC", da, "declination", 30);
   lineWidth		= get_int ("PieChartC", da, "lineWidth", 1);
// shadowThickness   	= get_int ("PieChartC", da, "shadowThickness",    2);
// pieThickness		= get_int ("PieChartC", da, "pieThickness", 2);
// labelOffset		= get_int ("PieChartC", da, "labelOffset",        2);
// declination		= get_int ("PieChartC", da, "declination", 30);
// int precis		= get_int ("PieChartC", da, "decimalPlaces", 2);

//
// Get the value types...
//
   StringC	tstr = get_string("PieChartC", da, "legendValueType", "INT");
   legendValueType = get_valtype(tstr);
   tstr = get_string("PieChartC", da, "labelValueType", "PERCENTAGE");
   labelValueType  = get_valtype(tstr);

//
// Get the Booleans...
//
   showLegend		= get_boolean ("PieChartC", da, "showLegend", True);
   showTitle		= get_boolean ("PieChartC", da, "showTitle", True);
   bottomShadow		= get_boolean ("PieChartC", da, "bottomShadow", True);
   recomputeSize	= True;
   // recomputeSize	= get_boolean ("PieChartC", da, "recomputeSize", True);
   // deferred		= get_boolean("PieChartC", da, "deferred", False);
   titleTextShadow      = get_boolean ("PieChartC", da, "titleTextShadow", True);
   labelTextShadow      = get_boolean ("PieChartC", da, "labelTextShadow", True);
   legendTextShadow     = get_boolean ("PieChartC", da, "legendTextShadow", True);

//
// Get the colors..
//
   titleTextColor   	 = get_color ("PieChartC", da, "titleTextColor",  BLACK);
   titleTextShadowColor  = get_color ("PieChartC", da, "titleTextShadowColor", WHITE);
   legendTextShadowColor = get_color ("PieChartC", da, "legendTextShadowColor",  WHITE);
   legendTextColor 	 = get_color ("PieChartC", da, "legendTextColor",  BLACK);
   labelTextColor 	 = get_color ("PieChartC", da, "labelTextColor",  BLACK);
   labelTextShadowColor  = get_color ("PieChartC", da, "labelTextShadowColor", WHITE);
   lineColor             = get_color ("PieChartC", da, "lineColor",  BLACK);
   // colors[CHART]             = get_color("PieChartC", da, "chartColor", colors[BACKGROUND]);
   // colors[TOP_SHADOW]        = get_color("PieChartC", da, "topShadowColor",       WHITE);
   // colors[BOTTOM_SHADOW]     = get_color("PieChartC", da, "bottomShadowColor",    BLACK);
   // colors[BAR_TOP_SHADOW]    = get_color("PieChartC", da, "barTopShadowColor",    WHITE);
   // colors[BAR_BOTTOM_SHADOW] = get_color("PieChartC", da, "barBottomShadowColor", BLACK);

//
// Get pixmaps.
//
   innerEdgePixmap = 0;
   outerEdgePixmap = 0;
   backgroundPixmap = 0;
   // shadowType          = get_shadow_type("PieChartC", da, "shadowType",    XmSHADOW_IN);

//
// Calc and set some initial values.
//
   pieWd   = radius*2;
   pieHt   = radius*2;
   apprx = MAX_ARC_POINTS;
   sliceMaxOffset    = 0;
   sliceLeftOffset   = 0;
   sliceRightOffset  = 0;
   sliceTopOffset    = 0;
   sliceBottomOffset = 0;

//
// Get the fonts.
//
   StringC	fstr = get_string("PieChartC", da, "legendFont", "fixed");
   legendFont = XLoadQueryFont(display, fstr);
   fstr = get_string("PieChartC", da, "titleFont", "fixed");
   titleFont  = XLoadQueryFont(display, fstr);
   fstr = get_string("PieChartC", da, "labelFont", "fixed");
   labelFont  = XLoadQueryFont(display, fstr);

//
// Make the area fit the pie...
//
   // RecomputeSize();

//
// Manage the widgets.
//
   XtManageChild(da);

   Dprintf(("Leaving PieChartC\n"));
   Dprintf(("*********************\n"));
}


// =====================================================================
// =====================================================================
PieChartC::~PieChartC()
{
//
// Delete all the pie slices.
//
   destroyingSelf = True;
   int count = sliceList.size();
   for ( int i=count-1; i>=0; i--)
      delete sliceList[i];
}


// =====================================================================
// =====================================================================
void
PieChartC::LineColor (Pixel new_color)
{
   lineColor = new_color;
   DrawPie();
}


// =====================================================================
// =====================================================================
void
PieChartC::LegendTextColor (Pixel new_color)
{
   legendTextColor = new_color;
   DrawLegend();
}


// =====================================================================
// =====================================================================
void
PieChartC::LineWidth (int new_lineWidth)
{
   if ( lineWidth !=  new_lineWidth )
   {
      lineWidth = new_lineWidth;
//
//    Change the line width of all the slices.
//
      for ( register int i=0; i<sliceList.size(); i++ )
         sliceList[i]->lineWidth = lineWidth;

      RecomputeSize();

      Draw();
   }
}


// =====================================================================
// =====================================================================
void
PieChartC::TitleTextColor (Pixel color)
{
   titleTextColor = color;
   DrawTitle();
}


// =====================================================================
// =====================================================================
void
PieChartC::AddSlice(PieSliceC* slice)
{
//
// Add the slice to the pie's slice list
//
   sliceList.add(slice);
   total += slice->value;

//
// Recalculate the pie chart dimensions.
//
   CalcSliceValues();
   CalcPieSliceOffsets();
   CalcLegendSize();
   RecomputeSize();
   Draw();
}


// =====================================================================
// =====================================================================
void
PieChartC::RemoveSlice(PieSliceC* slice)
{
//
// Remove the slice from the pie's slice list
//
   if ( slice )
   {
      sliceList.remove(slice);
      total -= slice->value;
      CalcSliceValues();
      CalcPieSliceOffsets();
      CalcLegendSize();
      RecomputeSize();
      Draw();
   }
}


// =====================================================================
// =====================================================================
void
PieChartC::DrawTitle()
{
   Dprintf(("********************\n"));
   Dprintf(("Entering DrawTitle\n"));
   Dprintf(("  title: %s\n", (char*)title));

   if ( defer || !showTitle || title.size() <= 0 ) return;

   int w, h;
   TextExtents(titleFont, title, &w, &h);
   Dprintf(("  title extent: %d %d\n", w, h));

   int x = (int)(pieX - (w/2));
   int y = (int)(pieY - radius*DEG_COS(declination) - sliceTopOffset - lineWidth - 1);
   Dprintf(("  title pos: %d %d\n", x, y));

   if ( x < (int)marginLeft  ) x = marginLeft;
   if ( y < (int)marginTop+h ) y = marginTop+h;
   Dprintf(("  adjusted title pos: %d %d\n", x, y));

   Dprintf(("  titleTextColor: %d\n", titleTextColor));
   XSetFont(display, gc, titleFont->fid);

   if ( titleTextShadow )
   {
      XSetForeground ( display, gc, titleTextShadowColor );
      XDrawString ( display, CANVAS, gc, x+1, y+1, title, title.size());
   }

   XSetForeground ( display, gc, titleTextColor );
   XDrawString ( display, CANVAS, gc, x, y, title, title.size());

   Dprintf(("Leaving DrawTitle\n"));
   Dprintf(("*******************\n"));
}


// =====================================================================
// =====================================================================
void
PieChartC::DrawPie()
{
   Dprintf(("********************\n"));
   Dprintf(("Entering DrawPie\n"));

//
// If we are in batch mode then don`t draw yet.
//
   if ( defer || !gc ) return;

//
// If this pie is a 3D looking one then draw the edge first.
//
   if ( pieThickness > 1 && declination > 0 ) 
   {
      if ( sliceMaxOffset > 0 )
         DrawInnerEdges();
      DrawOuterEdges();
   }

//
// Now draw all the pie slices...
//
   if ( sliceList.size() <= 0 || total <= 0.0 )
      DrawEmpty();
   else {
      for ( register int i=0; i<sliceList.size(); i++ )
         sliceList[i]->Draw();
   }

   DrawTopSliceLabels();

   Dprintf(("Leaving DrawPie\n"));
   Dprintf(("******************\n"));
}


// =====================================================================
// =====================================================================
void
PieChartC::Draw()
{
   Dprintf(("********************\n"));
   Dprintf(("Entering Draw\n"));

//
// If we are in batch mode then don`t draw yet.
//
   if ( defer || !gc ) return;

#ifdef EXTERNAL_PIXMAP
   XSetForeground(display, gc, background);
   XFillRectangle(display, pixmap, gc, 0, 0, daWd, daHt);
#else
   XClearWindow ( display, window );
#endif

//
// Draw the pie portion of the chart.
//
   DrawPie();

//
// Draw the legend if desired.
//
   if ( showLegend )
      DrawLegend();

   if ( showTitle )
      DrawTitle();

#ifdef EXTERNAL_PIXMAP
   XCopyArea(display, pixmap, window, gc, 0, 0, daWd, daHt, 0, 0);
#else
   XFlush(display);
#endif

   Dprintf(("Leaving Draw\n"));
   Dprintf(("******************\n"));
}


// =====================================================================
// =====================================================================
void
PieChartC::DrawOuterEdges()
{
   Dprintf(("******************************\n"));
   Dprintf(("Entering DrawOuterEdges\n"));

//
// Initialize the x rotational matrix values.
//
   float          rot_cos = DEG_COS(declination);
   float          rot_sin = DEG_SIN(declination);
   register float angle   = DEG_TO_RAD*startAngle;

//
// This should probably be calculated differently...
//
   register float inc     = (DEG_TO_RAD*(endAngle-startAngle))/(float)(apprx);
   register float inc_cos = COS(inc);
   register float inc_sin = SIN(inc);

//
// Set the fill attributes for the outer edge.
//
   if ( outerEdgePixmap )
   {
      XSetFillStyle ( display, gc, FillOpaqueStippled );
      XSetStipple ( display, gc, outerEdgePixmap );
      XSetBackground ( display, gc, XBlackPixel(display,0) );
   }
   else
   {
      XSetFillStyle ( display, gc, FillSolid );
   }

//
// For each pie slice that is all or partially within the
// range of 180->360, draw the outer edge of it.
//
   for ( register int i=0; i<sliceList.size(); i++)
   {
      Dprintf(("  ----------------------------\n"));
      Dprintf(("  slice %d\n", i+1));
      register PieSliceC* slice = sliceList[i];

      float start_angle = angle;   // + (DEG_TO_RAD*slice->rotation);
      float end_angle   = start_angle + slice->scaleValue * TWO_PI;
      Dprintf(("  angles: %f %f\n", DEGREES(start_angle), DEGREES(end_angle)));

//
//    Now draw the outer edges of this slice if it is exposed.
//
      if ( start_angle > M_PI || end_angle > M_PI && start_angle != end_angle )
      {
	 Dprintf(("  DRAWING outer edge of slice\n"));
//
//       Calculate the start and end angles of the area
//       that will make the visible outer edge for this slice.
//
         if ( start_angle < M_PI   ) start_angle = M_PI;
         if ( end_angle   > TWO_PI ) end_angle = TWO_PI;
         Dprintf(("  edge angles: %f %f\n", start_angle, end_angle));

//
//       Determine the number of points for this slice edge.
//
         float delta_angle;
         if ( end_angle >= start_angle )
            delta_angle = end_angle - start_angle;
         else
            delta_angle = end_angle+TWO_PI - start_angle;
         Dprintf(("  delta angle: %f\n", delta_angle));

         int num_points = (int)(delta_angle/inc);
         Dprintf(("  num arc points: %d\n", num_points));

         if ( num_points > (MAX_PIE_POINTS/2) ) 
            num_points = (MAX_PIE_POINTS/2);
         else if ( num_points < 2 )
	 {
	    Dprintf(("  reached min points\n"));
            num_points = 2;
//          inc = (DEG_TO_RAD*(endAngle - startAngle))/(float)(num_points);
//          inc_cos = COS(inc);
//          inc_sin = SIN(inc);
	 }
         Dprintf(("  adjusted num arc points: %d\n", num_points));

         int k = num_points * 2 - 1;
//
//       Set the center point for this slice.
//
         float cx = pieX;
         float cy = pieY;
         if ( slice->offset > 0 )
         {
//
//          Get the trig values for the average slice angle.
//
            // float avg_angle = start_angle + slice->scaleValue * M_PI;
            float avg_angle = angle + slice->scaleValue * M_PI;
            Dprintf(("  avg angle: %f\n", avg_angle*RAD_TO_DEG));
            cx += COS(avg_angle) * (float)slice->offset;
            cy += SIN(avg_angle) * (float)slice->offset;
	    Dprintf(("  offset center: %f %f\n", cx, cy));
         }

//
//       Set the sine and cosine values for the start angle.
//
         float angle_cos = COS(start_angle);
         float angle_sin = SIN(start_angle);

//
//       Go around the pie slice & approximate its edges.
//
         XPoint Xpts[MAX_PIE_POINTS];
         num_points--;
         for ( register int j=0; j<num_points; j++ )
         {
// 
//          Apply the x rotational values for this portion of
//          the chart which is given by the following matrix.
//                 --             --
//                |  1.0, 0.0, 0.0  |
//                |  0.0, cos,-sin  |
//                |  0.0, sin, cos  |
//                |  0.0, 0.0, 0.0  |
//                 --             --
//
            // Dprintf(("Points: %d and %d\n", j, k-j));
            Xpts[j].x = (short)(cx + angle_cos * (float)radius);
            Xpts[j].y = (short)(cy + (angle_sin * (float)radius * rot_cos));

//
//          Calculate the point that cooresponds with the edge
//          point using the slice thickness.
//
            Xpts[k-j].x = Xpts[j].x;
            Xpts[k-j].y = Xpts[j].y - (short)((float)pieThickness*rot_sin);

//
//          Calculate the trig values for the next iteration...
//
            float angle_tmp;
	    angle_tmp = angle_sin * inc_cos + angle_cos * inc_sin;
            angle_cos = angle_cos * inc_cos - angle_sin * inc_sin;
            angle_sin = angle_tmp;
         }

//
//       Now do the end angle for this arc.
//
         Xpts[j].x   = (short)(cx + (COS(end_angle) * (float)radius));
         Xpts[j].y   = (short)(cy + ((SIN(end_angle) * (float)radius) * rot_cos));
         Xpts[k-j].x = Xpts[j].x;
         Xpts[k-j].y = Xpts[j].y - (short)(pieThickness*rot_sin);
         num_points++;

//
//       Since we created 2 sets of points we need to increment
//       the number of points by 2 and draw the polygon.
//
         num_points *= 2;
         // XSetForeground ( display, gc, slice->topColor );
         XSetForeground ( display, gc, slice->outerEdgeColor );
         XFillPolygon ( display, CANVAS, gc,
                        Xpts, num_points, Complex, CoordModeOrigin);
                        // Xpts, num_points, Convex, CoordModeOrigin);

//
//       Draw the border around this slice outer edge.
//
         if ( slice->lineWidth > 0 )
	 {
            XSetLineAttributes ( display, gc, slice->lineWidth,
			         LineSolid, CapButt, JoinBevel);
            // XSetForeground ( display, gc, slice->lineColor );
            XSetForeground ( display, gc, lineColor );
            Xpts[num_points].x = Xpts[0].x;
            Xpts[num_points].y = Xpts[0].y;
            num_points++;
            XDrawLines ( display, CANVAS, gc, Xpts, 
                         num_points, CoordModeOrigin);
	 }
      }
      //  else Dprintf(("  NOT Drawing edge\n"));

//
//    Increment the angle to the end of the current slice.
//
      angle += slice->scaleValue * TWO_PI;
      if ( angle >= TWO_PI ) angle -= TWO_PI;
   }

//
// Reset any affected attributes.
//
   XSetFillStyle ( display, gc, FillSolid );

   Dprintf(("Leaving DrawOuterEdges\n"));
   Dprintf(("****************************\n"));
}


// =====================================================================
// =====================================================================
void
PieChartC::DrawInnerEdges()
{
   Dprintf(("****************************\n"));
   Dprintf(("Entering DrawInnerEdges\n"));

   if ( sliceList.size() <= 1 ) return;

//
// Set the fill attributes for the inner slice edges.
//
   if ( innerEdgePixmap )
   {
      XSetFillStyle ( display, gc, FillOpaqueStippled );
      XSetStipple ( display, gc, innerEdgePixmap );
      XSetBackground ( display, gc, XBlackPixel(display,0));
   }
   else
   {
      XSetFillStyle ( display, gc, FillSolid );
   }

//
// Init the angles.
//
   register float angle   = DEG_TO_RAD*startAngle;
   register float rot_cos = COS(DEG_TO_RAD*declination);
   register float rot_sin = SIN(DEG_TO_RAD*declination);

//
// For each slice see if its offset, because we might need to draw
// the inner edges for that slice the previous, and next slices.
//
   for ( register int i=0; i<sliceList.size(); i++ )
   {
      register PieSliceC *slice = sliceList[i];

      Dprintf((" slice offset: %d\n", slice->offset));
      if ( slice->offset > 0 && slice->scaleValue > 0.0 )
      {
         float start_angle = angle;
         float end_angle   = angle + slice->scaleValue * TWO_PI;
         float avg_angle   = angle + slice->scaleValue * M_PI;
         Dprintf(("  angle: %f\n", angle*RAD_TO_DEG));
         Dprintf(("  avg angle: %f\n", avg_angle*RAD_TO_DEG));

//
//       See if the inner edge for the end angle of the 
//       previous slice is exposed and if so, draw it.
//
         register int j;
         if ( start_angle>=M_PI*0.5 && start_angle<=M_PI*1.5 )
         {
            if ( i == 0 )
	       j = sliceList.size()-1;
            else
               j = i-1;

            while ( j != i )
	    {
	       if ( sliceList[j]->scaleValue>0.0 ) break;
	       j--;
	       if ( j < 0 )
		  j = sliceList.size()-1;
	    }

	    if ( j != i && sliceList[j]->offset <= 0 )
               sliceList[j]->DrawInnerEdge ( start_angle, avg_angle, rot_cos, rot_sin );
         }

//
//       Draw the inner edge for the start angle of the "next"
//       slice if it is exposed.
//
         if ( end_angle>M_PI*1.5 || end_angle<M_PI*0.5 )
         {
            if ( i == sliceList.size()-1 )
	       j = 0;
            else
               j = i+1;

            while ( j != i )
	    {
	       if ( sliceList[j]->scaleValue>0.0 ) break;
	       j++;
	       if ( j > sliceList.size()-1 )
		  j = 0;
	    }

	    if ( j != i && sliceList[j]->offset <= 0 )
               sliceList[j]->DrawInnerEdge ( end_angle, avg_angle, rot_cos, rot_sin );
         }

//
//       Draw the inner edge for the start angle of the current
//       slice if its exposed.
//
         if ( start_angle<M_PI*0.5 || start_angle>M_PI*1.5 )
            slice->DrawInnerEdge(start_angle, avg_angle, rot_cos, rot_sin );

//
//       Draw the inner edge for the end angle of the current
//       slice if its exposed.
//
         if ( end_angle > M_PI*0.5 && end_angle < M_PI*1.5 )
            slice->DrawInnerEdge(end_angle, avg_angle, rot_cos, rot_sin );
      }
//
//    Increment the angle...
//
      angle += slice->scaleValue*TWO_PI;
      if ( angle >= TWO_PI ) angle -= TWO_PI;
   }

//
// Restore the appropriate attribures.
//
   XSetFillStyle ( display, gc, FillSolid );

   Dprintf(("Leaving DrawInnerEdges\n"));
   Dprintf(("******************************\n"));
}


// =====================================================================
// =====================================================================
void
PieChartC::StartAngle(float angle)
{
   Dprintf(("****************************\n"));
   Dprintf(("Entering StartAngle\n"));
   Dprintf(("  angle: %f\n", angle));

   float delta = endAngle - startAngle;

//
// Make sure the angle is between 0 and 2PI.
//
   while ( angle > 360 ) angle -= 360;
   while ( angle < 0   ) angle += 360;

//
// Reset the pie angles.
//
   startAngle = angle;
   endAngle   = angle + delta;

   CalcSliceValues();

//
// Redraw the pie.
//
   if ( sliceMaxOffset > 0 )
      CalcPieSliceOffsets();

   Draw();

   Dprintf(("Leaving StartAngle\n"));
   Dprintf(("**************************\n"));
}


// =====================================================================
// =====================================================================
void
PieChartC::Defer(Boolean mode)
{
//
// If we are turning the defer mode off then see if we need to redraw.
//
   if ( mode == False )
   {
      deferCount--;
      if ( deferCount <= 0 )
      {
	 deferCount = 0;           // Just in case...
         defer = False;
         Draw();
      }
   }
   else
   {
      defer = True;
      deferCount++;
   }
}


// =====================================================================
// =====================================================================
void
PieChartC::CalcPieSliceOffsets()
{
   Dprintf(("****************************\n"));
   Dprintf(("Entering CalcPieSliceOffsets\n"));

   sliceLeftOffset	= radius;
   sliceRightOffset	= radius;
   sliceTopOffset	= radius;
   sliceBottomOffset	= radius;

   register int start_angle = (int)startAngle;
   for(int i=0; i<sliceList.size(); i++)
   {
      Dprintf(("  ----------------------------\n"));
      register PieSliceC* slice = sliceList[i];
      Dprintf(("  slice %d offset: %d\n", i+1, slice->offset));

      register int end_angle = start_angle + (int)(slice->scaleValue*360);

      Dprintf(("  angles: %d %d\n", start_angle, end_angle));
      if ( slice->scaleValue > 0.0 && slice->offset > 0 )
      {
         int pos_x, pos_y;
         register float len = (float)slice->offset + (float)radius;

         if ( start_angle >= 0 && start_angle <= 90 )
         {
	    pos_x  = ABS((int)(len * DEG_COS(start_angle)));
	    pos_y  = ABS((int)(len * DEG_SIN(start_angle)));
            if ( pos_x > sliceRightOffset )
	       sliceRightOffset = pos_x;
            if ( pos_y > sliceTopOffset )
	       sliceTopOffset = pos_y;

	    if ( end_angle <= 90 )
	    {
	       pos_y = ABS((int)(len * DEG_SIN(end_angle)));
               if ( pos_y > sliceTopOffset )
	          sliceTopOffset = pos_y;
	    }
	    else if ( end_angle <= 180 )
	    {
	       pos_x = ABS((int)(len * DEG_COS(end_angle)));
	       pos_y = (int)len;
               if ( pos_y > sliceTopOffset )
	          sliceTopOffset = pos_y;
               if ( pos_x > sliceLeftOffset )
	          sliceLeftOffset = pos_x;
	    }
	    else if ( end_angle <= 270 )
	    {
	       pos_x = (int)len;
	       pos_y = ABS((int)(len * DEG_SIN(end_angle)));
               if ( pos_x > sliceLeftOffset )
	          sliceLeftOffset = pos_x;
               if ( pos_y > sliceBottomOffset )
	          sliceBottomOffset = pos_y;
	    }
	    else // if ( end_angle < 360 )
	    {
	       pos_x = ABS((int)(len * DEG_COS(end_angle)));
	       pos_y = (int)len;
               if ( pos_x > sliceRightOffset )
	          sliceRightOffset = pos_x;
               if ( pos_y > sliceBottomOffset )
	          sliceBottomOffset = pos_y;
	    }
         }
         else if ( start_angle > 90 && start_angle <= 180 )
         {
	    pos_x = ABS((int)(len * DEG_COS(start_angle)));
	    pos_y = ABS((int)(len * DEG_SIN(start_angle)));
            if ( pos_y > sliceTopOffset )
	       sliceTopOffset = pos_y;
            if ( pos_x > sliceLeftOffset )
	       sliceLeftOffset = pos_x;

	    if ( end_angle <= 180 )
	    {
	       pos_x = ABS((int)(len * DEG_COS(end_angle)));
               if ( pos_x > sliceLeftOffset )
	          sliceLeftOffset = pos_x;
	    }
	    else if ( end_angle <= 270 )
	    {
	       pos_x = (int)len;
	       pos_y = ABS((int)(len * DEG_SIN(end_angle)));
               if ( pos_x > sliceLeftOffset )
	          sliceLeftOffset = pos_x;
               if ( pos_y > sliceBottomOffset )
	          sliceBottomOffset = pos_y;
	    }
	    else if ( end_angle <= 360 )
	    {
	       pos_x = ABS((int)(len * DEG_COS(end_angle)));
	       pos_y = (int)len;
               if ( pos_x > sliceRightOffset )
	          sliceRightOffset = pos_x;
               if ( pos_y > sliceBottomOffset )
	          sliceBottomOffset = pos_y;
	    }
	    else // if ( end_angle <= 360 )
	    {
	       pos_x  = (int)len;
	       pos_y    = ABS((int)(len * DEG_COS(end_angle)));
               if ( pos_y > sliceTopOffset )
	          sliceTopOffset = pos_y;
               if ( pos_x > sliceRightOffset )
	          sliceRightOffset = pos_x;
	    }
         }
         else if ( start_angle > 180 && start_angle <= 270 )
         {
	    pos_x = ABS((int)(len * DEG_COS(start_angle)));
	    pos_y = ABS((int)(len * DEG_SIN(start_angle)));
            if ( pos_x > sliceLeftOffset )
	       sliceLeftOffset = pos_x;
            if ( pos_y > sliceBottomOffset )
	       sliceBottomOffset = pos_y;

	    if ( end_angle <= 270 )
	    {
	       pos_y = ABS((int)(len * DEG_SIN(end_angle)));
               if ( pos_y > sliceBottomOffset )
	          sliceBottomOffset = pos_y;
	    }
	    else if ( end_angle <= 360 )
	    {
	       pos_x = ABS((int)(len * DEG_COS(end_angle)));
	       pos_y = (int)len;
               if ( pos_x > sliceRightOffset )
	          sliceRightOffset = pos_x;
               if ( pos_y > sliceBottomOffset )
	          sliceBottomOffset = pos_y;
	    }
	    else if ( end_angle <= 450 )
	    {
	       pos_x = (int)len;
	       pos_y = ABS((int)(len * DEG_COS(end_angle)));
               if ( pos_y > sliceTopOffset )
	          sliceTopOffset = pos_y;
               if ( pos_x > sliceRightOffset )
	          sliceRightOffset = pos_x;
	    }
	    else // if ( end_angle <= 540 )
	    {
	       pos_x = ABS((int)(len * DEG_COS(end_angle)));
	       pos_y = (int)len;
               if ( pos_y > sliceTopOffset )
	          sliceTopOffset = pos_y;
               if ( pos_x > sliceLeftOffset )
	          sliceLeftOffset = pos_x;
	    }
         }
         else if ( start_angle > 270 && start_angle <= 360 )
         {
	    pos_x = ABS((int)(len * DEG_COS(start_angle)));
	    pos_y = ABS((int)(len * DEG_SIN(start_angle)));
            if ( pos_x > sliceRightOffset )
	       sliceRightOffset = pos_x;
            if ( pos_y > sliceBottomOffset )
	       sliceBottomOffset = pos_y;

	    if ( end_angle <= 360 )
	    {
	       pos_x = ABS((int)(len * DEG_COS(end_angle)));
               if ( pos_x > sliceRightOffset )
	          sliceRightOffset = pos_x;
	    }
	    else if ( end_angle <= 450 )
	    {
	       pos_x = (int)len;
	       pos_y = ABS((int)(len * DEG_COS(end_angle)));
               if ( pos_y > sliceTopOffset )
	          sliceTopOffset = pos_y;
               if ( pos_x > sliceRightOffset )
	          sliceRightOffset = pos_x;
	    }
	    else if ( end_angle <= 540 )
	    {
	       pos_x = ABS((int)(len * DEG_COS(end_angle)));
	       pos_y = (int)len;
               if ( pos_y > sliceTopOffset )
	          sliceTopOffset = pos_y;
               if ( pos_x > sliceLeftOffset )
	          sliceLeftOffset = pos_x;
	    }
	    else // if ( end_angle <= 630 )
	    {
	       pos_x = (int)len;
	       pos_y = ABS((int)(len * DEG_SIN(end_angle)));
               if ( pos_x > sliceLeftOffset )
	          sliceLeftOffset = pos_x;
               if ( pos_y > sliceBottomOffset )
	          sliceBottomOffset = pos_y;
	    }
         }
      }

      start_angle = end_angle;
      if ( start_angle >= 360 ) start_angle -= 360;
   }

   sliceLeftOffset    -= radius;
   sliceRightOffset   -= radius;
   sliceTopOffset     -= radius;
   sliceBottomOffset  -= radius;

//
// Find out what the max slice offset is...
//
   sliceMaxOffset = sliceLeftOffset;
   if ( sliceRightOffset > sliceMaxOffset )
      sliceMaxOffset = sliceRightOffset;
   if ( sliceTopOffset > sliceMaxOffset )
      sliceMaxOffset = sliceTopOffset;
   if ( sliceBottomOffset > sliceMaxOffset )
      sliceMaxOffset = sliceBottomOffset;

   Dprintf(("  sliceLeftOffset: %d\n", sliceLeftOffset));
   Dprintf(("  sliceRightOffset: %d\n", sliceRightOffset));
   Dprintf(("  sliceTopOffset: %d\n", 	sliceTopOffset));
   Dprintf(("  sliceBottomOffset: %d\n", sliceBottomOffset));
   Dprintf(("Leaving CalcPieSliceOffsets\n"));
   Dprintf(("****************************\n"));
}

// =====================================================================
// =====================================================================
void
PieChartC::BackgroundColor(Pixel color)
{
   background = color;
   XtVaSetValues(da,XmNbackground,color,NULL);
   Draw();
}


// =====================================================================
// =====================================================================
void
PieChartC::BackgroundPixmap(Pixmap pixmap)
{
   backgroundPixmap = pixmap;
   Draw();
}


// =====================================================================
// =====================================================================
void
PieChartC::DrawLegend()
{
   Dprintf(("*************************\n"));
   Dprintf(("Entering DrawLegend\n"));
   Dprintf(("  pieY: %d\n", pieY));

   register int num_slices = sliceList.size();
   Dprintf(("  num slices: %d\n", sliceList.size() ));
   if ( num_slices <= 0 ) return;

//
// Determine the y start position of the legend.
//
   int char_height = FontHeight(legendFont);
   Dprintf(("  char_height: %d\n", char_height));
   Dprintf(("  sliceRightOffset: %d\n", sliceRightOffset));

   register int x, y;
   int start_x = pieX + radius + sliceRightOffset + (char_height+legendLabelSpacing)/2;
   y = (int)(pieY - legendHeight/2);
   Dprintf(("  start_y: %d\n", y));

   char tmpstr[1024];
   int max_x_ext = 0; 
   if ( legendValueType != PieSliceC::NONE )
   {
//
//    Determine the max slice value so we can get the amount to
//    adjust the values to right justify them...
//
      float max_value = sliceList[0]->value;
      int max_index = 0;
      for ( register int i=1; i<num_slices; i++ )
      {
         if ( sliceList[i]->value > max_value )
	 {
	    max_value = sliceList[i]->value;
	    max_index = i;
	 }
      }
      sliceList[max_index]->ValueString(tmpstr, legendValueType, legendPrecision);
      int dum;
      TextExtents(legendFont, tmpstr, &max_x_ext, &dum);
   }
   Dprintf(("  max value text extent: %d\n", max_x_ext));

//
// Set the line & font attributes for the legend boxes...
//
   XSetLineAttributes ( display, gc, 1, LineSolid, CapButt, JoinBevel );
   XSetFont(display, gc, legendFont->fid);

   int width  = char_height;
   int height = char_height;
   Dprintf(("  box dims: %d %d\n", width, height));

//
// For each slice draw a legend box and the slices value...
//
   for ( register int i=0; i<num_slices; i++ )
   {
      register PieSliceC* slice = sliceList[i];

      x  = start_x;
      Dprintf(("  box xy: %d %d\n", x,y)); 
      XSetForeground ( display, gc, slice->topColor );
      XFillRectangle ( display, CANVAS, gc, x, y, width, height );
      
      XSetForeground ( display, gc, lineColor );
      XDrawRectangle ( display, CANVAS, gc, x, y, width, height );

      x += height + height/2;
      y += height;

//
//    Draw the value of the slice in the legend, if desired.
//
      XSetForeground ( display, gc, legendTextColor );
      if ( legendValueType != PieSliceC::NONE )
      {
         slice->ValueString(tmpstr, legendValueType, legendPrecision);

         int x_ext, y_ext;
         TextExtents(legendFont, tmpstr, &x_ext, &y_ext);

         int slen = strlen(tmpstr);
	 int tmp_x = x + max_x_ext - x_ext;

         if ( legendTextShadow )
	 {
            XSetForeground ( display, gc, legendTextShadowColor );
            XDrawString ( display, CANVAS, gc, tmp_x+1, y+1, tmpstr, slen);
            XSetForeground ( display, gc, legendTextColor );
	 }
         XDrawString ( display, CANVAS, gc, tmp_x, y, tmpstr, slen);

         x += max_x_ext + 1;
      }

      Dprintf(("  String pos: %d %d\n", x,y)); 
      if ( legendTextShadow )
      {
         XSetForeground ( display, gc, legendTextShadowColor );
         XDrawString ( display, CANVAS, gc, x+1, y+1,
		       slice->label, slice->label.size());
         XSetForeground ( display, gc, legendTextColor );
      }
      XDrawString ( display, CANVAS, gc, x, y,
		    slice->label, slice->label.size() );

      y += legendLabelSpacing;
   }

   Dprintf(("Leaving DrawLegend\n"));
   Dprintf(("********************\n"));
}


// =====================================================================
// =====================================================================
void
PieChartC::ShowLegend ( Boolean vis)
{
   if ( showLegend != vis )
   {
      showLegend = vis;
      if ( vis )
	 CalcLegendSize();
      else
      {
	 legendWidth  = 0;
	 legendHeight = 0;
      }
      RecomputeSize();
      Draw();
   }
}


// =====================================================================
// =====================================================================
void
PieChartC::ShowTitle ( Boolean vis)
{
   if ( showTitle != vis )
   {
      showTitle = vis;
      RecomputeSize();
      Draw();
   }
}


// =====================================================================
// =====================================================================
void
PieChartC::Title(char *new_title)
{
   title = new_title;
   if ( showTitle )
      Draw();
}


// =====================================================================
// =====================================================================
void
PieChartC::RecomputeSize()
{
   Dprintf(("***********************\n"));
   Dprintf(("Entering RecomputeSize\n"));
   Dprintf(("  legend size: %d %d\n", legendWidth, legendHeight));

   if ( !recomputeSize ) return;

// XtVaGetValues(da, XmNwidth, &daWd, XmNheight, &daHt, NULL);
   Dprintf(("  margins rt: %d %d\n", marginRight, marginBottom));

//
// Calc the title height.
//
   int title_height = 0;
   if ( showTitle && title.size() > 0  )
      title_height = FontHeight(titleFont) + 1;

//
// Center the pie chart in the space thats available in the drawing area.
//
   Dprintf(("  declination: %d\n", declination));
   Dprintf(("  da size: %d %d\n", daWd, daHt));
   Dprintf(("  marginLeft: %d\n", marginLeft));
   Dprintf(("  marginRight: %d\n", marginRight));
   Dprintf(("  marginTop: %d\n", marginTop));
   Dprintf(("  marginBottom: %d\n", marginBottom));
   Dprintf(("  title_height: %d\n", title_height));
   Dprintf(("  legendWidth: %d\n", legendWidth));
   Dprintf(("  sliceLeftOffset: %d\n", sliceLeftOffset));
   Dprintf(("  sliceRightOffset: %d\n", sliceRightOffset));
   Dprintf(("  sliceTopOffset: %d\n", sliceTopOffset));
   Dprintf(("  sliceBottomOffset: %d\n", sliceBottomOffset));
   Dprintf(("  FontHeight: %d\n", FontHeight(legendFont)));
   Dprintf(("  pieThickness: %d\n", pieThickness));

   int thickness = 0;
   if ( declination > 0 )
      thickness = (Dimension)((float)pieThickness*(-DEG_SIN(declination)));
      // thickness = (Dimension)((float)pieThickness*DEG_COS(declination));
   Dprintf(("  declined thickness: %d\n", thickness));

//
// Calculate the space that the pie actually takes up.
//
   int wd, ht;
   wd = daWd  - marginLeft - marginRight - legendWidth -
	sliceLeftOffset - sliceRightOffset - FontHeight(legendFont) - 1;
   ht = daHt - marginTop - marginBottom - title_height -
	sliceTopOffset - sliceBottomOffset - thickness - 1;
   Dprintf(("  pie space size: %d %d\n", wd, ht));

//
// Make sure this didn't get too small...
//
   if ( wd < (int)minWd ) wd = minWd;
   if ( ht < (int)minHt ) ht = minHt;
   Dprintf(("  adjusted pie size: %d %d\n", wd, ht));

   pieWd         = (Dimension)wd;
   pieHt         = (Dimension)ht;
//
// Calculate the radius and remember if the pie is declined
// then the pie height can be bigger than the actual space
// allowed for it and still draw ok.
//
   Dimension pieDeclinedHt = pieHt;
   if ( declination > 0 )
      pieDeclinedHt = (Dimension)(((float)pieHt)/DEG_COS(declination));

   radius = (int)M_MIN((int)pieWd/2,(int)pieDeclinedHt/2);
   Dprintf(("  pie radius: %d\n", radius));

   pieX = (Position)(pieWd/2 + marginLeft + sliceLeftOffset + 1);
   pieY = (Position)(pieHt/2 + marginTop  + sliceTopOffset  + title_height + 1);
   Dprintf(("  pie pos: %d %d\n", (int)pieX, (int)pieY));

#ifdef EXTERNAL_PIXMAP
//
// Re-create pixmap if size has increased
//
   if ( daWd > pixmapWd || daHt > pixmapHt )
   {
      XFreePixmap(display, pixmap);
      unsigned  depth = DefaultDepth(display, DefaultScreen(display));
      pixmap = XCreatePixmap(display, window, daWd, daHt, depth);
      pixmapWd = daWd;
      pixmapHt = daHt;
   }
#endif

   Dprintf(("Leaving  RecomputeSize\n"));
   Dprintf(("**********************\n"));
}


// =====================================================================
// This determines the size of the legend.
// =====================================================================
void
PieChartC::CalcLegendSize()
{
   Dprintf(("************************\n"));
   Dprintf(("Entering CalcLegendSize\n"));

//
// If this pie has a legend then include the maximum space
// that the legend will occupy.
//
   legendHeight = 0;
   legendWidth  = 0;
   if ( !showLegend || sliceList.size() <=0 ) return;

//
// For each slice draw a legend box and the slices value...
//
   int   wd, ht;
   int   max_index = 0;
   float max_value = sliceList[0]->value;
   for ( register int i=0; i<sliceList.size(); i++ )
   {
      if ( sliceList[i]->value > max_value )
      {
         max_value = sliceList[i]->value;
	 max_index = i;
      }

      TextExtents(legendFont, sliceList[i]->Label(), &wd, &ht);
      if ( wd > (int)legendWidth ) legendWidth = wd;
      legendHeight += ht;
   }
   legendHeight += legendLabelSpacing * (sliceList.size()-1);

//
// Add the box and the space stuff to the width.
//
   legendWidth += ht + ht/2;

//
// If we are displaying values then add the width of the
// slice with the max value.
//
   if ( legendValueType != PieSliceC::NONE )
   {
      char tmpstr[1024];
      sliceList[max_index]->ValueString(tmpstr, legendValueType, legendPrecision);
      TextExtents(legendFont, tmpstr, &wd, &ht);
      legendWidth += wd + 1;
   }

   Dprintf(("  legend size: %d %d\n", legendWidth, legendHeight));
   Dprintf(("Leaving CalcLegendSize\n"));
   Dprintf(("************************\n"));
}


// =====================================================================
// =====================================================================
void
PieChartC::LabelValueType(PieSliceC::ValueType valtype, int prec)
{
   
   if ( valtype != labelValueType || labelPrecision != prec )
   {
      labelValueType = valtype;
      labelPrecision = prec;
      // RecomputeSize();
      Draw();
   }
}


// =====================================================================
// =====================================================================
void
PieChartC::LegendValueType(PieSliceC::ValueType valtype, int prec)
{
   if ( valtype != legendValueType || legendPrecision != prec )
   {
      legendValueType = valtype;
      legendPrecision = prec;
      CalcLegendSize();
      RecomputeSize();
      Draw();
   }
}


// =====================================================================
// =====================================================================
void
PieChartC::Declination(int new_declination)
{
   if ( declination != new_declination )
   {
      declination = new_declination;
      // CalcPieHeight();
      RecomputeSize();
      Draw();
   }
}


// =====================================================================
// =====================================================================
void
PieChartC::Thickness (unsigned int new_thickness)
{
   if ( pieThickness != new_thickness )
   {
      pieThickness = new_thickness;

//    for ( int i=0; i<sliceList.size(); i++)
//       sliceList[i]->thickness = new_thickness;
  
      RecomputeSize();
      Draw();
   }
}


// =====================================================================
// =====================================================================
void
PieChartC::DrawEmpty()
{
   if ( defer ) return;

//
// Initialize the values to go around the pie.
//
   register float inc = (DEG_TO_RAD*(endAngle - startAngle))/(float)(apprx );
   register float inc_cos = COS(inc);
   register float inc_sin = SIN(inc);
   register float angle_cos     = -1.0;
   register float angle_sin     = 0.0;
   // register float angle_cos     = COS(angle);
   // register float angle_sin     = SIN(angle);

//
// Set the center position of the current slice.
//
   float cx = pieX;
   float cy = pieY;

   XPoint  Xpts[MAX_PIE_POINTS];

   int num_points = apprx - 1;

//
// Initialize the x rotational matrix value for the declination.
//
   float rot_cos = DEG_COS(declination);
   float angle_tmp;

//
// Go around this pie slice and approximate its edges.
//
   register int i;
   num_points--;
   for ( i=0; i<num_points; i++ )
   {
      Xpts[i].x = (short)(cx +  (angle_cos * (float)radius));
      Xpts[i].y = (short)(cy + ((angle_sin * (float)radius)*rot_cos));
      angle_tmp = angle_sin * inc_cos + angle_cos * inc_sin;
      angle_cos = angle_cos * inc_cos - angle_sin * inc_sin;
      angle_sin = angle_tmp;
   }
   Xpts[num_points].x = Xpts[0].x;
   Xpts[num_points].y = Xpts[0].y;
   num_points++;

   int line_width = lineWidth;
   if ( line_width < 0 ) line_width = 1;

//
// Set the line attributes for this slice.
//
   XSetLineAttributes (display, gc, line_width,
		       LineSolid, CapButt, JoinBevel);
   XSetForeground ( display, gc, lineColor );

   XDrawLines ( display, CANVAS, gc,
		Xpts, num_points, CoordModeOrigin );

//
// Draw the outer edge if there is one.
//
   if ( declination > 0 && pieThickness > 0 )
   {
      num_points    = apprx/2;
      inc     = M_PI/(float)num_points;
      inc_cos = COS(inc);
      inc_sin = SIN(inc);
      angle_sin     =  0.0;
      angle_cos     = -1.0;
      float rot_sin = DEG_SIN(declination);

      Xpts[0].x = (short)(cx - radius);
      Xpts[0].y = (short)cy;

//
//    Go around the pie charts outer edge.
//
      num_points--;
      for ( i=1; i<num_points; i++ )
      {
//
//       Calculate the point that cooresponds with the edge
//       point using the slice thickness.
//
         Xpts[i].x = (short)(cx + angle_cos * (float)radius);
         Xpts[i].y = (short)((cy + (angle_sin * (float)radius * rot_cos)) -
                             ((float)pieThickness*rot_sin));

//
//       Calculate the trig values for the next iteration...
//
	 angle_tmp = angle_sin * inc_cos + angle_cos * inc_sin;
         angle_cos = angle_cos * inc_cos - angle_sin * inc_sin;
         angle_sin = angle_tmp;
      }

      angle_cos = 1.0;
      angle_sin = 0.0;
      Xpts[i].x = (short)(cx +  (angle_cos * (float)radius));
      Xpts[i].y = (short)((cy + (angle_sin * (float)radius) * rot_cos) -
                          (pieThickness*rot_sin));
      num_points++;

      Xpts[num_points].x = (short)(cx + radius);
      Xpts[num_points].y = (short)cy;
      num_points++;

      XDrawLines ( display, CANVAS, gc, Xpts, num_points, CoordModeOrigin);
   }

   Dprintf(("Leaving DrawEmpty\n"));
   Dprintf(("******************\n"));
}


// =====================================================================
// =====================================================================
void
PieChartC::DrawTopSliceLabels()
{
   if ( labelValueType != PieSliceC::NONE )
   {
      XSetFont(display, gc, labelFont->fid);
      float    rot_cos  = DEG_COS(declination);

      for ( int i=0; i<sliceList.size(); i++)
      {
	 register PieSliceC* slice = sliceList[i];

	 if ( slice->scaleValue > 0.0 )
	 {
            char str[1024];
            slice->ValueString(str, labelValueType, labelPrecision);
            int slen = strlen(str);

            float avg_angle = RADIANS(slice->startAngle) + slice->scaleValue*M_PI;
            int x = (int)(pieX + (COS(avg_angle)*(radius*0.7)));
            int y = (int)(pieY +((SIN(avg_angle)*(radius*0.7)) * rot_cos));

            // int wd, ht;
            // TextExtents(labelFont, str, &wd, &ht);
            // x -= wd/2;
            // y -= ht/2;

            if ( labelTextShadow )
            {
               XSetForeground ( display, gc, labelTextShadowColor );
               XDrawString ( display, CANVAS, gc, x+1, y+1, str, slen);
            }

            XSetForeground ( display, gc, labelTextColor );
            XDrawString ( display, CANVAS, gc, x, y, str, slen);
         }
      }
   }
}


// =====================================================================
// =====================================================================
void
PieChartC::TextExtents(XFontStruct* font, char *text, int *width, int *height)
{
   Dprintf(("*******************\n"));
   Dprintf(("Entering TextExtents\n"));
   Dprintf(("  font: %d\n", font));
   Dprintf(("  text: %s\n", text));

   int dir, asc, dsc;
   XCharStruct overall;

   XTextExtents(font, text, strlen(text), &dir, &asc, &dsc, &overall);
   Dprintf(("  dir: %d  asc: %d  dsc: %d\n", dir, asc, dsc));
   Dprintf(("  all wd: %d ascent: %d  descent: %d\n", overall.width, overall.ascent, overall.descent));

   *width  = overall.width;
   // *height = overall.ascent + overall.descent;
   *height = asc + dsc;

   Dprintf(("  width: %d\n", *width));
   Dprintf(("  height: %d\n", *height));
   Dprintf(("Leaving TextExtents\n"));
   Dprintf(("*******************\n"));
}


// =====================================================================
// =====================================================================
void
PieChartC::Total(float new_total)
{
   if ( total != new_total )
   {
      total = new_total;
      int count = sliceList.size();
      for (register int i=0; i<count; i++)
         sliceList[i]->value = sliceList[i]->scaleValue*total;
      Draw();
   }
}


// =====================================================================
// =====================================================================
void
PieChartC::CalcSliceValues()
{
   register float running_angle = startAngle;

   int count = sliceList.size();
   for (register int i=0; i<count; i++)
   {
      sliceList[i]->startAngle = running_angle;
      if ( total > 0.0 && sliceList[i]->value > 0.0 )
         sliceList[i]->scaleValue = sliceList[i]->value/total;
      else
         sliceList[i]->scaleValue = 0.0;
      running_angle += sliceList[i]->scaleValue*360.0;
   }
}


// =====================================================================
// This routine should be called the first time that the pie chart is
// to be displayed.
// =====================================================================
void
PieChartC::InitialDisplay()
{
   Dprintf(("  creating the graphics context\n"));
   defer = False;
   window = XtWindow(da);

#ifdef GET_NEW_GC
   XtGCMask	fixMask = GCBackground | GCClipMask | GCClipXOrigin
			| GCClipYOrigin | GCFillRule | GCFillStyle | GCFunction
			| GCGraphicsExposures | GCPlaneMask | GCLineStyle
			| GCLineWidth | GCFont | GCArcMode;
   XtGCMask	modMask = GCForeground;
   XtGCMask	naMask  = GCCapStyle | GCJoinStyle | GCDashList | GCDashOffset
			| GCStipple | GCSubwindowMode | GCTile
			| GCTileStipXOrigin | GCTileStipYOrigin;

   Pixel background;
   XtVaGetValues(da, XmNbackground, &background, NULL);

   XGCValues fixVals;
   fixVals.arc_mode		= ArcChord;
   fixVals.background		= background;
   fixVals.clip_mask		= None;
   fixVals.clip_x_origin	= 0;
   fixVals.clip_y_origin	= 0;
   fixVals.fill_rule		= EvenOddRule;
   fixVals.fill_style		= FillSolid;
   fixVals.font			= titleFont->fid;
   fixVals.function		= GXcopy;
   fixVals.graphics_exposures	=  True;
   fixVals.line_width		= 0;
   fixVals.line_style		= LineSolid;
   fixVals.plane_mask		= AllPlanes;

   gc = XtAllocateGC(da, 0, fixMask, &fixVals, modMask, naMask);
   Dprintf(("  graphics context: %d\n", gc));
#else
   gc  = XDefaultGC(display,0);
   Dprintf(("  default graphics context: %d\n", gc));

   XtVaGetValues(da, XmNwidth, &daWd, XmNheight, &daHt, NULL);
   Dprintf(("  da dims: %d %d\n", daWd, daHt));

   if ( daWd < minWd ) daWd = minWd;
   if ( daHt < minHt ) daHt = minHt;
#endif

#ifdef EXTERNAL_PIXMAP
//
// Create off-screen pixmap to be used for drawing.
//
   if ( !pixmap )
   {
      unsigned depth = DefaultDepth(display, DefaultScreen(display));
      pixmap = XCreatePixmap(display, window, daWd, daHt,depth);
      pixmapWd = daWd;
      pixmapHt = daHt;
   }
   else if ( daWd > pixmapWd || daHt > pixmapHt )
   {
//
//    Re-create pixmap if size has increased
//
      XFreePixmap(display, pixmap);
      unsigned depth = DefaultDepth(display, DefaultScreen(display));
      pixmap = XCreatePixmap(display, window, daWd, daHt,depth);
      pixmapWd = daWd;
      pixmapHt = daHt;
   }
   pixmapRefCnt++;
#endif

//
// If this is the very first pie chart then initialize some stuff.
//
   if ( !innerEdgePixmap )
   {
      static char shade_bits[] = { 0x01, 0x02 };
      innerEdgePixmap = XCreateBitmapFromData(display,window,shade_bits,2,2);
   }
   if ( !outerEdgePixmap )
      outerEdgePixmap = innerEdgePixmap;

//
// Calculate all the initial values.
//
   CalcSliceValues();
   CalcPieSliceOffsets();
   CalcLegendSize();
   RecomputeSize();

//
// Add event handler to detect visibility changes
//
   XtAddEventHandler(da, VisibilityChangeMask, False,
		     (XtEventHandler)VisChangeEV, (XtPointer)this);

//
// Add callback to handle resizes of the drawing area.
//
   XtAddCallback(da, XmNresizeCallback,
		 (XtCallbackProc)RecomputeSizeCB, (XtPointer)this);
}


// =====================================================================
// This routine is called when the window for the drawing area has
// changed sizes.
// =====================================================================
void
PieChartC::RecomputeSizeCB(Widget, PieChartC *pc, XtPointer)
{
   if ( !pc->gc ) return;

//
// Get the size of the drawing area for the pie chart.
//
   XtVaGetValues(pc->da, XmNwidth,  &pc->daWd,
			 XmNheight, &pc->daHt,
			 NULL);

   if ( pc->daWd < pc->minWd ) pc->daWd = pc->minWd;
   if ( pc->daHt < pc->minHt ) pc->daHt = pc->minHt;

   pc->RecomputeSize();
   pc->Draw();
}


// =====================================================================
// This routine handles the visibility changes of the drawing area.
// =====================================================================
void
PieChartC::VisChangeEV(Widget, PieChartC *pc, XVisibilityEvent *ev, Boolean*)
{
   if ( !pc->gc ) pc->InitialDisplay();

   Boolean      obscured;
   obscured = (ev->state == VisibilityFullyObscured);
   if ( pc->obscured != obscured )
   {
      pc->obscured = obscured;
      if ( !obscured ) pc->Draw();
   }
}


// =====================================================================
// =====================================================================
void
PieChartC::ExposeCB(Widget, PieChartC *pc, XmDrawingAreaCallbackStruct *db)
{
   Dprintf(("*****************\n"));
   Dprintf(("Entering ExposeCB\n"));

   XExposeEvent *ev = (XExposeEvent*)db->event;

   if ( ev->count > 0 ) return;		// Wait for last expose event

//
// Create graphics context if this is the first time.
//
   if ( !pc->gc )
      pc->InitialDisplay();

   pc->Draw();

   Dprintf(("Leaving ExposeCB\n"));
   Dprintf(("*****************\n"));
}


// =====================================================================
// The constructor for the pie slice class.
// =====================================================================
PieSliceC::PieSliceC(PieChartC *pie, char *slice_name, float val)
{
   Dprintf((" slice name: %s\n", slice_name));

   pieChart = pie;
   value    = val;
   name     = slice_name;

//
// Get the default slice information.
//
   StringC  rsrc;
   rsrc = name + "labelString";
   label = get_string("PieChartC", pie->da,rsrc,name);

   rsrc = name + "topColor";
   topColor = get_color("PieChartC", pie->da,rsrc,WhitePixel(pie->display,0));

   rsrc = name + "innerEdgeColor";
   innerEdgeColor = get_color("PieChartC", pie->da, rsrc, topColor);

   rsrc = name + "outerEdgeColor";
   outerEdgeColor = get_color("PieChartC", pie->da, rsrc, topColor);

   rsrc = name + "offset";
   offset = get_int("PieChartC", pie->da, rsrc, 0);

   rsrc = name + "lineWidth";
   lineWidth = get_int("PieChartC", pie->da, rsrc, pie->lineWidth);

   topPixmap = 0;
// topPixmap = get_pixmap("PieChartC", pie->da, get_string("PieChartC", pie->da, rsrc, "");

   pie->AddSlice(this);
}


// =====================================================================
// The other constructor for the pie slice class (includes label).
// =====================================================================
PieSliceC::PieSliceC(PieChartC *pie, char *slice_name, char* slice_label, float val)
{
   name     = slice_name;
   label    = slice_label;
   pieChart = pie;
   value    = val;

//
// Get the default slice information.
//
   StringC  rsrc;

   rsrc = name + "topColor";
   topColor = get_color("PieChartC", pie->da,rsrc,WhitePixel(pie->display,0));

   rsrc = name + "innerEdgeColor";
   innerEdgeColor = get_color("PieChartC", pie->da, rsrc, topColor);

   rsrc = name + "outerEdgeColor";
   outerEdgeColor = get_color("PieChartC", pie->da, rsrc, topColor);

   rsrc = name + "offset";
   offset = get_int("PieChartC", pie->da, rsrc, 0);

   rsrc = name + "lineWidth";
   lineWidth = get_int("PieChartC", pie->da, rsrc, pie->lineWidth);

   topPixmap = 0;
// topPixmap = get_pixmap("PieChartC", pie->da, get_string("PieChartC", pie->da, rsrc, "");

   pie->AddSlice(this);
}


// =====================================================================
// =====================================================================
PieSliceC::~PieSliceC()
{
   if ( !pieChart->destroyingSelf )
      pieChart->RemoveSlice(this);
}


// =====================================================================
// =====================================================================
void
PieSliceC::Draw()
{
   Dprintf(("************************\n"));
   Dprintf(("Entering PieSliceC::Draw\n"));

   if ( pieChart->defer || scaleValue <= 0.0 ) return;

   float start_angle = RADIANS(startAngle);
   float end_angle   = start_angle + scaleValue*TWO_PI;
   Dprintf(("  slice start_angle: %f\n", startAngle));
   Dprintf(("  slice end_angle: %f\n", DEGREES(end_angle)));

//
// Set the center position of the current slice.
//
   float cx = pieChart->pieX;
   float cy = pieChart->pieY;
   if ( offset > 0 )
   {
      float avg_angle = (start_angle + end_angle)*0.5;
      cx += COS(avg_angle)*(float)offset;
      cy += SIN(avg_angle)*(float)offset;
   }

//
// Determine the number of points needed for this slice.
//
   int num_points = (int)(scaleValue * (float)pieChart->apprx);
   if ( num_points < 2 ) num_points = 2;
   Dprintf(("  num_points: %d\n", num_points));

//
// Initialize the values to go around the pie.
//
   register float inc       = (end_angle-start_angle)/(float)(num_points-1);
   register float inc_cos   = COS(inc);
   register float inc_sin   = SIN(inc);
   register float angle_cos = COS(start_angle);
   register float angle_sin = SIN(start_angle);
   float    rot_cos         = DEG_COS(pieChart->declination);

//
// Go around this pie slice and approximate its edges.
//
   XPoint  Xpts[MAX_PIE_POINTS];
   for ( int i=0; i<num_points; i++ )
   {
      Xpts[i].x = (short)(cx +  (angle_cos * (float)pieChart->radius));
      Xpts[i].y = (short)(cy + ((angle_sin * (float)pieChart->radius)*rot_cos));
      // Dprintf(("   #%2d: %d %d\n", i, Xpts[i].x, Xpts[i].y));

//
//   Calculate the trig values for the next iteration...
//
      float angle_tmp;
      angle_tmp = angle_sin * inc_cos + angle_cos * inc_sin;
      angle_cos = angle_cos * inc_cos - angle_sin * inc_sin;
      angle_sin = angle_tmp;
   }

   if ( pieChart->sliceList.size() > 1 )
   {
      Xpts[num_points].x = (short)cx;
      Xpts[num_points].y = (short)cy;
      num_points++;
   }

//
// Draw the top of the slice.
//
   if ( topPixmap )
   {
      XSetFillStyle ( pieChart->display, pieChart->gc, FillOpaqueStippled );
      XSetStipple ( pieChart->display, pieChart->gc, topPixmap );
      XSetBackground ( pieChart->display, pieChart->gc,
		       XBlackPixel(pieChart->display,0) );
   }
   else
   {
      XSetFillStyle ( pieChart->display, pieChart->gc, FillSolid );
   }
   XSetForeground ( pieChart->display, pieChart->gc, topColor );
   XFillPolygon ( pieChart->display, pieChart->CANVAS, pieChart->gc,
		  Xpts, num_points, Complex, CoordModeOrigin );
		  // Xpts, num_points, Convex, CoordModeOrigin );

//
// Draw the outline if there is one.
//
   if ( lineWidth > 0 )
   {
      XSetLineAttributes ( pieChart->display, pieChart->gc,
			   lineWidth, LineSolid, CapButt, JoinBevel);
      XSetForeground ( pieChart->display, pieChart->gc, pieChart->lineColor );

//
//    If there's only one slice then don't draw the lines to
//    the center of the pie.
//
      if ( pieChart->sliceList.size() == 1 )
      {
         XDrawLines ( pieChart->display, pieChart->CANVAS, pieChart->gc,
		      Xpts, num_points, CoordModeOrigin );
      }
      else
      {
         Xpts[num_points].x = Xpts[0].x;
         Xpts[num_points].y = Xpts[0].y;
         num_points++;
         XDrawLines ( pieChart->display, pieChart->CANVAS, pieChart->gc,
		      Xpts, num_points, CoordModeOrigin );
      }
   }

   Dprintf(("Leaving PieSliceC::Draw\n"));
   Dprintf(("************************\n"));
}


// =====================================================================
// =====================================================================
void
PieSliceC::DrawInnerEdge ( register float angle, register float avg_angle, float rot_cos, float rot_sin )
{
   Dprintf(("************************\n"));
   Dprintf(("Entering DrawInnerEdge\n"));
   Dprintf(("  slice: %d\n", this ));

   if ( scaleValue <= 0.0 ) return;

//
// Get the center of the previous slice.
//
   float cx = pieChart->pieX;
   float cy = pieChart->pieY;
   Dprintf(("  pie center: %f %f\n", cx, cy));

//
// If the slice is offset then move the center point.
//
   if ( offset > 0 )
   {
      cx += (COS(avg_angle) * (float)offset);
      cy += (SIN(avg_angle) * (float)offset);
      Dprintf(("xfrmd center: %f %f\n", cx, cy));
   }

//
// Calculate the end to middle edge of this slice.
//
   float fval = (float)pieChart->pieThickness * -rot_sin;
   XPoint  Xpts[5];
   Xpts[0].x = (short)(cx + (COS(angle) * (float)pieChart->radius));
   Xpts[0].y = (short)(cy + ((SIN(angle) * (float)pieChart->radius) * rot_cos));
   Xpts[1].x = Xpts[0].x;
   Xpts[1].y = Xpts[0].y + (short)fval;
   Xpts[3].x = (short)cx;
   Xpts[3].y = (short)cy;    // * rot_cos;
   Xpts[2].x = (short)cx;
   Xpts[2].y = Xpts[3].y + (short)fval;

//
// Re-Draw the filled portion of the slice.
//
   XSetForeground ( pieChart->display, pieChart->gc, innerEdgeColor );
   XFillPolygon ( pieChart->display, pieChart->CANVAS, pieChart->gc,
		  Xpts, 4, Convex, CoordModeOrigin);
      
//
// Draw the border around the slice side edge.
//
   if ( lineWidth > 0 )
   {
      Xpts[4].x = Xpts[0].x;
      Xpts[4].y = Xpts[0].y;
      XSetLineAttributes ( pieChart->display, pieChart->gc, 
                           lineWidth, LineSolid, CapButt, JoinBevel );
      XSetForeground ( pieChart->display, pieChart->gc, pieChart->lineColor );
      XDrawLines ( pieChart->display, pieChart->CANVAS,
                   pieChart->gc, Xpts, 5, CoordModeOrigin );
   }

   Dprintf(("Leaving DrawInnerEdge\n"));
   Dprintf(("**********************\n"));
}


// =====================================================================
// =====================================================================
void
PieSliceC::ValueString(char* str, ValueType valtype, int prec)
{
   Dprintf(("********************\n"));
   Dprintf(("Entering ValueString\n"));
   Dprintf(("  slice: %s\n", (char*)name));
   Dprintf(("  valtype: %d\n", valtype));
   Dprintf(("  precision: %d\n", prec));
   Dprintf(("  value: %f\n", value));
   Dprintf(("  scaleValue: %f\n", scaleValue));

   switch ( valtype )
   {
      case PieSliceC::HEX:
         Dprintf(("  HEX\n"));
         sprintf(str,"0x%x", (int)value);
	 break;

      case PieSliceC::FLOAT:
         Dprintf(("  FLOAT\n"));
         sprintf(str,"%.*f", prec, value);
	 break;

      case PieSliceC::PERCENTAGE:
         Dprintf(("  PERCENTAGE\n"));
         sprintf (str,"%.*f%%",prec, (scaleValue*100.0));
	 break;

      case PieSliceC::INT:
         Dprintf(("  INT\n"));
         sprintf(str,"%d", (int)value);
	 break;

      case PieSliceC::NONE:
      default:
         Dprintf(("  NONE\n"));
	 str="";
	 break;
   }
   Dprintf(("  return str: <%s>\n", str));
   Dprintf(("Leaving ValueString\n"));
   Dprintf(("********************\n"));
}


// =====================================================================
// =====================================================================
void
PieSliceC::TopColor ( Pixel color)
{
   if ( topColor != color )
   {
      topColor = color;
      pieChart->DrawPie();
   }
}


// =====================================================================
// =====================================================================
void
PieSliceC::TopPixmap ( Pixmap pixmap)
{
   if ( topPixmap != pixmap )
   {
      topPixmap = pixmap;
      pieChart->DrawPie();
   }
}


// =====================================================================
// =====================================================================
void
PieSliceC::InnerEdgeColor( Pixel color)
{
   if ( innerEdgeColor != color )
   {
      innerEdgeColor = color;
      pieChart->DrawPie();
   }
}


// =====================================================================
// =====================================================================
void
PieSliceC::OuterEdgeColor ( Pixel color)
{
   if ( outerEdgeColor != color )
   {
      outerEdgeColor = color;
      pieChart->DrawPie();
   }
}


// =====================================================================
// =====================================================================
void
PieSliceC::Value ( float new_value )
{
   Dprintf((" Input Value: %f\n", new_value));
   Dprintf((" Current Value: %f\n", value));
   if ( value != new_value )
   {
      if ( new_value < 0.0 ) new_value = 0.0;
//
//    Compute the new grand total for the pie.
//
      Dprintf(("  prev pie total: %f\n", pieChart->total));
      pieChart->total += (new_value - value);
      Dprintf(("  new pie total: %f\n", pieChart->total));
      value = new_value;

      pieChart->CalcSliceValues();
      pieChart->CalcPieSliceOffsets();
      pieChart->RecomputeSize();
      pieChart->Draw();
   }
}


// =====================================================================
// =====================================================================
void
PieSliceC::Offset( int new_offset)
{
   if ( offset != new_offset )
   {
      if ( new_offset < 0 ) new_offset = 0;
      offset = new_offset;
      pieChart->CalcPieSliceOffsets();
      pieChart->RecomputeSize();
      pieChart->Draw();
   }
}


// =====================================================================
// =====================================================================
void
PieSliceC::LineWidth( int width)
{
   if ( width != lineWidth )
   {
      if ( width < 0 ) width = 0;
      lineWidth = width;
      pieChart->RecomputeSize();
      pieChart->Draw();
   }
}


// =====================================================================
// =====================================================================
void
PieSliceC::Label(char* new_label)
{
   label = new_label;
   pieChart->CalcLegendSize();
   pieChart->RecomputeSize();
   pieChart->Draw();
}


// =====================================================================
// =====================================================================
PieSliceC::ValueType
PieChartC::get_valtype(char*str)
{
   switch ( *str )
   {
      case 'F':
      case 'f':
	 return(PieSliceC::FLOAT);

      case 'N':
      case 'n':
	 return(PieSliceC::NONE);

      case 'P':
      case 'p':
	 return(PieSliceC::PERCENTAGE);

      case 'I':
      case 'i':
      default:
	 return(PieSliceC::INT);
   }
}


#ifdef DO_SLICE_ROTATION
// =====================================================================
// =====================================================================
void
PieSliceC::Rotation ( int new_rotation)
{
   while ( new_rotation > 360 ) new_rotation -= 360;
   while ( new_rotation <   0 ) new_rotation += 360;
   if ( rotation != new_rotation )
   {
      rotation = new_rotation;
      CalcPieSliceOffsets();
      RecomputeSize();
      Draw();
   }
}
#endif

#ifdef OLD_STUFF
// 
//    Apply the x rotational values for this portion of
//    the chart which is given by the following matrix.
//           --                  --
//          |  1.0, 0.0, 0.0, 0.0  |
//          |  0.0, cos,-sin, 0.0  |
//          |  0.0, sin, cos, 0.0  |
//          |  0.0, 0.0, 0.0, 1.0  |
//           --                  --
//
//
// Now do the end angle directly to take care of precision errors
// that may have acumulated in the loop above.
//
   if ( end_angle >= TWO_PI ) end_angle -= TWO_PI;
   Xpts[num_points].x = (short)(center_x + (COS(end_angle) * (float)pieChart->radius));
   Xpts[num_points].y = (short)(center_y + ((SIN(end_angle) * (float)pieChart->radius)*rot_cos));
   num_points++;
#endif


