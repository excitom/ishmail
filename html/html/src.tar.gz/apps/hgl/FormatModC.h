/*
 * $Id: FormatModC.h,v 1.1 1998/06/24 01:29:07 lang Exp $
 *
 * Copyright (c) 1992 HAL Computer Systems International, Ltd.
 * 
 *          HAL COMPUTER SYSTEMS INTERNATIONAL, LTD.
 *                  1315 Dell Avenue
 *                  Campbell, CA  95008
 *
 * Author: Greg Hilton
 * Contributors: Tom Lang, Frank Bieser, and others
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * http://www.gnu.org/copyleft/gpl.html
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#ifndef _FormatModC_h_
#define _FormatModC_h_

#include "ValueC.h"

#include <Xm/Xm.h>

class FormatModC {

   Widget	form;
   Widget	label;
   Widget	frame;
   Widget	precisTF;
   Widget	precisLabel;
   Widget	radioBox;
   Widget	intTB;
   Widget	hexTB;
   Widget	floatTB;

//
// Current state
//
   ValueC::ValueFormat	format;

//
// Initial state
//
   struct {
      ValueC::ValueFormat	format;
      int			precis;
   } init;

//
// Callbacks
//
   static void	SetFormat(Widget, FormatModC*, XmToggleButtonCallbackStruct*);

public:

// Methods

   FormatModC(Widget, const char*, ArgList argv=NULL, Cardinal argc=0);

//
// Cast to widget
//
   inline operator	Widget() const		{ return form;	}

//
// Return component widgets
//
   MEMBER_QUERY(Widget, Form,		form)
   MEMBER_QUERY(Widget, Label,		label)
   MEMBER_QUERY(Widget, Frame,		frame)
   MEMBER_QUERY(Widget, PrecisTF,	precisTF)
   MEMBER_QUERY(Widget, PrecisLabel,	precisLabel)
   MEMBER_QUERY(Widget, RadioBox,	radioBox)
   MEMBER_QUERY(Widget, IntTB,		intTB)
   MEMBER_QUERY(Widget, HexTB,		hexTB)
   MEMBER_QUERY(Widget, FloatTB,	floatTB)
   MEMBER_QUERY(ValueC::ValueFormat,	Format,	format)

   int			Precision();

//
// Apply settings to the given value
//
   void		Apply(ValueC&);

//
// Initialize settings
//
   void		Init(const ValueC&);
   void		Init(ValueC::ValueFormat, int);

//
// Change settings back to initial values
//
   void		Reset();
};

#endif // _FormatModC_h_
