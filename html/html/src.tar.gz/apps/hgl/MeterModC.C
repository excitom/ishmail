/*
 * $Id: MeterModC.C,v 1.1 1998/06/24 01:29:07 lang Exp $
 *
 * Copyright (c) 1992 HAL Computer Systems International, Ltd.
 * 
 *          HAL COMPUTER SYSTEMS INTERNATIONAL, LTD.
 *                  1315 Dell Avenue
 *                  Campbell, CA  95008
 *
 * Author: Greg Hilton
 * Contributors: Tom Lang, Frank Bieser, and others
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * http://www.gnu.org/copyleft/gpl.html
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#include "MeterModC.h"
#include "FormatModC.h"
#include "ShadowModC.h"
#include "OrientModC.h"
#include "ColorModC.h"
#include "WArgList.h"
#include "rsrc.h"

#include <Xm/Form.h>
#include <Xm/Frame.h>
#include <Xm/Label.h>
#include <Xm/TextF.h>
#include <Xm/RowColumn.h>

MeterModC::MeterModC(Widget parent, const char *name, ArgList argv,
		     Cardinal argc) : ModFormC(parent, name, argv, argc)
{
   WArgList	args;
   StringC	wname;

   meter = NULL;

//
// Create the paramForm hierarchy
//
//   paramForm
//      Label		minLabel
//      TextField	minTF
//      Label		maxLabel
//      TextField	maxTF
//      Label		tick1SpaceLabel
//      TextField	tick1SpaceTF
//      Label		tick2SpaceLabel
//      TextField	tick2SpaceTF
//      Label		tick1LenLabel
//      TextField	tick1LenTF
//      Label		tick2LenLabel
//      TextField	tick2LenTF
//      FormatModC	formatForm
//      ShadowModC	shadowForm
//
   int	ltOffset = get_int("MeterModC", paramForm, "labelTextOffset");

   wname = "minLabel";
   minLabel = XmCreateLabel(paramForm, wname, 0,0);

   wname = "minTF";
   args.Reset();
   args.TopAttachment(XmATTACH_FORM);
   args.LeftAttachment(XmATTACH_FORM);
   minTF = XmCreateTextField(paramForm, wname, ARGS);

   wname = "majorTickSpacingLabel";
   tick1SpaceLabel = XmCreateLabel(paramForm, wname, 0,0);

   wname = "majorTickSpacingTF";
   args.Reset();
   args.TopAttachment(XmATTACH_WIDGET, minTF);
   args.LeftAttachment(XmATTACH_FORM);
   tick1SpaceTF = XmCreateTextField(paramForm, wname, ARGS);

   wname = "majorTickLengthLabel";
   tick1LenLabel = XmCreateLabel(paramForm, wname, 0,0);

   wname = "majorTickLengthTF";
   args.Reset();
   args.TopAttachment(XmATTACH_WIDGET, tick1SpaceTF);
   args.LeftAttachment(XmATTACH_FORM);
   tick1LenTF = XmCreateTextField(paramForm, wname, ARGS);

   wname = "formatMod";
   args.Reset();
   args.TopAttachment(XmATTACH_WIDGET, tick1LenTF);
   formatForm = new FormatModC(paramForm, wname, ARGS);

   wname = "shadowMod";
   args.Reset();
   args.TopAttachment(XmATTACH_WIDGET, *formatForm);
   shadowForm = new ShadowModC(paramForm, wname, ARGS);

//
// Get maximum label width
//
   Dimension	wd, max_wd;
   args.Reset();
   args.Add(XmNwidth, &wd);
   XtGetValues(minLabel,                ARGS); max_wd = wd;
   XtGetValues(tick1SpaceLabel,         ARGS); if (wd>max_wd) max_wd = wd;
   XtGetValues(tick1LenLabel,           ARGS); if (wd>max_wd) max_wd = wd;
   XtGetValues(formatForm->Label(),     ARGS); if (wd>max_wd) max_wd = wd;
   XtGetValues(shadowForm->TypeLabel(), ARGS); if (wd>max_wd) max_wd = wd;

   args.Reset();
   args.LeftAttachment(XmATTACH_FORM, max_wd + ltOffset);
   XtSetValues(minTF,                   ARGS);
   XtSetValues(tick1SpaceTF,            ARGS);
   XtSetValues(tick1LenTF,              ARGS);
   XtSetValues(formatForm->Frame(),     ARGS);
   XtSetValues(shadowForm->TypeFrame(), ARGS);

//
// Attach labels
//
   args.Reset();
   args.TopAttachment(XmATTACH_OPPOSITE_WIDGET,    minTF);
   args.BottomAttachment(XmATTACH_OPPOSITE_WIDGET, minTF);
   args.RightAttachment(XmATTACH_WIDGET,           minTF);
   XtSetValues(minLabel, ARGS);

   args.TopWidget(tick1SpaceTF);
   args.BottomWidget(tick1SpaceTF);
   args.RightWidget(tick1SpaceTF);
   XtSetValues(tick1SpaceLabel, ARGS);

   args.TopWidget(tick1LenTF);
   args.BottomWidget(tick1LenTF);
   args.RightWidget(tick1LenTF);
   XtSetValues(tick1LenLabel, ARGS);

//
// Create the second column of labels and fields
//
   wname = "maxLabel";
   maxLabel = XmCreateLabel(paramForm, wname, 0,0);

   wname = "maxTF";
   args.Reset();
   args.TopAttachment(XmATTACH_OPPOSITE_WIDGET, minTF);
   args.LeftAttachment(XmATTACH_WIDGET, minTF);
   maxTF = XmCreateTextField(paramForm, wname, ARGS);

   wname = "minorTickSpacingLabel";
   tick2SpaceLabel = XmCreateLabel(paramForm, wname, 0,0);

   wname = "minorTickSpacingTF";
   args.Reset();
   args.TopAttachment(XmATTACH_OPPOSITE_WIDGET, tick1SpaceTF);
   args.LeftAttachment(XmATTACH_WIDGET, tick1SpaceTF);
   tick2SpaceTF = XmCreateTextField(paramForm, wname, ARGS);

   wname = "minorTickLengthLabel";
   tick2LenLabel = XmCreateLabel(paramForm, wname, 0,0);

   wname = "minorTickLengthTF";
   args.Reset();
   args.TopAttachment(XmATTACH_OPPOSITE_WIDGET, tick1LenTF);
   args.LeftAttachment(XmATTACH_WIDGET, tick1LenTF);
   tick2LenTF = XmCreateTextField(paramForm, wname, ARGS);

//
// Position 2nd column labels and text
//
   max_wd = 0;
   args.Reset();
   args.Add(XmNwidth, &wd);
   XtGetValues(maxLabel,        ARGS); if (wd>max_wd) max_wd = wd;
   XtGetValues(tick2SpaceLabel, ARGS); if (wd>max_wd) max_wd = wd;
   XtGetValues(tick2LenLabel,   ARGS); if (wd>max_wd) max_wd = wd;

   args.Reset();
   args.LeftAttachment(XmATTACH_WIDGET, minTF, max_wd + ltOffset);
   XtSetValues(maxTF, ARGS);

   args.LeftWidget(tick1SpaceTF);
   XtSetValues(tick2SpaceTF, ARGS);

   args.LeftWidget(tick1LenTF);
   XtSetValues(tick2LenTF, ARGS);

   args.Reset();
   args.LeftAttachment  (XmATTACH_NONE);
   args.RightAttachment (XmATTACH_WIDGET,          maxTF);
   args.TopAttachment   (XmATTACH_OPPOSITE_WIDGET, maxTF);
   args.BottomAttachment(XmATTACH_OPPOSITE_WIDGET, maxTF);
   XtSetValues(maxLabel, ARGS);

   args.RightWidget (tick2SpaceTF);
   args.TopWidget   (tick2SpaceTF);
   args.BottomWidget(tick2SpaceTF);
   XtSetValues(tick2SpaceLabel, ARGS);

   args.RightWidget (tick2LenTF);
   args.TopWidget   (tick2LenTF);
   args.BottomWidget(tick2LenTF);
   XtSetValues(tick2LenLabel, ARGS);

//
// Create the colorRC hierarchy
//
//   colorRC
//      ColorModC	backgroundForm
//      ColorModC	digitBackgroundForm
//      ColorModC	digitForegroundForm
//      ColorModC	topShadowForm
//      ColorModC	bottomShadowForm
//
   wname = "backgroundMod";
   colorForm[MeterC::BACKGROUND]       = new ColorModC(colorRC, wname, 0,0);
   wname = "faceColorMod";
   colorForm[MeterC::FACE_COLOR]       = new ColorModC(colorRC, wname, 0,0);
   wname = "indicatorColorMod";
   colorForm[MeterC::INDICATOR_COLOR]  = new ColorModC(colorRC, wname, 0,0);
   wname = "valueColorMod";
   colorForm[MeterC::VALUE_COLOR]      = new ColorModC(colorRC, wname, 0,0);
   wname = "labelColorMod";
   colorForm[MeterC::LABEL_COLOR]      = new ColorModC(colorRC, wname, 0,0);
   wname = "tickColorMod";
   colorForm[MeterC::TICK_COLOR]       = new ColorModC(colorRC, wname, 0,0);
   wname = "markColorMod";
   colorForm[MeterC::MARK_COLOR]       = new ColorModC(colorRC, wname, 0,0);
   wname = "topShadowColorMod";
   colorForm[MeterC::TOP_SHADOW]       = new ColorModC(colorRC, wname, 0,0);
   wname = "bottomShadowColorMod";
   colorForm[MeterC::BOTTOM_SHADOW]    = new ColorModC(colorRC, wname, 0,0);

//
// Manage children
//
   Widget	list[14];
   list[0] = *colorForm[MeterC::BACKGROUND];
   list[1] = *colorForm[MeterC::FACE_COLOR];
   list[2] = *colorForm[MeterC::INDICATOR_COLOR];
   list[3] = *colorForm[MeterC::VALUE_COLOR];
   list[4] = *colorForm[MeterC::LABEL_COLOR];
   list[5] = *colorForm[MeterC::TICK_COLOR];
   list[6] = *colorForm[MeterC::MARK_COLOR];
   list[7] = *colorForm[MeterC::TOP_SHADOW];
   list[8] = *colorForm[MeterC::BOTTOM_SHADOW];
   XtManageChildren(list, 9);	// colorRC children

   list[ 0] = minLabel;
   list[ 1] = minTF;
   list[ 2] = maxLabel;
   list[ 3] = maxTF;
   list[ 4] = tick1SpaceLabel;
   list[ 5] = tick1SpaceTF;
   list[ 6] = tick2SpaceLabel;
   list[ 7] = tick2SpaceTF;
   list[ 8] = tick1LenLabel;
   list[ 9] = tick1LenTF;
   list[10] = tick2LenLabel;
   list[11] = tick2LenTF;
   list[12] = *formatForm;
   list[13] = *shadowForm;
   XtManageChildren(list, 14);	// paramForm children

} // End MeterModC MeterModC

/*---------------------------------------------------------------
 *  Destructor
 */

MeterModC::~MeterModC()
{
   delete formatForm;
   delete shadowForm;
   for (int i=0; i<MeterC::COLOR_ATTR_COUNT; i++) delete colorForm[i];
}

/*---------------------------------------------------------------
 *  Method to apply meter changes
 */

void
MeterModC::Apply(MeterC& m)
{
   m.Defer(True);

//
// Set the range
//
   char	*cs = XmTextFieldGetString(minTF);
   float	minVal = atof(cs);
   XtFree(cs);

   cs = XmTextFieldGetString(maxTF);
   float	maxVal = atof(cs);
   XtFree(cs);

   m.SetRange(minVal, maxVal);

//
// Set the numeric format
//
   ValueC	formVal;
   formatForm->Apply(formVal);

   m.SetOutputFormat(formVal.Format());
   m.SetPrecision(formVal.Precision());

//
// Set the shadow attributes
//
   m.SetShadowType(shadowForm->Type());
   m.SetShadowThickness(shadowForm->Thickness());

//
// Set the tick spacings
//
   cs = XmTextFieldGetString(tick1SpaceTF);
   float	tick1Space = atof(cs);
   XtFree(cs);

   cs = XmTextFieldGetString(tick2SpaceTF);
   float	tick2Space = atof(cs);
   XtFree(cs);

   m.SetTickSpacing(tick1Space, tick2Space);

//
// Set the tick lengths
//
   cs = XmTextFieldGetString(tick1LenTF);
   int	tick1Len = atoi(cs);
   XtFree(cs);

   cs = XmTextFieldGetString(tick2LenTF);
   int	tick2Len = atoi(cs);
   XtFree(cs);

   m.SetTickLength(tick1Len, tick2Len);

//
// Set the colors
//
   for (int i=0; i<MeterC::COLOR_ATTR_COUNT; i++) {
      ColorModC	*cm = colorForm[i];
      if ( cm->Changed() ) {
	 m.SetColor((MeterC::MeterColorAttr)i, cm->Value());
      }
   }

   m.Defer(False);
   m.Draw();

   return;

} // End MeterModC Apply

/*---------------------------------------------------------------
 *  Method to initialize the settings based on the given meter
 */

void
MeterModC::Init(MeterC& m)
{
   formatForm->Init(m.OutputFormat(), m.Precision());
   shadowForm->Init(m.ShadowType(), m.ShadowThickness());

//
// Initialize the fields
//
   m.GetRange(&init.minVal, &init.maxVal);
   XmTextFieldSetString(minTF, (char *)(StringC)init.minVal);
   XmTextFieldSetString(maxTF, (char *)(StringC)init.maxVal);

   m.GetTickSpacing(&init.tick1Space, &init.tick1Space);
   XmTextFieldSetString(tick1SpaceTF, (char *)(StringC)init.tick1Space);
   XmTextFieldSetString(tick2SpaceTF, (char *)(StringC)init.tick2Space);

   m.GetTickLength(&init.tick1Len, &init.tick2Len);
   StringC	str;
   str += init.tick1Len;
   XmTextFieldSetString(tick1LenTF, str);
   str = "";
   str += init.tick2Len;
   XmTextFieldSetString(tick2LenTF, str);

//
// Initialize the colors
//
   for (int i=0; i<MeterC::COLOR_ATTR_COUNT; i++) {
      colorForm[i]->Init(m.GetColor((MeterC::MeterColorAttr)i));
   }

   meter = &m;

} // End MeterModC Init

/*---------------------------------------------------------------
 *  Method to reset the fields to their initial values
 */

void
MeterModC::Reset()
{
   XmTextFieldSetString(minTF, (char *)(StringC)init.minVal);
   XmTextFieldSetString(maxTF, (char *)(StringC)init.maxVal);
   XmTextFieldSetString(tick1SpaceTF, (char *)(StringC)init.tick1Space);
   XmTextFieldSetString(tick2SpaceTF, (char *)(StringC)init.tick2Space);

   StringC	str;
   str += init.tick1Len;
   XmTextFieldSetString(tick1LenTF, str);
   str = "";
   str += init.tick2Len;
   XmTextFieldSetString(tick2LenTF, str);

   formatForm->Reset();
   shadowForm->Reset();

//
// Initialize the colors
//
   for (int i=0; i<MeterC::COLOR_ATTR_COUNT; i++) colorForm[i]->Reset();

   if ( autoApply ) {
      meter->Defer(True);
      meter->SetRange(init.minVal, init.maxVal);
      meter->SetTickSpacing(init.tick1Space, init.tick2Space);
      meter->SetTickLength(init.tick1Len, init.tick2Len);
      meter->SetOutputFormat(formatForm->Format());
      meter->SetPrecision(formatForm->Precision());
      meter->SetShadowType(shadowForm->Type());
      meter->SetShadowThickness(shadowForm->Thickness());
      for (int i=0; i<MeterC::COLOR_ATTR_COUNT; i++)
	 meter->SetColor((MeterC::MeterColorAttr)i, colorForm[i]->Value());
      meter->Defer(False);
      meter->Draw();
   }

} // End MeterModC Reset

/*---------------------------------------------------------------
 *  Method to add the callbacks needed to support auto update
 */

void
MeterModC::EnableAutoApply()
{
   if ( autoApply ) return;

#define AddValueChanged(W,C) \
   XtAddCallback(W, XmNvalueChangedCallback, \
	         (XtCallbackProc)(C), (XtPointer)this)

#define AddActivate(W,C) \
   XtAddCallback(W, XmNactivateCallback, \
	         (XtCallbackProc)(C), (XtPointer)this)

#define AddColorActivate(COL,C) \
   AddActivate(colorForm[MeterC::COL]->TextField(), C)

//
// Add auto-update callbacks
//
   AddActivate     (minTF,                   ChangeRange);
   AddActivate     (maxTF,                   ChangeRange);
   AddActivate     (tick1SpaceTF,            ChangeTickSpace);
   AddActivate     (tick2SpaceTF,            ChangeTickSpace);
   AddActivate     (tick1LenTF,              ChangeTickLength);
   AddActivate     (tick2LenTF,              ChangeTickLength);
   AddValueChanged (formatForm->IntTB(),     ChangeFormat);
   AddValueChanged (formatForm->HexTB(),     ChangeFormat);
   AddValueChanged (formatForm->FloatTB(),   ChangeFormat);
   AddActivate     (formatForm->PrecisTF(),  ChangeFormatPrecis);
   AddValueChanged (shadowForm->InTB(),      ChangeShadow);
   AddValueChanged (shadowForm->OutTB(),     ChangeShadow);
   AddValueChanged (shadowForm->EtchInTB(),  ChangeShadow);
   AddValueChanged (shadowForm->EtchOutTB(), ChangeShadow);
   AddActivate     (shadowForm->ThickTF(),   ChangeShadowThick);
   AddColorActivate(BACKGROUND,              ChangeBackground);
   AddColorActivate(FACE_COLOR,              ChangeFaceColor);
   AddColorActivate(INDICATOR_COLOR,         ChangeIndicatorColor);
   AddColorActivate(VALUE_COLOR,             ChangeValueColor);
   AddColorActivate(LABEL_COLOR,             ChangeLabelColor);
   AddColorActivate(TICK_COLOR,              ChangeTickColor);
   AddColorActivate(MARK_COLOR,              ChangeMarkColor);
   AddColorActivate(TOP_SHADOW,              ChangeTopShadow);
   AddColorActivate(BOTTOM_SHADOW,           ChangeBottomShadow);

} // End MeterModC EnableAutoApply

/*---------------------------------------------------------------
 *  Method to remove the callbacks needed to support auto update
 */

void
MeterModC::DisableAutoApply()
{
   if ( !autoApply ) return;

#define RemoveValueChanged(W,C) \
   XtRemoveCallback(W, XmNvalueChangedCallback, \
	            (XtCallbackProc)(C), (XtPointer)this)

#define RemoveActivate(W,C) \
   XtRemoveCallback(W, XmNactivateCallback, \
	            (XtCallbackProc)(C), (XtPointer)this)

#define RemoveColorActivate(COL,C) \
   RemoveActivate(colorForm[MeterC::COL]->TextField(), C)

//
// Remove auto-update callbacks
//
   RemoveActivate     (minTF,                   ChangeRange);
   RemoveActivate     (maxTF,                   ChangeRange);
   RemoveActivate     (tick1SpaceTF,            ChangeTickSpace);
   RemoveActivate     (tick2SpaceTF,            ChangeTickSpace);
   RemoveActivate     (tick1LenTF,              ChangeTickLength);
   RemoveActivate     (tick2LenTF,              ChangeTickLength);
   RemoveValueChanged (formatForm->IntTB(),     ChangeFormat);
   RemoveValueChanged (formatForm->HexTB(),     ChangeFormat);
   RemoveValueChanged (formatForm->FloatTB(),   ChangeFormat);
   RemoveActivate     (formatForm->PrecisTF(),  ChangeFormatPrecis);
   RemoveValueChanged (shadowForm->InTB(),      ChangeShadow);
   RemoveValueChanged (shadowForm->OutTB(),     ChangeShadow);
   RemoveValueChanged (shadowForm->EtchInTB(),  ChangeShadow);
   RemoveValueChanged (shadowForm->EtchOutTB(), ChangeShadow);
   RemoveActivate     (shadowForm->ThickTF(),   ChangeShadowThick);
   RemoveColorActivate(BACKGROUND,              ChangeBackground);
   RemoveColorActivate(FACE_COLOR,              ChangeFaceColor);
   RemoveColorActivate(INDICATOR_COLOR,         ChangeIndicatorColor);
   RemoveColorActivate(VALUE_COLOR,             ChangeValueColor);
   RemoveColorActivate(LABEL_COLOR,             ChangeLabelColor);
   RemoveColorActivate(TICK_COLOR,              ChangeTickColor);
   RemoveColorActivate(MARK_COLOR,              ChangeMarkColor);
   RemoveColorActivate(TOP_SHADOW,              ChangeTopShadow);
   RemoveColorActivate(BOTTOM_SHADOW,           ChangeBottomShadow);

} // End MeterModC DisableAutoApply

void
MeterModC::ChangeRange(Widget, MeterModC *mm, XtPointer)
{
   if ( XmTextFieldGetLastPosition(mm->minTF) == 0 ||
        XmTextFieldGetLastPosition(mm->maxTF) == 0 ) return;

   char *cs = XmTextFieldGetString(mm->minTF);
   float	min = atof(cs);
   XtFree(cs);

   cs = XmTextFieldGetString(mm->maxTF);
   float	max = atof(cs);
   XtFree(cs);

   if ( min >= max ) return;

   mm->meter->SetRange(min, max);
}

void
MeterModC::ChangeTickSpace(Widget, MeterModC *mm, XtPointer)
{
   if ( XmTextFieldGetLastPosition(mm->tick1SpaceTF) == 0 ||
        XmTextFieldGetLastPosition(mm->tick2SpaceTF) == 0 ) return;

   char *cs = XmTextFieldGetString(mm->tick1SpaceTF);
   float	tick1 = atof(cs);
   XtFree(cs);

   cs = XmTextFieldGetString(mm->tick2SpaceTF);
   float	tick2 = atof(cs);
   XtFree(cs);

   mm->meter->SetTickSpacing(tick1, tick2);
}

void
MeterModC::ChangeTickLength(Widget, MeterModC *mm, XtPointer)
{
   if ( XmTextFieldGetLastPosition(mm->tick1LenTF) == 0 ||
        XmTextFieldGetLastPosition(mm->tick2LenTF) == 0 ) return;

   char *cs = XmTextFieldGetString(mm->tick1LenTF);
   int	tick1 = atoi(cs);
   XtFree(cs);

   cs = XmTextFieldGetString(mm->tick2LenTF);
   int	tick2 = atoi(cs);
   XtFree(cs);

   mm->meter->SetTickLength(tick1, tick2);
}

void
MeterModC::ChangeFormat(Widget, MeterModC *mm, XmToggleButtonCallbackStruct *tb)
{
   if ( tb->set )
      mm->meter->SetOutputFormat(mm->formatForm->Format());
}

void
MeterModC::ChangeFormatPrecis(Widget, MeterModC *mm, XtPointer)
{
   mm->meter->SetPrecision(mm->formatForm->Precision());
}

void
MeterModC::ChangeShadow(Widget, MeterModC *mm,
			XmToggleButtonCallbackStruct *tb)
{
   if ( tb->set )
      mm->meter->SetShadowType(mm->shadowForm->Type());
}

void
MeterModC::ChangeShadowThick(Widget, MeterModC *mm, XtPointer)
{
   mm->meter->SetShadowThickness(mm->shadowForm->Thickness());
}

void
MeterModC::ChangeBackground(Widget, MeterModC *mm, XtPointer)
{
   mm->ChangeColor(MeterC::BACKGROUND);
}

void
MeterModC::ChangeFaceColor(Widget, MeterModC *mm, XtPointer)
{
   mm->ChangeColor(MeterC::FACE_COLOR);
}

void
MeterModC::ChangeIndicatorColor(Widget, MeterModC *mm, XtPointer)
{
   mm->ChangeColor(MeterC::INDICATOR_COLOR);
}

void
MeterModC::ChangeValueColor(Widget, MeterModC *mm, XtPointer)
{
   mm->ChangeColor(MeterC::VALUE_COLOR);
}

void
MeterModC::ChangeLabelColor(Widget, MeterModC *mm, XtPointer)
{
   mm->ChangeColor(MeterC::LABEL_COLOR);
}

void
MeterModC::ChangeTickColor(Widget, MeterModC *mm, XtPointer)
{
   mm->ChangeColor(MeterC::TICK_COLOR);
}

void
MeterModC::ChangeMarkColor(Widget, MeterModC *mm, XtPointer)
{
   mm->ChangeColor(MeterC::MARK_COLOR);
}

void
MeterModC::ChangeTopShadow(Widget, MeterModC *mm, XtPointer)
{
   mm->ChangeColor(MeterC::TOP_SHADOW);
}

void
MeterModC::ChangeBottomShadow(Widget, MeterModC *mm, XtPointer)
{
   mm->ChangeColor(MeterC::BOTTOM_SHADOW);
}

void
MeterModC::ChangeColor(MeterC::MeterColorAttr color)
{
   ColorModC		*cm = colorForm[color];

   if ( cm->Changed() ) meter->SetColor(color, cm->Value());
}
