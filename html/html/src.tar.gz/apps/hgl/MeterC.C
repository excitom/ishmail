/*
 * $Id: MeterC.C,v 1.1 1998/06/24 01:29:07 lang Exp $
 *
 * Copyright (c) 1992 HAL Computer Systems International, Ltd.
 * 
 *          HAL COMPUTER SYSTEMS INTERNATIONAL, LTD.
 *                  1315 Dell Avenue
 *                  Campbell, CA  95008
 *
 * Author: Greg Hilton
 * Contributors: Tom Lang, Frank Bieser, and others
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * http://www.gnu.org/copyleft/gpl.html
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#include "HalAppC.h"
#include "MeterC.h"
#include "WArgList.h"
#include "rsrc.h"
#include "MatrixC.h"
#include "RegexC.h"
#include "IntListC.h"
#include "StringListC.h"
#include "WorkingBoxC.h"

#include <Xm/DrawingA.h>

#define DEFAULT_BG_COLOR	WhitePixel(halApp->display, \
                                           DefaultScreen(halApp->display))
#define DEFAULT_FG_COLOR	BlackPixel(halApp->display,  \
                                           DefaultScreen(halApp->display))

/*----------------------------------------------------------------------
 * Method to build the widget hierarchy
 */

MeterC::MeterC(Widget parent, const char *name, ArgList argv, Cardinal argc)
: GraphC(parent, name, argv, argc)
{
   dragging     = False;
   markList.AllowDuplicates(TRUE);

//
// Read attributes
//
   char	*cl = "MeterC";
   labelOffset	    = get_int(cl, da, "labelOffset", 2);
   shadowType       = get_shadow_type(cl, da, "shadowType", XmSHADOW_OUT);
   shadowThickness  = get_int(cl, da, "shadowThickness", 2);
   majorTickLen     = get_int(cl, da, "majorTickLength", 8);
   minorTickLen     = get_int(cl, da, "minorTickLength", 4);
   majorTickSpacing = get_float(cl, da, "majorTickSpacing", 0.0);
   minorTickSpacing = get_float(cl, da, "minorTickSpacing", 0.0);

   value       = get_float(cl, da, "value", 0.0);
   minValue    = get_float(cl, da, "minValue", value - 1.0);
   maxValue    = get_float(cl, da, "maxValue", minValue + 2.0);
   valRangeInv = 1.0 / (maxValue - minValue);
   int precis  = get_int  (cl, da, "decimalPlaces", 2);
   formatVal.SetPrecision(precis);

   allowInput	    = get_boolean(cl, da, "allowInput", False);
   if ( allowInput ) {
      allowInput = False;
      AllowInput(True);
   }

   colors[BACKGROUND]      = get_color(cl, da, "background",     DEFAULT_BG_COLOR);
   colors[TOP_SHADOW]      = get_color(cl, da, "topShadowColor", DEFAULT_BG_COLOR);
   colors[BOTTOM_SHADOW]   = get_color(cl, da, "bottomShadowColor", DEFAULT_FG_COLOR);
   colors[FACE_COLOR]      = get_color(cl, da, "faceColor",      colors[BACKGROUND]);
   colors[INDICATOR_COLOR] = get_color(cl, da, "indicatorColor", DEFAULT_FG_COLOR);
   colors[VALUE_COLOR]     = get_color(cl, da, "valueColor",     DEFAULT_FG_COLOR);
   colors[LABEL_COLOR]     = get_color(cl, da, "labelColor",     DEFAULT_FG_COLOR);
   colors[TICK_COLOR]      = get_color(cl, da, "tickColor",      DEFAULT_FG_COLOR);
   colors[MARK_COLOR]      = get_color(cl, da, "markColor",      DEFAULT_FG_COLOR);

//
// Get color names
//
   colorNames[BACKGROUND]      = ColorName(da, colors[BACKGROUND]);
   colorNames[FACE_COLOR]      = ColorName(da, colors[FACE_COLOR]);
   colorNames[INDICATOR_COLOR] = ColorName(da, colors[INDICATOR_COLOR]);
   colorNames[VALUE_COLOR]     = ColorName(da, colors[VALUE_COLOR]);
   colorNames[LABEL_COLOR]     = ColorName(da, colors[LABEL_COLOR]);
   colorNames[TICK_COLOR]      = ColorName(da, colors[TICK_COLOR]);
   colorNames[MARK_COLOR]      = ColorName(da, colors[MARK_COLOR]);
   colorNames[TOP_SHADOW]      = ColorName(da, colors[TOP_SHADOW]);
   colorNames[BOTTOM_SHADOW]   = ColorName(da, colors[BOTTOM_SHADOW]);

//
// Load font
//
   StringC	str = get_string(cl, da, "font", "fixed");
   font = XLoadQueryFont(halApp->display, str);
   if ( !font ) font = halApp->font;

   return;

} // End MeterC MeterC

/*----------------------------------------------------------------------
 * MeterC destructor
 */

MeterC::~MeterC()
{
   if ( halApp->xRunning )  
      XFreeFont(halApp->display, font);

   DeleteCallbacks(dragCalls);
   DeleteCallbacks(valueChangedCalls);
}

/*----------------------------------------------------------------------
 * Method to draw meter
 */

void
MeterC::Draw()
{
   if ( !gc || obscured ) return;

   XSetForeground(halApp->display, gc, colors[BACKGROUND]);
   XFillRectangle(halApp->display, pixmap, gc, 0, 0, daWd, daHt);

//
// Create label strings
//
   formatVal = minValue;
   StringC	minStr = formatVal;
   formatVal = maxValue;
   StringC	maxStr = formatVal;

   int		dir, asc, dsc;
   XCharStruct	minSize, maxSize;
   XTextExtents(font, minStr, minStr.size(), &dir, &asc, &dsc, &minSize);
   XTextExtents(font, maxStr, maxStr.size(), &dir, &asc, &dsc, &maxSize);
   int	maxLabelWd = MAX(minSize.width, maxSize.width);

   int	margWd = marginWd*2;
   if ( markList.size() > 0 ) margWd += maxLabelWd + labelOffset;
   else			      margWd += maxLabelWd/2;
   if ( majorTickLen >= minorTickLen ) {
      if      ( majorTickSpacing > 0 ) margWd += majorTickLen;
      else if ( minorTickSpacing > 0 ) margWd += minorTickLen;
   } else {
      if      ( minorTickSpacing > 0 ) margWd += minorTickLen;
      else if ( majorTickSpacing > 0 ) margWd += majorTickLen;
   }

   int	labelHt = font->ascent + font->descent + labelOffset;
   int	topMargin = marginHt;
   if ( markList.size() > 0 ) topMargin += labelHt;
   if ( majorTickLen >= minorTickLen ) {
      if      ( majorTickSpacing > 0 ) topMargin += majorTickLen;
      else if ( minorTickSpacing > 0 ) topMargin += minorTickLen;
   } else {
      if      ( minorTickSpacing > 0 ) topMargin += minorTickLen;
      else if ( majorTickSpacing > 0 ) topMargin += majorTickLen;
   }

   int	botMargin = marginHt + labelHt;

   int	meterWd = daWd - margWd*2;
   int	meterHt = daHt - topMargin - botMargin;
   if ( meterWd < 1 ) meterWd = 1;
   if ( meterHt < 1 ) meterHt = 1;

//
// Keep circular
//
   if      ( meterWd > meterHt*2 ) meterWd = meterHt*2;
   else if ( meterWd < meterHt*2 ) {
      int	newHt = meterWd/2;
      int	marginDiff = (meterHt - newHt)/2;
      topMargin += marginDiff;
      botMargin += marginDiff;
      meterHt = newHt;
   }

//
// Center it in area
//
   int meterX = (int)(daWd - meterWd) / (int)2;
   int meterY = (int)(daHt - meterHt - topMargin - botMargin) / (int)2;
   meterY += topMargin;

   meterRadius = meterWd/2;

//
// Draw meter outline and shadow
//
   XSetForeground(halApp->display, gc, colors[FACE_COLOR]);
   XFillArc(halApp->display, pixmap, gc, meterX, meterY, meterWd, meterHt*2,
	    0, 180*64);

   if ( shadowThickness > 0 )
      DrawShadow(colors[TOP_SHADOW], colors[BOTTOM_SHADOW], meterX, meterY,
		 meterWd, meterHt, shadowThickness);

//
// Draw current value indicator
//
   MatrixC	mat;
   int	x = meterX + meterWd / 2;
   int	y = meterY + meterHt - shadowThickness;
   float	angle = NormalizeValue(value) * 180.0;
   mat.Rotate(angle);					// Rotate to position
   mat.Scale((float)((float)((int)meterWd - (int)shadowThickness*2)/(float)2),
	     (float) ((int)meterHt - (int)shadowThickness*2));
   mat.Translate(x, y);					// Translate to position

   int	x2 = -1;
   int	y2 =  0;
   mat.Transform(&x2, &y2);

   indicatorX = x;
   indicatorY = y;
   XSetForeground(halApp->display, gc, colors[INDICATOR_COLOR]);
   XDrawLine(halApp->display, pixmap, gc, x, y, x2, y2);
   XPoint	points[3];
   points[0].x = (short)x2;
   points[0].y = (short)y2;
   float	fx = -0.92;
   float	fy = -0.06;
   mat.Transform(&fx, &fy);
   points[1].x = (short)(fx + ((fx>0.0) ? 0.5 : -0.5));
   points[1].y = (short)(fy + ((fy>0.0) ? 0.5 : -0.5));
   fx = -0.92;
   fy =  0.06;
   mat.Transform(&fx, &fy);
   points[2].x = (short)(fx + ((fx>0.0) ? 0.5 : -0.5));
   points[2].y = (short)(fy + ((fy>0.0) ? 0.5 : -0.5));
   XFillPolygon(halApp->display, pixmap, gc, points, 3, Convex,CoordModeOrigin);

//
// Draw label strings
//
   x = meterX - minSize.width/2;
   y = meterY + meterHt + labelOffset + font->ascent;
   XSetForeground(halApp->display, gc, colors[LABEL_COLOR]);
   XDrawString(halApp->display, pixmap, gc, x, y, minStr, minStr.size());

   x = meterX + meterWd - maxSize.width/2;
   XDrawString(halApp->display, pixmap, gc, x, y, maxStr, maxStr.size());

//
// Draw meter value
//
   StringC	valStr = ValueString();
   XCharStruct	size;
   XTextExtents(font, valStr, valStr.size(), &dir, &asc, &dsc, &size);
   x = meterX + ((meterWd - size.width) / 2);
   y = meterY + meterHt - shadowThickness - labelOffset - size.descent;
   XSetForeground(halApp->display, gc, colors[VALUE_COLOR]);
   XDrawString(halApp->display, pixmap, gc, x, y, valStr, valStr.size());

//
// Draw ticks
//
   XSetForeground(halApp->display, gc, colors[TICK_COLOR]);
   float	meterWd2 = meterWd/2.0;
   if ( majorTickSpacing > 0.0 ) {

      float	val = minValue;
      x = meterX + meterWd / 2;
      y = meterY + meterHt - shadowThickness;
      while ( val <= maxValue ) {

	 mat.Identity();
	 angle = NormalizeValue(val) * 180.0;
	 mat.Rotate(angle);			// Rotate to position
	 mat.Scale((float)1.0, (float)(meterHt*2.0)/(float)meterWd);
	 mat.Translate(x, y);			// Translate to position

	 fx = -meterWd2;
	 fy =  0;
	 mat.Transform(&fx, &fy);
	 int	x1 = (int)(fx + ((fx>0.0) ? 0.5 : -0.5));
	 int	y1 = (int)(fy + ((fy>0.0) ? 0.5 : -0.5));
	 fx = -meterWd2 - majorTickLen;
	 fy =  0;
	 mat.Transform(&fx, &fy);
	 x2 = (int)(fx + ((fx>0.0) ? 0.5 : -0.5));
	 y2 = (int)(fy + ((fy>0.0) ? 0.5 : -0.5));

	 XDrawLine(halApp->display, pixmap, gc, x1, y1, x2, y2);

	 val += majorTickSpacing;

      } // End for each major tick

   } // End if there are major ticks

   if ( minorTickSpacing > 0.0 ) {

      float	val = minValue;
      x = meterX + meterWd / 2;
      y = meterY + meterHt - shadowThickness;
      while ( val <= maxValue ) {

	 mat.Identity();
	 angle = NormalizeValue(val) * 180.0;
	 mat.Rotate(angle);			// Rotate to position
	 mat.Scale((float)1.0, (float)(meterHt*2.0)/(float)meterWd);
	 mat.Translate(x, y);			// Translate to position

	 fx = -meterWd2;
	 fy =  0;
	 mat.Transform(&fx, &fy);
	 int	x1 = (int)(fx + ((fx>0.0) ? 0.5 : -0.5));
	 int	y1 = (int)(fy + ((fy>0.0) ? 0.5 : -0.5));
	 fx = -meterWd2 - minorTickLen;
	 fy =  0;
	 mat.Transform(&fx, &fy);
	 x2 = (int)(fx + ((fx>0.0) ? 0.5 : -0.5));
	 y2 = (int)(fy + ((fy>0.0) ? 0.5 : -0.5));

	 XDrawLine(halApp->display, pixmap, gc, x1, y1, x2, y2);

	 val += minorTickSpacing;

      } // End for each minor tick

   } // End if there are minor ticks

//
// Draw marks
//
   XSetForeground(halApp->display, gc, colors[MARK_COLOR]);

   x = meterX + meterWd / 2;
   y = meterY + meterHt - shadowThickness;
   unsigned	count = markList.size();
   for (int i=0; i<count; i++) {
      formatVal = *markList[i];

      angle = NormalizeValue(formatVal) * 180.0;
      mat.Identity();
      mat.Rotate(angle);				// Rotate to position
      mat.Scale((float)1.0, (float)(meterHt*2.0)/(float)meterWd);
      mat.Translate(x, y);				// Translate to position

      fx = -meterWd2 - minorTickLen;
      fy =  0.00;
      mat.Transform(&fx, &fy);
      int	x1 = (int)(fx + ((fx>0.0) ? 0.5 : -0.5));
      int	y1 = (int)(fy + ((fy>0.0) ? 0.5 : -0.5));
      fx = -meterWd2 + minorTickLen;
      fy = 0.00;
      mat.Transform(&fx, &fy);
      x2 = (int)(fx + ((fx>0.0) ? 0.5 : -0.5));
      y2 = (int)(fy + ((fy>0.0) ? 0.5 : -0.5));

      XDrawLine(halApp->display, pixmap, gc, x1, y1, x2, y2);

      valStr = (StringC)formatVal;
      XTextExtents(font, valStr, valStr.size(), &dir, &asc, &dsc, &size);
      if ( x1 < x ) {
	 x1 -= (size.width + labelOffset);
	 if ( x1 < 0 ) x1 = 0; 
      } else {
	 x1 += labelOffset;
	 if ( (x1+size.width) > (int)daWd ) x1 = daWd - size.width;; 
      }
      y1 -= (labelOffset + size.descent);
      XDrawString(halApp->display, pixmap, gc, x1, y1, valStr, valStr.size());
   }

   XCopyArea(halApp->display, pixmap, win, gc, 0, 0, daWd, daHt, 0, 0);

} // End MeterC Draw

/*----------------------------------------------------------------------
 * Method to draw a shadow for the specified meter region
 */

void
MeterC::DrawShadow(Pixel tsColor, Pixel bsColor, int x, int y, int wd,
			int ht, int thick)
{
   switch (shadowType) {
      case XmSHADOW_IN:
	 DrawShadowIn(tsColor, bsColor, x, y, wd, ht, thick);
	 break;
      case XmSHADOW_OUT:
	 DrawShadowIn(bsColor, tsColor, x, y, wd, ht, thick);
	 break;
      case XmSHADOW_ETCHED_IN:
	 DrawShadowEtchedIn(tsColor, bsColor, x, y, wd, ht, thick);
	 break;
      case XmSHADOW_ETCHED_OUT:
	 DrawShadowEtchedIn(bsColor, tsColor, x, y, wd, ht, thick);
	 break;
   }

} // End MeterC DrawShadow

/*----------------------------------------------------------------------
 * Method to draw an inward shadow around the specified meter region
 */

void
MeterC::DrawShadowIn(Pixel tsColor, Pixel bsColor, int x, int y, int wd,
			  int ht, int thick)
{
//
// Draw top lines
//
   int	i;
   int	x1 = x;
   int	w1 = wd;
   int	y1 = y;
   int	h1 = ht;
   XSetForeground(halApp->display, gc, bsColor);
   for (i=0; i<thick; i++) {
      XDrawArc(halApp->display, pixmap, gc, x1, y1, w1, h1*2, 45*64, 135*64);
      x1++;
      y1++;
      w1 -= 2;
      h1 -= 2;
   }

//
// Draw right lines
//
   XSetForeground(halApp->display, gc, tsColor);
   x1 = x;
   w1 = wd;
   y1 = y;
   h1 = ht;
   for (i=0; i<thick; i++) {
      XDrawArc(halApp->display, pixmap, gc, x1, y1, w1, h1*2, 0, 45*64);
      x1++;
      y1++;
      w1 -= 2;
      h1 -= 2;
   }

//
// Draw bottom lines
//
   x1 = x + 1;
   int	x2 = x + wd;
   y1 = y + ht;
   for (i=0; i<thick; i++) {
      XDrawLine(halApp->display, pixmap, gc, x1, y1, x2, y1);
      x1++;
      y1--;
   }

} // End MeterC DrawShadowIn

/*----------------------------------------------------------------------
 * Method to draw an etched in shadow around the specified meter region
 */

void
MeterC::DrawShadowEtchedIn(Pixel tsColor, Pixel bsColor, int x, int y,
				int wd, int ht, int thick)
{
   int	thick1 = thick / 2;
   int	thick2 = thick - thick1;
   DrawShadowIn(tsColor, bsColor, x, y, wd, ht, thick1);
   DrawShadowIn(bsColor, tsColor, x+thick1, y+thick1, wd-thick1*2,
		     ht-thick1*2, thick2);

} // End MeterC DrawShadowEtchedIn

/*----------------------------------------------------------------------
 * Method to convert value into range 0.0 to 1.0
  */

float
MeterC::NormalizeValue(float val)
{
   return ((val - minValue) * valRangeInv);
}

/*----------------------------------------------------------------------
 * Method to add a mark
 */

void
MeterC::AddMark(const ValueC val)
{
   float	fval = val;
   markList.append(fval);
   if ( !deferred ) Draw();
}

/*----------------------------------------------------------------------
 * Method to set the shadow thickness
 */

void
MeterC::SetShadowThickness(Dimension thick)
{
   if ( thick != shadowThickness ) {
      shadowThickness = thick;
      if ( !deferred ) Draw();
   }
}

/*----------------------------------------------------------------------
 * Method to set the shadow type
 */

void
MeterC::SetShadowType(unsigned char type)
{
   if ( type != shadowType ) {
      shadowType = type;
      if ( !deferred ) Draw();
   }
}

/*----------------------------------------------------------------------
 * Method to set the spacing between labels and the meter
 */

void
MeterC::SetLabelOffset(int offset)
{
   if ( offset != labelOffset ) {
      labelOffset = offset;
      if ( !deferred ) Draw();
   }
}

/*----------------------------------------------------------------------
 * Methods to set mark values
 */

void
MeterC::SetMarks(const IntListC& list)
{
   markList.removeAll();

   unsigned	count = list.size();
   for (int i=0; i<count; i++) {
      float	fval = *list[i];
      markList.append(fval);
   }

   if ( !deferred ) Draw();
}

void
MeterC::SetMarks(const FloatListC& list)
{
   markList = list;
   if ( !deferred ) Draw();
}

/*----------------------------------------------------------------------
 * Method to set the numeric output format to INT, HEX or FLOAT
 */

void
MeterC::SetOutputFormat(ValueC::ValueFormat newFormat)
{
   if ( newFormat != formatVal.Format() ) {
      formatVal.SetFormat(newFormat);
      if ( !deferred ) Draw();
   }
}

/*----------------------------------------------------------------------
 * Methods to set the number of decimal places for float output
 */

void
MeterC::SetPrecision(int places)
{
   if ( places != formatVal.Precision() ) {
      formatVal.SetPrecision(places);
      if ( !deferred && formatVal.Format() == ValueC::FLOAT ) Draw();
   }
}

/*----------------------------------------------------------------------
 * Method to set the minimum and maximum values for the meter
 */

void
MeterC::SetRange(const ValueC min, const ValueC max)
{
   if ( (float)max <= (float)min ) return;

   minValue = min;
   maxValue = max;
   valRangeInv = 1.0/(maxValue - minValue);

   if ( !deferred ) Draw();
}

/*----------------------------------------------------------------------
 * Method to set the current value
 */

void
MeterC::SetValue(const ValueC val)
{
   value = val;
   if ( !deferred ) Draw();
}

/*----------------------------------------------------------------------
 * Method to set the major and minor tick mark lengths
 */

void
MeterC::SetTickLength(int maj, int min)
{
   if ( maj != majorTickLen || min != minorTickLen ) {
      majorTickLen = maj;
      minorTickLen = min;
      if ( !deferred ) Draw();
   }
}

/*----------------------------------------------------------------------
 * Method to set the major and minor tick mark spacings
 */

void
MeterC::SetTickSpacing(const ValueC maj, const ValueC min)
{
   if ( (float)maj != (float)majorTickSpacing ||
	(float)min != (float)minorTickSpacing ) {
      majorTickSpacing = (float)maj;
      minorTickSpacing = (float)min;
      if ( !deferred ) Draw();
   }
}

/*----------------------------------------------------------------------
 * Methods to set the requested color
 */

void
MeterC::SetColor(MeterC::MeterColorAttr attr, Pixel color)
{
   if ( colors[attr] == color ) return;

   colors[attr]     = color;
   colorNames[attr] = ColorName(da, color);

   switch (attr) {

      case (BACKGROUND):
	 XtVaSetValues(da, XmNbackground, color, NULL);

      default:
	 if ( !deferred ) Draw();
	 break;

   } // End switch color attribute
}

void
MeterC::SetColor(MeterC::MeterColorAttr attr, const char *name)
{
   Pixel	color;
   if ( PixelValue(da, name, &color) ) SetColor(attr, color);
}

/*----------------------------------------------------------------------
 * Method to return the requested pixel value
 */

Pixel
MeterC::GetColor(MeterC::MeterColorAttr attr) const
{
   return colors[attr];
}

/*----------------------------------------------------------------------
 * Method to return the requested color name
 */

StringC
MeterC::GetColorName(MeterC::MeterColorAttr attr) const
{
   return colorNames[attr];
}

/*-----------------------------------------------------------------------
 *  Methods to return the min and max values
 */

void
MeterC::GetRange(ValueC *min, ValueC *max) const
{
   *min = minValue;
   *max = maxValue;
}

void
MeterC::GetRange(StringC *min, StringC *max) const
{
   ValueC	tmp(formatVal);
   tmp = minValue;
   *min = (StringC)tmp;
   tmp = maxValue;
   *max = (StringC)tmp;
}

void
MeterC::GetRange(int *min, int *max) const
{
   *min = (int)minValue;
   *max = (int)maxValue;
}

void
MeterC::GetRange(long *min, long *max) const
{
   *min = (long)minValue;
   *max = (long)maxValue;
}

void
MeterC::GetRange(float *min, float *max) const
{
   *min = minValue;
   *max = maxValue;
}

/*-----------------------------------------------------------------------
 *  Method to return the major and minor tick mark lengths
 */

void
MeterC::GetTickLength(int *maj, int *min) const
{
   *maj = majorTickLen;
   *min = minorTickLen;
}

/*-----------------------------------------------------------------------
 *  Methods to return the major and minor tick mark spacings
 */

void
MeterC::GetTickSpacing(StringC *maj, StringC *min) const
{
   ValueC	tmp(formatVal);
   tmp = majorTickSpacing;
   *maj = (StringC)tmp;
   tmp = minorTickSpacing;
   *min = (StringC)tmp;
}

void
MeterC::GetTickSpacing(ValueC *maj, ValueC *min) const
{
   *maj = majorTickSpacing;
   *min = minorTickSpacing;
}

void
MeterC::GetTickSpacing(int *maj, int *min) const
{
   *maj = (int)majorTickSpacing;
   *min = (int)minorTickSpacing;
}

void
MeterC::GetTickSpacing(long *maj, long *min) const
{
   *maj = (long)majorTickSpacing;
   *min = (long)minorTickSpacing;
}

void
MeterC::GetTickSpacing(float *maj, float *min) const
{
   *maj = (float)majorTickSpacing;
   *min = (float)minorTickSpacing;
}

/*----------------------------------------------------------------------
 * Method to return a string representation of the current value
 */

StringC
MeterC::ValueString() const
{
   ValueC	tmp(formatVal);
   tmp = value;
   return tmp;
}

/*----------------------------------------------------------------------
 * Method to copy the attributes of another meter
 */

MeterC&
MeterC::operator=(const MeterC& that)
{
   marginWd         = that.marginWd;
   marginHt         = that.marginHt;
   shadowType       = that.shadowType;
   shadowThickness  = that.shadowThickness;
   labelOffset      = that.labelOffset;
   formatVal	    = that.formatVal;
   minValue	    = that.minValue;
   maxValue	    = that.maxValue;
   valRangeInv	    = that.valRangeInv;
   majorTickLen	    = that.majorTickLen;
   minorTickLen	    = that.minorTickLen;
   majorTickSpacing = that.majorTickSpacing;
   minorTickSpacing = that.minorTickSpacing;

   for (int i=0; i<COLOR_ATTR_COUNT; i++) {
      colors[i]	    = that.colors[i];
      colorNames[i] = that.colorNames[i];
   }
   XtVaSetValues(da, XmNbackground, colors[BACKGROUND], NULL);

   if ( !deferred ) Draw();

   return *this;

} // End MeterC operator=

/*----------------------------------------------------------------------
 * Method to write resources to a file
 */

void
MeterC::Write(FILE *fp, const char *prefix)
{
//
// Create next level prefix
//
   StringC	prefix2 = prefix; prefix2 += "\t";

//
// Write data
//
   fprintf(fp, "%s{METER\n", prefix);

   WriteResource  (fp, prefix2 + "background",		colorNames[BACKGROUND]);
   WriteResource  (fp, prefix2 + "faceColor",		colorNames[FACE_COLOR]);
   WriteResource  (fp, prefix2 + "indicatorColor",colorNames[INDICATOR_COLOR]);
   WriteResource  (fp, prefix2 + "valueColor",	colorNames[VALUE_COLOR]);
   WriteResource  (fp, prefix2 + "labelColor",	colorNames[LABEL_COLOR]);
   WriteResource  (fp, prefix2 + "tickColor",		colorNames[TICK_COLOR]);
   WriteResource  (fp, prefix2 + "markColor",		colorNames[MARK_COLOR]);
   WriteResource  (fp, prefix2 + "topShadowColor",	colorNames[TOP_SHADOW]);
   WriteResource  (fp, prefix2 + "bottomShadowColor",colorNames[BOTTOM_SHADOW]);

   WriteResource  (fp, prefix2 + "value",		value);
   WriteResource  (fp, prefix2 + "minValue",		minValue);
   WriteResource  (fp, prefix2 + "maxValue",		maxValue);
   WriteResource  (fp, prefix2 + "outputFormat",	formatVal.FormatName());
   WriteResource  (fp, prefix2 + "decimalPlaces",	formatVal.Precision());
   WriteResource  (fp, prefix2 + "marks",		markList);
//   WriteResource  (fp, prefix2 + "font",		fontName);
   WriteShadowType(fp, prefix2 + "shadowType",		shadowType);
   WriteResource  (fp, prefix2 + "shadowThickness",	shadowThickness);
   WriteResource  (fp, prefix2 + "majorTickLength",	majorTickLen);
   WriteResource  (fp, prefix2 + "minorTickLength",	minorTickLen);
   WriteResource  (fp, prefix2 + "majorTickSpacing",	majorTickSpacing);
   WriteResource  (fp, prefix2 + "minorTickSpacing",	minorTickSpacing);
   WriteResource  (fp, prefix2 + "labelOffset",		labelOffset);
   WriteResource  (fp, prefix2 + "marginWidth",		marginWd);
   WriteResource  (fp, prefix2 + "marginHeight",	marginHt);
   WriteResource  (fp, prefix2 + "allowInput",	        allowInput);
   fprintf(fp, "%sMETER}\n", prefix);

} // End MeterC Write

/*----------------------------------------------------------------------
 * Method to read resources from a file
 */

int
MeterC::Read(FILE *fp, WorkingBoxC *wb)
{
   StringC		line;
   static RegexC	*pair = NULL;
   static RegexC	*end  = NULL;

   if ( !pair ) {
      end  = new RegexC("[ \t]*METER}[ \t]*$");
      pair = new RegexC("[ \t]*\\([^:]+\\):[ \t]*\\(.*\\)");  // rsrc: val
   }

//
// Read resources until next "}" line
//
   StringListC	rsrcList;
   StringListC	valueList;
   rsrcList.AllowDuplicates(TRUE);
   valueList.AllowDuplicates(TRUE);

   line.Clear();
   int	status = line.GetLine(fp);
   while ( status != EOF && !end->match(line) && (!wb || !wb->Cancelled()) ) {

      if ( pair->match(line) ) {
	 StringC	tmp = line((*pair)[1]);
	 tmp.toLower();
	 rsrcList.append(tmp);
	 tmp = line((*pair)[2]);
	 valueList.append(tmp);
      }

      line.Clear();
      status = line.GetLine(fp);
   }

//
// Extract resources from resource string
//
   Defer(True);
   while ( rsrcList.size() > 0 && (!wb || !wb->Cancelled()) ) {

      StringC	*rsrc = rsrcList[0];
      StringC	*rval = valueList[0];
      StringC	tmp;
      int	index;

      if      ( *rsrc == "background"        ) SetColor(BACKGROUND,     *rval);
      else if ( *rsrc == "facecolor"         ) SetColor(FACE_COLOR,     *rval);
      else if ( *rsrc == "indicatorcolor"    ) SetColor(INDICATOR_COLOR,*rval);
      else if ( *rsrc == "valuecolor"        ) SetColor(VALUE_COLOR,    *rval);
      else if ( *rsrc == "labelcolor"        ) SetColor(LABEL_COLOR,    *rval);
      else if ( *rsrc == "tickcolor"         ) SetColor(TICK_COLOR,     *rval);
      else if ( *rsrc == "markcolor"         ) SetColor(MARK_COLOR,     *rval);
      else if ( *rsrc == "topshadowcolor"    ) SetColor(TOP_SHADOW,     *rval);
      else if ( *rsrc == "bottomshadowcolor" ) SetColor(BOTTOM_SHADOW,  *rval);
      else if ( *rsrc == "value"             ) value = atof(*rval);

      else if ( *rsrc == "minvalue" || *rsrc == "maxvalue" ) {

	 if ( *rsrc == "minvalue" ) {
	    minValue = atof(*rval);
	 } else {
	    tmp = "minvalue";
	    index = rsrcList.indexOf(tmp);
	    if ( index != rsrcList.NULL_INDEX ) {
		minValue = atoi(*valueList[index]);
		rsrcList.remove(index);
		valueList.remove(index);
	    }
	 }

	 if ( *rsrc == "maxvalue" ) {
	    maxValue = atof(*rval);
	 } else {
	    tmp = "maxvalue";
	    index = rsrcList.indexOf(tmp);
	    if ( index != rsrcList.NULL_INDEX ) {
		maxValue = atoi(*valueList[index]);
		rsrcList.remove(index);
		valueList.remove(index);
	    }
	 }

	 valRangeInv = 1.0/(maxValue - minValue);

      } // End if resource is min or max value

      else if ( *rsrc == "outputformat"  ) formatVal.SetFormat(*rval);
      else if ( *rsrc == "decimalplaces" ) formatVal.SetPrecision(atoi(*rval));

      else if ( *rsrc == "marks" ) {

	 static RegexC	*word = NULL;
	 if ( !word ) word = new RegexC("[^ \t]+");

	 markList.removeAll();
	 while ( word->search(*rval) >= 0 ) {
	    float	mark = atof((*rval)((*word)[0]));
	    markList.append(mark);
	    (*rval)((*word)[0]) = "";
	 }
      }
//      else if ( *rsrc == "font"         ) fontName = *rval;

      else if ( *rsrc == "shadowtype" ) {

	 XrmValue	from, to;
	 unsigned char	result;
	 from.addr = (XPointer)(char *)*rval;
	 from.size = strlen(*rval) + 1;
	 to.addr	= (XPointer)&result;
	 to.size	= sizeof(unsigned char);
	 if ( XtConvertAndStore(da, XmRString, &from, XmRShadowType, &to) )
	    shadowType = result;
      }

      else if ( *rsrc == "shadowthickness"  ) shadowThickness  = atoi(*rval);
      else if ( *rsrc == "majorticklength"  ) majorTickLen     = atoi(*rval);
      else if ( *rsrc == "minorticklength"  ) minorTickLen     = atoi(*rval);
      else if ( *rsrc == "majortickspacing" ) majorTickSpacing = atof(*rval);
      else if ( *rsrc == "minortickspacing" ) minorTickSpacing = atof(*rval);
      else if ( *rsrc == "labeloffset"      ) labelOffset      = atoi(*rval);
      else if ( *rsrc == "marginwidth"      ) marginWd         = atoi(*rval);
      else if ( *rsrc == "marginheight"     ) marginHt         = atoi(*rval);
      // else if ( *rsrc == "allowInput"    ) allowInput = ???;

//
// Remove current entry
//
      rsrcList.remove((int)0);
      valueList.remove((int)0);
   }

   Defer(False);
   return status;

} // End MeterC Read



/*----------------------------------------------------------------------
 *  Event handler for the button press event.
 */

void
MeterC::HandleButtonPress(Widget, MeterC *mp, XButtonPressedEvent *ev, Boolean*)
{
   if ( ev->button == Button1 ) {
      if ( ev->y <= mp->indicatorY ) {
//
//       See if this point is in the meter range...
//
         float dist = hypot((double)(mp->indicatorX-ev->x),
		            (double)(mp->indicatorY-ev->y));

         if ( (int)dist <= mp->meterRadius ) {
            float angle = atan2((double)(mp->indicatorY-ev->y),
		                (double)(mp->indicatorX-ev->x));
            if ( angle < 0.0 || angle > M_PI) return;
            mp->SetValue((float)(mp->minValue + (mp->maxValue-mp->minValue)*(angle/M_PI)));
            mp->dragging = True;
	    mp->inBounds = True;
	 }
      }
   }
} 



/*----------------------------------------------------------------------
 *  Event handler for the button motion event.
 */

void
MeterC::HandleButtonMotion(Widget, MeterC *mp, XMotionEvent *ev, Boolean*)
{
   if ( mp->dragging ) {
      float angle = atan2((double)(mp->indicatorY-ev->y),
		          (double)(mp->indicatorX-ev->x));
      if ( angle >= 0.0 && angle <= M_PI ) {
         mp->SetValue((float)(mp->minValue + (mp->maxValue-mp->minValue)*(angle/M_PI)));
      }
      else if ( mp->inBounds ) {
         if ( ev->x <= mp->indicatorX )
            mp->SetValue(mp->minValue);
	 else
            mp->SetValue(mp->maxValue);
      }

      if ( ev->y <= mp->indicatorY )
	 mp->inBounds = True;
      else
	 mp->inBounds = False;

      mp->CallDragCallbacks();
   }
} 


/*----------------------------------------------------------------------
 *  Event handler for the button motion event.
 */

void
MeterC::HandleButtonRelease(Widget, MeterC *mp, XButtonReleasedEvent *ev, Boolean*)
{
   if ( mp->dragging && ev->button == Button1 ) {
      float angle = atan2((double)(mp->indicatorY-ev->y),
		          (double)(mp->indicatorX-ev->x));
      if ( angle >= 0.0 && angle <= M_PI)
         mp->SetValue((float)(mp->minValue + (mp->maxValue-mp->minValue)*(angle/M_PI)));
      mp->CallValueChangedCallbacks();
      mp->dragging = False;
   }
} 


/*----------------------------------------------------------------------
 *  Turn on or off the input events.
 */
void
MeterC::AllowInput(Boolean val)
{
   if ( val != allowInput ) {
      if ( val ) {
	 XtAddEventHandler(da, ButtonPressMask, False,
	                   (XtEventHandler) HandleButtonPress,
			   (XtPointer)this);
	 XtAddEventHandler(da, Button1MotionMask, False,
	                   (XtEventHandler) HandleButtonMotion,
			   (XtPointer)this);
	 XtAddEventHandler(da, ButtonReleaseMask, False,
	                   (XtEventHandler) HandleButtonRelease,
			   (XtPointer)this);
      } else {
	 XtRemoveEventHandler(da, ButtonPressMask, False,
	                      (XtEventHandler) HandleButtonPress,
			      (XtPointer)this);
	 XtRemoveEventHandler(da, Button1MotionMask, False,
	                      (XtEventHandler) HandleButtonMotion,
			      (XtPointer)this);
	 XtRemoveEventHandler(da, ButtonReleaseMask, False,
	                      (XtEventHandler) HandleButtonRelease,
			      (XtPointer)this);
      }
   }
}
