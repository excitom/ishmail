/*
 * $Id: CounterC.C,v 1.1 1998/06/24 01:29:07 lang Exp $
 *
 * Copyright (c) 1993 HAL Computer Systems International, Ltd.
 * 
 *          HAL COMPUTER SYSTEMS INTERNATIONAL, LTD.
 *                  1315 Dell Avenue
 *                  Campbell, CA  95008
 *
 * Author: Greg Hilton
 * Contributors: Tom Lang, Frank Bieser, and others
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * http://www.gnu.org/copyleft/gpl.html
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#include "HalAppC.h"
#include "CounterC.h"
#include "WArgList.h"
#include "Shadow.h"
#include "rsrc.h"
#include "MatrixC.h"
#include "RegexC.h"
#include "StringListC.h"
#include "WorkingBoxC.h"

#define DEFAULT_BG_COLOR	WhitePixel(halApp->display, \
					   DefaultScreen(halApp->display))
#define DEFAULT_FG_COLOR	BlackPixel(halApp->display, \
					   DefaultScreen(halApp->display))
#define DEFAULT_SEGMENT_WD	20
#define DEFAULT_SEGMENT_HT	40

Boolean		CounterC::segmentTable[128][SEGMENT_COUNT];

/*----------------------------------------------------------------------
 * Constructor
 */

CounterC::CounterC(Widget parent, const char *name, ArgList argv, Cardinal argc)
: GraphC(parent, name, argv, argc)
{
//
// Read attributes
//
   prefHt     = get_int  ("CounterC", da, "digitHeight", 0);
   digitCount = get_int  ("CounterC", da, "digitCount",  0);
   shadowType = get_shadow_type("CounterC", da, "shadowType", XmSHADOW_IN);
   value      = get_float("CounterC", da, "value", 0.0);
   int precis = get_int  ("CounterC", da, "decimalPlaces", 2);
   value.SetPrecision(precis);

   colors[BACKGROUND]    = get_color("CounterC", da, "background",
				     DEFAULT_BG_COLOR);
   colors[DIGIT_BG]      = get_color("CounterC", da, "digitBackground",
				     colors[BACKGROUND]);
   colors[DIGIT_FG]      = get_color("CounterC", da, "digitForeground",
				     DEFAULT_FG_COLOR);
   colors[TOP_SHADOW]    = get_color("CounterC", da, "topShadowColor",
				     colors[BACKGROUND]);
   colors[BOTTOM_SHADOW] = get_color("CounterC", da, "bottomShadowColor",
				     DEFAULT_FG_COLOR);
   shadowThickness       = get_int("CounterC", da, "shadowThickness", 1);

//
// Get color names
//
   colorNames[BACKGROUND]    = ColorName(da, colors[BACKGROUND]);
   colorNames[DIGIT_FG]	     = ColorName(da, colors[DIGIT_FG]);
   colorNames[DIGIT_BG]	     = ColorName(da, colors[DIGIT_BG]);
   colorNames[TOP_SHADOW]    = ColorName(da, colors[TOP_SHADOW]);
   colorNames[BOTTOM_SHADOW] = ColorName(da, colors[BOTTOM_SHADOW]);

//
// Build segment table if necessary
//
//           000 
//          1   2
//          1 7 2
//           333 
//          4 7 5
//          4   5
//           666 
//
   static Boolean	segmentTableBuilt = False;
   if ( !segmentTableBuilt ) {

      Boolean	*seg = segmentTable[0];
      for (int i=0; i<128*SEGMENT_COUNT; i++) *seg++ = False;
      seg = segmentTable['0'];
      seg[0] = seg[1] = seg[2] = seg[4] = seg[5] = seg[6] = True;
      seg = segmentTable['1'];
      seg[2] = seg[5] = True;
      seg = segmentTable['2'];
      seg[0] = seg[2] = seg[3] = seg[4] = seg[6] = True;
      seg = segmentTable['3'];
      seg[0] = seg[2] = seg[3] = seg[5] = seg[6] = True;
      seg = segmentTable['4'];
      seg[1] = seg[2] = seg[3] = seg[5] = True;
      seg = segmentTable['5'];
      seg[0] = seg[1] = seg[3] = seg[5] = seg[6] = True;
      seg = segmentTable['6'];
      seg[0] = seg[1] = seg[3] = seg[4] = seg[5] = seg[6] = True;
      seg = segmentTable['7'];
      seg[0] = seg[2] = seg[5] = True;
      seg = segmentTable['8'];
      seg[0] = seg[1] = seg[2] = seg[3] = seg[4] = seg[5] = seg[6] = True;
      seg = segmentTable['9'];
      seg[0] = seg[1] = seg[2] = seg[3] = seg[5] = seg[6] = True;
      seg = segmentTable['a'];
      seg[0] = seg[1] = seg[2] = seg[3] = seg[4] = seg[5] = True;
      seg = segmentTable['A'];
      seg[0] = seg[1] = seg[2] = seg[3] = seg[4] = seg[5] = True;
      seg = segmentTable['b'];
      seg[1] = seg[3] = seg[4] = seg[5] = seg[6] = True;
      seg = segmentTable['B'];
      seg[1] = seg[3] = seg[4] = seg[5] = seg[6] = True;
      seg = segmentTable['c'];
      seg[0] = seg[1] = seg[4] = seg[6] = True;
      seg = segmentTable['C'];
      seg[0] = seg[1] = seg[4] = seg[6] = True;
      seg = segmentTable['d'];
      seg[2] = seg[3] = seg[4] = seg[5] = seg[6] = True;
      seg = segmentTable['D'];
      seg[2] = seg[3] = seg[4] = seg[5] = seg[6] = True;
      seg = segmentTable['e'];
      seg[0] = seg[1] = seg[3] = seg[4] = seg[6] = True;
      seg = segmentTable['E'];
      seg[0] = seg[1] = seg[3] = seg[4] = seg[6] = True;
      seg = segmentTable['f'];
      seg[0] = seg[1] = seg[3] = seg[4] = True;
      seg = segmentTable['F'];
      seg[0] = seg[1] = seg[3] = seg[4] = True;
      seg = segmentTable['+'];
      seg[3] = seg[7] = True;
      seg = segmentTable['-'];
      seg[3] = True;
      seg = segmentTable['.'];
      seg[8] = True;

   } // End if !segment table built

   return;

} // End CounterC CounterC

/*----------------------------------------------------------------------
 * Method to draw counter
 */

void
CounterC::Draw()
{
   if ( !gc || obscured ) return;

   XSetForeground(halApp->display, gc, colors[BACKGROUND]);
   XFillRectangle(halApp->display, pixmap, gc, 0, 0, daWd, daHt);

   int	backWd = daWd;
   int	backHt = daHt;
   if ( backWd < 1 ) backWd = 1;
   if ( backHt < 1 ) backHt = 1;

//
// Should be no larger than preferred height
//
   if ( prefHt > (int)0 && backHt > (int)(prefHt + shadowThickness*2) )
      backHt = prefHt + shadowThickness*2;

   int	margWd  = marginWd + shadowThickness;
   int	margHt  = marginHt + shadowThickness;
   int	margWd2 = margWd * 2;
   int	margHt2 = margHt * 2;

//
// Calculate digit sizes
//
   int	digitHt = backHt - margHt2;
   int	digitWd = digitHt / 2;
   int	spacing = digitWd / 4;
   int	spaceWd = digitWd + spacing;
   int	numDigits = digitCount;
   StringC	valStr = value;

   //if ( numDigits <= 0 ) numDigits = backWd / spaceWd;
   if ( numDigits <= 0 ) numDigits = valStr.size();

//
// See how much space is needed for the requested number of digits
//
   int	needed = spaceWd * numDigits + margWd2;

//
// If there is extra space, just use what is needed
//
   if ( needed < backWd ) {
	backWd = needed;

   } else if ( needed > backWd ) {

//
// If there is not enough space available, try reducing the size of the digits
//
      if ( backHt > prefHt ) {
	 digitWd = ((backWd - margWd2)/numDigits)*4/5;
	 if ( digitWd <= 3 ) digitWd = 3;
	 digitHt = 2*digitWd;
	 spacing = digitWd / 4;
	 spaceWd = digitWd + spacing;
	 backHt  = digitHt + margHt2;
	 needed  = spaceWd * numDigits + margWd2;
      }

//
// If there is still not enough space available, try reducing the space between
//    digits.
//
      while ( needed > backWd && spacing > 1 ) {
	 spacing--;
	 spaceWd--;
 	 needed = spaceWd * numDigits + margWd2;
      }

//
// If there still isn't enough space, reduce the digit count
//
      while ( needed > backWd && numDigits > 1 ) {
	 numDigits--;
 	 needed = spaceWd * numDigits + margWd2;
      }

//
// If there still isn't enough space, give up
//
      if ( needed > backWd ) return;

   } // End if not enough space

//
// Center it in graph
//
   int	backX = (int)(daWd - backWd) / (int)2;
   int	backY = (int)(daHt - backHt) / (int)2;

//
// Draw background with shadow.
//
   XSetForeground(halApp->display, gc, colors[DIGIT_BG]);
   XFillRectangle(halApp->display, pixmap, gc, backX, backY, backWd, backHt);

   if ( shadowThickness > 0 )
      DrawShadow(halApp->display, pixmap, gc, colors[TOP_SHADOW],
		 colors[BOTTOM_SHADOW], backX, backY, backWd, backHt,
		 shadowThickness, shadowType);

//
// Loop through value string, starting at the right
//
   int	x = backX + backWd - margWd - digitWd;
   int	y = backY + margHt;
   XSetForeground(halApp->display, gc, colors[DIGIT_FG]);
   int		i = valStr.size() - 1;
   while (x > 0 && i >= 0) {

      MatrixC	mat;
      mat.Scale((float)digitWd/(float)DEFAULT_SEGMENT_WD,
	        (float)digitHt/(float)DEFAULT_SEGMENT_HT);
      mat.Translate(x, y);
      DrawDigit(valStr[i], mat);
      x -= spaceWd;
      i--;

   } // End for each character in value

   XCopyArea(halApp->display, pixmap, win, gc, 0, 0, daWd, daHt, 0, 0);

} // End CounterC Draw

/*----------------------------------------------------------------------
 * Method to draw digit in the given rectangle
 */

void
CounterC::DrawDigit(char c, const MatrixC& mat)
{
   Boolean	*segs = segmentTable[(c&0x7f)];
   for (int i=0; i<SEGMENT_COUNT; i++) {
      if ( segs[i] ) DrawSegment(i, mat);
   }

} // End CounterC DrawDigit

/*----------------------------------------------------------------------
 * Method to draw the given segment in the specified rectangle
 */

void
CounterC::DrawSegment(int seg, const MatrixC& mat)
{
   XPoint	points[6];
   int		x, y;
   int		cnt = 0;

   switch (seg) {
      case 0:
	 x =  0; y =  0; mat.Transform(&x, &y);
	 points[cnt].x = (short)x; points[cnt].y = (short)y; cnt++;
	 x = 20; y =  0; mat.Transform(&x, &y);
	 points[cnt].x = (short)x; points[cnt].y = (short)y; cnt++;
	 x = 16; y =  4; mat.Transform(&x, &y);
	 points[cnt].x = (short)x; points[cnt].y = (short)y; cnt++;
	 x =  4; y =  4; mat.Transform(&x, &y);
	 points[cnt].x = (short)x; points[cnt].y = (short)y; cnt++;
	 break;
      case 1:
	 x =  0; y =  1; mat.Transform(&x, &y);
	 points[cnt].x = (short)x; points[cnt].y = (short)y; cnt++;
	 x =  4; y =  5; mat.Transform(&x, &y);
	 points[cnt].x = (short)x; points[cnt].y = (short)y; cnt++;
	 x =  4; y = 16; mat.Transform(&x, &y);
	 points[cnt]. x = (short)x; points[cnt].y = (short)y; cnt++;
	 x =  0; y = 20; mat.Transform(&x, &y);
	 points[cnt].x = (short)x; points[cnt].y = (short)y; cnt++;
	 break;
      case 2:
	 x = 20; y =  1; mat.Transform(&x, &y);
	 points[cnt].x = (short)x; points[cnt].y = (short)y; cnt++;
	 x = 20; y = 20; mat.Transform(&x, &y);
	 points[cnt].x = (short)x; points[cnt].y = (short)y; cnt++;
	 x = 16; y = 16; mat.Transform(&x, &y);
	 points[cnt].x = (short)x; points[cnt].y = (short)y; cnt++;
	 x = 16; y =  5; mat.Transform(&x, &y);
	 points[cnt].x = (short)x; points[cnt].y = (short)y; cnt++;
	 break;
      case 3:
	 x =  1; y = 20; mat.Transform(&x, &y);
	 points[cnt].x = (short)x; points[cnt].y = (short)y; cnt++;
	 x =  3; y = 22; mat.Transform(&x, &y);
	 points[cnt].x = (short)x; points[cnt].y = (short)y; cnt++;
	 x = 17; y = 22; mat.Transform(&x, &y);
	 points[cnt].x = (short)x; points[cnt].y = (short)y; cnt++;
	 x = 19; y = 20; mat.Transform(&x, &y);
	 points[cnt].x = (short)x; points[cnt].y = (short)y; cnt++;
	 x = 17; y = 18; mat.Transform(&x, &y);
	 points[cnt].x = (short)x; points[cnt].y = (short)y; cnt++;
	 x =  3; y = 18; mat.Transform(&x, &y);
	 points[cnt].x = (short)x; points[cnt].y = (short)y; cnt++;
	 break;
      case 4:
	 x =  0; y = 20; mat.Transform(&x, &y);
	 points[cnt].x = (short)x; points[cnt].y = (short)y; cnt++;
	 x =  4; y = 24; mat.Transform(&x, &y);
	 points[cnt].x = (short)x; points[cnt].y = (short)y; cnt++;
	 x =  4; y = 35; mat.Transform(&x, &y);
	 points[cnt]. x = (short)x; points[cnt].y = (short)y; cnt++;
	 x =  0; y = 39; mat.Transform(&x, &y);
	 points[cnt].x = (short)x; points[cnt].y = (short)y; cnt++;
	 break;
      case 5:
	 x = 20; y = 20; mat.Transform(&x, &y);
	 points[cnt].x = (short)x; points[cnt].y = (short)y; cnt++;
	 x = 20; y = 39; mat.Transform(&x, &y);
	 points[cnt].x = (short)x; points[cnt].y = (short)y; cnt++;
	 x = 16; y = 35; mat.Transform(&x, &y);
	 points[cnt].x = (short)x; points[cnt].y = (short)y; cnt++;
	 x = 16; y = 24; mat.Transform(&x, &y);
	 points[cnt].x = (short)x; points[cnt].y = (short)y; cnt++;
	 break;
      case 6:
	 x =  0; y = 40; mat.Transform(&x, &y);
	 points[cnt].x = (short)x; points[cnt].y = (short)y; cnt++;
	 x = 20; y = 40; mat.Transform(&x, &y);
	 points[cnt].x = (short)x; points[cnt].y = (short)y; cnt++;
	 x = 16; y = 36; mat.Transform(&x, &y);
	 points[cnt].x = (short)x; points[cnt].y = (short)y; cnt++;
	 x =  4; y = 36; mat.Transform(&x, &y);
	 points[cnt].x = (short)x; points[cnt].y = (short)y; cnt++;
	 break;
      case 7:
	 x = 10; y = 11; mat.Transform(&x, &y);
	 points[cnt].x = (short)x; points[cnt].y = (short)y; cnt++;
	 x = 12; y = 13; mat.Transform(&x, &y);
	 points[cnt].x = (short)x; points[cnt].y = (short)y; cnt++;
	 x = 12; y = 27; mat.Transform(&x, &y);
	 points[cnt].x = (short)x; points[cnt].y = (short)y; cnt++;
	 x = 10; y = 29; mat.Transform(&x, &y);
	 points[cnt].x = (short)x; points[cnt].y = (short)y; cnt++;
	 x =  8; y = 27; mat.Transform(&x, &y);
	 points[cnt].x = (short)x; points[cnt].y = (short)y; cnt++;
	 x =  8; y = 13; mat.Transform(&x, &y);
	 points[cnt].x = (short)x; points[cnt].y = (short)y; cnt++;
	 break;
      case 8:
	 x =  6; y = 32; mat.Transform(&x, &y);
	 points[cnt].x = (short)x; points[cnt].y = (short)y; cnt++;
	 x = 14; y = 32; mat.Transform(&x, &y);
	 points[cnt].x = (short)x; points[cnt].y = (short)y; cnt++;
	 x = 14; y = 40; mat.Transform(&x, &y);
	 points[cnt].x = (short)x; points[cnt].y = (short)y; cnt++;
	 x =  6; y = 40; mat.Transform(&x, &y);
	 points[cnt].x = (short)x; points[cnt].y = (short)y; cnt++;
	 break;

      default:
	 return;

   } // End switch segment number

   XFillPolygon(halApp->display, pixmap, gc, points, cnt, Convex, CoordModeOrigin);

} // End CounterC DrawDigit

/*----------------------------------------------------------------------
 * Method to set the digit count
 */

void
CounterC::SetDigitCount(int count)
{
   if ( count != digitCount ) {
      digitCount = count;
      if ( !deferred ) Draw();
   }
}

/*----------------------------------------------------------------------
 * Method to set the digit height
 */

void
CounterC::SetDigitHeight(int height)
{
   if ( height != prefHt ) {
      prefHt = height;
      if ( !deferred ) Draw();
   }
}

/*----------------------------------------------------------------------
 * Method to set the shadow thickness
 */

void
CounterC::SetShadowThickness(Dimension thick)
{
   if ( thick != shadowThickness ) {
      shadowThickness = thick;
      if ( !deferred ) Draw();
   }
}

/*----------------------------------------------------------------------
 * Method to set the shadow type
 */

void
CounterC::SetShadowType(unsigned char type)
{
   if ( type != shadowType ) {
      shadowType = type;
      if ( !deferred ) Draw();
   }
}

/*----------------------------------------------------------------------
 * Method to set the numeric output format to INT, HEX or FLOAT
 */

void
CounterC::SetOutputFormat(ValueC::ValueFormat newFormat)
{
   if ( newFormat != value.Format() ) {
      value.SetFormat(newFormat);
      if ( !deferred ) Draw();
   }
}

/*----------------------------------------------------------------------
 * Method to set the number of decimal places for float output
 */

void
CounterC::SetPrecision(int places)
{
   if ( places != value.Precision() ) {
      value.SetPrecision(places);
      if ( !deferred && value.Format() == ValueC::FLOAT ) Draw();
   }
}

/*----------------------------------------------------------------------
 * Method to set the current value
 */

void
CounterC::SetValue(const ValueC val)
{
   value = (float)val;
   if ( !deferred ) Draw();
}

/*----------------------------------------------------------------------
 * Methods to set the requested color
 */

void
CounterC::SetColor(CounterC::CounterColorAttr attr, Pixel color)
{
   if ( colors[attr] == color ) return;

   colors[attr]	    = color;
   colorNames[attr] = ColorName(da, color);

   switch (attr) {

      case (BACKGROUND):
	 XtVaSetValues(da, XmNbackground, color, NULL);

      default:
	 if ( !deferred ) Draw();
	 break;

   } // End switch color attribute

} // End CounterC SetColor

void
CounterC::SetColor(CounterC::CounterColorAttr attr, const char *name)
{
   Pixel	color;
   if ( PixelValue(da, name, &color) ) SetColor(attr, color);
}

/*----------------------------------------------------------------------
 * Method to return the requested pixel value
 */

Pixel
CounterC::GetColor(CounterC::CounterColorAttr attr) const
{
   return colors[attr];
}

/*----------------------------------------------------------------------
 * Method to return the requested color name
 */

StringC
CounterC::GetColorName(CounterC::CounterColorAttr attr) const
{
   return colorNames[attr];
}

/*----------------------------------------------------------------------
 * Method to copy the attributes of another counter
 */

CounterC&
CounterC::operator=(const CounterC& that)
{
   marginWd        = that.marginWd;
   marginHt        = that.marginHt;
   shadowType      = that.shadowType;
   shadowThickness = that.shadowThickness;
   digitCount      = that.digitCount;
   prefHt          = that.prefHt;

   value.SetFormat   (that.value.Format());
   value.SetPrecision(that.value.Precision());

   for (int i=0; i<COLOR_ATTR_COUNT; i++) {
      colors[i]	    = that.colors[i];
      colorNames[i] = that.colorNames[i];
   }
   XtVaSetValues(da, XmNbackground, colors[BACKGROUND], NULL);

   if ( !deferred ) Draw();

   return *this;

} // End CounterC operator=

/*----------------------------------------------------------------------
 * Method to write resources to a file
 */

void
CounterC::Write(FILE *fp, const char *prefix)
{
//
// Create next level prefix
//
   StringC	prefix2 = prefix; prefix2 += "\t";

//
// Write data
//
   fprintf(fp, "%s{COUNTER\n", prefix);

   WriteResource  (fp, prefix2 + "background",		colorNames[BACKGROUND]);
   WriteResource  (fp, prefix2 + "digitBackground",	colorNames[DIGIT_BG]);
   WriteResource  (fp, prefix2 + "digitForeground",	colorNames[DIGIT_FG]);
   WriteResource  (fp, prefix2 + "topShadowColor",	colorNames[TOP_SHADOW]);
   WriteResource  (fp, prefix2 + "bottomShadowColor",colorNames[BOTTOM_SHADOW]);

   WriteResource  (fp, prefix2 + "value",		(float)value);
   WriteResource  (fp, prefix2 + "digitCount",		digitCount);
   WriteResource  (fp, prefix2 + "digitHeight",		prefHt);
   WriteResource  (fp, prefix2 + "outputFormat",	value.FormatName());
   WriteResource  (fp, prefix2 + "decimalPlaces",	value.Precision());
   WriteShadowType(fp, prefix2 + "shadowType",		shadowType);
   WriteResource  (fp, prefix2 + "shadowThickness",	shadowThickness);
   WriteResource  (fp, prefix2 + "marginWidth",		marginWd);
   WriteResource  (fp, prefix2 + "marginHeight",	marginHt);

   fprintf(fp, "%sCOUNTER}\n", prefix);

} // End CounterC Write

/*----------------------------------------------------------------------
 * Method to read resources from a file
 */

int
CounterC::Read(FILE *fp, WorkingBoxC *wb)
{
   StringC		line;
   static RegexC	*pair = NULL;
   static RegexC	*end  = NULL;

   if ( !pair ) {
      end  = new RegexC("[ \t]*COUNTER}[ \t]*$");
      pair = new RegexC("[ \t]*\\([^:]+\\):[ \t]*\\(.*\\)");  // rsrc: val
   }

//
// Read resources until next "}" line
//
   StringListC	rsrcList;
   StringListC	valList;
   rsrcList.AllowDuplicates(TRUE);
   valList.AllowDuplicates(TRUE);

   line.Clear();
   int	status = line.GetLine(fp);
   while ( status != EOF && !end->match(line) && (!wb || !wb->Cancelled()) ) {

      if ( pair->match(line) ) {
	 StringC	tmp = line((*pair)[1]);
	 tmp.toLower();
	 rsrcList.append(tmp);
	 tmp = line((*pair)[2]);
	 valList.append(tmp);
      }

      line.Clear();
      status = line.GetLine(fp);
   }

//
// Extract resources from resource string
//
   Defer(True);
   while ( rsrcList.size() > 0 && (!wb || !wb->Cancelled()) ) {

      StringC	*rsrc = rsrcList[0];
      StringC	*val  = valList[0];

      if      ( *rsrc == "background"        ) SetColor(BACKGROUND,     *val);
      else if ( *rsrc == "digitbackground"   ) SetColor(DIGIT_BG,       *val);
      else if ( *rsrc == "digitforeground"   ) SetColor(DIGIT_FG,       *val);
      else if ( *rsrc == "topshadowcolor"    ) SetColor(TOP_SHADOW,     *val);
      else if ( *rsrc == "bottomshadowcolor" ) SetColor(BOTTOM_SHADOW,  *val);

      else if ( *rsrc == "shadowtype" ) {

	 XrmValue	from, to;
	 unsigned char	result;
	 from.addr = (XPointer)(char *)*val;
	 from.size = strlen(*val) + 1;
	 to.addr   = (XPointer)&result;
	 to.size   = sizeof(unsigned char);
	 if ( XtConvertAndStore(da, XmRString, &from, XmRShadowType, &to) )
	    shadowType = result;
      }

      else if ( *rsrc == "value"           ) value = atof(*val);
      else if ( *rsrc == "outputformat"    ) value.SetFormat(*val);
      else if ( *rsrc == "decimalplaces"   ) value.SetPrecision(atoi(*val));
      else if ( *rsrc == "shadowthickness" ) shadowThickness  = atoi(*val);
      else if ( *rsrc == "digitcount"      ) digitCount       = atoi(*val);
      else if ( *rsrc == "digitheight"     ) prefHt           = atoi(*val);
      else if ( *rsrc == "marginwidth"     ) marginWd         = atoi(*val);
      else if ( *rsrc == "marginheight"    ) marginHt         = atoi(*val);

//
// Remove current entry
//
      rsrcList.remove((int)0);
      valList.remove((int)0);
   }

   Defer(False);
   return status;

} // End CounterC Read
