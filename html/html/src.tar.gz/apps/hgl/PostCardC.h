/*
 * $Id: PostCardC.h,v 1.1 1998/06/24 01:29:07 lang Exp $
 *
 * Copyright (c) 1992 HAL Computer Systems International, Ltd.
 * 
 *          HAL COMPUTER SYSTEMS INTERNATIONAL, LTD.
 *                  1315 Dell Avenue
 *                  Campbell, CA  95008
 *
 * Author: Greg Hilton
 * Contributors: Tom Lang, Frank Bieser, and others
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * http://www.gnu.org/copyleft/gpl.html
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#ifndef _postcardc_h_h
#define _postcardc_h_h

#define  POSTCARD_NAME			"Comment PostCard"

#include "HalDialogC.h"
#include "StringListC.h"

class ListBoxC;

enum severity_mode {
    PC_CRUCIAL, 
    PC_MAJOR, 
    PC_MEDIUM, 
    PC_MINOR};
enum category_mode {
    PC_BUG, 
    PC_PERF, 
    PC_COMMENT};

class PostCardC : public HalDialogC {

    int button_mode;

    Widget text_w;
    Widget abstract_w;
    ListBoxC *toBox;
    Widget subjLabel;
    Widget send_w;

    Widget commentTB;
    Widget perfTB;
    Widget bugTB;
    Widget crucialTB;
    Widget majorTB;
    Widget mediumTB;
    Widget minorTB;

    Widget applyPB;

    Widget leftRC;
    Widget addrRC;
    Widget statusRC;
    Widget actionForm;
    Widget buttonBox;

    StringC     subjectTitle;
    StringC     versionTitle;
    StringC     productTitle;
    StringC     componentTitle;
    StringC     keyTitle;
    StringListC recipientList;
    StringC     abstract;
    StringC     desc;

   int answer;
   int ready;

    StringC     mailCmd;

    severity_mode sev_mode;
    category_mode cat_mode;

    static void DoHelp   (Widget, PostCardC*, XtPointer);
    static void DoHider   (Widget, PostCardC*, XtPointer);
    static void DoPopup  (Widget, PostCardC*, XtPointer);
    static void DoCategory  (Widget, PostCardC*, XmToggleButtonCallbackStruct*);
    static void DoSeverity  (Widget, PostCardC*, XmToggleButtonCallbackStruct*);
    static void RestoreText (Widget, XtPointer, XtPointer);

    void   Build();
    Widget CreateLabeledTextForm(Widget, char*, char*);
    void   InvalidText (Widget);

 public:
    
    // Methods

    PostCardC(Widget);
    PostCardC(Widget, StringListC&);
    PostCardC(Widget, StringListC&, StringC&);
    ~PostCardC();

    int    PrepareMessage (Widget, XmAnyCallbackStruct*);
    int    SendMessage ();
    static void send_it  (Widget, PostCardC*, XmAnyCallbackStruct*);
    void SetVersion(const StringC&, const StringC&, const StringC&);
    void SetVersion(const StringC&, const StringC&, const StringC&, const StringC&);
    void SetCategory(category_mode);
    void SetSeverity(severity_mode);
    void SetRecipients(StringListC&);
    void SetSubject(StringC&);

    Widget BugButton()  { return (bugTB); };
    Widget SendButton() { return (applyPB); };
    Widget TextW()      { return (text_w); };
    Widget AbstractW()  { return (abstract_w); };
    ListBoxC *ToBox()    { return (toBox); };

   int Answer() { return(answer); };
   void Answer(int i) { answer = i; };
   int Ready() { return(ready); };
   void Ready(int i) { ready = i; };
   void NotReady() { ready = 0; };
};

#endif //_postcardc_h_h
