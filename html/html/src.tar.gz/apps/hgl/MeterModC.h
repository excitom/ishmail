/*
 * $Id: MeterModC.h,v 1.1 1998/06/24 01:29:07 lang Exp $
 *
 * Copyright (c) 1992 HAL Computer Systems International, Ltd.
 * 
 *          HAL COMPUTER SYSTEMS INTERNATIONAL, LTD.
 *                  1315 Dell Avenue
 *                  Campbell, CA  95008
 *
 * Author: Greg Hilton
 * Contributors: Tom Lang, Frank Bieser, and others
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * http://www.gnu.org/copyleft/gpl.html
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#ifndef _MeterModC_h_
#define _MeterModC_h_

#include "MeterC.h"
#include "ModFormC.h"
#include "ValueC.h"

#include <Xm/Xm.h>

class FormatModC;
class ShadowModC;
class OrientModC;
class ColorModC;

class MeterModC : public ModFormC {

   Widget	minLabel;
   Widget	minTF;
   Widget	maxLabel;
   Widget	maxTF;
   Widget	tick1SpaceLabel;
   Widget	tick1SpaceTF;
   Widget	tick2SpaceLabel;
   Widget	tick2SpaceTF;
   Widget	tick1LenLabel;
   Widget	tick1LenTF;
   Widget	tick2LenLabel;
   Widget	tick2LenTF;
   FormatModC	*formatForm;
   ShadowModC	*shadowForm;
   ColorModC	*colorForm[MeterC::COLOR_ATTR_COUNT];
   MeterC	*meter;

//
// Initial values
//
   struct {
      ValueC		minVal;
      ValueC		maxVal;
      ValueC		tick1Space;
      ValueC		tick2Space;
      int		tick1Len;
      int		tick2Len;
   } init;

//
// Auto apply callbacks
//
   void		EnableAutoApply();
   void 	DisableAutoApply();
   void 	ChangeColor(MeterC::MeterColorAttr);

   static void	ChangeRange         (Widget, MeterModC*, XtPointer);
   static void	ChangeTickSpace     (Widget, MeterModC*, XtPointer);
   static void	ChangeTickLength    (Widget, MeterModC*, XtPointer);
   static void	ChangeFormat	    (Widget, MeterModC*,
				     XmToggleButtonCallbackStruct*);
   static void	ChangeFormatPrecis  (Widget, MeterModC*, XtPointer);
   static void	ChangeShadow	    (Widget, MeterModC*,
				     XmToggleButtonCallbackStruct*);
   static void	ChangeShadowThick   (Widget, MeterModC*, XtPointer);
   static void	ChangeBackground    (Widget, MeterModC*, XtPointer);
   static void	ChangeFaceColor     (Widget, MeterModC*, XtPointer);
   static void	ChangeIndicatorColor(Widget, MeterModC*, XtPointer);
   static void	ChangeValueColor    (Widget, MeterModC*, XtPointer);
   static void	ChangeLabelColor    (Widget, MeterModC*, XtPointer);
   static void	ChangeTickColor     (Widget, MeterModC*, XtPointer);
   static void	ChangeMarkColor     (Widget, MeterModC*, XtPointer);
   static void	ChangeTopShadow     (Widget, MeterModC*, XtPointer);
   static void	ChangeBottomShadow  (Widget, MeterModC*, XtPointer);

public:

// Methods

   MeterModC(Widget, const char*, ArgList argv=NULL, Cardinal argc=0);
   ~MeterModC();

   MEMBER_QUERY(Widget,      MinLabel,              minLabel)
   MEMBER_QUERY(Widget,      MinTF,                 minTF)
   MEMBER_QUERY(Widget,      MaxLabel,              maxLabel)
   MEMBER_QUERY(Widget,      MaxTF,                 maxTF)
   MEMBER_QUERY(Widget,      MajorTickSpacingLabel, tick1SpaceLabel)
   MEMBER_QUERY(Widget,      MajorTickSpacingTF,    tick1SpaceTF)
   MEMBER_QUERY(Widget,      MinorTickSpacingLabel, tick2SpaceLabel)
   MEMBER_QUERY(Widget,      MinorTickSpacingTF,    tick2SpaceTF)
   MEMBER_QUERY(Widget,      MajorTickLengthLabel,  tick1LenLabel)
   MEMBER_QUERY(Widget,      MajorTickLengthTF,     tick1LenTF)
   MEMBER_QUERY(Widget,      MinorTickLengthLabel,  tick2LenLabel)
   MEMBER_QUERY(Widget,      MinorTickLengthTF,     tick2LenTF)
   MEMBER_QUERY(FormatModC&, FormatForm,           *formatForm)
   MEMBER_QUERY(ShadowModC&, ShadowForm,           *shadowForm)

   void		Apply(MeterC&);
   void		Init(MeterC&);
   void		Reset();
};

#endif // _MeterModC_h_
