/*
 * $Id: GraphC.h,v 1.1 1998/06/24 01:29:07 lang Exp $
 *
 * Copyright (c) 1993 HAL Computer Systems International, Ltd.
 * 
 *          HAL COMPUTER SYSTEMS INTERNATIONAL, LTD.
 *                  1315 Dell Avenue
 *                  Campbell, CA  95008
 *
 * Author: Greg Hilton
 * Contributors: Tom Lang, Frank Bieser, and others
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * http://www.gnu.org/copyleft/gpl.html
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#ifndef _GraphC_h_
#define _GraphC_h_

#include "Base.h"
#include <Xm/Xm.h>

#include <stdio.h>

class WorkingBoxC;

//----------------------------------------------------------------------------
// Class definition

class GraphC {

public:

   enum GraphType {
      COUNTER_GRAPH = 0,
      SCALE_GRAPH,
      METER_GRAPH,
      STRIP_CHART,
      BAR_CHART,
      PIE_CHART,
      HISTOGRAM
   };

protected:

//
// Drawing attributes
//
   Widget		da;
   Window		win;
   GC			gc;
   static Pixmap	pixmap;
   static int		pixmapRefCnt;
   static Dimension	pixmapWd;
   static Dimension	pixmapHt;
   Dimension		daWd;
   Dimension		daHt;
   Dimension		marginWd;
   Dimension		marginHt;
   Boolean		obscured;		// Hidden by another window
   Boolean		deferred;
   int			deferCount;

//
// Callbacks and event handlers
//
   static void		ExposeCB(Widget, GraphC*,
				 XmDrawingAreaCallbackStruct*);
   static void		ResizeCB(Widget, GraphC*, XtPointer);
   static void		HandleVisChange(Widget, GraphC*, XVisibilityEvent*,
					Boolean*);

private:

   void			Init();

public:

//
// Cast to widget
//
   virtual inline operator	Widget() const		{ return da;	}

//
// Constructor and destructor
//
   GraphC(Widget parent, const char *name, ArgList argv=NULL, Cardinal argc=0);
   GraphC(Widget _da);
   virtual		~GraphC();

//
// Read from and write to a file
//
   virtual int		Read(FILE*, WorkingBoxC *wb=NULL) = 0;
   virtual void		Write(FILE*, const char *prefix="") = 0;

//
// Methods to modify the graph
//
   void			Defer(Boolean);
   virtual void		Draw() = 0;
   void			SetMargins(Dimension, Dimension);

//
// Methods to query the graph
//
   MEMBER_QUERY(Widget,	DrawingArea, da);

   void			GetMargins(Dimension*, Dimension*) const;
   virtual GraphType	Type() const = 0;
};

/* PRINTING */

inline ostream& operator<<(ostream& strm, const GraphC&) { return strm; }

#endif // _GraphC_h_
