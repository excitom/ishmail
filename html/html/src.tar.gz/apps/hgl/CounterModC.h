/*
 * $Id: CounterModC.h,v 1.1 1998/06/24 01:29:07 lang Exp $
 *
 * Copyright (c) 1992 HAL Computer Systems International, Ltd.
 * 
 *          HAL COMPUTER SYSTEMS INTERNATIONAL, LTD.
 *                  1315 Dell Avenue
 *                  Campbell, CA  95008
 *
 * Author: Greg Hilton
 * Contributors: Tom Lang, Frank Bieser, and others
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * http://www.gnu.org/copyleft/gpl.html
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#ifndef _CounterModC_h_
#define _CounterModC_h_

#include "CounterC.h"
#include "ModFormC.h"

#include <Xm/Xm.h>

class FormatModC;
class ShadowModC;
class ColorModC;
class CounterModC;

class CounterModC : public ModFormC {

   FormatModC	*formatForm;
   ShadowModC	*shadowForm;
   Widget	countLabel;
   Widget	countTF;
   Widget	heightLabel;
   Widget	heightTF;
   Widget	pixelLabel;
   Widget	margWdLabel;
   Widget	margWdTF;
   Widget	margHtLabel;
   Widget	margHtTF;
   ColorModC	*colorForm[CounterC::COLOR_ATTR_COUNT];
   CounterC	*counter;

//
// Initial values
//
   struct {
      int	digitCount;
      Dimension	prefHt;
      Dimension	marginWd;
      Dimension	marginHt;
   } init;

//
// Auto update callbacks
//
   void	EnableAutoApply();
   void	DisableAutoApply();
   void ChangeColor(CounterC::CounterColorAttr);

   static void	ChangeFormat       (Widget, CounterModC*,
				    XmToggleButtonCallbackStruct*);
   static void	ChangeFormatPrecis (Widget, CounterModC*, XtPointer);
   static void	ChangeShadow       (Widget, CounterModC*,
				    XmToggleButtonCallbackStruct*);
   static void	ChangeShadowThick  (Widget, CounterModC*, XtPointer);
   static void	ChangeCount        (Widget, CounterModC*, XtPointer);
   static void	ChangeHeight       (Widget, CounterModC*, XtPointer);
   static void	ChangeMargin       (Widget, CounterModC*, XtPointer);
   static void	ChangeBackground   (Widget, CounterModC*, XtPointer);
   static void	ChangeDigitBG      (Widget, CounterModC*, XtPointer);
   static void	ChangeDigitFG      (Widget, CounterModC*, XtPointer);
   static void	ChangeTopShadow    (Widget, CounterModC*, XtPointer);
   static void	ChangeBottomShadow (Widget, CounterModC*, XtPointer);

public:

// Methods

   CounterModC(Widget, const char*, ArgList argv=NULL, Cardinal argc=0);
   ~CounterModC();

   MEMBER_QUERY(Widget,      CountLabel,        countLabel);
   MEMBER_QUERY(Widget,      CountTF,           countTF);
   MEMBER_QUERY(Widget,      HeightLabel,       heightLabel);
   MEMBER_QUERY(Widget,      HeightTF,          heightTF);
   MEMBER_QUERY(Widget,      PixelLabel,        pixelLabel);
   MEMBER_QUERY(Widget,      MarginWidthLabel,  margWdLabel);
   MEMBER_QUERY(Widget,      MarginWidthTF,     margWdTF);
   MEMBER_QUERY(Widget,      MarginHeightLabel, margHtLabel);
   MEMBER_QUERY(Widget,      MarginHeightTF,    margHtTF);
   MEMBER_QUERY(FormatModC&, FormatForm,       *formatForm);
   MEMBER_QUERY(ShadowModC&, ShadowForm,       *shadowForm);

   void		Apply(CounterC&);
   void		Init(CounterC&);
   void		Reset();
};

#endif // _CounterModC_h_
