/*
 * $Id: ScaleC.h,v 1.1 1998/06/24 01:29:07 lang Exp $
 *
 * Copyright (c) 1992 HAL Computer Systems International, Ltd.
 * 
 *          HAL COMPUTER SYSTEMS INTERNATIONAL, LTD.
 *                  1315 Dell Avenue
 *                  Campbell, CA  95008
 *
 * Author: Greg Hilton
 * Contributors: Tom Lang, Frank Bieser, and others
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * http://www.gnu.org/copyleft/gpl.html
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#ifndef _ScaleC_h_
#define _ScaleC_h_

#include "GraphC.h"
#include "ValueC.h"
#include "StringC.h"
#include "FloatListC.h"

#include <Xm/Xm.h>

class IntListC;
class WorkingBoxC;

//----------------------------------------------------------------------------
// Class definition

class ScaleC : public GraphC {

public:

   enum ScaleColorAttr {
      BACKGROUND = 0,
      BAR_COLOR,
      TROUGH_COLOR,
      VALUE_COLOR,
      LABEL_COLOR,
      MARK_COLOR,
      BAR_TOP_SHADOW,
      BAR_BOTTOM_SHADOW,
      TROUGH_TOP_SHADOW,
      TROUGH_BOTTOM_SHADOW,
      COLOR_ATTR_COUNT
   };

protected:

   friend class ScaleModC;

//
// Drawing attributes
//
   XFontStruct		*font;
   Pixel		colors[COLOR_ATTR_COUNT];
   StringC		colorNames[COLOR_ATTR_COUNT];
   int			prefSize;	// Wd or Ht depending on orientation
   unsigned char	barShadowType;
   Dimension		barShadowThickness;
   unsigned char	troughShadowType;
   Dimension		troughShadowThickness;
   unsigned char	orientation;
   int			labelOffset;

   ValueC		formatVal;
   float		value;
   float		minValue;
   float		maxValue;
   float		valRangeInv;
   FloatListC		markList;

//
// Private methods
//
   void			DrawHorizontal();
   void			DrawVertical();
   float		NormalizeValue(float);

public:

//
// Cast to widget
//
   inline operator	Widget() const		{ return da;	}

//
// Constructor and destructor
//
   ScaleC(Widget parent, const char *name, ArgList argv=NULL, Cardinal argc=0);
   virtual	~ScaleC();

//
// Assignment from another scale
//
   ScaleC&		operator=(const ScaleC&);

//
// Read from and write to a file
//
   int			Read(FILE*, WorkingBoxC *wb=NULL);
   void			Write(FILE*, const char *prefix="");

//
// Methods to modify the scale
//
   void			AddMark(const ValueC);
   void			Draw();
   void			SetBarShadowThickness(Dimension);
   void			SetBarShadowType(unsigned char);
   void			SetColor(ScaleC::ScaleColorAttr, Pixel);
   void			SetColor(ScaleC::ScaleColorAttr, const char *);
   void			SetLabelOffset(int);
   void			SetMarks(const IntListC&);
   void			SetMarks(const FloatListC&);
   void			SetOrientation(unsigned char);
   void			SetOutputFormat(ValueC::ValueFormat);
   void			SetPrecision(int);
   void			SetRange(const ValueC, const ValueC);
   void			SetTroughShadowThickness(Dimension);
   void			SetTroughShadowType(unsigned char);
   void			SetTroughSize(int);
   void			SetValue(const ValueC);

//
// Methods to query the scale
//
   MEMBER_QUERY(Dimension,     BarShadowThickness,     barShadowThickness)
   MEMBER_QUERY(unsigned char, BarShadowType,          barShadowType)
   MEMBER_QUERY(int,           LabelOffset,            labelOffset)
   MEMBER_QUERY(unsigned char, Orientation,            orientation)
   MEMBER_QUERY(int,           Precision,              formatVal.Precision())
   MEMBER_QUERY(Dimension,     TroughShadowThickness,  troughShadowThickness)
   MEMBER_QUERY(unsigned char, TroughShadowType,       troughShadowType)
   MEMBER_QUERY(int,           TroughSize,             prefSize)
   MEMBER_QUERY(float,         Value,                  value)
   MEMBER_QUERY(ValueC::ValueFormat,    OutputFormat,  formatVal.Format())

   Pixel		GetColor    (ScaleC::ScaleColorAttr) const;
   StringC		GetColorName(ScaleC::ScaleColorAttr) const;
   void			GetRange(int*, int*) const;
   void			GetRange(long*, long*) const;
   void			GetRange(float*, float*) const;
   void			GetRange(ValueC*, ValueC*) const;
   void			GetRange(StringC*, StringC*) const;
   StringC		ValueString() const;
   inline GraphType	Type() const { return SCALE_GRAPH; }
};

#endif // _ScaleC_h_
