/*
 * $Id: PieChartC.h,v 1.1 1998/06/24 01:29:07 lang Exp $
 *
 * Copyright (c) 1992 HAL Computer Systems International, Ltd.
 * 
 *          HAL COMPUTER SYSTEMS INTERNATIONAL, LTD.
 *                  1315 Dell Avenue
 *                  Campbell, CA  95008
 *
 * Author: Greg Hilton
 * Contributors: Tom Lang, Frank Bieser, and others
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * http://www.gnu.org/copyleft/gpl.html
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#ifndef _PieChart_h
#define _PieChart_h

#include <X11/Xlib.h>
#include <X11/Intrinsic.h>
#include <Xm/DrawingA.h>

#include "StringC.h"
#include "Base.h"

class PieSliceC;
class PieSliceListC;
class PieChartC;

// =====================================================================
// Define the class of pie slices for the pie chart.
// =====================================================================
class PieSliceC
{
   friend PieChartC;

   public:
      enum ValueType { NONE, INT, HEX, FLOAT, PERCENTAGE};

   private:

      PieChartC*	pieChart;
      StringC           name;
      StringC           label;
      float           	scaleValue;	// scaled value, between 0 -> 1
      float             value;
      float             startAngle;
      int    		lineWidth;
      Pixel           	topColor; 
      Pixel           	innerEdgeColor; 
      Pixel           	outerEdgeColor; 
      int             	offset;		// pixel dist. from pie center
      Pixmap          	topPixmap;	// slice top portion pixmap

   public:

      PieSliceC(PieChartC *pie, char* name, float val);
      PieSliceC(PieChartC *pie, char* name, char* label, float val);
     ~PieSliceC();

   public:
      void 	Draw();
      void	DrawInnerEdge(float, float, float, float);
      void	Label(char*);
      void	Value (float);
      void	Offset (int);
      void	LineWidth (int);
      void	TopColor (Pixel);
      void	TopPixmap (Pixmap);
      void	OuterEdgeColor (Pixel);
      void	InnerEdgeColor (Pixel);
      void	ValueString (char* str, ValueType, int);

      MEMBER_QUERY(Pixel,	  InnerEdgeColor,    innerEdgeColor);
      MEMBER_QUERY(Pixel,	  OuterEdgeColor,    outerEdgeColor);
      MEMBER_QUERY(int,		  Offset,	     offset);
      MEMBER_QUERY(Pixel,	  TopColor,	     topColor);
      MEMBER_QUERY(Pixmap,	  TopPixmap,         topPixmap);
      MEMBER_QUERY(float,	  Value,	     value);
      MEMBER_QUERY(float,	  ScaleValue,	     scaleValue);
      MEMBER_QUERY(int,		  LineWidth,         lineWidth);
      PTR_QUERY   (StringC&,	  Name,              name);
      PTR_QUERY   (StringC&,	  Label,             label);
};


// =====================================================================
// Define the pie slice list class.
// =====================================================================
class PieSliceListC
{

   public:
      PieSliceListC();
      PieSliceListC(const PieSliceListC &);
     ~PieSliceListC();

   public:
//      PieSliceListC &	operator = (const PieSliceListC &);
      PieSliceC *	operator [] (const int) const;

   public:
      void                    add (const PieSliceC *);
      void                    remove (const int);
      void                    remove (const PieSliceC *);
      void                    removeAll ();
      unsigned int            size() const;
      int                     indexOf( const PieSliceC *);
      Boolean                 inList (const PieSliceC *) const;
      PieSliceC*              lookup (const char* name);

   private:
      unsigned int            _listSize;
      unsigned int            _nItems;
      PieSliceC **             _items;
      static const int        allocSize;
};


// =====================================================================
// Define the pie chart class itself.
// =====================================================================
class PieChartC
{
      friend PieSliceC;

   private:
      Window	    	window;			// window ID
      GC		gc;
      Boolean		obscured;
      Display*		display;
      XtAppContext	context;
      Screen*	    	screen;			// window's screen
      Colormap        	colormap;
      static Pixmap	pixmap;
      static int	pixmapRefCnt;
      static Dimension	pixmapWd;
      static Dimension	pixmapHt;

      String          	name;			// widget resource name
      int               radius;            	// radius of pie chart
      Position          pieX;
      Position          pieY;
      Dimension		pieWd;
      Dimension		pieHt;
      Dimension		minWd;
      Dimension		minHt;
      unsigned int      pieThickness;
      Boolean           destroyingSelf;

      Pixel	    	background;		// window background pixel
      Pixmap          	backgroundPixmap;	// window background pixmap
      Boolean         	recomputeSize;

      Pixmap          	innerEdgePixmap;
      Pixmap          	outerEdgePixmap;

      Boolean         	showLegend;
      int             	legendLabelSpacing;
      XFontStruct*      legendFont;
      Pixel           	legendTextColor;
      Boolean           legendTextShadow;
      Pixel           	legendTextShadowColor;
      Dimension		legendWidth;
      Dimension 	legendHeight;

      Boolean         	labelTextShadow;
      XFontStruct*      labelFont;
      Pixel           	labelTextColor;
      Pixel           	labelTextShadowColor;

      Boolean		showTitle;
      StringC           title;
      XFontStruct*   	titleFont;
      Pixel             titleTextColor;
      Boolean		titleTextShadow;
      Pixel		titleTextShadowColor;

      int               sliceMaxOffset;
      int               sliceLeftOffset;
      int               sliceRightOffset;
      int               sliceTopOffset;
      int               sliceBottomOffset;
      PieSliceListC	sliceList;

      PieSliceC::ValueType    legendValueType;
      PieSliceC::ValueType    labelValueType;
      int               legendPrecision;
      int               labelPrecision;
      int               declination;       	// orientation around x-axis
      int               lineWidth;
      Pixel             lineColor;

      Dimension		marginLeft;       	// x space from left edge  
      Dimension		marginRight;      	// x space from right edge 
      Dimension		marginTop;        	// y space from top edge   
      Dimension		marginBottom;     	// y space from bottom edge

      float		startAngle; 		// Start position (radians)
      float		endAngle;   		// always > start angle
      Boolean           defer;
      int           	deferCount;
      Boolean           bottomShadow;
      int               apprx;       		// full arc approximation
      float             total;       	        // total of all slice values
      Widget		da;
      Dimension         daHt;
      Dimension         daWd;
      // Pixmap           insensitivePixmap; /* pixmap when insensitive */
      // XFontStruct*   	sliceFont; // this is a label font.
      // unsigned int               maxThickness;

   private:
      static void ExposeCB (Widget, PieChartC*, XmDrawingAreaCallbackStruct*);
      static void RecomputeSizeCB (Widget, PieChartC*, XtPointer);
      static void VisChangeEV(Widget, PieChartC*, XVisibilityEvent*, Boolean*);
      static void ButtonPressEV(Widget, PieChartC*, XButtonPressedEvent*, Boolean*);

   private:
      PieSliceC::ValueType    get_valtype(char*);

   protected:
      void	CalcLegendSize();
      void	CalcPieHeight();
      void	CalcPieSliceOffsets();
      void	CalcSliceValues();
      void	DrawEmpty();
      void	DrawInnerEdges();
      void	DrawLegend();
      void	DrawOuterEdges();
      void	DrawPie();
      void	DrawTitle();
      void	DrawTopSliceLabels();
      void	InitialDisplay();
      void	RecomputeSize();
      void      TextExtents(XFontStruct*, char*, int *width, int *height);

   public:
      PieChartC(Widget, char*, ArgList, Cardinal);
     ~PieChartC();

//
// Define the public methods.
//
   public:
      void	AddSlice(PieSliceC*);
      void	RemoveSlice(PieSliceC*);
      void	BackgroundColor(Pixel);
      void	BackgroundPixmap(Pixmap);
      void	Declination(int);
      void	Defer(Boolean);
      void	Draw();
      void	ShowLegend(Boolean);
      void	ShowTitle(Boolean);
      void	LineWidth (int);
      void	LineColor (Pixel);
      void	StartAngle(float);
      void	EndAngle(float);
      void	Rotation(int);
      void	Thickness (unsigned int);
      void	Title(char*);
      void	TitleTextColor(Pixel);
      void	Total (float);
      void	LegendTextColor(Pixel);
      void      LegendValueType(PieSliceC::ValueType, int prec = 0);
      void      LabelValueType(PieSliceC::ValueType, int prec = 0);

      inline void  LegendTextShadow(Boolean val) {
	 legendTextShadow = val;
	 Draw();
      }
      inline void  LegendTextShadowColor(Pixel val) {
         legendTextShadowColor = val;
	 Draw();
      }
      inline void  TitleTextShadow(Boolean val) {
	 titleTextShadow = val;
	 Draw();
      }
      inline void  TitleTextShadowColor(Pixel val) {
         titleTextShadowColor = val;
	 Draw();
      }
      inline void  LabelTextShadow(Boolean val) {
	 labelTextShadow = val;
	 Draw();
      }
      inline void  LabelTextColor(Pixel val) {
	 labelTextColor = val;
	 Draw();
      }
      inline void  LabelTextShadowColor(Pixel val) {
	 labelTextShadowColor = val;
	 Draw();
      }
      inline PieSliceC* NameToSlice(const char* name) {
         return sliceList.lookup(name);
      }
      inline int FontHeight(XFontStruct* font) {
	 return (font->ascent + font->descent);
      }

      MEMBER_QUERY(int,		   NumSlices, 	          sliceList.size())
         PTR_QUERY(PieSliceListC*, SliceList,             &sliceList)
      MEMBER_QUERY(Boolean,	   ShowTitle,             showTitle)
      MEMBER_QUERY(Pixel,	   BackgroundColor,       background)
      MEMBER_QUERY(Pixel,	   LabelTextColor,        labelTextColor)
      MEMBER_QUERY(Boolean,	   LabelTextShadow,       labelTextShadow)
      MEMBER_QUERY(Pixel,	   LabelTextShadowColor,  labelTextShadowColor)
      MEMBER_QUERY(Boolean,	   ShowLegend,            showLegend)
      MEMBER_QUERY(Pixel,	   LegendLabelSpacing,    legendLabelSpacing)
      MEMBER_QUERY(Pixel,	   LegendTextColor,       legendTextColor)
      MEMBER_QUERY(Boolean,	   LegendTextShadow,      legendTextShadow)
      MEMBER_QUERY(Pixel,	   LegendTextShadowColor, legendTextShadowColor)
         PTR_QUERY(StringC&,	   Title, 	          title)
      MEMBER_QUERY(Pixel,	   TitleTextColor,        titleTextColor)
      MEMBER_QUERY(Boolean,	   TitleTextShadow,       titleTextShadow)
      MEMBER_QUERY(Pixel,	   TitleTextShadowColor,  titleTextShadowColor)
      MEMBER_QUERY(Pixmap,	   BackgroundPixmap,      backgroundPixmap)
      MEMBER_QUERY(Widget,	   DrawingArea,	          da)
      MEMBER_QUERY(float,	   EndAngle, 	          endAngle)
      MEMBER_QUERY(float,	   StartAngle, 	          startAngle)
      MEMBER_QUERY(float,	   Total, 	          total)
      MEMBER_QUERY(int,		   Declination,           declination)
      MEMBER_QUERY(Pixel,	   LineColor,             lineColor)
      MEMBER_QUERY(int,		   LineWidth, 	          lineWidth)
      MEMBER_QUERY(int,		   Radius, 	          radius)
      MEMBER_QUERY(int,		   Rotation, 	          (int)startAngle)
      MEMBER_QUERY(int,	           LabelPrecision,        labelPrecision)
      MEMBER_QUERY(int,	           LegendPrecision,       legendPrecision)
      MEMBER_QUERY(unsigned int,   Thickness, 	          pieThickness)
      MEMBER_QUERY(PieSliceC::ValueType, LabelValueType,    labelValueType)
      MEMBER_QUERY(PieSliceC::ValueType, LegendValueType,   legendValueType)

      inline operator Widget() const 	{ return da; }
};
#endif
