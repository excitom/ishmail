/*
 * $Id: HalTreeC.C,v 1.1 1998/06/24 01:29:07 lang Exp $
 *
 * Copyright (c) 1993 HAL Computer Systems International, Ltd.
 * 
 *          HAL COMPUTER SYSTEMS INTERNATIONAL, LTD.
 *                  1315 Dell Avenue
 *                  Campbell, CA  95008
 *
 * Author: Greg Hilton
 * Contributors: Tom Lang, Frank Bieser, and others
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * http://www.gnu.org/copyleft/gpl.html
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#ifdef ICL
#include <stddef.h>
#endif
#include "WArgList.h"
#include "WXmString.h"
#include "rsrc.h"
#include "HalTreeC.h"
#include "TreeLayoutC.h"
#include "OutlineLayoutC.h"
#include "HalAppC.h"
#include "JoyStickC.h"

#include <Xm/Xm.h>
#include <Xm/Form.h>
#include <Xm/Frame.h>
#include <Xm/Label.h>
#include <Xm/DrawingA.h>
#include <Xm/ScrolledW.h>
#include <Xm/AtomMgr.h>

#ifdef debug
#define dprintf(a) printf a
#else
#define dprintf(a)
#endif

#define X_GRANULARITY 50
#define Y_GRANULARITY 10
// #define DRAW_WORLD

//=====================================================================
// Constructor for the tree class.
//=====================================================================
HalTreeC::HalTreeC (Widget parent, char *nm, ArgList argv, Cardinal argc)
{
   WArgList args;

// dragCalls.AllowDuplicates(TRUE); ?????

//
// Create the main form this thing:
//
   viewForm = XmCreateForm(parent, nm, argv, argc);
   XtVaSetValues(viewForm, XmNresizable, False, NULL);

//
// Create a form to write status information into.
//
   args.Reset();
   args.TopAttachment(XmATTACH_NONE);
   args.LeftAttachment(XmATTACH_FORM);
   args.RightAttachment(XmATTACH_NONE);
   args.BottomAttachment(XmATTACH_FORM);
   statusForm = XmCreateForm(viewForm, "treeStatusForm", ARGS);

   args.Reset();
   args.TopAttachment(XmATTACH_FORM);
   args.LeftAttachment(XmATTACH_FORM);
   args.RightAttachment(XmATTACH_FORM);
   args.BottomAttachment(XmATTACH_WIDGET, statusForm);
   scrollForm = XmCreateForm(viewForm, "scrollForm", ARGS);

//
// Create the scrollForm widget hierarchy
//
// scrollForm
//    Frame             treeViewFrame
//       DrawingArea    treeViewDA
//    ScrollBar         hScrollBar
//    ScrollBar         vScrollBar
//    JoyStickC
//
   args.Reset();
   args.LeftAttachment(XmATTACH_FORM);
   args.RightAttachment(XmATTACH_FORM);
   args.TopAttachment(XmATTACH_FORM);
   args.BottomAttachment(XmATTACH_FORM);
   args.MarginWidth(0);
   args.MarginHeight(0);
   viewFrame = XmCreateFrame(scrollForm, "treeViewFrame", ARGS);

   args.Reset();
   args.LeftAttachment(XmATTACH_OPPOSITE_WIDGET, viewFrame);
   args.RightAttachment(XmATTACH_OPPOSITE_WIDGET, viewFrame);
   args.TopAttachment(XmATTACH_NONE);
   args.BottomAttachment(XmATTACH_FORM);
   args.Orientation(XmHORIZONTAL);
   args.ProcessingDirection(XmMAX_ON_RIGHT);
   args.ShowArrows(TRUE);
   args.MappedWhenManaged(FALSE);
   hScrollBar = XmCreateScrollBar(scrollForm, "hScrollBar", ARGS);

   args.Reset();
   args.LeftAttachment(XmATTACH_NONE);
   args.RightAttachment(XmATTACH_FORM);
   args.TopAttachment(XmATTACH_OPPOSITE_WIDGET, viewFrame);
   args.BottomAttachment(XmATTACH_OPPOSITE_WIDGET, viewFrame);
   args.Orientation(XmVERTICAL);
   args.ProcessingDirection(XmMAX_ON_BOTTOM);
   args.ShowArrows(TRUE);
   args.MappedWhenManaged(FALSE);
   vScrollBar = XmCreateScrollBar(scrollForm, "vScrollBar", ARGS);

   hScrollOn  = vScrollOn = FALSE; 
   world_x  = world_y  = 0; 
   world_wd = world_ht = 0; 
   hScrollMaxValue = vScrollMaxValue = 0; 

//
// Create an area for the joy stick
//
   args.Reset();
   args.LeftAttachment(XmATTACH_NONE);
   args.RightAttachment(XmATTACH_FORM);
   args.TopAttachment(XmATTACH_NONE);
   args.BottomAttachment(XmATTACH_FORM);
   args.ShadowType(XmSHADOW_IN);
   args.MappedWhenManaged(FALSE);
   args.MarginWidth(0);
   args.MarginHeight(0);
   joyStickFrame = XmCreateFrame(scrollForm, "joyStickFrame", ARGS);

   joyStick = new JoyStickC(joyStickFrame, "joyStick", 0,0);
   XtManageChild(*joyStick);
   joyStickOn = FALSE; 

   joyStick->AddMoveCallback((CallbackFn*)DoMoveJoyStick, this);

//
// Create the drawing are widget.
//

   args.Reset();
   args.ResizePolicy(XmRESIZE_GROW);
   args.UserData(this);
   viewDA = XmCreateDrawingArea (viewFrame, "treeViewDA", ARGS);

//
// Fill in the status form stuff.
//
   Widget totalLabel = XmCreateLabel(statusForm, "totalLabel", 0,0);
   XtManageChild(totalLabel);

   args.Reset();
   args.LeftAttachment(XmATTACH_WIDGET, totalLabel);
   totalVal = XmCreateLabel(statusForm, "totalVal", ARGS);
   XtManageChild(totalVal);

   args.LeftWidget(totalVal);
   Widget  dispLabel = XmCreateLabel(statusForm, "dispLabel", ARGS);
   XtManageChild(dispLabel);

   args.LeftWidget(dispLabel);
   dispVal = XmCreateLabel(statusForm, "dispVal", ARGS);
   XtManageChild(dispVal);

   args.LeftWidget(dispVal);
   Widget  visLabel = XmCreateLabel(statusForm, "visLabel", ARGS);
   XtManageChild(visLabel);

   args.LeftWidget(visLabel);
   visVal = XmCreateLabel(statusForm, "visVal", ARGS);
   XtManageChild(visVal);

   args.LeftWidget(visVal);
   Widget  selLabel = XmCreateLabel(statusForm, "selLabel", ARGS);
   XtManageChild(selLabel);

   args.LeftWidget(selLabel);
   selVal = XmCreateLabel(statusForm, "selVal", ARGS);
   XtManageChild(selVal);

//
// Set and get the resources of the tree.
//
   viewGC         = NULL;
   viewWin	  = (Window)NULL;
   deferred       = FALSE;
   hasWidgetNodes = FALSE;
   deferCount     = 0;
   treeLayout     = NULL;
   outlineLayout  = NULL;
   layout         = NULL;
   busy           = 0;
   realized       = FALSE;
   drawing        = FALSE;
   changed        = TRUE;
   pickX	  = 0;
   pickY	  = 0;
   pickOffsetX	  = 0;
   pickOffsetY	  = 0;
   pickGC	  = NULL;
   pickNode	  = NULL;
   clickTimer	  = (XtIntervalId)NULL;
   buttonState	  = 0;
   callSelect     = FALSE;
   callDeselect   = FALSE;

   viewDSP = halApp->display;

   dragEnabled       = get_boolean("HalTreeC", viewDA, "enableDragOut", True);
   dropEnabled       = get_boolean("HalTreeC", viewDA, "enableDropIn",  False);


//
// Get some attributes that we need.
//
   statusShown = get_boolean("HalTreeC", viewDA, "showStatus", TRUE);
   Pixel fg = get_color("HalTreeC", viewDA, "foreground", XBlackPixel(viewDSP,0));
   Pixel bg = get_color("HalTreeC", viewDA, "background", XWhitePixel(viewDSP,0));
   XtVaSetValues(viewDA, XmNforeground, fg, XmNbackground, bg, NULL);

   lineColor           = get_color("HalTreeC", viewDA, "lineColor", fg);
   lineEtchColor       = get_color("HalTreeC", viewDA, "lineEtchColor",
				    XWhitePixel(viewDSP,0));
   lineWidth           = get_int("HalTreeC", viewDA, "lineWidth", 1);
   StringC layoutStr   = get_string("HalTreeC", viewDA, "layout", "Tree");
   StringC lineTypeStr = get_string("HalTreeC", viewDA, "lineType", "Etched_In");

   vScrollInc          = get_int("HalTreeC", viewDA, "vScrollInc", 20);
   hScrollInc          = get_int("HalTreeC", viewDA, "hScrollInc", 20);

   lineTypeStr.toLower();
   if ( lineTypeStr(0,2) == "no" )
      lineType = XmNO_LINE;
   else if ( lineTypeStr(0,6) == "single" )
      lineType = XmSINGLE_LINE;
   else if ( lineTypeStr(lineTypeStr.size()-4,3) == "out" )
      lineType = XmSHADOW_ETCHED_OUT;
   else
      lineType = XmSHADOW_ETCHED_IN;

//
// See which layout types will be available.
//

   if ( get_boolean("HalTreeC", viewDA, "hasTreeLayout", TRUE) ) {
      treeLayout = new TreeLayoutC(this);
   }
   if ( get_boolean("HalTreeC", viewDA, "hasOutlineLayout", TRUE) ) {
      outlineLayout = new OutlineLayoutC(this);
   }

//
// See which layout type should be used.
//
   layoutStr.toLower();
   if ( layoutStr(0,7) == "outline" ) {
      if ( !outlineLayout ) outlineLayout = new OutlineLayoutC(this);
      layout = outlineLayout;
   }
   else /* if ( layoutStr[0] == 'T' ) */ { 
      if ( !treeLayout ) treeLayout = new TreeLayoutC(this);
      layout = treeLayout;
   }

//
// Get the selection mode.
//
   StringC selectModeStr;
   if ( (void*)layout == (void*)outlineLayout )
      selectModeStr = get_string("HalTreeC", viewDA, "selectMode", "Drag_Select");
   else
      selectModeStr = get_string("HalTreeC", viewDA, "selectMode", "Region_Select");

   selectModeStr.toLower();
   if	   ( selectModeStr(0,4) == "drag"   ) selectMode = DRAG_SELECT;
   else if ( selectModeStr(0,6) == "single" ) selectMode = SINGLE_SELECT;
   else if ( selectModeStr(0,6) == "region" ) selectMode = REGION_SELECT;

//
// Get the fontList from the resource file
//
   StringC fontListName = get_string(viewDA, "fontList", "fixed");
   XrmValue fromVal, toVal;
   fromVal.addr = (XPointer)((char*)fontListName);
   fromVal.size = fontListName.size() + 1;
   toVal.addr = (XPointer)&fontList;
   toVal.size = sizeof(XmFontList);
   (void)XtConvertAndStore(viewDA, XmRString, &fromVal, XmRFontList, &toVal);

//
// Add the selection event handler to the drawing area
//
   AddSelectHandler(viewDA);

//
// Set the scroll bar values.
//
   args.Reset();
   args.Increment(vScrollInc);
   XtSetValues(vScrollBar, ARGS);

   args.Reset();
   args.Increment(hScrollInc);
   XtSetValues(hScrollBar, ARGS);

//
// Set the event handlers & callbacks.
//
   XtAddCallback(hScrollBar, XmNdecrementCallback,
                 (XtCallbackProc)HandleScroll, (XtPointer)this);
   XtAddCallback(hScrollBar, XmNdragCallback,
                 (XtCallbackProc)HandleScroll, (XtPointer)this);
   XtAddCallback(hScrollBar, XmNincrementCallback,
                 (XtCallbackProc)HandleScroll, (XtPointer)this);
   XtAddCallback(hScrollBar, XmNpageDecrementCallback,
                 (XtCallbackProc)HandleScroll, (XtPointer)this);
   XtAddCallback(hScrollBar, XmNpageIncrementCallback,
                 (XtCallbackProc)HandleScroll, (XtPointer)this);
   XtAddCallback(hScrollBar, XmNtoBottomCallback,
                 (XtCallbackProc)HandleScroll, (XtPointer)this);
   XtAddCallback(hScrollBar, XmNtoTopCallback,
                 (XtCallbackProc)HandleScroll, (XtPointer)this);
   XtAddCallback(hScrollBar, XmNvalueChangedCallback,
                 (XtCallbackProc)HandleScroll, (XtPointer)this);

   XtAddCallback(vScrollBar, XmNdecrementCallback,
                 (XtCallbackProc)HandleScroll, (XtPointer)this);
   XtAddCallback(vScrollBar, XmNdragCallback,
                 (XtCallbackProc)HandleScroll, (XtPointer)this);
   XtAddCallback(vScrollBar, XmNincrementCallback,
                 (XtCallbackProc)HandleScroll, (XtPointer)this);
   XtAddCallback(vScrollBar, XmNpageDecrementCallback,
                 (XtCallbackProc)HandleScroll, (XtPointer)this);
   XtAddCallback(vScrollBar, XmNpageIncrementCallback,
                 (XtCallbackProc)HandleScroll, (XtPointer)this);
   XtAddCallback(vScrollBar, XmNtoBottomCallback,
                 (XtCallbackProc)HandleScroll, (XtPointer)this);
   XtAddCallback(vScrollBar, XmNtoTopCallback,
                 (XtCallbackProc)HandleScroll, (XtPointer)this);
   XtAddCallback(vScrollBar, XmNvalueChangedCallback,
                 (XtCallbackProc)HandleScroll, (XtPointer)this);

//
// Create a top level dummy node to hold the root nodes
//
   topLevelNode = NULL;
   topLevelNode = new HalTreeNodeC(this);
   topLevelNode->inTree = 1;
   topLevelNode->Show();

   XtAddEventHandler(viewForm, StructureNotifyMask, FALSE,
                     (XtEventHandler)HandleMapChange, (XtPointer)this);

   numNodes = numNodesShown = numNodesVisible = 0;
   UpdateStatus();

//
// Enable everything...
//
   XtManageChild(viewFrame);
   XtManageChild(hScrollBar);
   XtManageChild(vScrollBar);
   XtManageChild(viewDA);

   if ( !statusShown ) {
      args.Reset();
      args.BottomAttachment(XmATTACH_FORM);
      XtSetValues(scrollForm, ARGS);
   }
   else
      XtManageChild(statusForm);

   XtManageChild(scrollForm);
   XtManageChild(joyStickFrame);
   XtManageChild(viewForm);

} // End constructor


//=====================================================================
// This is used to add the node to the tree
//=====================================================================
void
HalTreeC::AddNode(HalTreeNodeC* node, HalTreeNodeC* p, int pos)
{
   dprintf(("***** Entering AddNode *****\n"));
   halApp->BusyCursor(TRUE);

   numNodes++;
   node->inTree = 1;

//
// Add the node to the proper parent node list, if there is one.
// If the parent is null then set this nodes parent to the top
// level, if it has been set.
//
   if ( !p ) {
      if ( topLevelNode )
	 p = topLevelNode;
      else
         topLevelNode = node;
   }

   if ( p ) {
      if ( pos < 0 || pos > p->NumChildren() )
         p->children->append(node);
      else
         p->children->insert(node,pos);
   }
   node->parent = p;
   node->CalculateSize();

//
// If a widget is shown then make it so.
//
   if ( node->Shown() ) {
      changed = TRUE;
      Draw();
   }
   halApp->BusyCursor(FALSE);
   dprintf(("***** Leaving AddNode *****\n"));
}


//=====================================================================
// This is used to remove a node from the display.
//=====================================================================
void
HalTreeC::RemoveNode(HalTreeNodeC* node)
{
   if ( halApp->xRunning ) {
      Defer(TRUE);
   }

   if ( node->Shown() ) {
      changed = TRUE;
      node->Hide();
   }
   if ( node->inTree ) {
      numNodes--;
      if ( numNodes < 0 ) numNodes = 0;
      node->inTree = 0;
   }

//
// If this node has children then we're going to have to remove them.
//
   HalTreeNodeListC& children = node->Children();
   int num_children = node->NumChildren()-1;
   for ( int i=num_children; i>=0; i-- ) {
      RemoveNode(children[i]);
   }

//
// Remove this from the parent's children node list.
//
   if ( node->parent ) {
      node->parent->children->remove(node);
      node->parent = NULL;
   }

   if ( halApp->xRunning ) {
      if ( node->selected ) {
         selectedList.remove(node);
	 node->selected = 0;
        // CallDeselectCallbacks();
      }
      Defer(FALSE);
   }
}  // end RemoveNode();


//=====================================================================
//=====================================================================
void
HalTreeC::Defer(Boolean on)
{
   if      ( on )       deferCount++;
   else if ( deferred ) deferCount--;

   deferred = (deferCount > 0);

   if ( !deferred ) {
      Draw(TRUE);    // always layout if put in defered mode.
   }
}


//=====================================================================
//=====================================================================
void
HalTreeC::SetLayout(LayoutC* t)
{
   if ( t && t != layout ) {
      layout = t;
      Draw(TRUE);
   }
}


//=====================================================================
// This routine lays out and draws the the nodes in the tree.
//=====================================================================
void
HalTreeC::Draw(Boolean do_layout)
{
   dprintf(("*****Entering HalTreeC::Draw*****\n"));
   if ( do_layout ) changed = TRUE;

   if ( realized && !deferCount && !drawing ) {
      busy++;
      drawing = TRUE;
      dprintf(("  changed: %s\n", (changed)?"TRUE":"FALSE"));
      if ( changed ) {
         Erase();
	 changed = FALSE;
         layout->Draw();
//
//       Make sure the position is ok since laying out can
//       change the world dimensions.
//
	 int reset = 0;
         int new_world_x = world_wd - daWd;
         if ( world_x > new_world_x )
	    reset = 1; 
	 else
	    new_world_x = world_x;

         int new_world_y = world_ht - daHt;
         if ( world_y > new_world_y )
	    reset = 1; 
	 else
	    new_world_y = world_y;

         if ( reset )
	    SetTreePosition(new_world_x, new_world_y);
      }
      else {
	 layout->Redraw();
      }
      UpdateStatus();
      XCopyArea(viewDSP, viewPm, viewWin, viewGC, 0, 0, viewPmWd, viewPmHt, 
		0, 0);
      drawing = FALSE;
      busy--;
   }


//
// Remove expose events from the queue so this won't draw...again.
//
   XSync(viewDSP, FALSE);
   XEvent	event;
   while ( XCheckTypedWindowEvent(viewDSP, viewWin, Expose, &event) );

#ifdef DRAW_WORLD
      Pixel clr = get_color(viewDA, "duh", "red");
      XSetForeground(viewDSP, viewGC, clr);
      XDrawRectangle(viewDSP, viewWin, viewGC, 0, 0, daWd-1, daHt-1);
      clr = get_color(viewDA, "duh", "green");
      XSetForeground(viewDSP, viewGC, clr);
      XDrawRectangle(viewDSP, viewWin, viewGC, 0, 0,
		     world_wd-1-world_x, world_ht-1-world_y);
#endif

   dprintf(("*****Leaving HalTreeC::Draw****\n"));
}


//=====================================================================
// This sets the default line type value for the tree.
//=====================================================================
void
HalTreeC::SetLineType(unsigned char lt)
{
   if ( lt != lineType ) {
      lineType = lt;
      Draw();
   }
}


//=====================================================================
//=====================================================================
void
HalTreeC::Erase()
{
   busy++;
   if ( realized ) {
      Pixel bg;
      XtVaGetValues(viewDA, XmNbackground, &bg, NULL);
      XSetForeground(halApp->display, viewGC, bg);
      XFillRectangle(halApp->display, viewPm, viewGC, 0, 0, viewPmWd, viewPmHt);
   }
   busy--;
}


//=====================================================================
// This deletes everything in the tree.
//=====================================================================
void
HalTreeC::DeleteAll()
{
//
// Delete the children of the top level node list which will subsequently
// delete all the sub-nodes beneath them.
//
   int num_children = topLevelNode->NumChildren();
   HalTreeNodeListC& children = topLevelNode->Children();
   for ( register int i=num_children-1; i>=0; i--)
      delete children[i];
}


//=====================================================================
// The destructor.
//=====================================================================
HalTreeC::~HalTreeC()
{
   if ( halApp->xRunning )
      XtReleaseGC (*this, viewGC);

   DeleteCallbacks(selectCalls);
   DeleteCallbacks(deselectCalls);

   DeleteCallbacks(dragCalls);
   DeleteCallbacks(dropCalls);
   DeleteCallbacks(dragMotionCalls);

//
// Delete the default layout types.
//
   delete outlineLayout;
   delete treeLayout;
   XFreePixmap(halApp->display, viewPm);

//
// Delete all the root nodes, which will delete all the rest
// of the nodes.
//
   Defer(TRUE);      // so it won't redraw while deleting the nodes.
   DeleteAll();
   XmFontListFree(fontList);
}


// =====================================================================
// =====================================================================
void
HalTreeC::SetLineEtchColor(Pixel c)
{
   if ( lineEtchColor != c ) {
      lineEtchColor = c;
      Draw();
   }
}


//=====================================================================
//=====================================================================
void
HalTreeC::SetLineColor(Pixel c)
{
   if ( lineColor != c ) {
      lineColor = c;
      Draw();
   }
}


//=====================================================================
//=====================================================================
void
HalTreeC::SetLineWidth(Dimension w)
{
   if ( lineWidth != w && w > 0 ) {
      lineWidth = w;
      changed = TRUE;
      Draw();
   }
}


//=====================================================================
//=====================================================================
HalTreeNodeListC&
HalTreeC::Roots()
{
   return topLevelNode->Children();
}


//=====================================================================
// This routine is called whenever an expose event is reported from the
// drawing area.  Unfortunately, this is called entirely too much &
// some effort should be spent to try to speed this up.
//=====================================================================
void
HalTreeC::DoExpose(Widget, HalTreeC* This, XmDrawingAreaCallbackStruct* cbs)
{
   dprintf(("*****Entering DoExpose*****\n"));
   XExposeEvent *ev = (XExposeEvent*)cbs->event;
   if ( ev->count > 0 || This->busy  || !This->realized || This->deferred ) {
      dprintf(("  not exposing\n"));
      return;
   }

   This->Redraw();
   dprintf(("*****Leaving DoExpose*****\n"));
}


//=====================================================================
//=====================================================================
void
HalTreeC::SetTreePosition(int new_x, int new_y)
{
   if ( new_x <= 0 ) {
      new_x = 0;
   }
   else {
      int max = world_wd - daWd - 1;
      if ( new_x > max ) new_x = max;
   }

   if ( new_y <= 0 ) {
      new_y = 0;
   }
   else {
      int max = world_ht - daHt - 1;
      if ( new_y > max ) new_y = max;
   }

//
// See if anything has changed.
//
   busy++;
   int moved = 0;
   if ( new_x != world_x ) {
      moved = 1;
      world_x = new_x;
      if ( hScrollOn )
         XtVaSetValues(hScrollBar, XmNvalue, world_x, NULL);
   }
   if ( new_y != world_y ) {
      moved = 1;
      world_y = new_y;
      if ( vScrollOn )
         XtVaSetValues(vScrollBar, XmNvalue, world_y, NULL);
   }
   busy--;

   if ( moved ) {
      Erase();
      Redraw();
   }
}


//=====================================================================
//=====================================================================
void
HalTreeC::DoMoveJoyStick(void*,  HalTreeC* This)
{
   int dx, dy;
   This->joyStick->GetMovePercentage(&dx, &dy);
   This->SetTreePosition(This->world_x + ((dx*This->hScrollInc)/100),
                         This->world_y + ((dy*This->vScrollInc)/100)); 

//
// If this is the last draw make sure all the lines are drawn.
//
   if ( This->joyStick->State() == RELEASE_JOYSTICK ) {
      This->Redraw();
   }
}


//=====================================================================
//=====================================================================
void
HalTreeC::DefaultNodes()
{
   DefaultNode(topLevelNode);
   changed = TRUE;
   Draw();
}


//=====================================================================
//=====================================================================
void
HalTreeC::DefaultNode(HalTreeNodeC* node)
{
//
// Set this nodes attributes to the tree attributes.
//
   node->lineWidth      = lineWidth;
   node->lineType       = lineType;
   node->lineColor      = lineColor;
   node->lineEtchColor  = lineEtchColor;
   int num_children = node->NumChildren();
   if ( num_children ) {
      HalTreeNodeListC& children = node->Children();
      for ( int i=0; i<num_children; i++)
	 DefaultNode(children[i]);
   }
}


//=====================================================================
// This routine is used to set the selection mode.
//=====================================================================
void
HalTreeC::SetSelectMode(HalTreeSelectModeT m)
{
   if ( m != selectMode ) selectMode = m;
}


//=====================================================================
// This routine is used to add the event handlers to the input widget.
// Any widget that has this handler enabled will contain the ability
// to start a selection.
//=====================================================================
void
HalTreeC::AddSelectHandler(Widget w)
{
   XtAddEventHandler(w, ButtonPressMask, FALSE,
                     (XtEventHandler) DoButtonPress, (XtPointer)this);
}


//=====================================================================
// This routine initializes the grafx stuff we need before drawing.
//=====================================================================
void
HalTreeC::InitPickGC()
{
//
// Create context for rubberband selection box
//
   Pixel	fg, bg;
   XtVaGetValues(viewDA, XmNforeground, &fg, XmNbackground, &bg, NULL);

   XGCValues	pickVals;
   pickVals.foreground = fg ^ bg;
   pickVals.function = GXxor;
   pickGC = XtGetGC(viewDA, GCForeground|GCFunction, &pickVals);
} // End InitPickGC


//=====================================================================
// This callback updates the visRect in response to a tree resize
//=====================================================================
void
HalTreeC::HandleResize(Widget, HalTreeC *This, XtPointer)
{
   dprintf(("***** Entering HandleResize *****\n"));

   if ( !This->realized || This->busy || !This->layout ) return;

//
// Redraw everything.
//
   halApp->BusyCursor(True);

   Dimension    wd, ht;
   XtVaGetValues(This->viewDA, XmNwidth, &wd, XmNheight, &ht, NULL);
   wd += This->noScrollRoff;
   ht += This->noScrollBoff;
   if ( wd > This->viewPmWd || ht > This->viewPmHt ) {
      XFreePixmap(halApp->display, This->viewPm);
      unsigned depth = DefaultDepth(This->viewDSP,
                                    DefaultScreen(This->viewDSP));
      This->viewPmWd = MAX(wd, This->viewPmWd);
      This->viewPmHt = MAX(ht, This->viewPmHt);
      This->viewPm = XCreatePixmap(This->viewDSP, This->viewWin,
                                   This->viewPmWd, This->viewPmHt, depth);
   }

   This->UpdateScrollBars();
   This->Erase();
   This->Redraw();
   halApp->BusyCursor(False);

   dprintf(("***** Leaving HandleResize *****\n"));
}  // end HandleResize


//=====================================================================
// These callbacks update the visRect in response to a scroll
//=====================================================================
void
HalTreeC::HandleScroll(Widget w, HalTreeC* This, XmScrollBarCallbackStruct* sb)
{
   dprintf(("***** Entering HandleScroll *****\n"));
   if ( This->busy ) return;

//
// If this is a drag scroll, see if there are any more scroll events
// coming.  If there are, ignore this one.
//
   if ( sb->reason == XmCR_DRAG && sb->event->type == MotionNotify ) {
      XMotionEvent *ev = (XMotionEvent*)sb->event;
      XEvent	next;
      int found = 0;
      while ( XCheckTypedWindowEvent(ev->display, ev->window, ev->type, &next) ) {
	 found = 1;
      }
      if ( found ) {
         XPutBackEvent(ev->display, &next);
	 return;
      }
   }

   This->busy++;
   if ( This->realized ) {
      if ( w == This->hScrollBar ) {
	 This->world_x = sb->value;
      }
      else {
         This->world_y = sb->value;
      }
      This->Erase();
      This->Redraw();
   }

//
// If this is the last of scrolling make sure the lines
// are drawn.
//
   if ( sb->reason == XmCR_VALUE_CHANGED ) {
      This->Redraw();
   }

   This->busy--;
   dprintf(("***** Leaving HandleScroll *****\n"));
}


/*-----------------------------------------------------------------------
 *  Methods to turn scrollbars on
 */
void
HalTreeC::EnableHScroll()
{
   if ( hScrollOn ) return;

   world_x = 0;
   hScrollOn = TRUE;

   int	val, size, inc, pinc;
   XmScrollBarGetValues(hScrollBar, &val, &size, &inc, &pinc);
   XmScrollBarSetValues(hScrollBar, world_x, size, inc, pinc, FALSE);
   XtVaSetValues(viewFrame, XmNbottomOffset, scrollBoff, NULL);
   XtMapWidget(hScrollBar);

//
// This might change the drawing area height.
//
   Dimension ht;
   XtVaGetValues(viewDA, XmNheight, &ht, NULL);
   daHt = (int)ht;

   if ( vScrollOn && !joyStickOn ) {
      XtMapWidget(joyStickFrame);
      joyStickOn = TRUE;
   }
}


void
HalTreeC::EnableVScroll()
{
   if ( vScrollOn ) return;

   world_y = 0;
   vScrollOn = TRUE;

   int	val, size, inc, pinc;
   XmScrollBarGetValues(vScrollBar, &val, &size, &inc, &pinc);
   XmScrollBarSetValues(vScrollBar, world_y, size, inc, pinc, FALSE);
   XtVaSetValues(viewFrame, XmNrightOffset, scrollRoff, NULL);
   XtMapWidget(vScrollBar);

   Dimension wd;
   XtVaGetValues(viewDA, XmNwidth, &wd, NULL);
   daWd = (int)wd;

   if ( hScrollOn && !joyStickOn ) {
      XtMapWidget(joyStickFrame);
      joyStickOn = TRUE;
   }
}


/*-----------------------------------------------------------------------
 *  Methods to turn scrollbars off
 */

void
HalTreeC::DisableHScroll()
{
   if ( !hScrollOn ) return;

   world_x = 0;
   hScrollOn = FALSE;

   XtUnmapWidget(hScrollBar);
   XtVaSetValues(viewFrame, XmNbottomOffset, noScrollBoff, NULL);

   if ( joyStickOn ) {
      XtUnmapWidget(joyStickFrame);
      joyStickOn = FALSE;
   }
}

void
HalTreeC::DisableVScroll()
{
   if ( !vScrollOn ) return;

   world_y = 0;
   vScrollOn = FALSE;

   XtUnmapWidget(vScrollBar);
   XtVaSetValues(viewFrame, XmNrightOffset, noScrollRoff, NULL);

   if ( joyStickOn ) {
      XtUnmapWidget(joyStickFrame);
      joyStickOn = FALSE;
   }
}

//=====================================================================
// Method to set size of scrollbars
//=====================================================================
void
HalTreeC::UpdateScrollBars()
{
   dprintf(("***** Entering UpdateScrollBars *****\n"));
   dprintf(("  world size: %d %d\n", world_wd, world_ht));

   if ( !realized ) return;

   GetViewPortSize();

   busy++;
//
// Set the scrollbars.
//
   if ( world_wd <= daWd ) {
      DisableHScroll();
      hScrollMaxValue = 0;
   }
   else {
      EnableHScroll(); //  This can change daWd so check it again.
      if ( world_x + daWd > world_wd ) world_x = world_wd - daWd;

      XtVaSetValues(hScrollBar, XmNsliderSize, daWd, XmNmaximum, world_wd,
      		    XmNvalue, world_x, NULL);
      hScrollMaxValue = world_wd - daWd;
   }

   if ( world_ht <= daHt ) {
      DisableVScroll();
      vScrollMaxValue = 0;
   }
   else {
      EnableVScroll();	// This can change daHt so check it again.
      if ( world_y + daHt > world_ht ) world_y = world_ht - daHt;

      XtVaSetValues(vScrollBar, XmNsliderSize, daHt, XmNmaximum, world_ht,
      		    XmNvalue, world_y, NULL);
      vScrollMaxValue = world_ht - daHt;
   }
   busy--;
   dprintf(("***** Leaving UpdateScrollBars *****\n"));
}


//=====================================================================
// This routine is called when the node has been selected.
//=====================================================================
void
HalTreeC::DoButtonPress(Widget w, HalTreeC* This, XButtonEvent *ev, Boolean *)
{
   if (ev->button == Button2) {
      if ( !This->dragEnabled ) return;
      This->HandleButton2Press(ev);
   }
   if (ev->button != Button1) return;

   This->busy++;

   This->callSelect   = FALSE;
   This->callDeselect = FALSE;
   This->buttonState  = ev->state;

//
// Find out what the positional offsets are in case this event
// happened in a child window of the drawing area.
//
   if ( w == This->viewDA ) {
      This->pickOffsetX = This->pickOffsetY = 0;
   } else {
      Window  child;
      XTranslateCoordinates(This->viewDSP, XtWindow(w),
			    This->viewWin, 0, 0,
                            &This->pickOffsetX, &This->pickOffsetY,
			    &child);
   }

//
// Set the "real" world pick position.
//
   This->pickX = ev->x + This->world_x + This->pickOffsetX;
   This->pickY = ev->y + This->world_y + This->pickOffsetY;

   HalTreeNodeC *firstNode = This->layout->PickNode(This->pickX, This->pickY);
   if (firstNode) {
     if (!firstNode->AllowPick(This->pickX, This->pickY)) {
       firstNode->picked = 0;
       This->busy--;
       return;
     }
   }

   XtAddEventHandler(w, Button1MotionMask, FALSE,
                     (XtEventHandler) DoButtonMotion, (XtPointer)This);
   XtAddEventHandler(w, ButtonReleaseMask, FALSE,
                     (XtEventHandler) DoButtonRelease, (XtPointer)This);

//
// If we are using the region select mode then we need to start
// drawing a rectangle.
//
   if ( This->selectMode == REGION_SELECT ) {

      if ( !This->pickGC ) This->InitPickGC();

      This->pickRect.Set(This->pickX, This->pickY, 1,1);
      XDrawRectangle(This->viewDSP, This->viewWin, This->pickGC,
		     This->pickRect.xmin-This->world_x,
		     This->pickRect.ymin-This->world_y,
                     This->pickRect.wd,   This->pickRect.ht);
   }
   else if ( This->selectMode == SINGLE_SELECT ) {
//
//    Get the node that this was selected in from the layout routine.
//
      HalTreeNodeListC nodeList;
      if ( firstNode ) {
         This->pickNode = firstNode;
         nodeList.add(This->pickNode);
      }
      This->UpdateSelection(ev->state, nodeList);
   }
   else /* if ( This->selectMode == DRAG_SELECT ) */ {
//
//    Unselect all the previous stuff if not extending.
//
      Boolean	extend = (ev->state & (ShiftMask|ControlMask));
      if ( !extend ) {
         unsigned	count = This->selectedList.size();
         if ( count > 0 ) {
	    for (int i=0; i<count; i++ ) {
	       This->selectedList[i]->Unhighlight();
	       This->selectedList[i]->selected    = 0;
	       This->selectedList[i]->highlighted = 0;
	    }
	    This->selectedList.removeAll();
	    This->callDeselect = TRUE;
         }
      }

      if ( firstNode != This->pickNode ) {
         This->pickNode = firstNode;
         if ( This->pickNode ) {
            if ( This->pickNode->selected ) {
               This->pickNode->Unhighlight();
               This->pickNode->highlighted = 0;
               This->pickNode->selected    = 0;
               This->pickNode->picked      = 0;
	       This->callDeselect          = TRUE;
               This->selectedList.remove(This->pickNode);
            }
            else {
               This->pickNode->Highlight();
               This->pickNode->highlighted = 1;
               This->pickNode->picked      = 1;
               This->pickNode->selected    = 1;
	       This->callSelect            = TRUE;
               This->selectedList.add(This->pickNode);
            }
         }
      }
      This->SetStatusLabel(This->selVal, This->selectedList.size());
   }
   This->busy--;
} // End DoButtonPress


// =====================================================================
// Handle press of button 2
// =====================================================================
void
HalTreeC::HandleButton2Press(XButtonEvent* ev)
{
dprintf(("********Entering HandleButton2Press*********\n"));
   callSelect   = FALSE;
   callDeselect = FALSE;
   buttonState  = ev->state;

//
// Find what node is under the pointer
//
   int  x = world_x + ev->x;
   int  y = world_y + ev->y;
   HalTreeNodeC*   dragItem = layout->PickNode(x, y);

   if ( !dragItem ) return;
   if ( !dragItem->ValidDragSite() ) return;
//   if (!dragItem->AllowPick(x, y))
//      return;

   TreeDragDataT  *dragData = new TreeDragDataT;

//
// If this icon is selected, drag the entire selection.  If not, select and
//    drag only this icon.
// The selection will be left to the application programmer for now
//
//   if ( selItems.includes(dragItem) ) dragData->itemList = selItems;
//   else {
//      SelectNodeOnly(*dragItem);
      dragData->dragNodeList.add(dragItem);
      dragData->widget = viewDA;
      dragData->event  = (XEvent*)ev;
  
   CallDragCallbacks(dragData);
dprintf(("********Leaving HandleButton2Press*********\n"));
}


// =====================================================================
// ConvertProc() for dropping COMPOUND_TEXT into text fields
// =====================================================================
Boolean
HalTreeC::ConvertProc(Widget w, Atom* selection, Atom* target, Atom* type, 
		XtPointer* value, unsigned long* value_length, int* format, 
		unsigned long* max_length, XtPointer client_data, 
		XtRequestId* request_id)
{
dprintf(("********Entering ConvertProc*********\n"));
   Atom atom      = XmInternAtom(XtDisplay(w), "COMPOUND_TEXT", False);
   if ( *target != atom )
      return(False);

//
// get the selected node from the dragContext user data
//
   TreeDragDataT* 	dragInfo;
   XtVaGetValues(w, XmNclientData, &dragInfo, NULL);
   HalTreeNodeC*	dragNode = dragInfo->dragNodeList[0];
//
// get the string to drop
//
   char* dragText = dragNode->DragString(dragInfo->event);
// for ( int i=0; i<tree->selected.size(); i++ ) {
//   picknode = selected[0];
//   char* text = dragNode->DragString()

//
// Convert dragText to compound text
//
   XmString   string   = XmStringCreateLtoR(dragText, XmSTRING_DEFAULT_CHARSET);
   char*      text     = XmCvtXmStringToCT(string);
   char*      passtext = XtMalloc(strlen(text)+1);
   memcpy(passtext, text, strlen(text)+1);
//
// Set up the return values
//
   *type          = atom;
   *value         = (XtPointer)passtext;
   *value_length  = strlen(passtext);
   *format        = 8;

dprintf(("********Leaving ConvertProc*********\n"));
   return True;
}


// =====================================================================
//  Handle drag over event
// =====================================================================
void
HalTreeC::HandleDragOver(Widget w, XtPointer, XmDragProcCallbackStruct *dp)
{
dprintf(("********Entering HandleDragOver()*********\n"));

   if ( dp->reason == XmCR_DROP_SITE_MOTION_MESSAGE ) {
      HalTreeC*	  This;
      XtVaGetValues(w, XmNuserData,  &This, NULL);

// find the node the pointer is over, to drop on
      int  x = This->world_x + dp->x;
      int  y = This->world_y + dp->y;
      HalTreeNodeC   *dropSite = This->layout->PickNode(x, y);

      if (dropSite ) {
         if ( dropSite->ValidDropSite() && This->dropCalls.size() > 0 ) {
// see if the user has defined any motion callbacks, and call them
            if ( This->dragMotionCalls.size() > 0 ) {
	       TreeDragMotionDataT	dragMotionData;
	       dragMotionData.dp	= dp;
	       dragMotionData.node	= dropSite;  
               This->CallDragMotionCallbacks(&dragMotionData);
	    }

//
// DJL - the values for XmDROP_SITE_VALID and XmDROP_SITE_INVALID, while 
// documented, do not exist in any Motif include files except HaL.  This was
// a bug in Motif that was fixed by moi a couple of years ago.  Use the values
// as they exist in the include files so that everyone is happy. (bug was
// DTS 5754).
//
	    else
               dp->dropSiteStatus = XmVALID_DROP_SITE;
         }     
         else
            dp->dropSiteStatus = XmINVALID_DROP_SITE;
      }
      else dp->dropSiteStatus = XmINVALID_DROP_SITE;
   } // End if this is a motion message

   dp->animate = False;

dprintf(("********Leaving HandleDragOver()*********\n"));
} // End HandleDragOver

// =====================================================================
//  Handle drop event
// =====================================================================
void
HalTreeC::HandleDropIn(Widget w, XtPointer, XmDropProcCallbackStruct *dp)
{
dprintf(("********Entering HandledropIn()*********\n"));
   HalTreeC*      This;
   XtVaGetValues(w, XmNuserData, &This, NULL);

//
// find the node under the pointer 
//
   int  x = This->world_x + dp->x;
   int  y = This->world_y + dp->y;
   HalTreeNodeC   *dropSite = This->layout->PickNode(x, y);
   if ( !dropSite ) {
      WArgList    args;
      args.TransferStatus(XmTRANSFER_FAILURE);
      XmDropTransferStart(dp->dragContext, ARGS);
   }
   else {
      Boolean  validDrop = dropSite->ValidDropSite();
      if ( This->dropCalls.size()>0 && validDrop ) {
         TreeDropDataT     dropData;
         dropData.item     = dropSite;
         dropData.procData = dp;
// //////Call drop callbacks
         This->CallDropCallbacks(&dropData);
      }
      else {    //not a valid drop site or user has not defined drop callback
         WArgList    args;
         args.TransferStatus(XmTRANSFER_FAILURE);
         XmDropTransferStart(dp->dragContext, ARGS);
      }
   }
//   This->DropFinished();

dprintf(("********Leaving HandledropIn()*********\n"));
} // End HandleDropIn

// =====================================================================
//  Change state of drag and drop handling
// =====================================================================
void
HalTreeC::EnableDrag(Boolean val)
{
   if ( dragEnabled == val ) return;

   dragEnabled = val;
}

void
HalTreeC::EnableDrop(Boolean val)
{
   if ( dropEnabled == val ) return;

   dropEnabled = val;
   ChangeDrop();
}

// =====================================================================
// Method to set the types of items that can be dropped in this tree
// =====================================================================
void
HalTreeC::SetDropAtoms(Atom *atoms, int count)
{
   if ( count > dropAtomAlloc ) {
      delete dropAtoms;
      dropAtoms = new Atom[count];
      dropAtomAlloc = count;
   }

   for (int i=0; i<count; i++) dropAtoms[i] = atoms[i];
   dropAtomCount = count;

   ChangeDrop();
}

// =====================================================================
//  Method to update drag and drop status
// =====================================================================
void
HalTreeC::ChangeDrop()
{
   if ( !realized ) return;

   WArgList     args;

   args.Reset();
   args.ImportTargets(dropAtoms);
   args.NumImportTargets(dropAtomCount);
   args.DropSiteActivity(dropEnabled ? XmDROP_SITE_ACTIVE
                                     : XmDROP_SITE_INACTIVE);
   XmDropSiteUpdate(viewDA, ARGS);
}


// =====================================================================
// This is called while dragging the left mouse.
// =====================================================================
void
HalTreeC::DoButtonMotion(Widget, HalTreeC *This, XMotionEvent *ev, Boolean *)
{
   if ( This->selectMode != REGION_SELECT &&
	This->selectMode != DRAG_SELECT ) return;


   if ( This->selectMode == REGION_SELECT ) {
//
//    Clear the current rectangle.
//
      XDrawRectangle(This->viewDSP, This->viewWin, This->pickGC,
                     This->pickRect.xmin-This->world_x,
                     This->pickRect.ymin-This->world_y,
                     This->pickRect.wd,   This->pickRect.ht);
   }

//
// If pointer is outside the bounds, then scroll the window.
//
   int ptr_x = ev->x + This->pickOffsetX;
   int ptr_y = ev->y + This->pickOffsetY;

   if ( This->vScrollOn || This->hScrollOn ) {
      Boolean  off_top   = (ptr_y <= 0);
      Boolean  off_bot   = (ptr_y >= This->daHt);
      Boolean  off_left  = (ptr_x <= 0);
      Boolean  off_right = (ptr_x >= This->daWd);

      if ( off_top || off_bot || off_right || off_left ) {

         int new_world_x = This->world_x;
         int new_world_y = This->world_y;
         if ( off_left ) {
	    new_world_x -= This->hScrollInc;
	    ptr_x        = 0;
         }
         else if ( off_right ) {
	    new_world_x += This->hScrollInc;
	    ptr_x        = This->daWd - 1;
         }
         if ( off_top ) {
	    new_world_y -= This->vScrollInc;
	    ptr_y        = 0;
         }
         else if ( off_bot ) {
	    new_world_y  += This->vScrollInc;
	    ptr_y         = This->daHt - 1;
         }
//
//       Keep the pointer in the same screen location
//
         XWarpPointer(This->viewDSP, None, This->viewWin,
		      0, 0, 0, 0, ptr_x, ptr_y);

         This->SetTreePosition(new_world_x, new_world_y);
      }
   }

   This->busy++;
//
// Update the pick information according to the selection mode.
//
   if ( This->selectMode == REGION_SELECT ) {
//
//    Update the pick rectangle.
//
      int  world_ptr_x = ptr_x + This->world_x;
      int  world_ptr_y = ptr_y + This->world_y;
      if ( This->pickX > world_ptr_x ) {
         This->pickRect.xmin = world_ptr_x;
         This->pickRect.xmax = This->pickX;
      } else {
         This->pickRect.xmin = This->pickX;
         This->pickRect.xmax = world_ptr_x;
      }

      if ( This->pickY > world_ptr_y ) {
         This->pickRect.ymin = world_ptr_y;
         This->pickRect.ymax = This->pickY;
      } else {
         This->pickRect.ymin = This->pickY;
         This->pickRect.ymax = world_ptr_y;
      }

      This->pickRect.wd = This->pickRect.xmax - This->pickRect.xmin + 1;
      This->pickRect.ht = This->pickRect.ymax - This->pickRect.ymin + 1;

//
//    Draw the new pick rectangle.
//
      XDrawRectangle(This->viewDSP, This->viewWin, This->pickGC,
                     This->pickRect.xmin-This->world_x,
                     This->pickRect.ymin-This->world_y,
                     This->pickRect.wd, This->pickRect.ht);

      HalTreeNodeListC  nodeList;
      This->layout->PickNodes(This->pickRect, nodeList);
      This->UpdateSelection(ev->state, nodeList, FALSE);
   }

   else /* if ( This->selectMode == DRAG_SELECT ) */ {
//
//    This selects every node that the mouse goes over...
//
#ifdef FIX_GRANULARITY
      int new_pickX = ptr_x + This->world_x;
      int new_pickY = ptr_y + This->world_y;

      int dx = new_pickX - This->pickX;
      int dy = new_pickY - This->pickY;

      int num_points = MAX(dx/X_GRANULARITY,dy/Y_GRANULARITY);
      for ( int i=0; i<num_points; i++ )
#endif
      This->pickX = ptr_x + This->world_x;
      This->pickY = ptr_y + This->world_y;
      HalTreeNodeC* node = This->layout->PickNode(This->pickX, This->pickY);
      if ( node != This->pickNode ) {
         if ( node ) {
            if ( node->selected ) {
	       node->selected = 0;
	       This->callDeselect = TRUE;     // bogus
               node->Unhighlight();
               node->highlighted = 0;
               node->picked      = 0;
               This->selectedList.remove(node);
            }
            else {
	       node->selected   = 1;
	       This->callSelect = TRUE;
               node->Highlight();
               node->highlighted = 1;
               node->picked      = 1;
               This->selectedList.add(node);
            }
         }
      }
      This->pickNode = node;
      This->SetStatusLabel(This->selVal, This->selectedList.size());
   }
   This->busy--;
} // End DoButtonMotion


// =====================================================================
// This routine is called when the left button is released
// =====================================================================
void
HalTreeC::DoButtonRelease(Widget w, HalTreeC* This, XButtonEvent *ev, Boolean *)
{
   dprintf(("***** Entering DoButtonRelease *****\n"));
   dprintf(("  initial pickNode: %d\n", This->pickNode));
   XtRemoveEventHandler(w, Button1MotionMask, FALSE,
                     (XtEventHandler) DoButtonMotion, (XtPointer)This);
   XtRemoveEventHandler(w, ButtonReleaseMask, FALSE,
                     (XtEventHandler) DoButtonRelease, (XtPointer)This);

   if (ev->button != Button1) return;

   This->busy++;

   if ( This->selectMode == REGION_SELECT ) {
//
//    Clear the current rectangle.
//
      XDrawRectangle(This->viewDSP, This->viewWin, This->pickGC,
		     This->pickRect.xmin-This->world_x,
		     This->pickRect.ymin-This->world_y,
		     This->pickRect.wd,   This->pickRect.ht);

//
//    Get the final list of nodes in the pick rectangle.
//
      HalTreeNodeListC	nodeList;
      This->layout->PickNodes(This->pickRect, nodeList);

      if ( nodeList.size() > 0 ) {
         This->UpdateSelection(ev->state, nodeList);
	 if ( nodeList.size() == 1 )
	    This->pickNode = nodeList[0];
      }

      This->Draw(TRUE);      // for XWindow bug

   } // End if REGION_SELECT

   else /* if ( This->selectMode == DRAG_SELECT || SINGLE_SELECT ) */ {
      unsigned	count = This->selectedList.size();
      for (int i=0; i<count; i++ ) {
         This->selectedList[i]->picked = 0;
      }
      if ( This->callDeselect ) This->CallDeselectCallbacks();
      if ( This->callSelect   ) This->CallSelectCallbacks();
   }
   This->busy--;

//
// If there's a timer running, this is a double click, otherwise add one.
//
   dprintf(("  pickNode: %d\n", This->pickNode));
   dprintf(("  clickTimer: %d\n", This->clickTimer));
   if ( This->clickTimer ) {
      XtRemoveTimeOut(This->clickTimer);    // Remove single click timeout
      This->clickTimer = (XtIntervalId)NULL;
      if ( This->pickNode ) {
         dprintf(("  calling open for %s\n", (char*)This->pickNode->NodeName() ));
         This->pickNode->Open();
      }
   }
   else {
      This->clickTimer = XtAppAddTimeOut(halApp->context,
			    XtGetMultiClickTime(This->viewDSP),
			    (XtTimerCallbackProc)HandleSingleClick,
			    (XtPointer)This);
   }

   This->pickNode = NULL;
   This->SetStatusLabel(This->selVal, This->selectedList.size());
   dprintf(("***** Leaving DoButtonRelease *****\n"));

} // End DoButtonRelease


//=====================================================================
// Method to update selection of specified nodes
//=====================================================================
void
HalTreeC::UpdateSelection(int state, HalTreeNodeListC& nodeList, Boolean callCallbacks)
{
   busy++;
//
// If not extending, clear current selection list.
//
   Boolean	extend = (state & (ShiftMask|ControlMask));
   if ( !extend ) {
      unsigned	count = selectedList.size();
      if ( count > 0 ) {
	 for (int i=0; i<count; i++ ) {
	    if ( ! selectedList[i]->picked ) {
	       selectedList[i]->Unhighlight();
	       selectedList[i]->highlighted = 0;
	       callDeselect = TRUE;
	    }
	    selectedList[i]->selected    = 0;
	 }
	 selectedList.removeAll();
      }
   }

//
// Update the selection list with the new nodes.
//
   unsigned	count = nodeList.size();
   for (int i=0; i<count; i++ ) {

      HalTreeNodeC	*node = nodeList[i];
      node->picked = 0;

      if ( extend ) {
//
//       See if this node is in the selection list.
//
	 if ( node->selected ) {
	    selectedList.remove(node);
	    if ( node->highlighted ) {
	       node->Unhighlight();
	       node->highlighted = 0;
            }
	    node->selected    = 0;
	    callDeselect = TRUE;
	 } else {
	    selectedList.add(node);
	    if ( ! node->highlighted ) {
	       node->Highlight();
	       node->highlighted = 1;
	    }
	    node->selected    = 1;
	    callSelect = TRUE;
	 }
      } else { // Not extending

	 selectedList.add(node);
	 if ( ! node->highlighted ) {
	    node->Highlight();
	    node->highlighted = 1;
         }
	 node->selected    = 1;
	 callSelect = TRUE;
      }

   } // End for each node
   busy--;

   if ( callCallbacks ) {
      if ( callDeselect ) CallDeselectCallbacks();
      if ( callSelect   ) CallSelectCallbacks();
      callDeselect = FALSE;
      callSelect   = FALSE;
   }

   SetStatusLabel(selVal, selectedList.size());

} // End UpdateSelection


//=====================================================================
// Method to handle one click on a node
//=====================================================================
void
HalTreeC::HandleSingleClick(HalTreeC *This, XtIntervalId*)
{
   This->clickTimer = (XtIntervalId)NULL;
} // End HandleSingleClick


//=====================================================================
// Method to select the given node
//=====================================================================
void
HalTreeC::ScrollToNode(HalTreeNodeC* node)
{
   if ( node->Shown() ) {
      SetTreePosition(node->x + node->wd/2 - daWd/2,
                      node->y + node->ht/2 - daHt/2);
   }
}


//=====================================================================
// Method to select the given node
//=====================================================================
void
HalTreeC::SelectNode(HalTreeNodeC& node, Boolean notify)
{
//
// Return if this node is already selected or is not visible
//
   if ( !node.Shown() || node.Selected() ) return;

//
// Add this node to the selected list.
//
   if ( !node.highlighted ) {
      busy++;
      node.Highlight();
      node.highlighted = 1;
      node.selected = 1;
      busy--;
   }
   selectedList.add(&node);
   if ( notify ) CallSelectCallbacks();
   SetStatusLabel(selVal, selectedList.size());

} // End HalTreeC SelectNode


//=====================================================================
// Select the given nodes
//=====================================================================
void
HalTreeC::SelectNodes(HalTreeNodeListC& list, Boolean notify)
{
   halApp->BusyCursor(TRUE);

   Boolean	selected = FALSE;

   unsigned	count = list.size();
   for (int i=0; i<count; i++) {

      HalTreeNodeC	*node = list[i];

      unsigned	selBefore = selectedList.size();
      SelectNode(*node, FALSE);
      unsigned	selAfter  = selectedList.size();

      if ( selAfter > selBefore ) selected = TRUE;

   } // End for each node

   SetStatusLabel(selVal, selectedList.size());
   if ( notify && selected ) CallSelectCallbacks();
   halApp->BusyCursor(FALSE);


} // End HalTreeC SelectNodes


//=====================================================================
//  Select the given node and deselect all others
//=====================================================================
void
HalTreeC::SelectNodeOnly(HalTreeNodeC& node, Boolean notify)
{
   halApp->BusyCursor(TRUE);

   Boolean	wasSelected = selectedList.includes(&node);

//
// Deselect all nodes except this one
//
   if ( wasSelected ) selectedList.remove(&node);
   unsigned	dcount = selectedList.size();
   DeselectNodes(selectedList, FALSE);
   if ( wasSelected ) selectedList.add(&node);
   if ( notify && dcount>0 ) CallDeselectCallbacks();

   if ( !wasSelected ) SelectNode(node, notify);

   halApp->BusyCursor(FALSE);

} // End HalTreeC SelectNodeOnly


//=====================================================================
//  Select the given nodes and deselect all others
//=====================================================================
void
HalTreeC::SelectNodesOnly(HalTreeNodeListC& list, Boolean notify)
{
   halApp->BusyCursor(TRUE);

   Boolean	deselect = FALSE;

//
// Loop through selected list and deselect all nodes except the requested ones
//
   unsigned	count = selectedList.size();
   busy++;
   for (int i=count-1; i>=0; i--) {
      HalTreeNodeC	*node = selectedList[i];
      if ( !list.includes(node) ) {
	 selectedList.remove(i);
	 node->Unhighlight();
         node->highlighted = 0;
	 deselect = TRUE;
      }
   }
   busy--;

   if ( notify && deselect ) CallDeselectCallbacks();

//
// Now select the requested nodes
//
   SelectNodes(list, notify);

   halApp->BusyCursor(FALSE);

} // End HalTreeC SelectNodesOnly


//=====================================================================
//  Public method to deselect the given node
//=====================================================================
void
HalTreeC::DeselectNode(HalTreeNodeC& node, Boolean notify)
{
//
// Return if this node is not selected or visible
//
   if ( !node.Shown() || !node.Selected() ) return;

//
// Remove this node from the selected list.
//
   selectedList.remove(&node);
   if ( node.highlighted ) {
      busy++;
      node.Unhighlight();
      node.highlighted = 0;
      node.selected = 0;
      busy--;
   }	
   SetStatusLabel(selVal, selectedList.size());
   if ( notify ) CallDeselectCallbacks();


} // End HalTreeC DeselectNode


//=====================================================================
//  Deselect the given nodes
//=====================================================================
void
HalTreeC::DeselectNodes(HalTreeNodeListC& list, Boolean notify)
{
   halApp->BusyCursor(TRUE);

   Boolean	deselected = FALSE;

   unsigned	count = list.size();
   for (int i=count-1; i>=0; i--) {

      HalTreeNodeC	*node = list[i];

      unsigned	selBefore = selectedList.size();
      DeselectNode(*node, FALSE);
      unsigned	selAfter  = selectedList.size();

      if ( selBefore > selAfter ) deselected = TRUE;

   } // End for each node

   if ( notify && deselected ) CallDeselectCallbacks();
   halApp->BusyCursor(FALSE);

} // End HalTreeC DeselectNodes


//=====================================================================
//  Toggle the selection of the given node
//=====================================================================
void
HalTreeC::ToggleNode(HalTreeNodeC& node, Boolean notify)
{
//
// Deselect if selected
//
   if ( selectedList.includes(&node) ) DeselectNode(node, notify);
   else				       SelectNode(node, notify);

} // End HalTreeC ToggleNode


//=====================================================================
//  Toggle the selection of the given nodes
//=====================================================================
void
HalTreeC::ToggleNodes(HalTreeNodeListC& list, Boolean notify)
{
   halApp->BusyCursor(TRUE);

   Boolean	selected   = FALSE;
   Boolean	deselected = FALSE;

   unsigned	count = list.size();
   for (int i=0; i<count; i++) {

      HalTreeNodeC	*node = list[i];

      unsigned	selBefore = selectedList.size();
      ToggleNode(*node, FALSE);
      unsigned	selAfter = selectedList.size();

      if ( selBefore > selAfter ) deselected = TRUE;
      if ( selAfter > selBefore ) selected   = TRUE;

   } // End for each node

   if ( notify ) {
      if ( deselected ) CallDeselectCallbacks();
      if ( selected   ) CallSelectCallbacks();
   }

   halApp->BusyCursor(FALSE);

} // End HalTreeC ToggleNodes


//=====================================================================
//  Store a number in the given label
//=====================================================================
void
HalTreeC::SetStatusLabel(Widget label, unsigned count)
{
   StringC val;
   if ( label == totalVal ) {
      numNodesString = " ";
      numNodesString += (int)count;
      val = numNodesString;
   }
   else {
      val  = " ";
      val += (int)count;
      int icount = numNodesString.length() - val.length();
      while ( val.length() < icount ) val = " " + val;
   }
   WXmString    wval((char*)val);
   XtVaSetValues(label, XmNlabelString, (XmString)wval, NULL);
}


//=====================================================================
// Called on initial display
//=====================================================================
void
HalTreeC::HandleMapChange(Widget w, HalTreeC *This, XEvent *ev, Boolean*)
{
   dprintf(("***** Entering HandleMapChange *****\n"));
   if ( ev->type != MapNotify ) return;

   This->busy++;

   halApp->BusyCursor(TRUE);

   XtRemoveEventHandler(w, StructureNotifyMask, FALSE,
		        (XtEventHandler)HandleMapChange, (XtPointer)This);
   This->viewWin = XtWindow(This->viewDA);
   XtGCMask	fixMask = GCClipMask | GCFunction | GCPlaneMask | GCFillStyle 
			| GCGraphicsExposures;
   XtGCMask	modMask = GCForeground | GCLineWidth | GCLineStyle
			| GCCapStyle | GCJoinStyle;
   XtGCMask	naMask  = GCFont | GCArcMode | GCBackground | GCClipXOrigin
			| GCClipYOrigin | GCDashList | GCDashOffset
			| GCFillRule | GCStipple | GCSubwindowMode | GCTile
                        | GCTileStipXOrigin | GCTileStipYOrigin;

   XGCValues fixVals;
   fixVals.clip_mask = None;
   fixVals.function = GXcopy;
   fixVals.plane_mask = AllPlanes;
   fixVals.graphics_exposures = TRUE;
   fixVals.fill_style = FillSolid;
   This->viewGC  = XtAllocateGC(This->viewDA, 0, fixMask, &fixVals, modMask, 
				naMask);

//
// Initialize the view space.
//
   This->GetViewPortSize();

//
// Get offsets to use if scrollbars are not displayed
//
   XtVaGetValues(This->viewFrame, XmNrightOffset,  &This->noScrollRoff,
				  XmNbottomOffset, &This->noScrollBoff, NULL);

//
// Get size and offset for scrollbars
//
   int		roff, boff;
   Dimension	sbwd, sbht;
   XtVaGetValues(This->vScrollBar, XmNrightOffset,  &roff, XmNwidth,  &sbwd, 0);
   XtVaGetValues(This->hScrollBar, XmNbottomOffset, &boff, XmNheight, &sbht, 0);

//
// Get offsets to use if scrollbars are displayed
//
   This->scrollRoff = This->noScrollRoff + sbwd + roff;
   This->scrollBoff = This->noScrollBoff + sbht + boff;

//
// Set scrollbar values
//
   WArgList	args;
   args.Reset();
   args.Minimum(0);
   args.Maximum(This->daWd);
   args.SliderSize(This->daWd);
   args.PageIncrement(This->daWd);
   args.Value(0);
   XtSetValues(This->hScrollBar, ARGS);

   args.Maximum(This->daHt);
   args.SliderSize(This->daHt);
   args.PageIncrement(This->daHt);
   XtSetValues(This->vScrollBar, ARGS);

//
// Set the joy stick to the same size as the scroll bars.
//
   XtVaSetValues(This->joyStickFrame, XmNwidth, sbwd, XmNheight, sbht, NULL);

//
// Set the background color of the joystick drawing area.
//
   Pixel clr;
   XtVaGetValues(This->vScrollBar, XmNtroughColor, &clr, NULL);
   XtVaSetValues(*This->joyStick, XmNbackground, clr, NULL);

// Create the pixmap for drawing
   This->viewPmWd = This->daWd + This->noScrollRoff;
   This->viewPmHt = This->daHt + This->noScrollBoff;
   This->viewPm = XCreatePixmap(This->viewDSP, This->viewWin, 
		  This->viewPmWd, This->viewPmHt, 
		  DefaultDepth(This->viewDSP, DefaultScreen(This->viewDSP)));

//
// Create a drop site
//
   args.Reset();
   args.DragProc((XtCallbackProc)HandleDragOver);
   args.DropProc((XtCallbackProc)HandleDropIn);
   args.AnimationStyle(XmDRAG_UNDER_NONE);
   args.DropSiteType(XmDROP_SITE_SIMPLE);
   if ( This->dropEnabled ) {
      args.DropSiteActivity(XmDROP_SITE_ACTIVE);
      args.ImportTargets(This->dropAtoms);
      args.NumImportTargets(This->dropAtomCount);
   } else {
      args.DropSiteActivity(XmDROP_SITE_INACTIVE);
   }
   XmDropSiteRegister(This->viewDA, ARGS);
 

   halApp->BusyCursor(FALSE);
   This->realized = TRUE;
   This->busy--;

// Add callbacks

   XtAddCallback(This->viewDA, XmNresizeCallback,
                 (XtCallbackProc)HandleResize, (XtPointer)This);
   XtAddCallback(This->viewDA, XmNexposeCallback,
		 (XtCallbackProc)DoExpose, (XtPointer)This);

   This->Draw(TRUE);

   dprintf(("***** Leaving HandleMapChange *****\n"));

} // End HandleMapChange


/*-----------------------------------------------------------------------
 *  Control visibility of status line
 */
void
HalTreeC::HideStatus()
{
   if ( !statusShown ) return;

   WArgList	args;
   args.BottomAttachment(XmATTACH_FORM);
   XtSetValues(scrollForm, ARGS);

   XtUnmanageChild(statusForm);

   statusShown = FALSE;

} // End ShowStatus

void
HalTreeC::ShowStatus()
{
   if ( statusShown ) return;

   XtManageChild(statusForm);

   WArgList	args;
   args.BottomAttachment(XmATTACH_WIDGET, statusForm);
   XtSetValues(scrollForm, ARGS);

   statusShown = TRUE;

} // End HideStatus


void
HalTreeC::UpdateStatus()
{
   if ( !deferred ) {
      SetStatusLabel(totalVal, numNodes);
      SetStatusLabel(dispVal, numNodesShown);
      SetStatusLabel(visVal, numNodesVisible);
      SetStatusLabel(selVal, selectedList.size());
      // XtSetSensitive(selectButton,
		     // numNodes && (selectedList.size() != numNodes));
   }
}


void
HalTreeC::SetBackgroundColor(Pixel clr)
{
   XtVaSetValues(viewFrame, XmNbackground, clr, NULL);
   XtVaSetValues(viewDA, XmNbackground, clr, NULL);
}


Pixel
HalTreeC::BackgroundColor()
{
   Pixel clr;
   XtVaGetValues(viewDA, XmNbackground, &clr, NULL);
   return(clr);
}


int
HalTreeC::GetViewPortSize()
{
   int old_daWd = daWd;
   int old_daHt = daHt;

   Dimension	wd = 0, ht = 0;
   Dimension	mwd = 0, mht = 0;
   XtVaGetValues(viewDA, XmNwidth, &wd,
                         XmNheight, &ht,
			 XmNmarginWidth, &mwd,
			 XmNmarginHeight, &mht, NULL);
   
   daHt     = (int)ht;
   daWd     = (int)wd;
   marginWd = (int)mwd;
   marginHt = (int)mht;

   return(old_daWd==daWd && old_daHt==daHt);
}
