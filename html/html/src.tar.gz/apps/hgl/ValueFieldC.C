/*
 * $Id: ValueFieldC.C,v 1.1 1998/06/24 01:29:07 lang Exp $
 *
 * Copyright (c) 1992 HAL Computer Systems International, Ltd.
 * 
 *          HAL COMPUTER SYSTEMS INTERNATIONAL, LTD.
 *                  1315 Dell Avenue
 *                  Campbell, CA  95008
 *
 * Author: Greg Hilton
 * Contributors: Tom Lang, Frank Bieser, and others
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * http://www.gnu.org/copyleft/gpl.html
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#include <stdio.h>
#include <ctype.h>
#include <values.h>

#include <X11/Intrinsic.h>
#include <Xm/Xm.h>
#include <Xm/TextF.h>
#include <Xm/Form.h>
#include <Xm/LabelG.h>

#include "ValueFieldC.h"
#include "StringC.h"
#include "WArgList.h"

#define Dprintf(a)

// =====================================================================
// =====================================================================
ValueFieldC::ValueFieldC(Widget parent, char* name, Arg *args, Cardinal argcnt,
		         float min_val, float max_val, int prec )
{
   textField = XmCreateTextField(parent,name,args,argcnt);

//
// Add the callbacks.
//
   XtAddCallback(textField, XmNactivateCallback,
		 (XtCallbackProc)activateCB, (XtPointer)this);
   XtAddCallback(textField, XmNvalueChangedCallback,
		 (XtCallbackProc)checkValueCB, (XtPointer)this);

//
// Set the values.
//
   valstr	= 0;
   min 		= min_val;
   max 		= max_val;
   precision    = prec;

//
// Determine the min number of chars the user has to enter
// before we start checking the value.
//
   char str[512];
   sprintf(str,"%.*f", precision, min);
   min_chars = strlen(str);
}


// =====================================================================
// =====================================================================
ValueFieldC::ValueFieldC(Widget parent, char* name, Arg *args, Cardinal argcnt)
{
   textField = XmCreateTextField(parent,name,args,argcnt);

//
// Add the callbacks.
//
   XtAddCallback(textField, XmNactivateCallback,
		 (XtCallbackProc)activateCB, (XtPointer)this);
   XtAddCallback(textField, XmNvalueChangedCallback,
		 (XtCallbackProc)checkValueCB, (XtPointer)this);

//
// Set the values.
//
   valstr	= 0;
   min 		= MINFLOAT;
   max 		= MAXFLOAT;
   precision    = 6;

//
// Determine the min number of chars the user has to enter
// before we start checking the value.
//
   char str[512];
   sprintf(str,"%.*f", precision, min);
   min_chars = strlen(str);
}


// =====================================================================
// =====================================================================
ValueFieldC::~ValueFieldC()
{
   if ( !halApp->xRunning ) return;

   if ( textField && XtIsWidget(textField) )
      XtDestroyWidget(textField);
   if ( valstr )
      XtFree(valstr);    // Allocated by X
}


// =====================================================================
// =====================================================================
void
ValueFieldC::Value(char* value)
{
   Dprintf(("Char Value: %s\n", value));
   XmTextFieldSetString(textField,value);
}


// =====================================================================
// =====================================================================
void
ValueFieldC::Value(float value)
{
   Dprintf(("Float Value: %f\n", value));
   if ( value >= min && value <= max )
   {
      char str[512];
      sprintf(str,"%.*f", precision, value);
      Value(str);
   }
}

// =====================================================================
// =====================================================================
void
ValueFieldC::activateCB(Widget, ValueFieldC* vf, XtPointer)
{
//
// All we're doin here is checking for a null entry.
//
   char* str = XmTextFieldGetString(vf->textField);

   if ( !str || !*str )
   {
      Dprintf(("  setting string\n"));
      if ( vf->min <= 0 )
	 vf->Value((float)0);
      else
	 vf->Value(vf->min);
   }
}



// =====================================================================
// =====================================================================
void
ValueFieldC::checkValueCB(Widget, ValueFieldC* vf, XtPointer)
{
   vf->CheckValue();
}


// =====================================================================
// This routine makes sure the input is correct.
// =====================================================================
void
ValueFieldC::CheckValue()
{
   Dprintf(("*********************\n"));
   Dprintf(("Entering CheckValue\n"));

   Boolean bad_value = False;

   char* str = XmTextFieldGetString(textField);
   Dprintf(("  str: %s\n", str));
   int len = strlen(str);
   int decimal_pos = -1;
   int post_decimal_chars = 0;

   XmTextPosition cur_valpos = XmTextFieldGetInsertionPosition(textField);

//
// Make sure all the characters are good.
//
   for (register int i=0; i<len; i++)
   {
      if ( !isdigit(str[i]) )
      {
         if ( str[i] == '-' && (i!=0 || min >= 0.0) )
         {
	    Dprintf(("  bad minus sign\n"));
	    bad_value = True;
	    break;
         }
         else if ( str[i] == '.' )
         {
	    if ( decimal_pos > -1 )
	    {
	       Dprintf(("  too many decimals\n"));
	       bad_value = True;
	       break;
	    }
	    else
	       decimal_pos = i;
         }
	 else
	 {
	    Dprintf(("  bad digit\n"));
	    bad_value = True;
	    break;
         }
      }

//
//    Check the precision if we have previously encountered a decimal point.
//
      if ( decimal_pos > -1 )
      {
	 Dprintf(("  checking decimal pos: %d\n", post_decimal_chars));
	 if ( post_decimal_chars > precision )
	 {
//
//          Cut off the end of the string and set it.
//
	    Dprintf(("  bad num decimal chars\n"));
	    str[i] = 0;
	    Dprintf(("  cut off string: %s\n", str));

            Dprintf(("  remove the check CB\n"));
            XtRemoveCallback(textField, XmNvalueChangedCallback,
  		             (XtCallbackProc)checkValueCB,
  		             (XtPointer)this);

            XmTextFieldSetString(textField,str);
	    valpos = cur_valpos;
            XmTextFieldSetInsertionPosition(textField,cur_valpos);

	    if ( valstr && valstr != str )
	       XtFree(valstr);
	    valstr = str;

            XtAddCallback(textField, XmNvalueChangedCallback,
                          (XtCallbackProc)checkValueCB,
			  (XtPointer)this);
	 }
	 post_decimal_chars++;
      }
   }

//
// Check the validity of the range of the value.
//
   float val;
   if ( !bad_value )
   {
      val = atof(str);
      Dprintf(("  checking value: %f\n", val));
      if ( len>= min_chars && (val < min || val > max) )
      {
	 Dprintf(("  value out of range %f %f\n", min, max));
         bad_value = True;
      }
   }

//
// See if we had a bad value.
//
   if ( bad_value )
   {
      Dprintf(("  remove the check CB\n"));
      XtRemoveCallback(textField, XmNvalueChangedCallback,
  		       (XtCallbackProc)checkValueCB,
  		       (XtPointer)this);
      if ( valstr )
      {
	 Dprintf(("  restoring valstring to %s\n", valstr));
         XmTextFieldSetString(textField,valstr);
         XmTextFieldSetInsertionPosition(textField,valpos);
      }
      else
      {
	 Dprintf(("  clearing the field\n"));
         // valstr = 0;
         valpos = 0;
         XmTextFieldSetString(textField,"");
      }

      Dprintf(("  add the check CB\n"));
      XtAddCallback(textField, XmNvalueChangedCallback,
                    (XtCallbackProc)checkValueCB,
                    (XtPointer)this);
   }
   else
   {
      Dprintf(("  setting the value to %f\n", val));
      value = val;
      Dprintf(("  reset the value string\n"));
      if ( valstr && valstr != str )
         XtFree(valstr);
      valstr = str;
      valpos = XmTextFieldGetInsertionPosition(textField);
   }

   Dprintf(("Leaving  CheckValue\n"));
   Dprintf(("*********************\n"));
}


// =====================================================================
// =====================================================================
void
ValueFieldC::Min(float min_value)
{
//
// Determine the min number of chars the user has to enter
// before we start checking the value.
//
   min = min_value;
   char str[512];
   sprintf(str,"%.*f", precision, min);
   min_chars = strlen(str);
   CheckValue();
}


// =====================================================================
// =====================================================================
void
ValueFieldC::Max(float max_value)
{
   max = max_value;
   CheckValue();
}


// =====================================================================
// =====================================================================
void
ValueFieldC::Precision(int prec)
{
   precision = prec;
   Min(min);
}


// =====================================================================
// =====================================================================
Widget
LabeledValueFieldC::Initialize(Widget parent, char* name)
{
   StringC form_name(name);
   form_name += "Form";
   form   = XmCreateForm(parent, form_name, 0, 0);
   return(form);
}


// =====================================================================
// =====================================================================
void
LabeledValueFieldC::Build(char* name)
{
   WArgList	args;

   StringC label_name(name);
   label_name += "Label";
   args.Reset();
   args.LeftAttachment(XmATTACH_FORM);
   args.TopAttachment(XmATTACH_FORM);
   args.BottomAttachment(XmATTACH_FORM);
   label = XmCreateLabelGadget(form, label_name, ARGS);
   XtManageChild(label);    
   Dprintf(("  label widget: %d\n", label));

   args.Reset();
   args.LeftAttachment(XmATTACH_WIDGET, label);
   args.TopAttachment(XmATTACH_FORM);
   args.RightAttachment(XmATTACH_FORM);
   // args.BottomAttachment(XmATTACH_FORM);
   XtSetValues(TextField(),ARGS);
   XtManageChild(TextField());
}
