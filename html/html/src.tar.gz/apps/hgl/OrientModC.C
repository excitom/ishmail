/*
 * $Id: OrientModC.C,v 1.1 1998/06/24 01:29:07 lang Exp $
 *
 * Copyright (c) 1992 HAL Computer Systems International, Ltd.
 * 
 *          HAL COMPUTER SYSTEMS INTERNATIONAL, LTD.
 *                  1315 Dell Avenue
 *                  Campbell, CA  95008
 *
 * Author: Greg Hilton
 * Contributors: Tom Lang, Frank Bieser, and others
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * http://www.gnu.org/copyleft/gpl.html
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#include "OrientModC.h"
#include "WArgList.h"
#include "rsrc.h"
#include "StringC.h"

#include <Xm/Form.h>
#include <Xm/Frame.h>
#include <Xm/Label.h>
#include <Xm/RowColumn.h>
#include <Xm/ToggleB.h>

/*----------------------------------------------------------------------
 * Method to build the orientation form
 */

OrientModC::OrientModC(Widget parent, const char *name, ArgList argv,
		       Cardinal argc)
{
   WArgList	args;

//
// Create widget hierarchy
//
//   form
//	Label		label
//	Frame		frame
//
   form = XmCreateForm(parent, (char *)name, argv, argc);

   int	ltOffset = get_int("OrientModC", form, "labelTextOffset", 0);

   StringC	wname = "orientModLabel";
   label = XmCreateLabel(form, wname, 0,0);

   Dimension	wd;
   XtVaGetValues(label, XmNwidth, &wd, NULL);

   wname = "orientModFrame";
   args.Reset();
   args.LeftAttachment(XmATTACH_FORM, wd + ltOffset);
   frame = XmCreateFrame(form, wname, ARGS);

   args.Reset();
   args.TopAttachment(XmATTACH_OPPOSITE_WIDGET, frame);
   args.BottomAttachment(XmATTACH_OPPOSITE_WIDGET, frame);
   args.RightAttachment(XmATTACH_WIDGET, frame, ltOffset);
   XtSetValues(label, ARGS);

//
// Create frame hierarchy
//
//   frame
//	RowColumn	radioBox
//
   wname = "orientModRadioBox";
   args.Reset();
   args.Orientation(XmHORIZONTAL);
   args.RadioBehavior(True);
   radioBox = XmCreateRowColumn(frame, wname, ARGS);

//
// Create radioBox hierarchy
//
//   radioBox
//	ToggleButton	vertTB
//	ToggleButton	horzTB
//
   wname = "orientModVerticalTB";
   vertTB = XmCreateToggleButton(radioBox, wname, 0,0);

   wname = "orientModHorizontalTB";
   horzTB  = XmCreateToggleButton(radioBox, wname, 0,0);

   XtAddCallback(vertTB, XmNvalueChangedCallback, (XtCallbackProc)SetType,
		 (XtPointer)this);
   XtAddCallback(horzTB, XmNvalueChangedCallback, (XtCallbackProc)SetType,
		 (XtPointer)this);

//
// Manage widgets
//
   Widget	list[2];
   list[0] = vertTB;
   list[1] = horzTB;
   XtManageChildren(list, 2);	// radioBox children

   XtManageChild(radioBox);	// frame child

   list[0] = label;
   list[1] = frame;
   XtManageChildren(list, 2);	// form children

//
// Initialize
//
   XmToggleButtonSetState(vertTB, True, True);

} // End OrientModC OrientModC

/*---------------------------------------------------------------
 *  Callback routine to handle press of toggle button
 */

void
OrientModC::SetType(Widget w, OrientModC *om, XmToggleButtonCallbackStruct *tb)
{
   if ( !tb->set ) return;

   om->type = (w == om->horzTB) ? XmHORIZONTAL : XmVERTICAL;
}

/*---------------------------------------------------------------
 *  Method to initialize the settings based on the given type
 */

void
OrientModC::Init(unsigned char newType)
{
   init.type = type = newType;
   Widget	tb;
   switch (type) {
      case (XmVERTICAL):	tb = vertTB;	break;
      case (XmHORIZONTAL):	tb = horzTB;	break;
   }
   XmToggleButtonSetState(tb, True, True);

} // End OrientModC Init

/*---------------------------------------------------------------
 *  Method to reset the settings to the initial state
 */

void
OrientModC::Reset()
{
   type = init.type;
   Widget	tb;
   switch (type) {
      case (XmVERTICAL):	tb = vertTB;	break;
      case (XmHORIZONTAL):	tb = horzTB;	break;
   }
   XmToggleButtonSetState(tb, True, True);

} // End OrientModC Reset
