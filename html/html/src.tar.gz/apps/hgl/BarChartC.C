/*
 * $Id: BarChartC.C,v 1.1 1998/06/24 01:26:33 lang Exp $
 *
 * Copyright (c) 1992 HAL Computer Systems International, Ltd.
 * 
 *          HAL COMPUTER SYSTEMS INTERNATIONAL, LTD.
 *                  1315 Dell Avenue
 *                  Campbell, CA  95008
 *
 * Author: Greg Hilton
 * Contributors: Tom Lang, Frank Bieser, and others
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * http://www.gnu.org/copyleft/gpl.html
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */


#include "BarChartC.h"
#include "WArgList.h"
#include "Shadow.h"
#include "rsrc.h"
#include "HalAppC.h"

#include <Xm/Form.h>
#include <Xm/DrawingA.h>
#include <Xm/ScrollBar.h>

#define BLACK	BlackPixel(display, DefaultScreen(display))
#define WHITE	WhitePixel(display, DefaultScreen(display))

#define MAX_CHARS_IN_NUMBER     64      // Arbitrary

Pixmap		BarChartC::pixmap       = (Pixmap)NULL;
int		BarChartC::pixmapRefCnt = 0;
Dimension	BarChartC::pixmapWd     = 0;
Dimension	BarChartC::pixmapHt     = 0;

/*----------------------------------------------------------------------
 * Method to build the widget hierarchy
 */

BarChartC::BarChartC(Widget parent, const char *name, ArgList argv,
		       Cardinal argc)
{
   WArgList	args;		// Used to set all resources at once

   win         = (Window)NULL;
   gc          = NULL;
   minIndex    = 0;
   maxIndex    = 0;
   minDisp     = 0.0;
   maxDisp     = 0.0;
   minValue    = 0.0;
   maxValue    = 0.0;
   minRange    = 0.0;
   maxRange    = 0.0;
   countRangeInv = 1.0;
   autoRanging = True;
   drawScaleValues = True;
   obscured    = False;
   valueList.AllowDuplicates(TRUE);
   labelList.AllowDuplicates(TRUE);

   display = XtDisplay(parent);
   context = XtWidgetToApplicationContext(parent);

//
// Create form
//
   StringC	nameStr = name;
   nameStr += "Form";
   form = XmCreateForm(parent, nameStr, argv, argc);
   args.Reset();
   args.MarginWidth(0);
   args.MarginHeight(0);
   XtSetValues(form, ARGS);

//
// Create scroll bar
//
   nameStr = name;
   nameStr += "SB";
   args.Reset();
   args.Orientation(XmVERTICAL);
   args.LeftAttachment(XmATTACH_NONE);
   args.RightAttachment(XmATTACH_FORM);
   args.TopAttachment(XmATTACH_FORM);
   args.BottomAttachment(XmATTACH_FORM);
   scrollBar = XmCreateScrollBar(form, nameStr, ARGS);
   XtManageChild(scrollBar);

   XtAddCallback(scrollBar, XmNvalueChangedCallback, (XtCallbackProc)ScrollCB,
		 (XtPointer)this);
   XtAddCallback(scrollBar, XmNdragCallback,         (XtCallbackProc)ScrollCB,
		 (XtPointer)this);

   XtVaGetValues(scrollBar, XmNwidth, &scrollBarSpan, NULL);

//
// Create Threshold Scale
//

//
// Create drawing area
//
   args.Reset();
   args.RightAttachment(XmATTACH_WIDGET, scrollBar);
   args.LeftAttachment(XmATTACH_FORM, 0);
   args.TopAttachment(XmATTACH_FORM, 0);
   args.BottomAttachment(XmATTACH_FORM, 0);
   da = XmCreateDrawingArea(form, (char *)name, ARGS);
   XtManageChild(da);

   XtAddCallback(da, XmNexposeCallback, (XtCallbackProc)ExposeCB,
		 (XtPointer)this);

//
// Read attributes
//
   XtVaGetValues(da, XmNbackground,	   &colors[BACKGROUND],
		     XmNmarginWidth,	   &marginWd,
		     XmNmarginHeight,	   &marginHt,
		     NULL);

   colors[CHART]             = get_color("BarChartC", da, "chartColor",  colors[BACKGROUND]);
   colors[BAR]               = get_color("BarChartC", da, "barColor",             WHITE);
   colors[BAR_HIGHLIGHT]     = get_color("BarChartC", da, "barHighlightColor",    BLACK);
   colors[BAR_VALUE]         = get_color("BarChartC", da, "barValueColor",        BLACK);
   colors[BAR_BORDER]        = get_color("BarChartC", da, "barBorderColor",       BLACK);
   colors[AXIS]              = get_color("BarChartC", da, "axisColor",            BLACK);
   colors[LABEL]             = get_color("BarChartC", da, "labelColor",           BLACK);
   colors[TICK]              = get_color("BarChartC", da, "tickColor",            BLACK);
   colors[GRID]              = get_color("BarChartC", da, "gridColor",            BLACK);
   colors[MARK]              = get_color("BarChartC", da, "markColor",            BLACK);
   colors[TOP_SHADOW]        = get_color("BarChartC", da, "topShadowColor",       WHITE);
   colors[BOTTOM_SHADOW]     = get_color("BarChartC", da, "bottomShadowColor",    BLACK);
   colors[BAR_TOP_SHADOW]    = get_color("BarChartC", da, "barTopShadowColor",    WHITE);
   colors[BAR_BOTTOM_SHADOW] = get_color("BarChartC", da, "barBottomShadowColor", BLACK);

   StringC	fstr = get_string("BarChartC", da, "font", "fixed");
   font	= XLoadQueryFont(display, fstr);
   if ( !font ) font = halApp->font;
   shadowType          = get_shadow_type("BarChartC", da, "shadowType",    XmSHADOW_IN);
   barShadowType       = get_shadow_type("BarChartC", da, "barShadowType", XmSHADOW_OUT);
   shadowThickness     = get_int    ("BarChartC", da, "shadowThickness",    2);
   barShadowThickness  = get_int    ("BarChartC", da, "barShadowThickness", 2);
   compress            = get_boolean("BarChartC", da, "compressCountRange", False);
   labelOffset	       = get_int    ("BarChartC", da, "labelOffset",        2);
   majorTickLen        = get_int    ("BarChartC", da, "majorTickLength",    8);
   minorTickLen        = get_int    ("BarChartC", da, "minorTickLength",    4);
   majorTickSpace      = get_float  ("BarChartC", da, "majorTickSpacing", 0);
   minorTickSpace      = get_float  ("BarChartC", da, "minorTickSpacing", 0);
   majorGridVis        = get_boolean("BarChartC", da, "majorGridVisible",   False);
   minorGridVis        = get_boolean("BarChartC", da, "minorGridVisible",   False);
   orientation	       = get_orient ("BarChartC", da, "orientation", XmVERTICAL);
   int precis	       = get_int    ("BarChartC", da, "decimalPlaces", 2);
   valueFormat.SetPrecision(precis);
   visCount	       = get_int    ("BarChartC", da, "visibleBucketCount", 0);
   deferred	       = get_boolean("BarChartC", da, "deferred", False);
   deferCount	       = deferred ? 1 : 0;


//
// Set up the scroll bar
//
   if ( orientation == XmHORIZONTAL ) {

      args.Reset();
      args.Orientation(XmHORIZONTAL);
      args.LeftAttachment(XmATTACH_FORM);
      args.RightAttachment(XmATTACH_FORM);
      args.TopAttachment(XmATTACH_NONE);
      args.BottomAttachment(XmATTACH_FORM);
      args.Height(scrollBarSpan);
      XtSetValues(scrollBar, ARGS);

      args.Reset();
      args.LeftAttachment(XmATTACH_FORM, 0);
      args.RightAttachment(XmATTACH_FORM, 0);
      args.TopAttachment(XmATTACH_FORM, 0);
      args.BottomAttachment(XmATTACH_WIDGET, scrollBar);
      XtSetValues(da, ARGS);
   }

//
// Turn off the scroll bar if all values are visible
//
   if ( visCount < 1 ) {
      args.Reset();
      if ( orientation == XmVERTICAL ) args.RightAttachment(XmATTACH_FORM);
      else			       args.BottomAttachment(XmATTACH_FORM);
      XtSetValues(da, ARGS);
      XtUnmanageChild(scrollBar);
   }

   return;

} // End BarChartC BarChartC

/*----------------------------------------------------------------------
 * BarChartC destructor
 */

BarChartC::~BarChartC()
{
   if ( !halApp->xRunning )
      XFreeFont(halApp->display, font);

//   XtDestroyWidget(form);
}

/*----------------------------------------------------------------------
 * Callback to handle expose
 */

void
BarChartC::ExposeCB(Widget, BarChartC *sp, XmDrawingAreaCallbackStruct *db)
{
   XExposeEvent *ev = (XExposeEvent*)db->event;

   if ( ev->count > 0 ) return;		// Wait for last event

//
// Create graphics context if necessary
//
   if ( !sp->gc ) {

      sp->win = XtWindow(sp->da);

      XtGCMask	fixMask = GCBackground | GCClipMask | GCClipXOrigin
			| GCClipYOrigin | GCFillRule | GCFillStyle | GCFunction
			| GCGraphicsExposures | GCPlaneMask | GCLineStyle
			| GCLineWidth | GCFont | GCArcMode;
      XtGCMask	modMask = GCForeground;
      XtGCMask	naMask  = GCCapStyle | GCJoinStyle | GCDashList | GCDashOffset
			| GCStipple | GCSubwindowMode | GCTile
			| GCTileStipXOrigin | GCTileStipYOrigin;

      XGCValues fixVals;
      fixVals.arc_mode		 = ArcChord;
      fixVals.background         = sp->colors[BACKGROUND];
      fixVals.clip_mask		 = None;
      fixVals.clip_x_origin	 = 0;
      fixVals.clip_y_origin	 = 0;
      fixVals.fill_rule          = EvenOddRule;
      fixVals.fill_style         = FillSolid;
      fixVals.font	 	 = sp->font->fid;
      fixVals.function           = GXcopy;
      fixVals.graphics_exposures = TRUE;
      fixVals.line_width	 = 0;
      fixVals.line_style	 = LineSolid;
      fixVals.plane_mask         = AllPlanes;

      sp->gc = XtAllocateGC(sp->da, 0, fixMask, &fixVals, modMask, naMask);

      XtVaGetValues(sp->da, XmNwidth, &sp->daWd, XmNheight, &sp->daHt, NULL);

//
// Create off-screen pixmap to be used for drawing.  One pixmap is shared by
//    all bar charts
//
      if ( !pixmap ) {
      
	 unsigned depth = DefaultDepth(sp->display, DefaultScreen(sp->display));
         pixmapWd =  (sp->daWd > pixmapWd) ? sp->daWd : pixmapWd;
         pixmapHt =  (sp->daHt > pixmapHt) ? sp->daHt : pixmapHt;
	 pixmap = XCreatePixmap(sp->display, sp->win, pixmapWd, pixmapHt, depth);
      }
      
//
// Re-create pixmap if size has increased
//
      else if ( sp->daWd > pixmapWd || sp->daHt > pixmapHt ) {

	 XFreePixmap(sp->display, pixmap);
	 unsigned depth = DefaultDepth(sp->display, DefaultScreen(sp->display));
         pixmapWd =  (sp->daWd > pixmapWd) ? sp->daWd : pixmapWd;
         pixmapHt =  (sp->daHt > pixmapHt) ? sp->daHt : pixmapHt;
	 pixmap = XCreatePixmap(sp->display, sp->win, pixmapWd, pixmapHt, depth);
      }

      pixmapRefCnt++;

//
// Add event handler to detect visibility changes
//
      XtAddEventHandler(sp->da, VisibilityChangeMask, False,
			(XtEventHandler)HandleVisChange, (XtPointer)sp);

//
// Add callback to handle resizes
//
      XtAddCallback(sp->da, XmNresizeCallback, (XtCallbackProc)ResizeCB,
		    (XtPointer)sp);

   } // End if drawing context not created

//
// Redraw
//
   sp->Draw();

} // End BarChartC ExposeCB

/*----------------------------------------------------------------------
 * Callback to handle resize
 */

void
BarChartC::ResizeCB(Widget, BarChartC *sp, XtPointer)
{
   if ( !sp->gc ) return;

//
// Get the size of the histogram
//
   XtVaGetValues(sp->da, XmNwidth, &sp->daWd, XmNheight, &sp->daHt, NULL);

//
// Re-create pixmap if size has increased
//
   if ( sp->daWd > pixmapWd || sp->daHt > pixmapHt ) {

      XFreePixmap(sp->display, pixmap);
      unsigned  depth = DefaultDepth(sp->display, DefaultScreen(sp->display));
      pixmapWd =  (sp->daWd > pixmapWd) ? sp->daWd : pixmapWd;
      pixmapHt =  (sp->daHt > pixmapHt) ? sp->daHt : pixmapHt;
      pixmap = XCreatePixmap(sp->display, sp->win, pixmapWd, pixmapHt, depth);
   }

//
// Redraw
//
   sp->Draw();

} // End BarChartC ResizeCB

/*----------------------------------------------------------------------
 * Callback to handle scroll bar value change
 */

void
BarChartC::ScrollCB(Widget, BarChartC *sp, XmScrollBarCallbackStruct *sb)
{
   if ( sp->visCount > 0 ) {
      sp->minIndex = sb->value;
      sp->maxIndex = sp->minIndex + sp->visCount - 1;
      sp->Draw();
   }
}

/*-----------------------------------------------------------------------
 *  Event handler for visibility changes
 */

void
BarChartC::HandleVisChange(Widget, BarChartC *sp, XVisibilityEvent *ev,
			     Boolean*)
{
   Boolean	obscured;
   obscured = (ev->state == VisibilityFullyObscured);

   if ( sp->obscured != obscured ) {
      sp->obscured = obscured;
      if ( !obscured ) sp->Draw();
   }
}

/*-----------------------------------------------------------------------
 *  Method to set deferral mode
 */

void
BarChartC::Defer(Boolean on)
{
   if      ( on )       deferCount++;
   else if ( deferred ) deferCount--;

   deferred = (deferCount > 0);

   if ( !deferred ) Draw();
}

/*----------------------------------------------------------------------
 * Method to draw histogram
 */

void
BarChartC::Draw()
{
   if ( !gc || obscured ) return;

   XSetForeground(display, gc, colors[BACKGROUND]);
   XFillRectangle(display, pixmap, gc, 0, 0, daWd, daHt);

   if ( orientation == XmVERTICAL ) DrawVertical();
   else				    DrawHorizontal();

   XCopyArea(display, pixmap, win, gc, 0, 0, daWd, daHt, 0, 0);
}

/*----------------------------------------------------------------------
 * Method to draw vertical histogram
 */

void
BarChartC::DrawVertical()
{
//   StringC	minYStr, maxYStr;
   int		dir, asc, dsc;
   XCharStruct	size;
   int		lcount = labelList.size();	// User label count

//
// Compute maximum value label size
//
   int maxLabelWd = 0;
   XCharStruct labelStrSize;

   for (int i=0;i<lcount;i++) {
      StringC labelStr = *labelList[i];
      XTextExtents(font,labelStr,labelStr.size(),&dir,&asc,&dsc,&labelStrSize);
      maxLabelWd = MAX(labelStrSize.width,maxLabelWd);
   }

//
// Compute space needed for left margin
//
   int	leftMargin = marginWd + maxLabelWd + labelOffset;

//
// If first x label is too wide, increase left margin
//
   valueFormat = minDisp;
   StringC	minXStr = valueFormat;
   XCharStruct	minXSize;
   int		minWd2;
   XTextExtents(font, minXStr, minXStr.size(), &dir, &asc, &dsc, &minXSize);
   minWd2 = minXSize.width / 2;
   if ( minWd2 > leftMargin ) leftMargin = minWd2 + 1;

//
// Compute space needed for right margin
//
   int	rightMargin = marginWd;

//
// If last x label is too wide, increase right margin
//
   valueFormat = maxDisp;
   StringC	maxXStr = valueFormat;
   XCharStruct	maxXSize;
   int		maxWd2;
   XTextExtents(font, maxXStr, maxXStr.size(), &dir, &asc, &dsc, &maxXSize);
   maxWd2 = maxXSize.width / 2;
   if ( maxWd2 > rightMargin ) rightMargin = maxWd2 + 1;

   int	axisX1 = leftMargin;
   int	axisX2 = daWd - rightMargin - 1;
   int	axisWd = axisX2 - axisX1 + 1;
   int	valX1  = axisX1 + shadowThickness;
   int	valX2  = axisX2 - shadowThickness;
   int	valWd  = valX2 - valX1 + 1;

//
// Calculate top and bottom margins
//
   int	fontHt = font->ascent + font->descent;
   int	fontHt2 = fontHt / 2;

   int	topMargin = marginHt;
   if ( valueMarkList.size() > 0 ) topMargin += fontHt + labelOffset;
//   else				   topMargin += fontHt2;

   int	bottomMargin = marginHt + fontHt + labelOffset;
   if ( majorTickLen > minorTickLen ) {
      if      ( majorTickSpace > 0 ) bottomMargin += majorTickLen;
      else if ( minorTickSpace > 0 ) bottomMargin += minorTickLen;
   } else {
      if      ( minorTickSpace > 0 ) bottomMargin += minorTickLen;
      else if ( majorTickSpace > 0 ) bottomMargin += majorTickLen;
   }

   int	axisY1 = topMargin;
   int	axisY2 = daHt - bottomMargin - 1;
   int	axisHt = axisY2 - axisY1 + 1;
   int	valY1  = axisY1 + shadowThickness;
   int	valY2  = axisY2 - shadowThickness;
   int	valHt  = valY2 - valY1 + 1;

//
// Draw Value/X axis ticks
//
   XSetForeground(display, gc, colors[TICK]);

   if ( majorTickSpace > 0 ) {
      int	y1 = axisY2 + 1;
      int	y2 = axisY2 + majorTickLen;
      for (float val=minDisp; val<=maxDisp; val+=majorTickSpace) {
	 int	x = valX1 + (int)(NormalizeValue(val) * valWd);
	 XDrawLine(display, pixmap, gc, x, y1, x, y2);
      }
   }

   if ( minorTickSpace > 0 ) {
      int	y1 = axisY2 + 1;
      int	y2 = axisY2 + minorTickLen;
      for (float val=minDisp; val<=maxDisp; val+=minorTickSpace) {
	 int	x = valX1 + (int)(NormalizeValue(val) * valWd);
	 XDrawLine(display, pixmap, gc, x, y1, x, y2);
      }
   }

//
// Calculate Y-axis spacing
//
   int	vcount;
   int	bcount = valueList.size();
   if ( visCount > 0 ) vcount = MIN(visCount, bcount);
   else		       vcount = bcount;

   float	yincr = (float)(valHt-1);
   if ( vcount > 1 ) yincr /= (float)vcount;

   int		offset = valY1 - (int)(yincr * minIndex);
   float	range = yincr * valueList.size();

//
// Draw X-axis labels
//
   XSetForeground(display, gc, colors[LABEL]);

   int	y = axisY2 + labelOffset + font->ascent;
   if ( majorTickLen > minorTickLen ) {
      if      ( majorTickSpace > 0 ) y += majorTickLen;
      else if ( minorTickSpace > 0 ) y += minorTickLen;
   } else {
      if      ( minorTickSpace > 0 ) y += minorTickLen;
      else if ( majorTickSpace > 0 ) y += majorTickLen;
   }

   int	x = valX1 - minWd2;
   XDrawString(display, pixmap, gc, x, y, minXStr, minXStr.size());
   int	leftX = x + minXSize.width;

   x = valX2 - maxWd2;
   if ( x > leftX ) {
      XDrawString(display, pixmap, gc, x, y, maxXStr, maxXStr.size());
      int	rightX = x;

//
// Draw the interior labels
//
      if ( majorTickSpace > 0 ) {
	 for (float val=minDisp+majorTickSpace; val<maxDisp;
	      val+=majorTickSpace) {
	    valueFormat = val;
	    StringC valStr = valueFormat;
	    XTextExtents(font, valStr, valStr.size(), &dir, &asc, &dsc, &size);
	    x = valX1 + (int)(NormalizeValue(val) * valWd) - size.width/2;
//
// Draw only if it doesn't overlap another
//
	    if ( (x>leftX) && (x+size.width)<rightX ) {
	       XDrawString(display, pixmap, gc, x, y, valStr, valStr.size());
	       leftX = x + size.width;
	    }
	 } // End for each major value
      } // End if there are major ticks
   } // End if space for interior labels

//
// Draw Y-axis labels
//
      if ( lcount > 0 ) {

	 x = axisX1 - labelOffset;

//
// Draw the first and last labels
//
	 StringC	*label = labelList[minIndex];
	 XTextExtents(font, *label, label->size(), &dir, &asc, &dsc, &size);

	 float	yincr2 = yincr * 0.5;
	 y = valY1 + (int)yincr2 + font->ascent - fontHt2;
	 x -= size.width;
	 XDrawString(display, pixmap, gc, x, y, *label, label->size());
	 x += size.width;
	 int	topY = y + font->descent;

//
// Draw the last label
//
	 if ( lcount > 1 ) {

	    label = labelList[maxIndex];
	    XTextExtents(font, *label, label->size(), &dir, &asc, &dsc, &size);
	    y = valY2 - (int)yincr2 + font->ascent - fontHt2;
	    x -= size.width;
	    XDrawString(display, pixmap, gc, x, y, *label, label->size());
	    x += size.width;
	    int	botY = y - font->descent;
//
// Draw the interior labels
//
	    for (int i=minIndex+1; i<maxIndex; i++) {

	       label = labelList[i];
	       XTextExtents(font, *label, label->size(), &dir,&asc,&dsc, &size);

//
// Draw only if it doesn't overlap another
//
	       y = valY1 + (int)(yincr * (i-minIndex) + yincr2) + font->ascent
		 - fontHt2;
	       if ( (y-font->ascent) > topY && (y+font->descent) < botY ) {
		  x -= size.width;
		  XDrawString(display, pixmap, gc, x, y, *label, label->size());
		  x += size.width;
		  topY = y + font->descent;
	       }

	    } // End for each bar label
	 } // End if at least 2 labels
      } // End if at least 1 label

//
// Draw chart background
//
   XSetForeground(display, gc, colors[CHART]);
   XFillRectangle(display, pixmap, gc, axisX1, axisY1, axisWd, axisHt);

//
// Draw chart shadow if necessary
//
   if ( shadowThickness > 0 ) {

      DrawShadow(display, pixmap, gc, colors[TOP_SHADOW], colors[BOTTOM_SHADOW],
		 axisX1, axisY1, axisWd, axisHt, shadowThickness,
		 shadowType);

   } else { // Draw axis lines

      XSetForeground(display, gc, colors[AXIS]);
      XDrawLine(display, pixmap, gc, axisX1-1, axisY1, axisX1-1, axisY2);
      XDrawLine(display, pixmap, gc, axisX1-1, axisY2+1, axisX2, axisY2+1);
   }

   if ( valueList.size() > 0 ) {

//
// Set clipping window
//
      XRectangle	rect;
      rect.x      = (short)valX1;
      rect.y      = (short)valY1;
      rect.width  = (unsigned short)valWd;
      rect.height = (unsigned short)valHt;
      XSetClipRectangles(display, gc, 0, 0, &rect, 1, Unsorted);

//
// Draw bars
//
      float	offset = 0;
      for (int i=minIndex; i<=maxIndex; i++, offset+=yincr) {
	 int	y  = valY1 + (int)offset + 1;
	 int	y2 = valY1 + (int)(offset + yincr);
	 int	ht = y2 - y;
	 int	wd = (int)(NormalizeValue(*valueList[i]) * valWd);

         if (*valueList[i] >= thresholdValue)
	     XSetForeground(display, gc, colors[BAR_HIGHLIGHT]);
         else
	     XSetForeground(display, gc, colors[BAR]);
	 XFillRectangle(display, pixmap, gc, valX1, y, wd, ht);
//
// Draw scale value
//
         if ( drawScaleValues ) {
            int textSpacing = 2;
            StringC  valStr = ValueString(*valueList[i]);
            XTextExtents(font, valStr, valStr.size(), &dir, &asc, &dsc, &size);
            int svy = y + ((ht - (size.ascent + size.descent)) / 2) + size.ascent;
            int svx = (valX1 + wd) - barShadowThickness - textSpacing - size.width;
            if ( svx < (int)(valX1 + barShadowThickness + textSpacing) )
               svx = (valX1 + wd) + barShadowThickness + textSpacing;
            XSetForeground(display, gc, colors[BAR_VALUE]);
            if ( (int)(svy + size.descent + barShadowThickness) < (int)(y + ht) )
               XDrawString(display, pixmap, gc, svx, svy, valStr, valStr.size());
         }


	 if ( barShadowThickness > 0 ) {
	    DrawShadow(display, pixmap, gc, colors[BAR_TOP_SHADOW],
		       colors[BAR_BOTTOM_SHADOW], valX1, y, wd, ht,
		       barShadowThickness, barShadowType);
	 } else {
	    XSetForeground(display, gc, colors[BAR_BORDER]);
	    XDrawRectangle(display, pixmap, gc, valX1, y, wd-1, ht-1);
	 }
      }

      XSetClipMask(display, gc, None);

   } // End if at least one bucket

//
// Draw grid lines
//
   XSetForeground(display, gc, colors[GRID]);
   XSetLineAttributes(display, gc, 0, LineOnOffDash, CapButt, JoinMiter);

   if ( majorTickSpace > 0 && majorGridVis ) {
      for (float val=minDisp; val<=maxDisp; val+=majorTickSpace) {
	 int	x = valX1 + (int)(NormalizeValue(val) * valWd);
	 XDrawLine(display, pixmap, gc, x, valY1, x, valY2);
      }
   }

   if ( minorTickSpace > 0 && minorGridVis ) {
      for (float val=minDisp; val<=maxDisp; val+=minorTickSpace) {
	 int	x = valX1 + (int)(NormalizeValue(val) * valWd);
	 XDrawLine(display, pixmap, gc, x, valY1, x, valY2);
      }
   }

   XSetLineAttributes(display, gc, 0, LineSolid, CapButt, JoinMiter);

//
// Draw value axis marks
//
   XSetForeground(display, gc, colors[MARK]);

   y = axisY1 - labelOffset - font->descent;
   int	mcount = valueMarkList.size();
   for ( i=0; i<mcount; i++) {

      float	val = *valueMarkList[i];
      int	x = valX1 + (int)(NormalizeValue(val) * valWd);
      if ( x >= valX1 && x <= valX2 ) {
	 XDrawLine(display, pixmap, gc, x, axisY1, x, axisY2);

	 valueFormat = val;
	 StringC valStr = valueFormat;
	 XTextExtents(font, valStr, valStr.size(), &dir, &asc, &dsc, &size);

	 x -= size.width/2;
	 XDrawString(display, pixmap, gc, x, y, valStr, valStr.size());
      }

   } // End for each count mark


//
// Position the scroll bar
//
   int	sliderSize = MAX(vcount,1);
   int	sliderInc  = sliderSize;
   int	sliderMax  = MAX(bcount, sliderSize);

   WArgList	args;
   args.TopOffset(topMargin);
   args.BottomOffset(bottomMargin);
   args.Maximum(sliderMax);
   args.Value(minIndex);
   args.SliderSize(sliderSize);
   args.PageIncrement(sliderInc);
   XtSetValues(scrollBar, ARGS);

} // End BarChartC DrawVertical

/*----------------------------------------------------------------------
 * Method to draw horizontal histogram
 */

void
BarChartC::DrawHorizontal()
{
   int	lcount = labelList.size();

//
// Compute maximum value/y label size
//
   int		dir, asc, dsc;
   XCharStruct	minYSize, maxYSize;
   valueFormat = minDisp;
   StringC	minYStr = valueFormat;
   valueFormat = maxDisp;
   StringC	maxYStr = valueFormat;
   XTextExtents(font, minYStr, minYStr.size(), &dir, &asc, &dsc, &minYSize);
   XTextExtents(font, maxYStr, maxYStr.size(), &dir, &asc, &dsc, &maxYSize);
   int		maxLabelWd = MAX(minYSize.width, maxYSize.width);

//
// Get min and max labels for label/x axis
//
   StringC	minXStr, maxXStr;
   XCharStruct	minXSize, maxXSize;
   XCharStruct	size;

   if ( lcount > 0 ) minXStr = *labelList[minIndex];
   else		minXStr = "";
   if ( lcount > 1 ) maxXStr = *labelList[maxIndex];
   else		maxXStr = "";

//
// Compute space needed for left margin
//
   int	leftMargin = marginWd + maxLabelWd + labelOffset;
   if ( majorTickLen > minorTickLen ) {
      if      ( majorTickSpace > 0 ) leftMargin += majorTickLen;
      else if ( minorTickSpace > 0 ) leftMargin += minorTickLen;
   } else {
      if      ( minorTickSpace > 0 ) leftMargin += minorTickLen;
      else if ( majorTickSpace > 0 ) leftMargin += majorTickLen;
   }

//
// If first x label is too wide, increase left margin
//
   XTextExtents(font, minXStr, minXStr.size(), &dir, &asc, &dsc, &minXSize);
   int	minWd2  = minXSize.width / 2;
   if ( minWd2 > leftMargin ) leftMargin = minWd2 + 1;

//
// Compute space needed for right margin
//
   int	rightMargin = marginWd;
   if ( valueMarkList.size() > 0 ) rightMargin += maxLabelWd + labelOffset;

//
// If last x label is too wide, increase right margin
//
   XTextExtents(font, maxXStr, maxXStr.size(), &dir, &asc, &dsc, &maxXSize);
   int	maxWd2 = maxXSize.width / 2;
   if ( maxWd2 > rightMargin ) rightMargin = maxWd2 + 1;

   int	axisX1 = leftMargin;
   int	axisX2 = daWd - rightMargin - 1;
   int	axisWd = axisX2 - axisX1 + 1;
   int	valX1  = axisX1 + shadowThickness;
   int	valX2  = axisX2 - shadowThickness;
   int	valWd  = valX2 - valX1 + 1;

//
// Calculate top and bottom margins
//
   int	fontHt = font->ascent + font->descent;
   int	fontHt2 = fontHt / 2;

   int	topMargin = marginHt;
      topMargin += fontHt2;

   int	bottomMargin = marginHt + fontHt + labelOffset;

   int	axisY1 = topMargin;
   int	axisY2 = daHt - bottomMargin - 1;
   int	axisHt = axisY2 - axisY1 + 1;
   int	valY1  = axisY1 + shadowThickness;
   int	valY2  = axisY2 - shadowThickness;
   int	valHt  = valY2 - valY1 + 1;

//
// Draw Value/Y axis ticks
//
   XSetForeground(display, gc, colors[TICK]);

   if ( majorTickSpace > 0 ) {
      int	x1 = axisX1 - majorTickLen;
      int	x2 = axisX1 - 1;
      for (float val=minDisp; val<=maxDisp; val+=majorTickSpace) {
	 int	y = valY2 - (int)(NormalizeValue(val) * valHt);
	 XDrawLine(display, pixmap, gc, x1, y, x2, y);
      }
   }

   if ( minorTickSpace > 0 ) {
      int	x1 = axisX1 - minorTickLen;
      int	x2 = axisX1 - 1;
      for (float val=minDisp; val<=maxDisp; val+=minorTickSpace) {
	 int	y = valY2 - (int)(NormalizeValue(val) * valHt);
	 XDrawLine(display, pixmap, gc, x1, y, x2, y);
      }
   }

//
// Calculate Label/X axis spacing
//
   int	vcount;
   int	bcount = valueList.size();
   if ( visCount > 0 ) vcount = MIN(visCount, bcount);
   else		       vcount = bcount;

   float	xincr = (float)(valWd-1);
   if ( vcount > 1 ) xincr /= (float)vcount;

   int		offset = valX1 - (int)(xincr * minIndex);
   float	range = xincr * valueList.size();

//
// Draw Value/Y axis labels
//
   XSetForeground(display, gc, colors[LABEL]);

   int	x = axisX1 - labelOffset;
   if ( majorTickLen > minorTickLen ) {
      if      ( majorTickSpace > 0 ) x -= majorTickLen;
      else if ( minorTickSpace > 0 ) x -= minorTickLen;
   } else {
      if      ( minorTickSpace > 0 ) x -= minorTickLen;
      else if ( majorTickSpace > 0 ) x -= majorTickLen;
   }

   int	y = valY2 + font->ascent - fontHt2;
   x -= minYSize.width;
   XDrawString(display, pixmap, gc, x, y, minYStr, minYStr.size());
   x += minYSize.width;
   int	botY = y - font->ascent;

   y = valY1 + font->ascent - fontHt2;
   if ( y+font->descent < botY ) {

      x -= maxYSize.width;
      XDrawString(display, pixmap, gc, x, y, maxYStr, maxYStr.size());
      x += maxYSize.width;
      int	topY = y + font->descent;

//
// Draw the interior labels
//
      if ( majorTickSpace > 0.0 ) {
	 for (float val=minDisp+majorTickSpace; val<maxDisp;
	      val+=majorTickSpace) {
	    valueFormat = val;
	    StringC valStr = valueFormat;
	    XTextExtents(font, valStr, valStr.size(), &dir, &asc, &dsc, &size);
	    y = valY2 - (int)(NormalizeValue(val) * valHt) + font->ascent
	      - fontHt2;

//
// Draw only if it doesn't overlap another
//
	    if ( (y+font->descent<botY) && (y-font->ascent)>topY ) {
	       x -= size.width;
	       XDrawString(display, pixmap, gc, x, y, valStr, valStr.size());
	       x += size.width;
	       botY = y - font->ascent;
	    }

	 } // End for each major value
      } // End if there are major ticks
   } // End if no overlap

//
// Draw Label/X axis labels
//
      if ( lcount > 0 ) {

	 y = axisY2 + labelOffset + font->ascent;

//
// Draw the first and last labels
//
	 float	xincr2 = xincr * 0.5;
	 x = valX1 + (int)xincr2 - minWd2;
	 XDrawString(display, pixmap, gc, x, y, minXStr, minXStr.size());
	 int	leftX = x + minXSize.width;

//
// Draw the last label
//
	 if ( lcount > 1 ) {

	    x = valX2 - (int)xincr2 - maxWd2;
	    XDrawString(display, pixmap, gc, x, y, maxXStr, maxXStr.size());
	    int	rightX = x;
//
// Draw the interior labels
//
	    for (int i=minIndex+1; i<maxIndex; i++) {

	       StringC	*label = labelList[i];
	       XTextExtents(font, *label, label->size(), &dir,&asc,&dsc, &size);

//
// Draw only if it doesn't overlap another
//
	       x = valX1 + (int)(xincr * (i-minIndex) + xincr2) - size.width/2;
	       if ( x > leftX && (x+size.width) < rightX ) {
		  XDrawString(display, pixmap, gc, x, y, *label, label->size());
		  leftX = x + size.width;
	       }

	    } // End for each bar label
	 } // End if at least 2 labels
      } // End if at least 1 label

//
// Draw chart background
//
   XSetForeground(display, gc, colors[CHART]);
   XFillRectangle(display, pixmap, gc, axisX1, axisY1, axisWd, axisHt);

//
// Draw chart shadow if necessary
//
   if ( shadowThickness > 0 ) {

      DrawShadow(display, pixmap, gc, colors[TOP_SHADOW], colors[BOTTOM_SHADOW],
		 axisX1, axisY1, axisWd, axisHt, shadowThickness,
		 shadowType);

   } else { // Draw axis lines

      XSetForeground(display, gc, colors[AXIS]);
      XDrawLine(display, pixmap, gc, axisX1-1, axisY1, axisX1-1, axisY2);
      XDrawLine(display, pixmap, gc, axisX1-1, axisY2+1, axisX2, axisY2+1);
   }

   if ( valueList.size() > 0 ) {

//
// Set clipping window
//
      XRectangle	rect;
      rect.x      = (short)valX1;
      rect.y      = (short)valY1;
      rect.width  = (unsigned short)valWd;
      rect.height = (unsigned short)valHt;
      XSetClipRectangles(display, gc, 0, 0, &rect, 1, Unsorted);

//
// Draw bars
//
      float	offset = 0;
      for (int i=minIndex; i<=maxIndex; i++, offset+=xincr) {

	 int	x  = valX1 + (int)offset + 1;
	 int	x2 = valX1 + (int)(offset + xincr);
	 int	wd = x2 - x;
	 int	ht = (int)(NormalizeValue(*valueList[i]) * valHt);
	 int	y  = valY2 - ht + 1;

         if (*valueList[i] >= thresholdValue)
	     XSetForeground(display, gc, colors[BAR_HIGHLIGHT]);
         else
	     XSetForeground(display, gc, colors[BAR]);
	 XFillRectangle(display, pixmap, gc, x, y, wd, ht);

//
// Draw scale value
//
         if ( drawScaleValues ) {
            int textSpacing = 2;
            StringC  valStr = ValueString(*valueList[i]);
            XTextExtents(font, valStr, valStr.size(), &dir, &asc, &dsc, &size);
            int svy = y + barShadowThickness + size.ascent + textSpacing;
            if ( svy >
	         (int)(y + ht - size.descent - textSpacing - barShadowThickness ))
               svy = y - barShadowThickness - size.descent - textSpacing;
            int svx = (x + wd/2) - size.width/2;
            XSetForeground(display, gc, colors[BAR_VALUE]);
            if (svx > x)
               XDrawString(display, pixmap, gc, svx, svy, valStr, valStr.size());
         }

	 if ( barShadowThickness > 0 ) {
	    DrawShadow(display, pixmap, gc, colors[BAR_TOP_SHADOW],
		       colors[BAR_BOTTOM_SHADOW], x, y, wd, ht,
		       barShadowThickness, barShadowType);
	 } else {
	    XSetForeground(display, gc, colors[BAR_BORDER]);
	    XDrawRectangle(display, pixmap, gc, x, y, wd-1, ht-1);
	 }
      }

      XSetClipMask(display, gc, None);


   } // End if at least 1 point

//
// Draw grid lines
//
   XSetForeground(display, gc, colors[GRID]);
   XSetLineAttributes(display, gc, 0, LineOnOffDash, CapButt, JoinMiter);

   if ( majorTickSpace > 0 && majorGridVis ) {
      for (float val=minDisp; val<=maxDisp; val+=majorTickSpace) {
	 int	y = valY2 - (int)(NormalizeValue(val) * valHt);
	 XDrawLine(display, pixmap, gc, valX1, y, valX2, y);
      }
   }

   if ( minorTickSpace > 0 && minorGridVis ) {
      for (float val=minDisp; val<=maxDisp; val+=minorTickSpace) {
	 int	y = valY2 - (int)(NormalizeValue(val) * valHt);
	 XDrawLine(display, pixmap, gc, valX1, y, valX2, y);
      }
   }

   XSetLineAttributes(display, gc, 0, LineSolid, CapButt, JoinMiter);

//
// Draw value axis marks
//
   XSetForeground(display, gc, colors[MARK]);

   x = axisX2 + labelOffset;
   int	mcount = valueMarkList.size();
   for (int i=0; i<mcount; i++) {

      float	val = *valueMarkList[i];
      int	y = valY2 - (int)(NormalizeValue(val) * valHt);
      if ( y >= valY1 && y <= valY2 ) {
	 XDrawLine(display, pixmap, gc, axisX1, y, axisX2, y);

	 valueFormat = val;
	 StringC valStr = valueFormat;
	 XTextExtents(font, valStr, valStr.size(), &dir, &asc, &dsc, &size);

	 y += font->ascent - fontHt2;
	 XDrawString(display, pixmap, gc, x, y, valStr, valStr.size());
      }

   } // End for each value mark

//
// Position the scroll bar
//
   int	sliderSize = MAX(vcount,1);
   int	sliderInc  = sliderSize;
   int	sliderMax  = MAX(bcount, sliderSize);

   WArgList	args;
   args.LeftOffset(leftMargin);
   args.RightOffset(rightMargin);
   args.Maximum(sliderMax);
   args.Value(minIndex);
   args.SliderSize(sliderSize);
   args.PageIncrement(sliderInc);
   XtSetValues(scrollBar, ARGS);

} // End BarChartC DrawHorizontal

/*----------------------------------------------------------------------
 * Method to convert value into string
 */

StringC
BarChartC::ValueString(float val)
{
   valueFormat = val;
   return valueFormat;
}

/*----------------------------------------------------------------------
 * Methods to convert value and count into range 0.0 to 1.0
 */

float
BarChartC::NormalizeValue(float val)
{
   return ((val - minDisp) * countRangeInv);
}

/*----------------------------------------------------------------------
 * Methods to add marks
 */

void
BarChartC::AddValueMark(const ValueC val)
{
   float fval = val;
   valueMarkList.append(fval);
   if ( !deferred ) Draw();
}

/*----------------------------------------------------------------------
 * Methods to set the shadow thickness
 */

void
BarChartC::SetBarShadowThickness(Dimension thick)
{
   if ( thick != barShadowThickness ) {
      barShadowThickness = thick;
      if ( !deferred ) Draw();
   }
}

void
BarChartC::SetShadowThickness(Dimension thick)
{
   if ( thick != shadowThickness ) {
      shadowThickness = thick;
      if ( !deferred ) Draw();
   }
}

/*----------------------------------------------------------------------
 * Methods to set the shadow type
 */

void
BarChartC::SetBarShadowType(unsigned char type)
{
   if ( type != barShadowType ) {
      barShadowType = type;
      if ( !deferred ) Draw();
   }
}

void
BarChartC::SetShadowType(unsigned char type)
{
   if ( type != shadowType ) {
      shadowType = type;
      if ( !deferred ) Draw();
   }
}

/*----------------------------------------------------------------------
 * Method to set the bar values
 */
void
BarChartC::SetBarValues(const FloatListC& values, const StringListC& labels)
{

//
// Copy values
//
   unsigned	bcount = values.size();
   unsigned	lcount = labels.size();
   if ( bcount != lcount ) {
      valueList.removeAll();
      labelList.removeAll();
      for (int i=0; i<bcount; i++) {
	 valueList.append(*values[i]);
         if ( i < lcount )
	    labelList.append(*labels[i]);
         else
            labelList.append("");
      }
   } else {
      labelList = labels;
      valueList = values;
   }

//
// Update max value
//
   maxValue = 0.0;
   for (int i=0; i<bcount; i++) {
      float	val = *values[i];
      if ( val > maxValue ) maxValue = val;
   }

//
// Update min value
//
   minValue = maxValue;
   for (i=0; i<bcount; i++) {
      float	val = *(valueList[i]);
      if ( val < minValue ) minValue = val;
   }

//
// Set the Display min,max based on the status of autoRanging and Compress
//
   if (autoRanging) {
      if ( compress ) 
         minDisp = minValue;
      else
         minDisp = 0.0;
      maxDisp = maxValue;
   }
   else {
      minDisp = minRange;
      maxDisp = maxRange;
   }

   if ( maxDisp != minDisp ) countRangeInv = 1.0/(maxDisp - minDisp);
   else			       countRangeInv = 1.0;

//
// Update the visible range
//
   if ( visCount > 0 && visCount < bcount ) {
      minIndex = maxIndex - visCount + 1;
      if ( minIndex < 0 ) {
         minIndex = 0;
         maxIndex = minIndex + visCount - 1;
      }
   } else {
      minIndex = 0;
      maxIndex = bcount - 1;
      if ( maxIndex < 0 ) maxIndex = 0;
   }

   if ( !deferred ) Draw();

} // End BarChartC SetBarValues

/*----------------------------------------------------------------------
 * Method to set the count values
 */
void
BarChartC::SetBarValues(const IntListC& values, const StringListC& labels)
{

//
// Copy values
//
   unsigned	bcount = values.size();
   unsigned	lcount = labels.size();
   if ( bcount != lcount ) {
      valueList.removeAll();
      labelList.removeAll();
      for (int i=0; i<bcount; i++) {
         float fval = *values[i];
	 valueList.append(fval);
         if ( i < lcount )
	    labelList.append(*labels[i]);
         else
            labelList.append("");
      }
   } else {
      labelList = labels;
      valueList.removeAll();
      for (int i=0; i<bcount; i++) {
         float fval = *values[i];
	 valueList.append(fval);
      }
   }

//
// Update max value
//
   maxValue = 0.0;
   for (int i=0; i<bcount; i++) {
      float	count = (float)*values[i];
      if ( count > maxValue ) maxValue = count;
   }

//
// Update min value
//
   minValue = maxValue;
   for (i=0; i<bcount; i++) {
      float	count = *(valueList[i]);
      if ( count < minValue ) minValue = count;
   }

//
// Set the Display min,max based on the status of autoRanging and compress
//
   if ( autoRanging ) {
      if ( compress )
         minDisp = minValue;
      else
         minDisp = 0.0;
      maxDisp = maxValue;
   }
   else {
      minDisp = minRange;
      maxDisp = maxRange;
   }

   if ( maxDisp != minDisp ) countRangeInv = 1.0/(maxDisp - minDisp);
   else			       countRangeInv = 1.0;

//
// Update the visible range
//
   if ( visCount > 0 && visCount < bcount ) {
      minIndex = maxIndex - visCount + 1;
      if ( minIndex < 0 ) {
         minIndex = 0;
         maxIndex = minIndex + visCount - 1;
      }
   } else {
      minIndex = 0;
      maxIndex = bcount - 1;
      if ( maxIndex < 0 ) maxIndex = 0;
   }

   if ( !deferred ) Draw();

} // End BarChartC SetBarValues

/*----------------------------------------------------------------------
 * Methods to set the requested color
 */

void
BarChartC::SetColor(BarChartC::BarChartColorAttr attr, Pixel color)
{
   colors[attr] = color;
   switch (attr) {

      case (BACKGROUND):
	 XtVaSetValues(da, XmNbackground, color, NULL);

      default:
	 if ( !deferred ) Draw();
	 break;

   } // End switch color attribute
}

void
BarChartC::SetColor(BarChartC::BarChartColorAttr attr, const char *name)
{
   Pixel	color;
   if ( PixelValue(da, name, &color) ) SetColor(attr, color);
}

/*----------------------------------------------------------------------
 * Method to set whether the '0' count value is displayed
 */

void
BarChartC::SetValueCompress(Boolean comp)
{
   if ( comp != compress ) {
      compress = comp;
      if ( autoRanging ) {
         if ( compress )
	    minDisp = minValue;
         else
	    minDisp = 0.0;

         if ( maxDisp != minDisp ) countRangeInv = 1.0/(maxDisp - minDisp);
         else			  countRangeInv = 1.0;

         if ( !deferred ) Draw();
      }
   }

} // End BarChartC SetValueCompress

/*----------------------------------------------------------------------
 * Method to set marks on the count and value axes
 */

void
BarChartC::SetValueMarks(const FloatListC& list)
{
   valueMarkList = list;
   if ( !deferred ) Draw();
}

void
BarChartC::SetValueMarks(const IntListC& list)
{
   valueMarkList.removeAll();
   unsigned     count = list.size();
   for (int i=0; i<count; i++) {
      float fval = *list[i];
      valueMarkList.append(fval);
   }

   if ( !deferred ) Draw();
}

/*----------------------------------------------------------------------
 * Methods to set the major and minor tick spacings
 */

void
BarChartC::SetTickSpacing(const ValueC maj, const ValueC min)
{
   if ( (float)maj != majorTickSpace || (float)min != minorTickSpace ) {
      majorTickSpace = maj;
      minorTickSpace = min;
      if ( !deferred ) Draw();
   }
}

/*----------------------------------------------------------------------
 * Methods to set the major and minor grid visibilities
 */

void
BarChartC::SetGridVis(Boolean maj, Boolean min)
{
   if ( maj != majorGridVis || min != minorGridVis ) {
      majorGridVis = maj;
      minorGridVis = min;
      if ( !deferred ) Draw();
   }
}

/*----------------------------------------------------------------------
 * Method to set the spacing between labels and the histogram
 */

void
BarChartC::SetLabelOffset(int offset)
{
   if ( offset != labelOffset ) {
      labelOffset = offset;
      if ( !deferred ) Draw();
   }
}

/*----------------------------------------------------------------------
 * Method to set the margin width and height
 */

void
BarChartC::SetMargins(Dimension wd, Dimension ht)
{
   if ( wd != marginWd || ht != marginHt ) {
      marginWd = wd;
      marginHt = ht;
      if ( !deferred ) Draw();
   }

   return;
}

/*----------------------------------------------------------------------
 * Method to set the orientation
 */

void
BarChartC::SetOrientation(unsigned char orient)
{
   if ( (orient != XmVERTICAL && orient != XmHORIZONTAL) ||
	orient == orientation ) return;

   orientation = orient;

//
// Set up the scroll bar
//
   WArgList	args;
   if ( orientation == XmHORIZONTAL ) {

      args.Orientation(XmHORIZONTAL);
      args.LeftAttachment(XmATTACH_FORM);
      args.RightAttachment(XmATTACH_FORM);
      args.TopAttachment(XmATTACH_NONE);
      args.BottomAttachment(XmATTACH_FORM);
      args.Height(scrollBarSpan);
      XtSetValues(scrollBar, ARGS);

      args.Reset();
      if ( visCount < 1 ) args.BottomAttachment(XmATTACH_FORM);
      else		  args.BottomAttachment(XmATTACH_WIDGET, scrollBar);
      args.LeftAttachment(XmATTACH_FORM, 0);
      args.RightAttachment(XmATTACH_FORM, 0);
      args.TopAttachment(XmATTACH_FORM, 0);
      XtSetValues(da, ARGS);

   } else {

      args.Orientation(XmVERTICAL);
      args.LeftAttachment(XmATTACH_NONE);
      args.RightAttachment(XmATTACH_FORM);
      args.TopAttachment(XmATTACH_FORM);
      args.BottomAttachment(XmATTACH_FORM);
      args.Width(scrollBarSpan);
      XtSetValues(scrollBar, ARGS);

      args.Reset();
      if ( visCount < 1 ) args.RightAttachment(XmATTACH_FORM);
      else		  args.RightAttachment(XmATTACH_WIDGET, scrollBar);
      args.LeftAttachment(XmATTACH_FORM, 0);
      args.TopAttachment(XmATTACH_FORM, 0);
      args.BottomAttachment(XmATTACH_FORM, 0);
      XtSetValues(da, ARGS);

   } // End if vertical orientation

   if ( visCount < 1 ) XtUnmanageChild(scrollBar);

   if ( !deferred ) Draw();

} // End BarChartC SetOrientation

/*----------------------------------------------------------------------
 * Methods to set the numeric output formats
 */

void
BarChartC::SetValueFormat(ValueC::ValueFormat newFormat)
{
   if ( newFormat != valueFormat.Format() ) {
      valueFormat.SetFormat(newFormat);
      if ( !deferred ) Draw();
   }
}

/*----------------------------------------------------------------------
 * Method to set the major and minor tick lengths
 */

void
BarChartC::SetTickLength(int maj, int min)
{
   if ( maj != majorTickLen || min != minorTickLen ) {
      majorTickLen = maj;
      minorTickLen = min;
      if ( !deferred ) Draw();
   }
}

/*----------------------------------------------------------------------
 * Method to set the number of decimal points for the value axis
 */

void
BarChartC::SetValuePrecision(int precis)
{
   if ( precis != valueFormat.Precision() ) {
      valueFormat.SetPrecision(precis);
      if ( !deferred ) Draw();
   }
}

/*----------------------------------------------------------------------
 * Method to set the number of visible bars
 */
void
BarChartC::SetVisibleBarCount(unsigned count)
{
   if ( count != visCount ) {
      visCount = count;

      if ( visCount > 0 && visCount < valueList.size() ) {
	 minIndex = maxIndex - visCount + 1;
	 if ( minIndex < 0 ) {
	    minIndex = 0;
	    maxIndex = minIndex + visCount - 1;
	 }
      } else {
	 minIndex = 0;
	 maxIndex = valueList.size() - 1;
	 if ( maxIndex < 0 ) maxIndex = 0;
      }

//
// Turn off the scroll bar if all values are visible
//
      WArgList	args;
      if ( visCount < 1 ) {
	 args.Reset();
	 if ( orientation == XmVERTICAL )
	    args.RightAttachment  (XmATTACH_FORM);
	 else
	    args.BottomAttachment(XmATTACH_FORM);
	 XtSetValues(da, ARGS);
	 XtUnmanageChild(scrollBar);
      } else {
	 XtManageChild(scrollBar);
	 args.Reset();
	 if ( orientation == XmVERTICAL )
	    args.RightAttachment  (XmATTACH_WIDGET, scrollBar);
	 else
	    args.BottomAttachment(XmATTACH_WIDGET, scrollBar);
	 XtSetValues(da, ARGS);
      }

      if ( !deferred ) Draw();
   }

} // End BarChartC SetVisibleBarCount

/*----------------------------------------------------------------------
 * Method to Set the Threshold value for the Bar Chart
 */
void
BarChartC::SetThreshold(float value)
{
   if ( value != thresholdValue ) {
      thresholdValue = value;
      if ( !deferred )  Draw();
   }
}

/*----------------------------------------------------------------------
 * Method to Set the Threshold value for the Bar Chart
 */
void
BarChartC::SetRangeValues(float min, float max)
{
   if ( ( min != minRange || max != maxRange ) && ( max >= min ) ) {
      minRange = min;
      maxRange = max;

      if ( !autoRanging ) {
         minDisp = minRange;
         maxDisp = maxRange;

         if ( maxDisp != minDisp ) countRangeInv = 1.0/(maxDisp - minDisp);
         else		       countRangeInv = 1.0;
         if ( !deferred )  Draw();
      }
   }
}

/*----------------------------------------------------------------------
 * Method to Set Automatic Ranging
 */
void
BarChartC::SetAutoRanging(Boolean automatic)
{
//   if ( ( automatic && !autoRanging ) || ( !automatic && autoRanging ) ) {
   if ( automatic != autoRanging ) {
      autoRanging = automatic;
         
      if ( autoRanging ) {
         if ( compress )
            minDisp = minValue;
         else
            minDisp = 0.0;
         maxDisp = maxValue;
      }
      else {
         minDisp = minRange;
         maxDisp = maxRange;
      }

      if ( maxDisp != minDisp ) countRangeInv = 1.0/(maxDisp - minDisp);
      else		       countRangeInv = 1.0;

      if ( !deferred )  Draw();
   }
}

/*----------------------------------------------------------------------
 * Method to Set Automatic Ranging
 */
void
BarChartC::SetDrawScaleValues(Boolean drawSV)
{
   if ( drawSV != drawScaleValues ) {
      drawScaleValues = drawSV;
      if ( !deferred ) 
         Draw();
   }
}

/*----------------------------------------------------------------------
 * Method to return the requested pixel value
 */
Pixel
BarChartC::GetColor(BarChartC::BarChartColorAttr attr) const
{
   return colors[attr];
}

/*----------------------------------------------------------------------
 * Method to return the requested color name
 */

StringC
BarChartC::GetColorName(BarChartC::BarChartColorAttr attr) const
{
   return ColorName(da, colors[attr]);
}

/*-----------------------------------------------------------------------
 *  Methods to return the major and minor tick spacings
 */

void
BarChartC::GetTickSpacing(StringC *maj, StringC *min) const
{
   ValueC	tmp(valueFormat);
   tmp = majorTickSpace;
   *maj = (StringC)tmp;
   tmp = minorTickSpace;
   *min = (StringC)tmp;
}

void
BarChartC::GetTickSpacing(ValueC *maj, ValueC *min) const
{
   *maj = majorTickSpace;
   *min = minorTickSpace;
}

void
BarChartC::GetTickSpacing(int *maj, int *min) const
{
   *maj = (int)majorTickSpace;
   *min = (int)minorTickSpace;
}

/*-----------------------------------------------------------------------
 *  Methods to return the major and minor grid visibilities
 */

void
BarChartC::GetGridVis(Boolean *maj, Boolean *min) const
{
   *maj = majorGridVis;
   *min = minorGridVis;
}

/*----------------------------------------------------------------------
 * Method to return the margin width and height
 */

void
BarChartC::GetMargins(Dimension *wd, Dimension *ht) const
{
   *wd = marginWd;
   *ht = marginHt;
   return;
}

/*-----------------------------------------------------------------------
 *  Method to return the major and minor tick lengths
 */

void
BarChartC::GetTickLength(int *maj, int *min) const
{
   *maj = majorTickLen;
   *min = minorTickLen;
}
