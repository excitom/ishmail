/*
 * $Id: ColorPickerC.C,v 1.1 1998/06/24 01:29:07 lang Exp $
 *
 * Copyright (c) 1993 HAL Computer Systems International, Ltd.
 * 
 *          HAL COMPUTER SYSTEMS INTERNATIONAL, LTD.
 *                  1315 Dell Avenue
 *                  Campbell, CA  95008
 *
 * Author: Greg Hilton
 * Contributors: Tom Lang, Frank Bieser, and others
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * http://www.gnu.org/copyleft/gpl.html
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#include <X11/Intrinsic.h>
#include <X11/cursorfont.h>
#include <Xm/Scale.h>
#include <Xm/Form.h>
#include <Xm/TextF.h>
#include <Xm/Label.h>
#include <Xm/List.h>
#include <Xm/Frame.h>
#include <Xm/PushB.h>
#include <Xm/ScrolledW.h>

#include "Base.h"
#include "rsrc.h"
#include "WArgList.h"
#include "ColorPickerC.h"
#include "StrCase.h"


#define CHARSET XmSTRING_DEFAULT_CHARSET

#define ABS(a) ((a)<0 ? -(a) : (a))

#define RGB_THRESHOLD	50
#define RED_FACTOR	2
#define GRN_FACTOR	2
#define BLU_FACTOR	1


// ********************************************************************
// The constructor for this lovely class.
// ********************************************************************
ColorPickerC::ColorPickerC(Widget p, char* name, ArgList argv, Cardinal argc)
{
   WArgList     args;


   numColors  = 0;
   redValue   = 0;
   bluValue   = 0;
   grnValue   = 0;
   satValue   = 0;
   satRange   = 0;
   updating   = False;
   currEntry  = NULL;
   nearEntry  = NULL;
   pickCursor = (Cursor)NULL;
   colorMap   = DefaultColormapOfScreen(XtScreen(p));
   display    = XtDisplay(p);

//
// Initialize the first colors we will be allocating.
//
   currColor.red   = 0;
   currColor.green = 0;
   currColor.blue  = 0;
   currColor.flags = DoRed|DoGreen|DoBlue;
   XAllocColor(display, colorMap, &currColor);

   nearColor.red   = 0;
   nearColor.green = 0;
   nearColor.blue  = 0;
   nearColor.flags = DoRed|DoGreen|DoBlue;
   XAllocColor(display, colorMap, &nearColor);

//
// Make the display.
//
   mainForm = XmCreateForm(p, name, argv,argc);

//
// Create the major sections of the thing.
//
   args.Reset();
   args.FractionBase(5);
   args.LeftAttachment(XmATTACH_FORM);
   args.RightAttachment(XmATTACH_FORM);
   args.TopAttachment(XmATTACH_FORM);
   args.BottomAttachment(XmATTACH_FORM);
   baseForm = XmCreateForm(mainForm, "baseForm", ARGS);

   args.Reset();
   args.LeftAttachment(XmATTACH_FORM);
   args.RightAttachment(XmATTACH_FORM);
   args.TopAttachment(XmATTACH_POSITION, 4);
   args.BottomAttachment(XmATTACH_FORM);
   Widget colorForm = XmCreateForm(baseForm, "colorForm", ARGS);

   args.Reset();
   args.LeftAttachment(XmATTACH_FORM);
   args.RightAttachment(XmATTACH_NONE);
   args.TopAttachment(XmATTACH_FORM);
   args.BottomAttachment(XmATTACH_NONE);
   closeLabel = XmCreateLabel(colorForm, "closeLabel", ARGS);
   XtManageChild(closeLabel);

   args.Reset();
   args.LeftAttachment(XmATTACH_FORM);
   args.RightAttachment(XmATTACH_OPPOSITE_WIDGET, closeLabel);
   args.TopAttachment(XmATTACH_WIDGET, closeLabel);
   args.BottomAttachment(XmATTACH_FORM);
   args.Background(currColor.pixel);
   args.ShadowType(XmSHADOW_IN);
   closeWin = XmCreateFrame(colorForm, "closeWin", ARGS);
   XtManageChild(closeWin);

   args.Reset();
   args.LeftAttachment(XmATTACH_WIDGET, closeWin);
   args.RightAttachment(XmATTACH_NONE);
   args.TopAttachment(XmATTACH_FORM);
   args.BottomAttachment(XmATTACH_NONE);
   Widget colorLabel = XmCreateLabel(colorForm, "colorLabel", ARGS);
   XtManageChild(colorLabel);

   args.Reset();
   args.LeftAttachment(XmATTACH_WIDGET, closeWin);
   args.RightAttachment(XmATTACH_FORM);
   args.TopAttachment(XmATTACH_WIDGET, colorLabel);
   args.BottomAttachment(XmATTACH_FORM);
   args.Background(currColor.pixel);
   args.ShadowType(XmSHADOW_IN);
   colorWin = XmCreateFrame(colorForm, "colorWin", ARGS);
   XtManageChild(colorWin);
   XtManageChild(colorForm);

   args.Reset();
   args.LeftAttachment(XmATTACH_NONE);
   args.RightAttachment(XmATTACH_FORM);
   args.TopAttachment(XmATTACH_FORM);
   args.BottomAttachment(XmATTACH_POSITION, 4);
   Widget valueForm = XmCreateForm(baseForm, "valueForm", ARGS);

   args.Reset();
   args.LeftAttachment(XmATTACH_FORM);
   args.RightAttachment(XmATTACH_WIDGET, valueForm);
   args.TopAttachment(XmATTACH_FORM);
   args.BottomAttachment(XmATTACH_POSITION, 4);
   Widget listForm = XmCreateForm(baseForm, "listForm", ARGS);

//
// Fill in the scale form.
//
   args.Reset();
   args.LeftAttachment(XmATTACH_FORM);
   args.RightAttachment(XmATTACH_FORM);
   args.TopAttachment(XmATTACH_NONE);
   args.BottomAttachment(XmATTACH_FORM);
   valueTF = XmCreateTextField(valueForm, "valueTF", ARGS);
   XtManageChild(valueTF);
   XtAddCallback( valueTF, XmNactivateCallback,
		 (XtCallbackProc)DoHexValueChange, (XtPointer)this);

   args.Reset();
   args.LeftAttachment(XmATTACH_FORM);
   args.RightAttachment(XmATTACH_NONE);
   args.TopAttachment(XmATTACH_NONE);
   args.BottomAttachment(XmATTACH_WIDGET, valueTF);
   Widget valueLabel = XmCreateLabel(valueForm, "valueLabel", ARGS);
   XtManageChild(valueLabel);

//
// Create the forms for the color scales.
//
   args.Reset();
   args.LeftAttachment(XmATTACH_NONE);
   args.RightAttachment(XmATTACH_FORM);
   args.TopAttachment(XmATTACH_FORM);
   args.BottomAttachment(XmATTACH_WIDGET, valueLabel);
   Widget satForm = XmCreateForm(valueForm, "satForm", ARGS);

   args.Reset();
   args.LeftAttachment(XmATTACH_NONE);
   args.RightAttachment(XmATTACH_WIDGET, satForm);
   args.TopAttachment(XmATTACH_FORM);
   args.BottomAttachment(XmATTACH_WIDGET, valueLabel);
   Widget bluForm = XmCreateForm(valueForm, "bluForm", ARGS);

   args.Reset();
   args.LeftAttachment(XmATTACH_NONE);
   args.RightAttachment(XmATTACH_WIDGET, bluForm);
   args.TopAttachment(XmATTACH_FORM);
   args.BottomAttachment(XmATTACH_WIDGET, valueLabel);
   Widget grnForm = XmCreateForm(valueForm, "grnForm", ARGS);

   args.Reset();
   args.LeftAttachment(XmATTACH_NONE);
   args.RightAttachment(XmATTACH_WIDGET, grnForm);
   args.TopAttachment(XmATTACH_FORM);
   args.BottomAttachment(XmATTACH_WIDGET, valueLabel);
   Widget redForm = XmCreateForm(valueForm, "redForm", ARGS);

//
// Fill in the saturation form.
//
   args.Reset();
   args.LeftAttachment(XmATTACH_FORM);
   args.RightAttachment(XmATTACH_FORM);
   args.TopAttachment(XmATTACH_FORM);
   args.BottomAttachment(XmATTACH_NONE);
   satLabel = XmCreateLabel(satForm, "satLabel", ARGS);
   XtManageChild(satLabel);

   args.Reset();
   args.LeftAttachment(XmATTACH_NONE);
   args.RightAttachment(XmATTACH_FORM);
   args.TopAttachment(XmATTACH_NONE);
   args.BottomAttachment(XmATTACH_FORM);
   args.Columns((short)3);
   satTF = XmCreateTextField(satForm, "satTF", ARGS);
   XtManageChild(satTF);

   XtAddCallback(satTF, XmNactivateCallback,
		 (XtCallbackProc)DoChangeSaturation, (XtPointer)this);

   args.Reset();
   args.LeftAttachment(XmATTACH_FORM);
   args.RightAttachment(XmATTACH_FORM);
   args.TopAttachment(XmATTACH_WIDGET, satLabel);
   args.BottomAttachment(XmATTACH_WIDGET, satTF);
   args.Orientation(XmVERTICAL);
   args.Minimum(0);
   args.Maximum(100);
   args.ProcessingDirection(XmMAX_ON_TOP);
   // args.ScaleWidth((Dimension)40);
   satScale = XmCreateScale(satForm, "satScale", ARGS);
   XtManageChild(satScale);

//
// Fill in the red form.
//
   args.Reset();
   args.LeftAttachment(XmATTACH_FORM);
   args.TopAttachment(XmATTACH_FORM);
   args.RightAttachment(XmATTACH_FORM);
   args.BottomAttachment(XmATTACH_NONE);
   redLabel = XmCreateLabel(redForm, "redLabel", ARGS);
   XtManageChild(redLabel);

   args.Reset();
   args.LeftAttachment(XmATTACH_FORM);
   args.RightAttachment(XmATTACH_FORM);
   args.TopAttachment(XmATTACH_NONE);
   args.BottomAttachment(XmATTACH_FORM);
   args.Columns((short)3);
   redTF = XmCreateTextField(redForm, "redTF", ARGS);
   XtManageChild(redTF);

   args.Reset();
   args.LeftAttachment(XmATTACH_FORM);
   args.RightAttachment(XmATTACH_FORM);
   args.TopAttachment(XmATTACH_WIDGET, redLabel);
   args.BottomAttachment(XmATTACH_WIDGET, redTF);
   args.Orientation(XmVERTICAL);
   args.Minimum(0);
   args.Maximum(255);
   args.ProcessingDirection(XmMAX_ON_TOP);
   redScale = XmCreateScale(redForm, "redScale", ARGS);
   XtManageChild(redScale);

//
// Fill in the green form.
//
   args.Reset();
   args.LeftAttachment(XmATTACH_FORM);
   args.RightAttachment(XmATTACH_FORM);
   args.TopAttachment(XmATTACH_FORM);
   args.BottomAttachment(XmATTACH_NONE);
   grnLabel = XmCreateLabel(grnForm, "grnLabel", ARGS);
   XtManageChild(grnLabel);

   args.Reset();
   args.LeftAttachment(XmATTACH_FORM);
   args.RightAttachment(XmATTACH_FORM);
   args.TopAttachment(XmATTACH_NONE);
   args.BottomAttachment(XmATTACH_FORM);
   args.Columns((short)3);
   grnTF = XmCreateTextField(grnForm, "grnTF", ARGS);
   XtManageChild(grnTF);

   args.Reset();
   args.LeftAttachment(XmATTACH_FORM);
   args.RightAttachment(XmATTACH_FORM);
   args.TopAttachment(XmATTACH_WIDGET, grnLabel);
   args.BottomAttachment(XmATTACH_WIDGET, grnTF);
   args.Orientation(XmVERTICAL);
   args.Minimum(0);
   args.Maximum(255);
   args.ProcessingDirection(XmMAX_ON_TOP);
   grnScale = XmCreateScale(grnForm, "grnScale", ARGS);
   XtManageChild(grnScale);

//
// Fill in the blue form.
//
   args.Reset();
   args.LeftAttachment(XmATTACH_FORM);
   args.RightAttachment(XmATTACH_FORM);
   args.TopAttachment(XmATTACH_FORM);
   args.BottomAttachment(XmATTACH_NONE);
   bluLabel = XmCreateLabel(bluForm, "bluLabel", ARGS);
   XtManageChild(bluLabel);

   args.Reset();
   args.LeftAttachment(XmATTACH_FORM);
   args.RightAttachment(XmATTACH_FORM);
   args.TopAttachment(XmATTACH_NONE);
   args.BottomAttachment(XmATTACH_FORM);
   args.Columns((short)3);
   bluTF = XmCreateTextField(bluForm, "bluTF", ARGS);
   XtManageChild(bluTF);

   args.Reset();
   args.LeftAttachment(XmATTACH_FORM);
   args.RightAttachment(XmATTACH_FORM);
   args.TopAttachment(XmATTACH_WIDGET, bluLabel);
   args.BottomAttachment(XmATTACH_WIDGET, bluTF);
   args.Orientation(XmVERTICAL);
   args.Minimum(0);
   args.Maximum(255);
   args.ProcessingDirection(XmMAX_ON_TOP);
   bluScale = XmCreateScale(bluForm, "bluScale", ARGS);
   XtManageChild(bluScale);

//
// Assign the callbacks.
//
   XtAddCallback(redTF, XmNactivateCallback,
		 (XtCallbackProc)DoRgbNameChange, (XtPointer)this);
   XtAddCallback(grnTF, XmNactivateCallback,
		 (XtCallbackProc)DoRgbNameChange, (XtPointer)this);
   XtAddCallback(bluTF, XmNactivateCallback,
		 (XtCallbackProc)DoRgbNameChange, (XtPointer)this);

   XtAddCallback(redScale, XmNdragCallback,
		 (XtCallbackProc)DoDragScale, (XtPointer)this);
   XtAddCallback(redScale, XmNvalueChangedCallback,
		 (XtCallbackProc)DoDragScale, (XtPointer)this);
   XtAddCallback(grnScale, XmNdragCallback,
		 (XtCallbackProc)DoDragScale, (XtPointer)this);
   XtAddCallback(grnScale, XmNvalueChangedCallback,
		 (XtCallbackProc)DoDragScale, (XtPointer)this);
   XtAddCallback(bluScale, XmNvalueChangedCallback,
		 (XtCallbackProc)DoDragScale, (XtPointer)this);
   XtAddCallback(bluScale, XmNdragCallback,
		 (XtCallbackProc)DoDragScale, (XtPointer)this);

   XtAddCallback(satScale, XmNdragCallback,
		 (XtCallbackProc)DoDragSaturation, (XtPointer)this);
   XtAddCallback(satScale, XmNvalueChangedCallback,
		 (XtCallbackProc)DoDragSaturation, (XtPointer)this);

   XtManageChild(satForm);
   XtManageChild(grnForm);
   XtManageChild(bluForm);
   XtManageChild(redForm);
   XtManageChild(valueForm);

//
// Fill in the list form.
//
   args.Reset();
   args.LeftAttachment(XmATTACH_FORM);
   args.RightAttachment(XmATTACH_NONE);
   args.TopAttachment(XmATTACH_FORM);
   args.BottomAttachment(XmATTACH_NONE);
   Widget listLabel = XmCreateLabel(listForm, "listLabel", ARGS);
   XtManageChild(listLabel);

   args.Reset();
   args.LeftAttachment(XmATTACH_FORM);
   args.RightAttachment(XmATTACH_FORM);
   args.TopAttachment(XmATTACH_NONE);
   args.BottomAttachment(XmATTACH_FORM);
   args.MarginWidth(0);
   args.MarginHeight(0);
   Widget nameForm = XmCreateForm(listForm, "nameForm", ARGS);

   args.Reset();
   args.LeftAttachment(XmATTACH_NONE);
   args.RightAttachment(XmATTACH_FORM);
   args.TopAttachment(XmATTACH_NONE);
   args.BottomAttachment(XmATTACH_FORM);
   Widget pickPB = XmCreatePushButton(nameForm, "pickPB", ARGS);
   XtManageChild(pickPB);
   XtAddCallback( pickPB, XmNactivateCallback,
		 (XtCallbackProc)DoPickColorOnScreen, (XtPointer)this);

   args.Reset();
   args.LeftAttachment(XmATTACH_FORM);
   args.RightAttachment(XmATTACH_NONE);
   args.TopAttachment(XmATTACH_FORM);
   args.BottomAttachment(XmATTACH_NONE);
   nameLabel = XmCreateLabel(nameForm, "nameLabel", ARGS);
   XtManageChild(nameLabel);

   args.Reset();
   args.LeftAttachment(XmATTACH_FORM);
   args.RightAttachment(XmATTACH_WIDGET, pickPB);
   args.TopAttachment(XmATTACH_WIDGET, nameLabel);
   args.BottomAttachment(XmATTACH_FORM);
   nameTF = XmCreateTextField(nameForm, "nameTF", ARGS);
   XtManageChild(nameTF);
   XtAddCallback( nameTF, XmNactivateCallback,
		 (XtCallbackProc)DoNameChange, (XtPointer)this);

   XtManageChild(nameForm);

   Dimension name_ht, pick_ht;
   XtVaGetValues(nameTF, XmNheight, &name_ht, NULL);
   XtVaGetValues(pickPB, XmNheight, &pick_ht, NULL);
   if ( pick_ht < name_ht ) {
      XtVaSetValues(pickPB, XmNheight, name_ht, NULL);
   }

   args.Reset();
   args.LeftAttachment(XmATTACH_FORM);
   args.RightAttachment(XmATTACH_FORM);
   args.TopAttachment(XmATTACH_WIDGET, listLabel);
   args.BottomAttachment(XmATTACH_WIDGET, nameForm);
   args.SelectionPolicy(XmBROWSE_SELECT);
   nameList = XmCreateScrolledList(listForm, "nameList", ARGS);
   XtManageChild(nameList);

   XtAddCallback(nameList, XmNbrowseSelectionCallback,
		 (XtCallbackProc)DoSelectName, (XtPointer)this);

//
// Read the names of the colors.
//
   ReadColorNames();

//
// Manage the main widgets...
//
   XtManageChild(valueForm);
   XtManageChild(listForm);
   XtManageChild(baseForm);
   XtManageChild(mainForm);

   SetColorName("black");
}


// ********************************************************************
// This is the destructor for this class.
// ********************************************************************
ColorPickerC::~ColorPickerC()
{
   XFreeColors(display, colorMap, &currColor.pixel, 1, 0);
   XFreeColors(display, colorMap, &nearColor.pixel, 1, 0);
   if ( numColors > 0 ) {
      delete redList;
      delete colorEntries;
   }
}


// ********************************************************************
// This is called when a color name is selected.
// ********************************************************************
void
ColorPickerC::DoSelectName(Widget, ColorPickerC* This, XtPointer)
{
   int *pos, pos_count;
   XmListGetSelectedPos(This->nameList, &pos, &pos_count);
   if ( pos_count < 1 ) return;
   int id = pos[0] - 1;

   This->currEntry = This->nearEntry = &This->colorEntries[id];

   This->redValue = This->currEntry->r;
   This->grnValue = This->currEntry->g;
   This->bluValue = This->currEntry->b;

   This->UpdateColor();
   This->UpdateClosestColor();
   This->UpdateRGBFields();
   This->UpdateRGBScales();
   This->UpdateNameField();
   This->UpdateHexField();
   This->UpdateSaturation();
}


// ********************************************************************
// This is called when a color name is selected.
// ********************************************************************
void
ColorPickerC::DoNameChange(Widget, ColorPickerC* This, XtPointer)
{
   char* str = XmTextFieldGetString(This->nameTF);
   if ( !This->SetColorName(str) ) {
      if ( XtIsSensitive(This->nameLabel) )
         XtSetSensitive(This->nameLabel, False);
   }
   XtFree(str);
}


// ********************************************************************
// This is called when the user wants to select a color off the screen.
// ********************************************************************
void
ColorPickerC::DoPickColorOnScreen(Widget, ColorPickerC* This, XtPointer)
{
   This->PickColorOnScreen();
}


// ********************************************************************
//
// ********************************************************************
void
ColorPickerC::DoDragScale(Widget w, ColorPickerC* This, XtPointer ptr)
{

   XmScaleCallbackStruct *cbs = (XmScaleCallbackStruct*)ptr;

//
// Set the values of the value textfields.
//
   char str[32];
   sprintf(str,"%d", cbs->value);

   if ( w == This->redScale ) {
      This->redValue  = cbs->value;
      XmTextFieldSetString(This->redTF,str);
   }
   else if ( w == This->grnScale ) {
      This->grnValue  = cbs->value;
      XmTextFieldSetString(This->grnTF,str);
   }
   else if ( w == This->bluScale ) {
      This->bluValue  = cbs->value;
      XmTextFieldSetString(This->bluTF,str);
   }

//
// Update the hex value string.
//
   sprintf(str,"#%04x%04x%04x", This->redValue, This->grnValue, This->bluValue);
   XmTextFieldSetString(This->valueTF, str);

   This->UpdateColor();

//
// If this is the last of the drag then find the near color...
//
   //SKB if ( cbs->reason == XmCR_VALUE_CHANGED ) {
      This->FindClosestName();
      This->UpdateSaturation();
   //SKB }
}


// ********************************************************************
// This routine changes the color which appears in the color window.
// ********************************************************************
void
ColorPickerC::UpdateColor()
{
   currColor.red   = (redValue << 8);
   currColor.green = (grnValue << 8);
   currColor.blue  = (bluValue << 8);

   XFreeColors(display, colorMap, &currColor.pixel, 1, 0);
   if ( XAllocColor(display, colorMap, &currColor) )
      XtVaSetValues(colorWin, XmNbackground, currColor.pixel, NULL);
}


// ********************************************************************
// This routine changes the color which appears in the color window.
// ********************************************************************
void
ColorPickerC::UpdateClosestColor()
{
   if ( nearEntry ) {
      nearColor.red   = (nearEntry->r << 8);
      nearColor.green = (nearEntry->g << 8);
      nearColor.blue  = (nearEntry->b << 8);

      XFreeColors(display, colorMap, &nearColor.pixel, 1, 0);
      if ( XAllocColor(display, colorMap, &nearColor) )
         XtVaSetValues(closeWin, XmNbackground, nearColor.pixel, NULL);
   }
   else {
      Pixel bg;
      XtVaGetValues(XtParent(closeWin), XmNbackground, &bg, NULL);
      XtVaSetValues(closeWin, XmNbackground, bg, NULL);
   }
}


// ********************************************************************
//
// ********************************************************************
void
ColorPickerC::DoDragSaturation(Widget w, ColorPickerC* This, XtPointer ptr)
{
   if ( This->updating || This->satRange == 0 ) return;

   XmScaleGetValue(w,&This->satValue);

   char str[16];
   sprintf(str, "%d", This->satValue);
   XmTextFieldSetString(This->satTF, str);

   int dc = (int)((float)This->satRange * ((float)This->satValue*.01));
   This->redValue = This->redSat + dc;
   This->grnValue = This->grnSat + dc;
   This->bluValue = This->bluSat + dc;

   This->UpdateColor();
   This->UpdateRGBFields();
   This->UpdateRGBScales();
   This->UpdateHexField();

//
// See if this is the last saturation event.
//
   //SKB if ( ((XmScaleCallbackStruct*)ptr)->reason == XmCR_VALUE_CHANGED ) {
      This->FindClosestName();
   //SKB }
}


// ********************************************************************
// This is called when the user changes the value in the saturation
// text field.
// ********************************************************************
void
ColorPickerC::DoChangeSaturation(Widget w, ColorPickerC* This, XtPointer)
{
   if ( This->updating ) return;

   char* str = XmTextFieldGetString(w);
   if ( !str[0] ) {
      XtFree(str);
      return;
   }

//
// Get the value and check it.
//
   int val = atoi(str);
   XtFree(str);
   if ( val < 0 || val > 255 ) return;
   This->satValue = val;

   int dc = (int)((float)This->satRange * ((float)This->satValue*.01));
   This->redValue = This->redSat + dc;
   This->grnValue = This->grnSat + dc;
   This->bluValue = This->bluSat + dc;

   This->UpdateColor();
   This->UpdateRGBFields();
   This->UpdateRGBScales();
   This->UpdateHexField();
   This->FindClosestName();

   This->updating = True;
   XmScaleSetValue(This->satScale, val);
   This->updating = False;
}


// ********************************************************************
// This is called when the value of the string that holds the rbg
// value in one word changes...
// ********************************************************************
void
ColorPickerC::DoHexValueChange(Widget w, ColorPickerC* This, XtPointer)
{
   char* str  = XmTextFieldGetString(w);
   int   len  = strlen(str);
   if ( len < 3 ) return;
   int   part = (len-1)/3;
   int   r, g, b;

//
// Get the red portion.
//
   char *tmp = str + len - part;
   sscanf(tmp,"%x",&b);
   if ( b < 0 || b > 255 ) return;

   *tmp = 0;
   tmp -= part;
   sscanf(tmp,"%x",&g);
   if ( g < 0 || g > 255 ) return;

   *tmp = 0;
   tmp -= part;
   sscanf(tmp,"%x",&r);
   if ( r < 0 || r > 255 ) return;

//
// Since we made it to here the values are ok...
//
   This->redValue = r;
   This->grnValue = g;
   This->bluValue = b;
   This->UpdateAll();
   This->FindClosestName();

   XtFree(str);
}


// ********************************************************************
// This is called when the value of the red, green, or blue text field
// is changed.
// ********************************************************************
void
ColorPickerC::DoRgbNameChange(Widget, ColorPickerC* This, XtPointer)
{
   int r,g,b;
   char *str;

//
// Get all the textfield values for rgb.
//
   str = XmTextFieldGetString(This->redTF);
   r = atoi(str); XtFree(str);
   if ( r < 0 && r > 255 ) return;

   str = XmTextFieldGetString(This->grnTF);
   g = atoi(str); XtFree(str);
   if ( g < 0 && g > 255 ) return;

   str = XmTextFieldGetString(This->bluTF);
   b = atoi(str); XtFree(str);
   if ( b < 0 && b > 255 ) return;

   This->redValue = r;
   This->grnValue = g;
   This->bluValue = b;

   This->UpdateAll();
   This->FindClosestName();
}


// ********************************************************************
// This updates the display so that everything is in sink...
// ********************************************************************
void
ColorPickerC::UpdateAll()
{
   if ( updating ) return;
   UpdateColor();
   UpdateClosestColor();
   UpdateRGBFields();
   UpdateRGBScales();
   UpdateNameField();
   UpdateHexField();
   UpdateSaturation();
   UpdateList();
}


// ********************************************************************
//
// ********************************************************************
void
ColorPickerC::UpdateRGBScales()
{
   if ( updating ) return;
   updating = True;

//
// Set the values of the scales.
//
   XmScaleSetValue(redScale,redValue);
   XmScaleSetValue(grnScale,grnValue);
   XmScaleSetValue(bluScale,bluValue);

   updating = False;
}


// ********************************************************************
//
// ********************************************************************
void
ColorPickerC::UpdateSaturation()
{
   if ( updating ) return;
   updating = True;

   int min = MIN(MIN(redValue, bluValue), grnValue);
   int max = MAX(MAX(redValue, bluValue), grnValue);

   int dy   = 255 - max;
   satRange = dy + min;

   redSat = redValue - min;
   grnSat = grnValue - min;
   bluSat = bluValue - min;

   int max_floor = max - min;

   if ( satRange > 0 && max > 0)
      satValue = ((max-max_floor)*100)/satRange;
   else {
      satValue = (max*100)/255;
   }

   XmScaleSetValue(satScale,satValue);
   char str[16];
   sprintf(str,"%d", satValue);
   XmTextFieldSetString(satTF,str);

   updating = False;
}


// ********************************************************************
// This will take the current color values and set the rgb scales
// with those values.
// ********************************************************************
void
ColorPickerC::UpdateRGBFields()
{
   if ( updating ) return;

   updating = True;
   char str[128];
//
// Set the values of the value textfields.
//
   sprintf(str,"%d", redValue);
   XmTextFieldSetString(redTF,str);
   sprintf(str,"%d", grnValue);
   XmTextFieldSetString(grnTF,str);
   sprintf(str,"%d", bluValue);
   XmTextFieldSetString(bluTF,str);

   updating = False;
}


// ********************************************************************
// ********************************************************************
void
ColorPickerC::UpdateHexField()
{
//
// Set the text for the hext value field.
//
   char str[32];
   sprintf(str,"#%04x%04x%04x", redValue, grnValue, bluValue);
   XmTextFieldSetString(valueTF, str);
}


// ********************************************************************
// ********************************************************************
void
ColorPickerC::UpdateNameField()
{
   if ( nearEntry ) {
      XmTextFieldSetString(nameTF, nearEntry->colorName);
      if ( nearEntry == currEntry ) { 
         if ( !XtIsSensitive(nameLabel) )
            XtSetSensitive(nameLabel, True);
      }
      else {
         if ( XtIsSensitive(nameLabel) )
            XtSetSensitive(nameLabel, False);
      }
   }
   else {
      XmTextFieldSetString(nameTF, "");
      if ( XtIsSensitive(nameLabel) )
         XtSetSensitive(nameLabel, False);
   }
}


// ********************************************************************
// This is used to set the pixel value of the display.
// ********************************************************************
Boolean
ColorPickerC::SetPixelValue(Pixel pixel)
{
//
// Look up rgb values
//
   XColor       xcolor;
   XrmValue	fromVal;
   XrmValue	toVal;
   fromVal.addr = (XPointer)&pixel;
   fromVal.size = sizeof(Pixel);
   toVal.addr	= (XPointer)&xcolor;
   toVal.size	= sizeof(XColor);

   if ( !XtConvertAndStore(mainForm, XtRPixel, &fromVal, XtRColor, &toVal) )
      return False;

   // currColor.red   = (redValue << 8);
   // currColor.green = (grnValue << 8);
   // currColor.blue  = (bluValue << 8);

   redValue = (int)(xcolor.red   >> 8);
   grnValue = (int)(xcolor.green >> 8);
   bluValue = (int)(xcolor.blue  >> 8);
   SetRGBValues(redValue, grnValue, bluValue);

   return True;
}


// ********************************************************************
// This is used to set the pixel value of the display.
// ********************************************************************
void
ColorPickerC::SetRGBValues(int r, int g, int b)
{
   if ( r < 0   ) r = 0;
   if ( g < 0   ) g = 0;
   if ( b < 0   ) b = 0;
   if ( r > 255 ) r = 255;
   if ( g > 255 ) g = 255;
   if ( b > 255 ) b = 255;
   redValue = r;
   grnValue = g;
   bluValue = b;

//
// Update all the displays.
//
   FindClosestName();
   UpdateAll();
}


// ********************************************************************
// Searches for the input color name and sets the global color values
// if it matches anything. This does a lamo string search.
// ********************************************************************
Boolean
ColorPickerC::SetColorName(char* cname)
{
//
// See if we can find the name in the color table.
//
   colorEntryT* ent = FindEntry(cname);
   if ( ent ) {
      nearEntry = currEntry = ent;
      redValue  = nearEntry->r;
      grnValue  = nearEntry->g;
      bluValue  = nearEntry->b;
      UpdateAll();
      return True;
   }
   return False;
}


// ********************************************************************
// 
// ********************************************************************
void
ColorPickerC::UpdateList()
{
   if ( nearEntry ) {
      XmListSelectPos(nameList, nearEntry->itemIndex, False);
//
//    Make sure the item is visible.
//
      int top, visible;
      XtVaGetValues(nameList, XmNtopItemPosition, &top,
			      XmNvisibleItemCount, &visible, NULL);
      if ( nearEntry->itemIndex < top )
         XmListSetPos(nameList, nearEntry->itemIndex);
      else if ( nearEntry->itemIndex >= top+visible)
         XmListSetBottomPos(nameList, nearEntry->itemIndex);
   }
   else {
      XmListDeselectAllItems(nameList);
   }
}


// ********************************************************************
// Searches for the input color name in the color list.
// ********************************************************************
colorEntryT*
ColorPickerC::FindEntry(char* cname)
{
//
// See if we can find the name in the color table.
//
   register int i;
   register colorEntryT* entry;
   for ( i=0; i<numColors; i++ ) {
      entry = &colorEntries[i];
      if ( entry->colorName == cname ) {
	 return entry;
      }
   }

//
// Since we didn't find it...try a case insensitive search.
//
   for ( i=0; i<numColors; i++ ) {
      entry = &colorEntries[i];
      if ( !strcasecmp((char*)entry->colorName,(char*)cname) ) {
	 return entry;
      }
   }

   return NULL;
}


// ********************************************************************
// Reads the color names from the the color name file.
// ********************************************************************
void
ColorPickerC::ReadColorNames()
{

#ifdef SOLARIS
   rgbFile = get_string(*this, "rgbFilePath", "/usr/openwin/lib/X11/rgb.txt");
#else
   rgbFile = get_string(*this, "rgbFilePath", "/usr/lib/X11/rgb.txt");
#endif   

//
// Open the rgb.text database file.
//
   FILE	*fp = fopen((char*)rgbFile, "r");
   if ( !fp ) return;

//
// See how names are in the file.
//
   int num_lines = 0;
   char  buffer[512];
   while ( fgets(buffer, 512, fp) ) {
      num_lines++;
   }
   if ( !num_lines ) return;
   rewind(fp);

//
// Allocate the color entries for all the values.
//
   colorEntries = new colorEntryT[num_lines];
   if ( !colorEntries ) return;

   numColors = 0;
   int r,g,b;
   char name[128];
   while ( fscanf(fp,"%d %d %d %[^\n]s\n", &r, &g, &b, name) != EOF ) {

      int len = strlen(name) -1;
      if ( name[len] == '\n' ) name[len] = 0;

//
//    See if this entry is in the front part of the list.
//
      colorEntryT* entry = &colorEntries[numColors];
      entry->colorName = name;
      entry->r         = r;
      entry->g         = g;
      entry->b         = b;
      entry->nxtGrn    = NULL;
      entry->nxtBlu    = NULL;
      entry->itemIndex = ++numColors;

//
//    Add this entry to the color name list widget.
//
      char str[256];
      sprintf(str,"(%03d,%03d,%03d)   %s", r,g,b,(char*)entry->colorName);
      XmString xmstr = XmStringCreateLtoR(str,CHARSET);
      XmListAddItem(nameList,xmstr,0);
      XmStringFree(xmstr);
   }
   fclose(fp);

   SortColorTables();
}


// ********************************************************************
// This creates a wierd sort-hash kinda thing where there is a list
// of red values with sublists sorted by green & blue values under them.
// ********************************************************************
void
ColorPickerC::SortColorTables()
{
//
// Create a list of head link ptrs to the color entries.
//
   redList = new (colorEntryT*[256]);
   for ( int i=0; i<256; i++) {
      redList[i] = NULL; 
   }

//
// Load up the color tables.
//
   for ( i=0; i<numColors; i++) {

      colorEntryT* entry = &colorEntries[i];
      int head_id = entry->r;

      if ( ! redList[head_id] ) {
	 redList[head_id] = entry;
      }
      else {
//
//       Find out where this one goes. *NOTE: these are sorted by
//       green and then blue values off of the green ones.
//
         colorEntryT* redHead = redList[head_id];

         if ( entry->g < redHead->g ) {
	    redList[head_id] = entry;
	    entry->nxtGrn    = redHead;
	 }
	 else {
//
//          Go through the green list and find a place...
//
            colorEntryT* prevGrn = NULL;
            colorEntryT* nxtGrn  = redHead;
	    for (; nxtGrn && entry->g>nxtGrn->g; nxtGrn=nxtGrn->nxtGrn ) prevGrn=nxtGrn;
	    if ( !nxtGrn ) {
	       prevGrn->nxtGrn = entry;
	       continue;
	    }

	    if ( entry->g == nxtGrn->g ) {
//
//             Find out where this goes in the blue list.
//
	       colorEntryT* grnHead = nxtGrn;

//
//             Check the head first...
//
               if ( entry->b < nxtGrn->b ) {
		  if ( nxtGrn == redHead ) {
                     entry->nxtGrn    = redList[head_id]->nxtGrn;
                     redList[head_id]->nxtGrn = NULL;
                     entry->nxtBlu    = redList[head_id];
                     redList[head_id] = entry;
		     continue;
		  }
		  else {
                     entry->nxtGrn   = nxtGrn->nxtGrn;
                     prevGrn->nxtGrn = entry;
                     entry->nxtBlu   = nxtGrn;
                     nxtGrn->nxtGrn  = NULL;
		     continue;
                  }
	       }

//
//             Go down the blue list..
//
	       colorEntryT* prevBlu = NULL;
	       colorEntryT* nxtBlu  = grnHead;
	       for (; nxtBlu && entry->b>nxtBlu->b; nxtBlu=nxtBlu->nxtBlu ) prevBlu=nxtBlu;

               if ( prevBlu ) {
                  entry->nxtBlu   = prevBlu->nxtBlu;
                  prevBlu->nxtBlu = entry;
	       }
	       else {
		  entry->nxtBlu  = nxtBlu->nxtBlu;
		  nxtBlu->nxtBlu = entry;
	       }
	    }  // greens are equal.
	    else {
	       if ( prevGrn ) {
	          prevGrn->nxtGrn = entry;
	       }
	       entry->nxtGrn   = nxtGrn;
	    }
         }
      }
   }
}


// ********************************************************************
// This looks thru the color table to find the "closest" color name
// which matches the current rgb values.
// ********************************************************************
void
ColorPickerC::FindClosestName()
{

   if ( numColors == 0 ) return;
//
// Start with a match on the red value. 
//
   int red_delta  = RED_FACTOR*255;
   int start_id   = redValue;
   int id_offset  = 0;
   int min_delta  = RED_FACTOR*255+GRN_FACTOR*255+BLU_FACTOR*255;
   nearEntry      = NULL;
   currEntry      = NULL;

   while ( red_delta < min_delta && id_offset < RGB_THRESHOLD) {
//
//    Set the red index value to use.
//
      int id = start_id + id_offset;

      if ( id >= 0 && id < 256 ) {
         colorEntryT* ent = redList[id];
	 if ( ent ) {
	    red_delta = (RED_FACTOR * ABS(ent->r-redValue));

            int grn_delta = min_delta-1;

//
//          Examine each of the green values until we can't improve the
//          delta value or we run out of values.
//
            while ( ent ) {     // && grn_delta < min_delta ) {
//
//             Find the best blue value in this green list.
//
               colorEntryT *bluEnt = ent;
               for (; bluEnt->nxtBlu && bluEnt->b<bluValue; bluEnt=bluEnt->nxtBlu);

               if ( bluEnt->nxtBlu && ABS(bluEnt->nxtBlu->b-bluValue) < ABS(bluEnt->b-bluValue) ) {
                  bluEnt = bluEnt->nxtBlu;
	       }
               int blu_delta = (BLU_FACTOR * ABS(bluEnt->b-bluValue));

//
//             See how far we're off...so far
//
               grn_delta = (GRN_FACTOR * ABS(bluEnt->g-grnValue));
	       int delta = red_delta + grn_delta + blu_delta;
               if ( delta < min_delta ) {
	          min_delta  = delta;
	          nearEntry  = bluEnt;
		  if ( min_delta == 0 ) break;
	       }
	       ent = ent->nxtGrn;
            }
         }
      }

//
//    See if this is == or close...
//
      if ( min_delta == 0 ) break;

//
//    Set the next offset to look for.
//
      if ( id_offset >= 0 )
         id_offset = -(id_offset+1);
      else
         id_offset = -(id_offset);
   }

//
// Select the best one for the user.
//
   if (  nearEntry ) {
      if ( min_delta == 0 ) currEntry = nearEntry;
      UpdateList();
   }
   UpdateNameField();
   UpdateClosestColor();
}


// ********************************************************************
// This returns the color name of the current entry if there is one,
// otherwise it returns the contents of the hex value string.
// ********************************************************************
char*
ColorPickerC::GetColorName()
{
   if ( currEntry ) {
      colorName = currEntry->colorName;
   }
   else {
      char *str  = XmTextFieldGetString(valueTF);
      colorName = str;
      XtFree(str);

   }
   return((char*)colorName);
}


// ********************************************************************
// This returns the color name of the current entry if there is one,
// otherwise it returns the contents of the hex value string.
// ********************************************************************
char*
ColorPickerC::GetClosestColorName()
{
   if ( nearEntry )
      return((char*)nearEntry->colorName);
   else
      return "";
}


//************************************************************
// This method allows the user to pick a position
// on the screen and load the colorPicker with this value.
//************************************************************
void ColorPickerC::PickColorOnScreen()
{
   if ( !pickCursor )
      pickCursor = XCreateFontCursor(display, XC_hand1);

   XGrabPointer(display, XtWindow(*this), False,
		(unsigned int)(ButtonReleaseMask|Button1MotionMask),
		GrabModeAsync, GrabModeAsync, None, pickCursor, CurrentTime);
   XtAddEventHandler(*this, Button1MotionMask, False, 
		     (XtEventHandler)DoButtonRelease, (XtPointer)this);
   XtAddEventHandler(*this, ButtonReleaseMask, False, 
		     (XtEventHandler)DoButtonRelease, (XtPointer)this);
}


//************************************************************
// handle button release event for pick color off the screen.
//************************************************************
void ColorPickerC::DoButtonRelease(Widget w, ColorPickerC *This, XButtonEvent* ev, Boolean*)
{
//
// Release the pointer and remove the event handler.
//
   if ( ev->type == ButtonRelease ) {
      XUngrabPointer(This->display, CurrentTime);
      XtRemoveEventHandler(w, Button1MotionMask, False, 
		           (XtEventHandler)DoButtonRelease, (XtPointer)This);
      XtRemoveEventHandler(w, ButtonReleaseMask, False, 
		           (XtEventHandler)DoButtonRelease, (XtPointer)This);
  }

//
// First get the current pointer position and window.
//
   Window root_win, child_win;
   int rootx, rooty, winx, winy;
   unsigned int mask_return;
   XQueryPointer(This->display, XtWindow(*This), &root_win, &child_win,
		 &rootx, &rooty, &winx, &winy, &mask_return);

//
// Get a 1x1 image at the pointer position.
//
   XImage *image = XGetImage(This->display, root_win, rootx, rooty,
		             1, 1, AllPlanes, XYPixmap);
   if ( ! image ) return;

//
// Get the color map from the image.
//
   XWindowAttributes win_atts;
   Status status = XGetWindowAttributes(This->display, root_win, &win_atts);
   if ( !status ) return;

//
// Query the color at that position and set this with the color.
//
   XColor color;
   color.pixel = XGetPixel(image, 0,0);
   XQueryColor(This->display, win_atts.colormap, &color);
   XDestroyImage(image);
   This->SetPixelValue(color.pixel);
}


// ********************************************************************
// This looks thru the color table to find the "closest" color name
// which matches the current rgb values.
// ********************************************************************
void
ColorPickerC::GetRGBValues(int *r, int *g, int *b)
{
   *r = redValue;
   *g = grnValue;
   *b = bluValue;
}


#ifdef LATER
/*---------------------------------------------------------------
 * This method creates the color picker with the color
 * of the attribute which the user is changing.
 */

ColorPickerDialogC::ColorPickerDialogC(Widget p, char* nm)
: HalDialog(halApp, "colorPickerDialog") : ColorPickerC(appForm)
{
   WArgList args;

   //SKB colorPicker = new ColorPickerC(colorPickerDialog->AppForm());
   // args.Reset();
   // args.LeftAttachment(XmATTACH_FORM);
   // args.RightAttachment(XmATTACH_FORM); 
   // args.TopAttachment(XmATTACH_FORM);
   // args.BottomAttachment(XmATTACH_FORM);
   // XtSetValues(*colorPicker, ARGS);

   AddButtonBox();

   Widget p = colorPickerDialog->ButtonBox();
   colorPickOkPB     = XmCreatePushButton(p, "okPB",     0,0);
   colorPickApplyPB  = XmCreatePushButton(p, "applyPB",  0,0);
   Widget colorPickScreenPB   = XmCreatePushButton(p, "colorPickScreenPB",  0,0);
   colorPickCancelPB = XmCreatePushButton(p, "cancelPB",  0,0);

   XtAddCallback(colorPickOkPB, XmNactivateCallback,
		 (XtCallbackProc)DoColorPickerAction, (XtPointer)This);
   XtAddCallback(colorPickApplyPB, XmNactivateCallback,
		 (XtCallbackProc)DoColorPickerAction, (XtPointer)This);
   XtAddCallback(colorPickCancelPB, XmNactivateCallback,
		 (XtCallbackProc)DoColorPickerAction, (XtPointer)This);
   XtAddCallback(colorPickScreenPB, XmNactivateCallback,
		 (XtCallbackProc)DoPickColorOnScreen, (XtPointer)This);
   XtManageChild(colorPickOkPB);
   XtManageChild(colorPickApplyPB);
   XtManageChild(colorPickScreenPB);
   XtManageChild(colorPickCancelPB);
}
#endif
