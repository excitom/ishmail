/*
 * $Id: CounterModC.C,v 1.1 1998/06/24 01:29:07 lang Exp $
 *
 * Copyright (c) 1992 HAL Computer Systems International, Ltd.
 * 
 *          HAL COMPUTER SYSTEMS INTERNATIONAL, LTD.
 *                  1315 Dell Avenue
 *                  Campbell, CA  95008
 *
 * Author: Greg Hilton
 * Contributors: Tom Lang, Frank Bieser, and others
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * http://www.gnu.org/copyleft/gpl.html
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#include "CounterModC.h"
#include "FormatModC.h"
#include "ShadowModC.h"
#include "ColorModC.h"
#include "WArgList.h"
#include "rsrc.h"
#include "ValueC.h"

#include <Xm/Form.h>
#include <Xm/Frame.h>
#include <Xm/Label.h>
#include <Xm/TextF.h>
#include <Xm/RowColumn.h>

CounterModC::CounterModC(Widget parent, const char *name, ArgList argv,
			 Cardinal argc) : ModFormC(parent, name, argv, argc)
{
   WArgList	args;

   counter = NULL;

//
// Create the paramForm hierarchy
//
//   paramForm
//      FormatModC	formatForm
//      ShadowModC	shadowForm
//      Label		countLabel
//      TextField	countTF
//      Label		heightLabel
//      TextField	heightTF
//      Label		pixelLabel
//      Label		margWdLabel
//      TextField	margWdTF
//      Label		margHtLabel
//      TextField	margHtTF
//
   StringC	wname = "formatMod";
   formatForm = new FormatModC(paramForm, wname, 0,0);

   wname = "shadowMod";
   args.Reset();
   args.TopAttachment(XmATTACH_WIDGET, *formatForm);
   shadowForm = new ShadowModC(paramForm, wname, ARGS);

   wname = "countLabel";
   countLabel = XmCreateLabel(paramForm, wname, 0,0);

   wname = "marginWidthLabel";
   margWdLabel = XmCreateLabel(paramForm, wname, 0,0);

//
// Get maximum field width
//
   Dimension	wd, max_wd;
   args.Reset();
   args.Add(XmNwidth, &wd);
   XtGetValues(formatForm->Label(),     ARGS); max_wd = wd;
   XtGetValues(shadowForm->TypeLabel(), ARGS); if (wd > max_wd) max_wd = wd;
   XtGetValues(countLabel,              ARGS); if (wd > max_wd) max_wd = wd;
   XtGetValues(margWdLabel,             ARGS); if (wd > max_wd) max_wd = wd;

   int	ltOffset = get_int("CounterModC", paramForm, "labelTextOffset");

   args.Reset();
   args.LeftAttachment(XmATTACH_FORM, max_wd + ltOffset);
   XtSetValues(formatForm->Frame(),     ARGS);
   XtSetValues(shadowForm->TypeFrame(), ARGS);

   wname = "countTF";
   args.Reset();
   args.TopAttachment(XmATTACH_WIDGET, *shadowForm);
   args.LeftAttachment(XmATTACH_FORM, max_wd + ltOffset);
   countTF = XmCreateTextField(paramForm, wname, ARGS);

   args.Reset();
   args.TopAttachment(XmATTACH_OPPOSITE_WIDGET,    countTF);
   args.BottomAttachment(XmATTACH_OPPOSITE_WIDGET, countTF);
   args.RightAttachment(XmATTACH_WIDGET,           countTF);
   XtSetValues(countLabel, ARGS);

   wname = "marginWidthTF";
   args.Reset();
   args.TopAttachment(XmATTACH_WIDGET, countTF);
   args.LeftAttachment(XmATTACH_FORM, max_wd + ltOffset);
   margWdTF = XmCreateTextField(paramForm, wname, ARGS);

   args.Reset();
   args.TopAttachment   (XmATTACH_OPPOSITE_WIDGET, margWdTF);
   args.BottomAttachment(XmATTACH_OPPOSITE_WIDGET, margWdTF);
   args.RightAttachment (XmATTACH_WIDGET,          margWdTF);
   XtSetValues(margWdLabel, ARGS);

//
// Create second column of labels
//
   wname = "heightLabel";
   heightLabel = XmCreateLabel(paramForm, wname, 0,0);

   wname = "marginHeightLabel";
   margHtLabel = XmCreateLabel(paramForm, wname, 0,0);

   max_wd = 0;
   args.Reset();
   args.Add(XmNwidth, &wd);
   XtGetValues(heightLabel, ARGS); if (wd > max_wd) max_wd = wd;
   XtGetValues(margHtLabel, ARGS); if (wd > max_wd) max_wd = wd;

//
// Create preferred height field
//
   wname = "heightTF";
   args.Reset();
   args.TopAttachment(XmATTACH_WIDGET, *shadowForm);
   args.LeftAttachment(XmATTACH_WIDGET, countTF, max_wd + ltOffset);
   heightTF = XmCreateTextField(paramForm, wname, ARGS);

   args.Reset();
   args.LeftAttachment  (XmATTACH_NONE);
   args.RightAttachment (XmATTACH_WIDGET,          heightTF);
   args.TopAttachment   (XmATTACH_OPPOSITE_WIDGET, heightTF);
   args.BottomAttachment(XmATTACH_OPPOSITE_WIDGET, heightTF);
   XtSetValues(heightLabel, ARGS);

   wname = "pixelLabel";
   args.Reset();
   args.LeftAttachment  (XmATTACH_WIDGET,          heightTF);
   args.TopAttachment   (XmATTACH_OPPOSITE_WIDGET, heightTF);
   args.BottomAttachment(XmATTACH_OPPOSITE_WIDGET, heightTF);
   pixelLabel = XmCreateLabel(paramForm, wname, ARGS);

//
// Create margin height field
//
   wname = "marginHeightTF";
   args.Reset();
   args.TopAttachment(XmATTACH_WIDGET, countTF);
   args.LeftAttachment(XmATTACH_WIDGET, margWdTF, max_wd + ltOffset);
   margHtTF = XmCreateTextField(paramForm, wname, ARGS);

   args.Reset();
   args.LeftAttachment  (XmATTACH_NONE);
   args.RightAttachment (XmATTACH_WIDGET,          margHtTF);
   args.TopAttachment   (XmATTACH_OPPOSITE_WIDGET, margHtTF);
   args.BottomAttachment(XmATTACH_OPPOSITE_WIDGET, margHtTF);
   XtSetValues(margHtLabel, ARGS);

//
// Create the colorRC hierarchy
//
//   colorRC
//      ColorModC	backgroundForm
//      ColorModC	digitBackgroundForm
//      ColorModC	digitForegroundForm
//      ColorModC	topShadowForm
//      ColorModC	bottomShadowForm
//
   wname = "backgroundMod";
   colorForm[CounterC::BACKGROUND]    = new ColorModC(colorRC, wname, 0,0);
   wname = "digitBackgroundMod";
   colorForm[CounterC::DIGIT_BG]      = new ColorModC(colorRC, wname, 0,0);
   wname = "digitForegroundMod";
   colorForm[CounterC::DIGIT_FG]      = new ColorModC(colorRC, wname, 0,0);
   wname = "topShadowColorMod";
   colorForm[CounterC::TOP_SHADOW]    = new ColorModC(colorRC, wname, 0,0);
   wname = "bottomShadowColorMod";
   colorForm[CounterC::BOTTOM_SHADOW] = new ColorModC(colorRC, wname, 0,0);

//
// Manage children
//
   Widget	list[11];
   list[0] = *colorForm[CounterC::BACKGROUND];
   list[1] = *colorForm[CounterC::DIGIT_BG];
   list[2] = *colorForm[CounterC::DIGIT_FG];
   list[3] = *colorForm[CounterC::TOP_SHADOW];
   list[4] = *colorForm[CounterC::BOTTOM_SHADOW];
   XtManageChildren(list, 5);	// colorRC children

   list[ 0] = *formatForm;
   list[ 1] = *shadowForm;
   list[ 2] = countLabel;
   list[ 3] = countTF;
   list[ 4] = heightLabel;
   list[ 5] = heightTF;
   list[ 6] = pixelLabel;
   list[ 7] = margWdLabel;
   list[ 8] = margWdTF;
   list[ 9] = margHtLabel;
   list[10] = margHtTF;
   XtManageChildren(list, 11);	// paramForm children

} // End CounterModC CounterModC

/*---------------------------------------------------------------
 *  Destructor
 */

CounterModC::~CounterModC()
{
   delete formatForm;
   delete shadowForm;
   for (int i=0; i<CounterC::COLOR_ATTR_COUNT; i++) delete colorForm[i];
}

/*---------------------------------------------------------------
 *  Method to apply counter changes
 */

void
CounterModC::Apply(CounterC& c)
{
   char	*cs;
   c.Defer(True);

//
// Set the numeric format
//
   c.SetOutputFormat(formatForm->Format());
   c.SetPrecision(formatForm->Precision());

//
// Set the shadow attributes
//
   c.SetShadowType(shadowForm->Type());
   c.SetShadowThickness(shadowForm->Thickness());

//
// Set the digit count
//
   cs = XmTextFieldGetString(countTF);
   int	digitCount = atoi(cs);
   XtFree(cs);

   c.SetDigitCount(digitCount);

//
// Set the digit height
//
   cs = XmTextFieldGetString(heightTF);
   int	prefHt = atoi(cs);
   XtFree(cs);

   c.SetDigitHeight(prefHt);

//
// Set the margins
//
   cs = XmTextFieldGetString(margWdTF);
   int	marginWd = atoi(cs);
   XtFree(cs);

   cs = XmTextFieldGetString(margHtTF);
   int	marginHt = atoi(cs);
   XtFree(cs);

   c.SetMargins(marginWd, marginHt);

//
// Set the colors
//
   for (int i=0; i<CounterC::COLOR_ATTR_COUNT; i++) {
      ColorModC	*cm = colorForm[i];
      if ( cm->Changed() ) {
	 c.SetColor((CounterC::CounterColorAttr)i, cm->Value());
      }
   }

   c.Defer(False);
   c.Draw();

   return;

} // End CounterModC Apply

/*---------------------------------------------------------------
 *  Method to initialize the settings based on the given counter
 */

void
CounterModC::Init(CounterC& c)
{
   formatForm->Init(c.OutputFormat(), c.Precision());
   shadowForm->Init(c.ShadowType(), c.ShadowThickness());
   init.digitCount = c.DigitCount();
   init.prefHt     = c.DigitHeight();
   c.GetMargins(&init.marginWd, &init.marginHt);

//
// Initialize the fields
//
   StringC	str;
   str += init.digitCount;
   XmTextFieldSetString(countTF, str);
   str = "";
   str += (int)init.prefHt;
   XmTextFieldSetString(heightTF, str);
   str = "";
   str += (int)init.marginWd;
   XmTextFieldSetString(margWdTF, str);
   str = "";
   str += (int)init.marginHt;
   XmTextFieldSetString(margHtTF, str);

//
// Initialize the colors
//
   for (int i=0; i<CounterC::COLOR_ATTR_COUNT; i++) {
      colorForm[i]->Init(c.GetColor((CounterC::CounterColorAttr)i));
   }

   counter = &c;

} // End CounterModC Init

/*---------------------------------------------------------------
 *  Method to reset the fields to their initial values
 */

void
CounterModC::Reset()
{
   StringC	str;

   formatForm->Reset();
   shadowForm->Reset();

   str = "";
   str += init.digitCount;
   XmTextFieldSetString(countTF, str);

   str = "";
   str += (int)init.prefHt;
   XmTextFieldSetString(heightTF, str);

   str = "";
   str += (int)init.marginWd;
   XmTextFieldSetString(margWdTF, str);

   str = "";
   str += (int)init.marginHt;
   XmTextFieldSetString(margHtTF, str);

//
// Initialize the colors
//
   for (int i=0; i<CounterC::COLOR_ATTR_COUNT; i++) colorForm[i]->Reset();

   if ( autoApply ) {
      counter->Defer(True);
      counter->SetOutputFormat(formatForm->Format());
      counter->SetPrecision(formatForm->Precision());
      counter->SetShadowType(shadowForm->Type());
      counter->SetShadowThickness(shadowForm->Thickness());
      counter->SetDigitCount(init.digitCount);
      counter->SetDigitHeight(init.prefHt);
      counter->SetMargins(init.marginWd, init.marginHt);
      for (int i=0; i<CounterC::COLOR_ATTR_COUNT; i++)
	 counter->SetColor((CounterC::CounterColorAttr)i,colorForm[i]->Value());
      counter->Defer(False);
      counter->Draw();
   }

} // End CounterModC Reset

/*---------------------------------------------------------------
 *  Method to add the callbacks needed to support auto update
 */

void
CounterModC::EnableAutoApply()
{
   if ( autoApply ) return;

#define AddValueChanged(W,C) \
   XtAddCallback(W, XmNvalueChangedCallback, \
	         (XtCallbackProc)(C), (XtPointer)this)

#define AddActivate(W,C) \
   XtAddCallback(W, XmNactivateCallback, \
	         (XtCallbackProc)(C), (XtPointer)this)

#define AddColorActivate(COL,C) \
   AddActivate(colorForm[CounterC::COL]->TextField(), C)

//
// Add auto-update callbacks
//
   AddValueChanged (formatForm->IntTB(),     ChangeFormat);
   AddValueChanged (formatForm->HexTB(),     ChangeFormat);
   AddValueChanged (formatForm->FloatTB(),   ChangeFormat);
   AddActivate     (formatForm->PrecisTF(),  ChangeFormatPrecis);
   AddValueChanged (shadowForm->InTB(),      ChangeShadow);
   AddValueChanged (shadowForm->OutTB(),     ChangeShadow);
   AddValueChanged (shadowForm->EtchInTB(),  ChangeShadow);
   AddValueChanged (shadowForm->EtchOutTB(), ChangeShadow);
   AddActivate     (shadowForm->ThickTF(),   ChangeShadowThick);
   AddActivate     (countTF,                 ChangeCount);
   AddActivate     (heightTF,                ChangeHeight);
   AddActivate     (margWdTF,                ChangeMargin);
   AddActivate     (margHtTF,                ChangeMargin);
   AddColorActivate(BACKGROUND,              ChangeBackground);
   AddColorActivate(DIGIT_BG,                ChangeDigitBG);
   AddColorActivate(DIGIT_FG,                ChangeDigitFG);
   AddColorActivate(TOP_SHADOW,              ChangeTopShadow);
   AddColorActivate(BOTTOM_SHADOW,           ChangeBottomShadow);

} // End CounterModC EnableAutoApply

/*---------------------------------------------------------------
 *  Method to remove the callbacks needed to support auto update
 */

void
CounterModC::DisableAutoApply()
{
   if ( !autoApply ) return;

#define RemoveValueChanged(W,C) \
   XtRemoveCallback(W, XmNvalueChangedCallback, \
	            (XtCallbackProc)(C), (XtPointer)this)

#define RemoveActivate(W,C) \
   XtRemoveCallback(W, XmNactivateCallback, \
	            (XtCallbackProc)(C), (XtPointer)this)

#define RemoveColorActivate(COL,C) \
   RemoveActivate(colorForm[CounterC::COL]->TextField(), C)

//
// Remove auto-update callbacks
//
   RemoveValueChanged (formatForm->IntTB(),     ChangeFormat);
   RemoveValueChanged (formatForm->HexTB(),     ChangeFormat);
   RemoveValueChanged (formatForm->FloatTB(),   ChangeFormat);
   RemoveActivate     (formatForm->PrecisTF(),  ChangeFormatPrecis);
   RemoveValueChanged (shadowForm->InTB(),      ChangeShadow);
   RemoveValueChanged (shadowForm->OutTB(),     ChangeShadow);
   RemoveValueChanged (shadowForm->EtchInTB(),  ChangeShadow);
   RemoveValueChanged (shadowForm->EtchOutTB(), ChangeShadow);
   RemoveActivate     (shadowForm->ThickTF(),   ChangeShadowThick);
   RemoveActivate     (countTF,                 ChangeCount);
   RemoveActivate     (heightTF,                ChangeHeight);
   RemoveActivate     (margWdTF,                ChangeMargin);
   RemoveActivate     (margHtTF,                ChangeMargin);
   RemoveColorActivate(BACKGROUND,              ChangeBackground);
   RemoveColorActivate(DIGIT_BG,                ChangeDigitBG);
   RemoveColorActivate(DIGIT_FG,                ChangeDigitFG);
   RemoveColorActivate(TOP_SHADOW,              ChangeTopShadow);
   RemoveColorActivate(BOTTOM_SHADOW,           ChangeBottomShadow);

} // End CounterModC DisableAutoApply

void
CounterModC::ChangeFormat(Widget, CounterModC *cm,
			  XmToggleButtonCallbackStruct *tb)
{
   if ( tb->set )
      cm->counter->SetOutputFormat(cm->formatForm->Format());
}

void
CounterModC::ChangeFormatPrecis(Widget, CounterModC *cm, XtPointer)
{
   cm->counter->SetPrecision(cm->formatForm->Precision());
}

void
CounterModC::ChangeShadow(Widget, CounterModC *cm,
			  XmToggleButtonCallbackStruct *tb)
{
   if ( tb->set )
      cm->counter->SetShadowType(cm->shadowForm->Type());
}

void
CounterModC::ChangeShadowThick(Widget, CounterModC *cm, XtPointer)
{
   cm->counter->SetShadowThickness(cm->shadowForm->Thickness());
}

void
CounterModC::ChangeCount(Widget, CounterModC *cm, XtPointer)
{
   if ( XmTextFieldGetLastPosition(cm->countTF) == 0 ) return;

   char *cs = XmTextFieldGetString(cm->countTF);
   int	count = atoi(cs);
   XtFree(cs);

   cm->counter->SetDigitCount(count);
}

void
CounterModC::ChangeHeight(Widget, CounterModC *cm, XtPointer)
{
   if ( XmTextFieldGetLastPosition(cm->heightTF) == 0 ) return;

   char *cs = XmTextFieldGetString(cm->heightTF);
   int	height = atoi(cs);
   XtFree(cs);

   cm->counter->SetDigitHeight(height);
}

void
CounterModC::ChangeMargin(Widget, CounterModC *cm, XtPointer)
{
   if ( XmTextFieldGetLastPosition(cm->margWdTF) == 0 ||
        XmTextFieldGetLastPosition(cm->margHtTF) == 0 ) return;

   char *cs = XmTextFieldGetString(cm->margWdTF);
   int	wd = atoi(cs);
   XtFree(cs);

   cs = XmTextFieldGetString(cm->margHtTF);
   int	ht = atoi(cs);
   XtFree(cs);

   cm->counter->SetMargins(wd, ht);
}

void
CounterModC::ChangeBackground(Widget, CounterModC *cm, XtPointer)
{
   cm->ChangeColor(CounterC::BACKGROUND);
}

void
CounterModC::ChangeDigitBG(Widget, CounterModC *cm, XtPointer)
{
   cm->ChangeColor(CounterC::DIGIT_BG);
}

void
CounterModC::ChangeDigitFG(Widget, CounterModC *cm, XtPointer)
{
   cm->ChangeColor(CounterC::DIGIT_FG);
}

void
CounterModC::ChangeTopShadow(Widget, CounterModC *cm, XtPointer)
{
   cm->ChangeColor(CounterC::TOP_SHADOW);
}

void
CounterModC::ChangeBottomShadow(Widget, CounterModC *cm, XtPointer)
{
   cm->ChangeColor(CounterC::BOTTOM_SHADOW);
}

void
CounterModC::ChangeColor(CounterC::CounterColorAttr color)
{
   ColorModC		*cm = colorForm[color];

   if ( cm->Changed() ) counter->SetColor(color, cm->Value());
}

