/*
 * $Id: TreeNodeC.h,v 1.1 1998/06/24 01:29:07 lang Exp $
 *
 * Copyright (c) 1992 HAL Computer Systems International, Ltd.
 * 
 *          HAL COMPUTER SYSTEMS INTERNATIONAL, LTD.
 *                  1315 Dell Avenue
 *                  Campbell, CA  95008
 *
 * Author: Greg Hilton
 * Contributors: Tom Lang, Frank Bieser, and others
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * http://www.gnu.org/copyleft/gpl.html
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

# ifndef _TreeNodeC_h_
# define _TreeNodeC_h_

# include <Xm/Xm.h>

# include "TreeC.h"

class TreeNodeC: public TreeItemC {
    //
    //  Constructors/Destructor
    //
    public:
	TreeNodeC (char *, char *, TreeC &, TreeNodeC *);
	~TreeNodeC ();

    //
    //  Simple Access Functions
    //
    public:
	Widget			label ();
	Widget			parentButton ();
	Widget			childButton ();
	Widget			expandForm ();

    //
    //  Hooks so derived classes can catch state changes.
    //
    public:
	virtual void		shown ();
	virtual void		hidden ();
	virtual void		destroyed ();

    public:
	virtual void		parentShow () {}
	virtual void		parentHide () {}
	virtual void		childrenShow () {}
	virtual void		childrenHide () {}
	virtual void		select () {}
	virtual void		unselect () {}

    //
    //  Widget Hierarchy
    //
    private:
	TreeC				*_tree;
	Widget				_topForm;
	Widget					_baseForm;
	Widget						_parentButton;
	Widget						_label;
	Widget						_childButton;
	Widget					_expandForm;

    //
    //  State information
    //
    private:
	TreeNodeC *		_realParent;
	Boolean			_selected;
	Boolean			_expanded;
	Boolean			_parentPruned;
	Boolean			_childrenShown;
	Time			_lastPressTime;
	Boolean			_realizeExpandForm;

    //
    //  Callbacks and Event Handlers
    //
    private:
	static void		expandCB (Widget, TreeNodeC *, XtPointer);
	static void		parentCB (Widget, TreeNodeC *, XtPointer);
	static void		childrenCB (Widget, TreeNodeC *, XtPointer);
	static void		selectCB (Widget, TreeNodeC *, XButtonPressedEvent *, Boolean *);

    //
    //  Private member routines
    //
    private:
	void			childHidden (TreeNodeC *);
};

inline Widget
TreeNodeC::parentButton () {
    return _parentButton;
}

inline Widget
TreeNodeC::childButton () {
    return _childButton;
}

inline Widget
TreeNodeC::label () {
    return _label;
}

inline Widget
TreeNodeC::expandForm () {
    return _expandForm;
}

/************************************************

class AttributeInfo;
class ViewObj;
class VolumeViewObj;
class PlexViewObj;
class SubDiskViewObj;


class VolumeTreeNodeC: public TreeNodeC {
    public:
	VolumeTreeNodeC (VolumeViewObj *, ViewObj *);
	~VolumeTreeNodeC ();

    public:
	virtual void		childrenShow ();

    private:
	char *			getName (VolumeViewObj *);

    private:
	VolumeViewObj *		_obj;
	ViewObj *		_parentObj;
	AttributeInfo *		_info;
};

class PlexTreeNodeC: public TreeNodeC {
    public:
	PlexTreeNodeC (PlexViewObj *, ViewObj *);
	~PlexTreeNodeC ();

    public:
	virtual void		childrenShow ();

    private:
	char *			getName (PlexViewObj *);

    private:
	PlexViewObj *		_obj;
	ViewObj *		_parentObj;
	AttributeInfo *		_info;
};

class SubDiskTreeNodeC: public TreeNodeC {
    public:
	SubDiskTreeNodeC (SubDiskViewObj *, ViewObj *);
	~SubDiskTreeNodeC ();

    public:
	virtual void		childrenShow ();

    private:
	char *getName (SubDiskViewObj *);

    private:
	SubDiskViewObj *	_obj;
	ViewObj *		_parentObj;
	AttributeInfo *		_info;
};

**************************************/

# endif
