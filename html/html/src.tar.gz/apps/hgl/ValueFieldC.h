/*
 * $Id: ValueFieldC.h,v 1.1 1998/06/24 01:29:07 lang Exp $
 *
 * Copyright (c) 1992 HAL Computer Systems International, Ltd.
 * 
 *          HAL COMPUTER SYSTEMS INTERNATIONAL, LTD.
 *                  1315 Dell Avenue
 *                  Campbell, CA  95008
 *
 * Author: Greg Hilton
 * Contributors: Tom Lang, Frank Bieser, and others
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * http://www.gnu.org/copyleft/gpl.html
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#ifndef _ValueFieldC_h
#define _ValueFieldC_h

#include <stdio.h>
#include <X11/Intrinsic.h>
#include <Xm/Xm.h>

class ValueFieldC
{
      Widget            textField;
      float  		min;
      float  		max;
      float  		value;
      int  		precision;
      int  		min_chars;
      char*		valstr;
      XmTextPosition	valpos;

//
//    Callbacks.
//
      static void checkValueCB(Widget, ValueFieldC*, XtPointer);
      static void activateCB(Widget, ValueFieldC*, XtPointer);

   public:
//
//    Constructors & Destructors & Methods oh my
//
      ValueFieldC(Widget parent, char*, Arg*, Cardinal);
      ValueFieldC(Widget parent, char*, Arg*, Cardinal, float min, float max, int prec);
     ~ValueFieldC();
      void		CheckValue();

      inline Widget 	TextField()	const { return textField; }
      inline float	Value()		const { return value; }
      inline char*	ValueStr()	const { return valstr; }
      void		Value(float);
      void		Value(char*);
      inline void	Value(int v)    { Value((float)v); }
      void		Min(float);
      void		Max(float);
      void		Precision(int);
      inline float 	Min()  		const { return min; }
      inline float 	Max() 		const { return min; }
      inline int 	Precision() 	const { return precision; }

//
//    Set the value.
//
      // inline void       operator=(float    v) { Value(v); }
      // inline void       operator=(int      v) { Value((float)v); }
      // inline void       operator=(long     v) { Value((float)v); }
      // inline void       operator=(double   v) { Value((float)v); }
      // inline void       operator=(unsigned v) { Value((float)v); }

//
//    Get the value.
//
      // inline operator      float()    const { return value;           }
      // inline operator      int()      const { return (int)value;      }
      // inline operator      long()     const { return (long)value;     }
      // inline operator      double()   const { return (double)value;   }
      // inline operator      unsigned() const { return (unsigned)value; }

      inline operator 	   Widget()   const { return textField; }
};


// =====================================================================
// =====================================================================
class LabeledValueFieldC :  public ValueFieldC
{
   protected:

      Widget 	form;
      Widget	label;
      Widget    Initialize(Widget parent, char* name);
      void    	Build(char*);

   public:

//
//    Define constructors which create the form widget as the
//    parent of the ValueField in the Initialize routine.
//
      inline LabeledValueFieldC(Widget parent, char* name)
         : ValueFieldC(Initialize(parent,name),name,0,0)
      {
	 Build(name);
      }

      inline LabeledValueFieldC(Widget parent, char* name, float min, float max, int prec)
	 : ValueFieldC(Initialize(parent,name), name, 0, 0, min, max, prec)
      {
	 Build(name);
      }

      inline LabeledValueFieldC(Widget parent, char* name, int min, int max)
	 : ValueFieldC(Initialize(parent,name), name, 0, 0, (float)min, (float)max, 0)
      {
	 Build(name);
      }

      ~LabeledValueFieldC();

//
//    Set the value
//
      // inline void       operator=(float    v) { Value(v); }
      // inline void       operator=(int      v) { Value((float)v); }
      // inline void       operator=(long     v) { Value((float)v); }
      // inline void       operator=(double   v) { Value((float)v); }
      // inline void       operator=(unsigned v) { Value((float)v); }

//
//    Get the value.
//
      // inline operator      float()    const { return value;           }
      // inline operator      int()      const { return (int)value;      }
      // inline operator      long()     const { return (long)value;     }
      // inline operator      double()   const { return (double)value;   }
      // inline operator      unsigned() const { return (unsigned)value; }


      inline Widget		Form()		const { return form; }
      inline Widget		Label()		const { return label; }
      inline operator 		Widget()	const { return form; }
};
#endif
