#include <stream.h>

void
Clip(int x0, int y0, int x1, int y1)
{
   cout <<"Checking line from " <<x0 <<" " <<y0 <<" to " <<x1 <<" " <<y1 <<endl;

//
// Throw out lines that don't cross visible space
//
   int	xmax = 100;
   int	ymax = 100;
   if ( (x0 <= 0    && x1 <= 0) ||
        (x0 >= xmax && x1 >= xmax) ||
	(y0 <= 0    && y1 <= 0) ||
        (y0 >= ymax && y1 >= ymax) ) {
      cout <<"   Line does not cross space" <<endl;
      return;
   }

//
// Make sure x0 is left of x1
//
   int	tmp;
   if ( x0 > x1 ) {
      cout <<"   Swapping x coords" <<endl;
      tmp = x0; x0 = x1; x1 = tmp;
      tmp = y0; y0 = y1; y1 = tmp;
   }

//
// Calculate slope of line
//
   int		dx    = x1 - x0;
   int		dy    = y1 - y0;
   float	slope = (dx != 0) ? (float)dy/(float)dx : 0;
   int		x2, y2;

   if ( dx != 0 ) {

//
// Clip to left side of drawing area
//
      if ( x0 < 0 ) {
	 cout <<"   Clipping to left side" <<endl;
	 x2 = 0;
	 y2 = (int)(y1 - (slope * (x1 - x2)));
	 x0 = x2;
	 y0 = y2;
	 cout <<"   New line is " <<x0 <<" " <<y0 <<" to " <<x1 <<" "<<y1<<endl;
      }

//
// Clip to right side of drawing area
//
      if ( x1 > xmax ) {
	 cout <<"   Clipping to right side" <<endl;
	 x2 = xmax;
	 y2 = (int)(y1 - (slope * (x1 - x2)));
	 x1 = x2;
	 y1 = y2;
	 cout <<"   New line is " <<x0 <<" " <<y0 <<" to " <<x1 <<" "<<y1<<endl;
      }

//
// Throw out lines that don't cross visible space
//
      if ( (y0 <= 0    && y1 <= 0) ||
	   (y0 >= ymax && y1 >= ymax) ) {
	 cout <<"   Clipped line does not cross space" <<endl;
	 return;
      }

   } // End if line is not vertical

//
// Make sure y0 is above of y1
//
   if ( y0 > y1 ) {
      cout <<"   Swapping y coords" <<endl;
      tmp = x0; x0 = x1; x1 = tmp;
      tmp = y0; y0 = y1; y1 = tmp;
      dx    = x1 - x0;
      dy    = y1 - y0;
      if ( dx != 0 ) slope = (float)dy/(float)dx;
      else	     slope = 0;
   }

   if ( dx == 0 ) {
      cout <<"   Line is vertical" <<endl;
      if ( y0 < 0    ) y0 = 0;
      if ( y1 > xmax ) y1 = ymax;
      cout <<"   New line is " <<x0 <<" " <<y0 <<" to " <<x1 <<" "<<y1<<endl;
   }

   else {

//
// Clip to top side of drawing area
//
      if ( y0 < 0 ) {
	 cout <<"   Clipping to top side" <<endl;
	 y2 = 0;
	 x2 = (int)(x1 - ((y1 - y2) / slope));
	 y0 = y2;
	 x0 = x2;
	 cout <<"   New line is " <<x0 <<" " <<y0 <<" to " <<x1 <<" "<<y1<<endl;
      }

//
// Clip to bottom side of drawing area
//
      if ( y1 > ymax ) {
	 cout <<"   Clipping to bottom side" <<endl;
	 y2 = ymax;
	 x2 = (int)(x1 - ((y1 - y2) / slope));
	 y1 = y2;
	 x1 = x2;
	 cout <<"   New line is " <<x0 <<" " <<y0 <<" to " <<x1 <<" "<<y1<<endl;
      }

   } // End if line is not vertical

} // End Clip

main()
{
#if 0
//
// Test vertical lines.  Test horizontal lines by swapping order of args in
//    Clip();
//
   Clip(-50, -50, -50, 150);

   Clip(150, -50, 150, 150);

   Clip( 50, -50,  50, 150);
   Clip( 50,   0,  50, 150);
   Clip( 50,  50,  50, 150);
   Clip( 50, 100,  50, 150);
   Clip( 50, 140,  50, 150);

   Clip( 50, -50,  50, 100);
   Clip( 50, -50,  50,  50);
   Clip( 50, -50,  50,   0);
   Clip( 50, -50,  50, -40);

   Clip( 50,   0,  50, 100);
   Clip( 50,  10,  50,  90);
#endif

//
// Test angled lines
//
   Clip(-50, 100,   0, 150);
   Clip(-50,  50,  50, 150);
   Clip(-50,   0, 100, 150);
   Clip(-50,   0,  25,  75);
   Clip( 25,  75, 100, 150);
   Clip(  0,  50,  50, 100);
   Clip(  0,   0, 100, 100);
   Clip( 25,  25,  75,  75);
   Clip(  0, -50, 150, 100);
   Clip(  0, -50,  75,  25);
   Clip( 75,  25, 150, 100);
   Clip( 50, -50, 150,  50);
   Clip(100, -50, 150,   0);
}

 * 
 *          HAL COMPUTER SYSTEMS INTERNATIONAL, LTD.
 *                  1315 Dell Avenue
 *                  Campbell, CA  95008
 *
 * Author: Greg Hilton
 * Contributors: Tom Lang, Frank Bieser, and others
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * http://www.gnu.org/copyleft/gpl.html
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
