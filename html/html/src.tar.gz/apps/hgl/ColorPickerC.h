/*
 * $Id: ColorPickerC.h,v 1.1 1998/06/24 01:29:07 lang Exp $
 *
 * Copyright (c) 1993 HAL Computer Systems International, Ltd.
 * 
 *          HAL COMPUTER SYSTEMS INTERNATIONAL, LTD.
 *                  1315 Dell Avenue
 *                  Campbell, CA  95008
 *
 * Author: Greg Hilton
 * Contributors: Tom Lang, Frank Bieser, and others
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * http://www.gnu.org/copyleft/gpl.html
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#ifndef _ColorPickerC_h_
#define _ColorPickerC_h_

#include <X11/Intrinsic.h>
#include "StringC.h"


typedef struct colorEntry_s{
   StringC colorName;
   int     r, b, g;
   int     itemIndex;
   struct  colorEntry_s* nxtGrn;
   struct  colorEntry_s* nxtBlu;
} colorEntryT;


class ColorPickerC {

//
// The private parts.
//
   private:

      StringC		colorName;
      XColor		currColor;
      XColor		nearColor;
      Display	       *display;
      Window	        window;
      Colormap		colorMap;
      Boolean		updating;
      int		redValue;
      int		grnValue;
      int		bluValue;
      int		redSat;
      int		grnSat;
      int		bluSat;
      int		satValue;
      int		satRange;

      StringC		rgbFile;
      int		numColors;

      Cursor            pickCursor;

      Widget		mainForm;
      Widget		baseForm;
      Widget		satTF;
      Widget		redTF;
      Widget		grnTF;
      Widget		bluTF;
      Widget		colorWin;
      Widget		closeWin;
      Widget		closeLabel;
      Widget		satLabel;
      Widget		redLabel;
      Widget		grnLabel;
      Widget		bluLabel;
      Widget		satScale;
      Widget		redScale;
      Widget		grnScale;
      Widget		bluScale;
      Widget		valueTF;
      Widget		nameLabel;
      Widget		nameTF;
      Widget  		nameList;

      colorEntryT       *colorEntries;
      colorEntryT       **redList;
      colorEntryT       *currEntry;
      colorEntryT       *nearEntry;


//
// The callbacks and event handlers.
//
   private:

      static void  DoButtonRelease(Widget, ColorPickerC*, XButtonEvent*, Boolean*);
      static void  DoPickColorOnScreen (Widget, ColorPickerC*, XtPointer);
      static void  DoDragSaturation    (Widget, ColorPickerC*, XtPointer);
      static void  DoChangeSaturation  (Widget, ColorPickerC*, XtPointer);
      static void  DoSelectName        (Widget, ColorPickerC*, XtPointer);
      static void  DoNameChange        (Widget, ColorPickerC*, XtPointer);
      static void  DoRgbNameChange     (Widget, ColorPickerC*, XtPointer);
      static void  DoHexValueChange    (Widget, ColorPickerC*, XtPointer);
      static void  DoDragScale         (Widget, ColorPickerC*, XtPointer);

      void     		FindClosestName();
      void     		UpdateAll();
      void     		UpdateNameField();
      void     		UpdateHexField();
      void     		UpdateList();
      void     		UpdateColor();
      void     		UpdateClosestColor();
      void     		UpdateRGBFields();
      void     		UpdateRGBScales();
      void     		UpdateSaturation();
      void     		ReadColorNames();
      void     		SortColorTables();
      colorEntryT*	FindEntry(char*);

   public:
      ColorPickerC(Widget parent, char* name = "colorPicker", ArgList args=NULL, Cardinal argc=0);
     ~ColorPickerC();

      Boolean  SetPixelValue(Pixel);
      void     SetRGBValues(int, int, int);
      Boolean  SetColorName(char*);

      char*    GetColorName();
      char*    GetClosestColorName();
      void     GetRGBValues(int *r, int *g, int *b);
      void     PickColorOnScreen();

      operator Widget() const { return mainForm; }

      inline Widget    SaturationTF()	const { return satTF; }
      inline Widget    RedTF()		const { return redTF; }
      inline Widget    GreenTF()	const { return grnTF; }
      inline Widget    BlueTF()		const { return bluTF; }
      inline Widget    SaturationScale()const { return satScale; }
      inline Widget    RedScale()	const { return redScale; }
      inline Widget    GreenScale()	const { return grnScale; }
      inline Widget    BlueScale()	const { return bluScale; }
      inline Widget    ValueTF()	const { return valueTF; }
      inline Widget    NameTF()		const { return nameTF; }
      inline Widget    NameList()	const { return nameList; }
};

#endif // _ColorPickerC_h_
