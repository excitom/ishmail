/*
 * $Id: MeterC.h,v 1.1 1998/06/24 01:29:07 lang Exp $
 *
 * Copyright (c) 1992 HAL Computer Systems International, Ltd.
 * 
 *          HAL COMPUTER SYSTEMS INTERNATIONAL, LTD.
 *                  1315 Dell Avenue
 *                  Campbell, CA  95008
 *
 * Author: Greg Hilton
 * Contributors: Tom Lang, Frank Bieser, and others
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * http://www.gnu.org/copyleft/gpl.html
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#ifndef _MeterC_h_
#define _MeterC_h_

#include "GraphC.h"
#include "ValueC.h"
#include "StringC.h"
#include "FloatListC.h"
#include "CallbackListC.h"

#include <Xm/Xm.h>

class IntListC;
class WorkingBoxC;

//----------------------------------------------------------------------------
// Class definition

class MeterC : public GraphC {

public:

   enum MeterColorAttr {
      BACKGROUND = 0,
      FACE_COLOR,
      INDICATOR_COLOR,
      VALUE_COLOR,
      LABEL_COLOR,
      TICK_COLOR,
      MARK_COLOR,
      TOP_SHADOW,
      BOTTOM_SHADOW,
      COLOR_ATTR_COUNT
   };

protected:

//
// Drawing attributes
//
   XFontStruct		*font;
   Pixel		colors[COLOR_ATTR_COUNT];
   StringC		colorNames[COLOR_ATTR_COUNT];
   unsigned char	shadowType;
   Dimension		shadowThickness;
   int			labelOffset;

   ValueC		formatVal;
   float		value;
   float		minValue;
   float		maxValue;
   float		valRangeInv;
   FloatListC		markList;
   int			majorTickLen;
   int			minorTickLen;
   float		majorTickSpacing;
   float		minorTickSpacing;
   Boolean		allowInput;
   int			indicatorX;
   int			indicatorY;
   int			meterRadius;

   Boolean		inBounds;
   Boolean		dragging;
   CallbackListC	dragCalls;
   CallbackListC	valueChangedCalls;

//
// Callbacks and event handlers
//
   static void		HandleButtonMotion(Widget, MeterC*,
					   XMotionEvent*, Boolean*);
   static void		HandleButtonPress(Widget, MeterC*,
					  XButtonPressedEvent*, Boolean*);
   static void		HandleButtonRelease(Widget, MeterC*,
					    XButtonReleasedEvent*, Boolean*);

//
// Private methods
//
   void			DrawShadow(Pixel, Pixel, int, int, int, int, int);
   void			DrawShadowIn(Pixel, Pixel, int, int, int, int,int);
   void			DrawShadowEtchedIn(Pixel, Pixel, int, int, int,int,int);
   float		NormalizeValue(float);

public:

//
// Cast to widget
//
   inline operator	Widget() const		{ return da;	}

//
// Constructor and destructor
//
   MeterC(Widget parent, const char *name, ArgList argv=NULL, Cardinal argc=0);
   virtual ~MeterC();

//
// Assignment from another meter
//
   MeterC&		operator=(const MeterC&);

//
// Read from and write to a file
//
   int			Read(FILE*, WorkingBoxC *wb=NULL);
   void			Write(FILE*, const char *prefix="");

//
// Add callbacks
//
   inline void	AddDragCallback(CallbackFn *fn, void *data) {
      AddCallback(dragCalls, fn, data);
   }
   inline void	AddValueChangedCallback(CallbackFn *fn, void *data) {
      AddCallback(valueChangedCalls, fn, data);
   }

//
// Call callbacks
//
   inline void	CallDragCallbacks() {
      CallCallbacks(dragCalls, this);
   }
   inline void	CallValueChangedCallbacks() {
      CallCallbacks(valueChangedCalls, this);
   }

//
// Methods to modify the meter
//
   void			AddMark(const ValueC);
   void    		AllowInput(Boolean);
   void			Draw();
   void			SetColor(MeterC::MeterColorAttr, Pixel);
   void			SetColor(MeterC::MeterColorAttr, const char *);
   void			SetLabelOffset(int);
   void			SetMarks(const IntListC&);
   void			SetMarks(const FloatListC&);
   void			SetOutputFormat(ValueC::ValueFormat);
   void			SetPrecision(int);
   void			SetRange(const ValueC, const ValueC);
   void			SetShadowThickness(Dimension);
   void			SetShadowType(unsigned char);
   void			SetTickLength(int, int);
   void			SetTickSpacing(const ValueC, const ValueC);
   void			SetValue(const ValueC);

//
// Methods to query the meter
//
   MEMBER_QUERY(Boolean,       AllowInput,      allowInput)
   MEMBER_QUERY(int,           LabelOffset,     labelOffset)
   MEMBER_QUERY(int,           Precision,       formatVal.Precision())
   MEMBER_QUERY(Dimension,     ShadowThickness, shadowThickness)
   MEMBER_QUERY(unsigned char, ShadowType,      shadowType)
   MEMBER_QUERY(float,         Value,           value)
   MEMBER_QUERY(ValueC::ValueFormat,    OutputFormat, formatVal.Format())

   Pixel		GetColor    (MeterC::MeterColorAttr) const;
   StringC		GetColorName(MeterC::MeterColorAttr) const;
   void			GetRange(int*, int*) const;
   void			GetRange(long*, long*) const;
   void			GetRange(float*, float*) const;
   void			GetRange(ValueC*, ValueC*) const;
   void			GetRange(StringC*, StringC*) const;
   void			GetTickLength(int*, int*) const;
   void			GetTickSpacing(int*, int*) const;
   void			GetTickSpacing(long*, long*) const;
   void			GetTickSpacing(float*, float*) const;
   void			GetTickSpacing(ValueC*, ValueC*) const;
   void			GetTickSpacing(StringC*, StringC*) const;
   StringC		ValueString() const;
   inline GraphType	Type() const { return METER_GRAPH; }
};

#endif // _MeterC_h_
