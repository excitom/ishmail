/*
 * $Id: LayoutC.C,v 1.1 1998/06/24 01:29:07 lang Exp $
 *
 * Copyright (c) 1993 HAL Computer Systems International, Ltd.
 * 
 *          HAL COMPUTER SYSTEMS INTERNATIONAL, LTD.
 *                  1315 Dell Avenue
 *                  Campbell, CA  95008
 *
 * Author: Greg Hilton
 * Contributors: Tom Lang, Frank Bieser, and others
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * http://www.gnu.org/copyleft/gpl.html
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#include "rsrc.h"
#include "HalTreeC.h"
#include "LayoutC.h"
#include "HalTreeNodeC.h"
#include "RectC.h"

// =====================================================================
// Constructor for the tree layout class.
// =====================================================================
LayoutC::LayoutC (HalTreeC* t, char* nm)
{
   name = nm;
   tree = t;
   childSpace    = get_int("HalTreeC", *tree, "childSpace",   40);
   siblingSpace  = get_int("HalTreeC", *tree, "siblingSpace", 5);
}


// =====================================================================
// This routine sets the amount of space that is placed between
// each child of a parent.
// =====================================================================
void
LayoutC::SetSiblingSpacing (int space)
{
   if ( space != siblingSpace ) {
      siblingSpace = space;
      tree->Draw();
   }
}


// =====================================================================
// This routine sets the amount of space that is placed between
// parent and the children.
// =====================================================================
void
LayoutC::SetChildSpacing (int space)
{
   if ( space != childSpace ) {
      childSpace = space;
      tree->Draw();
   }
}


// =====================================================================
// This is the default routine used to find a node under the input
// position.
// =====================================================================
HalTreeNodeC*
LayoutC::PickNode(int x, int y)
{
   HalTreeNodeC		*top = tree->TopLevelNode();
   HalTreeNodeListC&	topList = top->Children();
   HalTreeNodeC		*node = NULL;

//
// Use the root nodes as "base" nodes and call the recursive
// routine to find the node under foot.
//
   int	count = topList.size();
   for (int i=0; !node && i<count; i++) {
      node = PickNode(topList[i], x, y);
      if ( node ) break;
   }
   return node;
}


// =====================================================================
// This is the recursive routine used to find the node at the input
// position.
// =====================================================================
HalTreeNodeC*
LayoutC::PickNode(HalTreeNodeC* node, int x, int y)
{
   if ( node->Shown() ) {
//
//    See if this position is within the node's bounds
//
      RectC  bounds(node->x, node->y, node->wd, node->ht);
      if ( bounds.Inside(x, y) ) {
         node->picked = 1;
         return node;
      }

//
//    See if it's in any of the children.
//
      int	count = node->NumChildren();
      if ( count ) {
         // int x = node->x - node->ht/2 - node->regHt/2;
         // int y = node->y - node->ht/2 - node->regHt/2;
         // bounds.Set(node->regWd, node->regHt);
         // if ( bounds.Inside(x, y) )
         {
            HalTreeNodeListC&  childList = node->Children();
            HalTreeNodeC	   *pickNode = NULL;
//
//          Use the root nodes as "base" nodes and call the recursive
//          routine to find the node under foot.
//
            for (int i=0; i<count; i++) {
               pickNode = PickNode(childList[i], x, y);
               if ( pickNode ) return pickNode;
            }
         }
      }
   }

   return NULL;
}

// =====================================================================
// This is the default routine used to find all the nodes within the
// input region.
// =====================================================================
int
LayoutC::PickNodes(RectC& pickRect, HalTreeNodeListC& list)
{
   HalTreeNodeC		*top = tree->TopLevelNode();
   HalTreeNodeListC&	topList = top->Children();

   int count = topList.size();
   for (int i=0; i<count; i++)
      PickNode(topList[i], pickRect, list);

   return list.size();
}


// =====================================================================
// This is the recursive routine used to find the nodes inside the 
// pick rectangle.
// =====================================================================
void
LayoutC::PickNode(HalTreeNodeC* node, RectC& pickRect, HalTreeNodeListC& list)
{
//
// If this node touches the pick rectangle, include it.
//
   RectC  bounds(node->x, node->y, node->wd, node->ht);
   if ( bounds.Overlaps(pickRect) ) {
      node->picked = 1;
      list.add(node);
   }

//
// Check the children.
//
   int count = node->NumChildren();
   if ( count ) {
      // bounds.SetSize(node->regWd, node->regHt);
      // if ( bounds.Overlaps(pickRect) )
      {
          HalTreeNodeListC& childList = node->Children();
          for (int i=0; i<count; i++)
             PickNode(childList[i], pickRect, list);
      }
   }

} // End PickNode


// =====================================================================
// =====================================================================
void
LayoutC::DrawLine(HalTreeNodeC* node, int sx, int sy, int dx, int dy)
{
   if ( node->lineType == XmNO_LINE ) return;

   tree->busy++;

// DJL - Check to ensure that the line is within the required parameters.  All
// X calls are 16 bits, but the integer is 32 bits, which causes an overflow
// problem.  If need be, transform items down so that they will be within
// 16 bits.

   int src_x = sx - tree->world_x;
   int src_y = sy - tree->world_y;
   int dst_x = dx - tree->world_x;
   int dst_y = dy - tree->world_y;

   if (((src_x < 0) && (dst_x < 0)) ||
       ((src_x > tree->daWd) && (dst_x > tree->daWd)) ||
       ((src_y < 0) && (dst_y < 0)) ||
       ((src_y > tree->daHt) && (dst_y > tree->daHt))) {
     tree->busy--;
     return;
   }

// DJL - at this point, we know that the line will appear somewhere on the
// screen.  We now need to transform the points on the line to make sure that
// all are within the range of -32767 to 32767
#define MIN_DIM	-32767
#define MAX_DIM	 32767
   long rise = (long)(src_y - dst_y);
   long run = (long)(src_x - dst_x);

   if ((src_x < MIN_DIM) || (src_x > MAX_DIM)) {
     int old_src_x = src_x;
     if (src_x < MIN_DIM) 
       src_x = MIN_DIM;
     else
       src_x = MAX_DIM;
     if (run != 0) {
       long tmp = (rise * (long)(old_src_x - src_x)) / run;
       src_y -= (int)tmp;
     }
   }
     
   if ((dst_x < MIN_DIM) || (dst_x > MAX_DIM)) {
     int old_dst_x = dst_x;
     if (dst_x < MIN_DIM) 
       dst_x = MIN_DIM;
     else
       dst_x = MAX_DIM;
     if (run != 0) {
       long tmp = (rise * (long)(old_dst_x - dst_x)) / run;
       dst_y -= (int)tmp;
     }
   }
     
   if ((src_y < MIN_DIM) || (src_y > MAX_DIM)) {
     int old_src_y = src_y;
     if (src_y < MIN_DIM) 
       src_y = MIN_DIM;
     else
       src_y = MAX_DIM;
     if (rise != 0) {
       long tmp = (run * (long)(old_src_y - src_y)) / rise;
       src_x -= (int)tmp;
     }
   }
     
   if ((dst_y < MIN_DIM) || (dst_y > MAX_DIM)) {
     int old_dst_y = dst_y;
     if (dst_y < MIN_DIM) 
       dst_y = MIN_DIM;
     else
       dst_y = MAX_DIM;
     if (rise != 0) {
       long tmp = (run * (long)(old_dst_y - dst_y)) / rise;
       dst_x -= (int)tmp;
     }
   }

   XSetLineAttributes(tree->viewDSP, tree->viewGC, node->lineWidth,
                      LineSolid, CapButt, JoinBevel);

   Pixel line_color = node->lineColor;
   Pixel etch_color = node->lineEtchColor;
   if ( node->lineType == XmSHADOW_ETCHED_IN || 
        node->lineType == XmSHADOW_ETCHED_OUT )
   {
      if ( node->lineType == XmSHADOW_ETCHED_OUT )
      {
         line_color = node->lineEtchColor;
         etch_color = node->lineColor;
      }
      XSetForeground(tree->viewDSP, tree->viewGC, etch_color);
      XDrawLine (tree->viewDSP, tree->viewPm, tree->viewGC,
	         src_x+1, src_y+1, dst_x+1, dst_y+1);
   }

   XSetForeground(tree->viewDSP, tree->viewGC, line_color);
   XDrawLine (tree->viewDSP, tree->viewPm, tree->viewGC,
	      src_x, src_y, dst_x, dst_y);
   tree->busy--;
}
