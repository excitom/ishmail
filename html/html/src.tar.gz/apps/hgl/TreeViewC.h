/*
 *  $Id: TreeViewC.h,v 1.1 1998/06/24 01:29:07 lang Exp $
 *  
 *  Copyright (c) 1994 HAL Computer Systems International, Ltd.
 * 
 *          HAL COMPUTER SYSTEMS INTERNATIONAL, LTD.
 *                  1315 Dell Avenue
 *                  Campbell, CA  95008
 *
 * Author: Greg Hilton
 * Contributors: Tom Lang, Frank Bieser, and others
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * http://www.gnu.org/copyleft/gpl.html
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
#ifndef _TreeViewC_h_
#define _TreeViewC_h_

#include "ViewC.h"
#include "VItemC.h"
#include "VItemListC.h"
#include "PtrDictC.h"
#include "RectC.h"

class TreeDataC;

typedef enum {
   TREE_OUTLINE,
   TREE_ANGLED,
   TREE_SQUARED
} TreeStyleT;

/*-----------------------------------------------------------------------
 *  This class is used to display a set of view items hierarchically
 */

class TreeViewC : public ViewC {

public:

   TreeViewC(VBoxC*);
   ~TreeViewC();

   void		AddItem(VItemC&);// Add a view item to the display
   void		AddItems(const VItemListC&);// Add view items to the display
   char		*ButtonName() const;	// Return widget name for button
						// in popup menu used to display
						// this view
   void		ChangeItemFields(const VItemC&) {}
   void		ChangeItemLabel(const VItemC&);
   void		ChangeItemPixmaps(const VItemC&);
   void		ChangeItemVis();
   void		ChangeItemVis(const VItemC&);
   Widget	CreateDragIcon(VItemListC&);
   void		DropFinished();	// Signal completion of drop
   VItemC	*DropItem();	// Return current drop site
   void		Draw(RectC&);	// Draw the items within the rect

   void		FlashItem(const VItemC*);
   void		GetSize(int*, int*);
   void		HandleButton1Motion(XMotionEvent*);
   void		HandleButton1Press(XButtonEvent*);
   void		HandleButton1Release(XButtonEvent*);
   void		HandleDoubleClick(XButtonEvent*);
   void		HandleDragOver(XmDragProcCallbackStruct *);
   void		HandleKeyPress(XKeyEvent*);
   void		HandleSingleClick() {}
   void		HandleSingleClick(XButtonEvent*);
   void		Hide();		// Remove this view
   void		HighlightItem(const VItemC*);
   VItemC	*PickItem(int, int);// Return the item at the given point
   void		PickItems(RectC&, VItemListC&); // Return the items in the
						    // pick rect
   void		PlaceItems();	// Calculate positions
   void		Redraw();		// Redraw the items in this view
   void		RedrawItem(const VItemC&);	// Redraw the specified item
   void		RemoveItem(VItemC&);
   void		RemoveItems(const VItemListC&);
   void		ScrollToItem(const VItemC&);
   void		Show();		// Display this view
   void		printOn(ostream&) const {};
					// Print information about this view

//
// Compare two views
//
   int		operator==(const ViewC&  ) const { return 1; }
   inline int	operator!=(const ViewC& i) const { return !(*this==i); }

   int		compare  (const ViewC&  ) const { return 0; }
   inline int	operator<(const ViewC& i) const { return (compare(i) < 0); }
   inline int	operator>(const ViewC& i) const { return (compare(i) > 0); }

//
// TreeViewC-specific calls
//
   void		SetTreeStyle(TreeStyleT);
   void		SetRootGravity(int);
   void		SetGenerationSpacing(int);
   void		SetSiblingSpacing(int);
   void		SetLineStyle(int);
   void		SetLineWidth(int);
   void		SetCompress(Boolean);

   TreeStyleT	TreeStyle()		const { return treeStyle; }
   int		RootGravity()		const { return rootGravity; }
   int		GenerationSpacing()	const { return genSpacing; }
   int		SiblingSpacing()	const { return sibSpacing; }
   int		LineStyle()		const { return lineStyle; }
   int		LineWidth()		const { return lineWidth; }
   int		Compressed()		const { return compress; }

//
// Visibility
//
   void		Hide(VItemC*);
   void		HideChildren(VItemC*);
   void		Show(VItemC*);
   void		ShowChildren(VItemC*);
   void		ShowDescendants(VItemC*);

//
// Children
//
   int		VisChildCount(VItemC*);

protected:

//
// Drawing
//
   int		needWd;
   int		needHt;
   int		marginWd;
   int		marginHt;
   int		genSpacing;	// Spacing between generations
   int		sibSpacing;	// Spacing between siblings
   int		lineWidth;
   int		lineStyle;
   Boolean	compress;	
   Boolean	needPlaces;
   Pixel	bgColor;
   Pixel	lineColor;
   Pixel	etchColor;
   TreeStyleT	treeStyle;
   int		rootGravity;	// Which side root nodes are on

   void		CenterItem(VItemC*);
   void		CheckForBetterFit(TreeDataC*);
   void		DrawHighlight(VItemC*, Pixel);
   void		DrawHighlight(TreeDataC*, Pixel,
			      Drawable drawto=(Drawable)NULL);
   void         DrawItem(VItemC*, VItemDrawModeT mode=AS_IS,
			 Drawable drawto=(Drawable)NULL);
   void         DrawLines(VItemC*, Drawable drawto=(Drawable)NULL);
   void         DrawLine(int, int, int, int, Drawable drawto=(Drawable)NULL);
   int		GenerationCount(VItemC*);
   void		GetClosestFit(TreeDataC*, VItemC*, RectC*);
   void		GetDomain(VItemC*, int, RectC*);
   void		SetDomainPos(TreeDataC*, int, int);
   void		PlaceItem(VItemC*);

//
// Highlighting
//
   Boolean	focusHere;
   VItemC	*hlItem;
   Pixel	hlColor;
   int		hlThick;

   static void	HandleFocusChange  (Widget, TreeViewC*, XEvent*,      Boolean*);
   static void	HandlePointerMotion(Widget, TreeViewC*, XMotionEvent*,Boolean*);

   VItemC	*RootOf(VItemC*);
   VItemC	*FirstVisibleChild(VItemC*);
   VItemC	*LastVisibleChild(VItemC*);

//
// Flashing
//
   VItemC	*flashItem;
   XtIntervalId	flashTimer;
   int		flashCount;
   Boolean	flashOn;

   static void	FlashProc(TreeViewC*, XtIntervalId*);

//
// Drag-and-drop
//
   VItemC	*dropItem;
   Widget	dragIcon;
   Pixel	dropColor;

//
// Picking
//
   GC			pickGC;
   int			pickX;
   int			pickY;
   RectC		pickRect;
   VItemListC		pickList;
   int			pickState;
   VItemDrawModeT	pickDrawMode;	// Turn them on or off during pick

   int			clickCount;
   Time			lastClickTime;
   VItemC		*pressItem;

   void			UpdatePickRect(int, int);

//
// Scrolling
//
   XtIntervalId	scrollTimer;
   XMotionEvent	scrollEvent;            // Motion event that started scrolling
   char		*scrollAction;          // Auto scroll action

   static void	HandleAutoScroll(TreeViewC*, XtIntervalId*);

   void		ScrollToItem(TreeDataC*);

//
// Nodes
//
   PtrDictC	dataDict;

//
// Private methods
//
   void         _AddItem(VItemC&);	// Doesn't update the screen
   Boolean	DataValid  (const TreeDataC* data);
   Boolean	DataVisible(const TreeDataC* data);
};

#endif // _TreeViewC_h_
