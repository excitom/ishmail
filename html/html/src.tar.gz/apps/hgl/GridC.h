/*
 * $Id: GridC.h,v 1.1 1998/06/24 01:29:07 lang Exp $
 *
 * Copyright (c) 1992 HAL Computer Systems International, Ltd.
 * 
 *          HAL COMPUTER SYSTEMS INTERNATIONAL, LTD.
 *                  1315 Dell Avenue
 *                  Campbell, CA  95008
 *
 * Author: Greg Hilton
 * Contributors: Tom Lang, Frank Bieser, and others
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * http://www.gnu.org/copyleft/gpl.html
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#ifndef _GridC_h_
#define _GridC_h_

#include <Xm/Xm.h>

#include "WidgetListC.h"

//----------------------------------------------------------------------------
// Class definition

class GridC {

   Dimension	gridWd;		// Pixel width of gridBB
   Dimension	gridHt;		// Pixel height of gridBB
   int		cellWd;		// Pixel width  of each cell
   int		cellHt;		// Pixel height of each cell
   int		spacingWd;	// Horizontal gap between cells
   int		spacingHt;	// Vertical gap between cells
   Dimension	marginWd;
   Dimension	marginHt;
   Boolean	vResize;	// Automatically resize vertically
   Boolean	hResize;	// Automatically resize horizontally
   int		rowCnt;		// Number of cells vertically
   int		colCnt;		// Number of cells horizontally
   Boolean	*cellUsed;	// Pointer to cell usage array
   int		alloc;		// Number of cells allocated
   Boolean	deferred;
   int		deferCount;
   WidgetListC	childOrderList;
   Boolean	childTooLarge;	// if SetPosition finds a too-large child

   Widget	gridBB;			// Bulleting board for layout

   void		AllocateCells();	// Allocate memory for cells
   void		ClearCells();		// Reset usage array
   Boolean	SetPosition(Widget);	// Lay out specified child on grid
   Boolean	FindPosition(int rows, int cols, int *x, int *y);
   				// Find space for the specified number of
				//    rows and columns
   Boolean	CellsFree(int row, int col, int rows, int cols);
   				// See if the given range of cells is free
   void		MarkCells(int row, int col, int rows, int cols);
   				// Mark the given range of cells as used

   static void	HandleChildResize(Widget, GridC*, XEvent*, Boolean*);
   static void	HandleChildDeath (Widget, GridC*, XtPointer);

public:

//
// Cast to widget
//
   inline operator	Widget() const	 { return gridBB; }

   Boolean	Defer(Boolean on);
   Boolean	ManageChild(Widget child);
   Boolean	SetCellSize(int wd, int ht);
   Boolean	SetCellCount(int rows, int cols);
   Boolean	SetChildOrder(WidgetListC&);
   Boolean	SetPositions();	// Lay out children on grid
   void		UnmanageChild(Widget child);

// Constructors

   GridC(Widget parent, const char *name);
   ~GridC();

// Query

   MEMBER_QUERY(int,		CellWidth,		cellWd)
   MEMBER_QUERY(int,		CellHeight,		cellHt)
   MEMBER_QUERY(int,		HorizontalSpacing,	spacingWd)
   MEMBER_QUERY(int,		VerticalSpacing,	spacingHt)
   MEMBER_QUERY(Dimension,	MarginWidth,		marginWd)
   MEMBER_QUERY(Dimension,	MarginHeight,		marginHt)
   MEMBER_QUERY(Boolean,	ResizeVertical,		vResize)
   MEMBER_QUERY(Boolean,	ResizeHorizontal,	hResize)
   MEMBER_QUERY(int,		Rows,			rowCnt)
   MEMBER_QUERY(int,		Columns,		colCnt)
   MEMBER_QUERY(Boolean,	Deferred,		deferred)
};

#endif // _GridC_h_
