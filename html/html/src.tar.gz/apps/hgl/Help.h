/*
 * $Id: Help.h,v 1.1 1998/06/24 01:29:07 lang Exp $
 *
 * Copyright (c) 1992 HAL Computer Systems International, Ltd.
 * 
 *          HAL COMPUTER SYSTEMS INTERNATIONAL, LTD.
 *                  1315 Dell Avenue
 *                  Campbell, CA  95008
 *
 * Author: Greg Hilton
 * Contributors: Tom Lang, Frank Bieser, and others
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * http://www.gnu.org/copyleft/gpl.html
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#ifndef _Help_h_
#define _Help_h_

// Copyright (c) 1992, 1993 HAL Computer Systems International, Ltd.

/*
 * HaL On-Line Help support for GUI applications.
 *
 * This class allows GUI applications to access helpcards from a simple
 * (ascii, flat-file) database, and have them displayed in a Help Dialog.
 *
 * The GUI app should only create a single instance of this class.
 *
 */

#include <Xm/Xm.h>

#include "Db.h"
#include "Base.h"

class Help {
  
  public:

  Help();
  virtual ~Help();

#ifdef HELP_PREVIEW
  Help( const char *yourAppName, const Widget yourAppShell,
	const char *helpdbfilename );

  int init( const char *yourAppName, const Widget yourAppShell,
	    const char *helpdbfilename );
#else
  Help( const char *yourAppName, const Widget yourAppShell,
	const XrmDatabase db = NULL );

  int init( const char *yourAppName, const Widget yourAppShell,
	    const XrmDatabase db = NULL );
#endif

  void displayHelpIndex();
  
  int displayHelpcard( const Widget guiComponent,
		      const char *resourceName = NULL );
  
  int displayHelpcard( const char *helpcardResourceString );

  // Std Xt callback function.  'client data' should be your Help ptr.
  static void helpcardCB( Widget, XtPointer, XtPointer );

  int iconifyHelpDialog();
  void removeOliasButton();

  MEMBER_QUERY( int, ReturnStatus, _returnStatus )

  protected:

  private:

  XrmDatabase _appXrmDb;
  Db **_db;
  int _dbCount;
  Boolean _firstTime;
  int _returnStatus;

  char *_locator;

  Widget _appShell;  // Client apps AppShell to create help dialogs... 

  Widget _helpDialog, _title, _text;
  Widget _indexDialog, _indexScrollList, _indexView, _indexNext, _indexPrev;
  Widget _indexHelpDialog, _helpHelpDialog;
  Widget _errorDialog;

  static void helpDialogCB( const Widget, const Help *,
			    const XmAnyCallbackStruct * );

  static void indexDialogCB( const Widget, const Help *,
			     const XmAnyCallbackStruct * );

  static void indexScrollListCB( const Widget, Help *,
				 const XmListCallbackStruct * );

  static void indexViewCB( const Widget, Help *,
			   const XmPushButtonCallbackStruct * );
  static void indexNextCB( const Widget, Help *,
			   const XmPushButtonCallbackStruct * );
  static void indexPrevCB( const Widget, Help *,
			   const XmPushButtonCallbackStruct * );

  char *findHelpcard( const Widget, const char *resourceName = NULL );

  void displayErrorMsg( const char *msg, const char *helpcardName ) const;

  int showDialog( const char *cardName, const Widget w = NULL );
};

#endif
