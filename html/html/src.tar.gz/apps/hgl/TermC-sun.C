/*
 *  $Id: TermC-sun.C,v 1.1 1998/06/24 01:29:07 lang Exp $
 *  
 *  Copyright (c) 1994 HAL Computer Systems International, Ltd.
 * 
 *          HAL COMPUTER SYSTEMS INTERNATIONAL, LTD.
 *                  1315 Dell Avenue
 *                  Campbell, CA  95008
 *
 * Author: Greg Hilton
 * Contributors: Tom Lang, Frank Bieser, and others
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * http://www.gnu.org/copyleft/gpl.html
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
   int	pgrp = getpid();

   if ( debuglev > 0 )
      cout <<"Child  closing X: " <<ConnectionNumber(halApp->display) <<endl;
   close(ConnectionNumber(halApp->display));

   if ( debuglev > 0 ) cout <<"Child closing input: " <<inputFd <<endl;
   close(inputFd);

//
// Disconnect from parent tty
//
   int	tty = open("/dev/tty", O_RDWR);
   if ( tty >= 0 ) {
      ioctl(tty, TIOCNOTTY, 0);
      if ( debuglev > 0 ) cout <<"Child closing tty: " <<tty <<endl;
      close(tty);
   }

   tty = open(name, O_RDWR);

//
// Make this user the owner
//
   chown(name, uid, gid);
   chmod(name, 0622);

//
// Close all files
//
   for (int i=0; i<=2; i++) {
      if ( i != tty ) {
	 if ( debuglev > 0 ) cout <<"Child closing file: " <<i <<endl;
	 close(i);
	 dup(tty);
      }
   }

   if ( tty > 2 ) {
      if ( debuglev > 0 ) cout <<"Child closing tty: " <<tty <<endl;
      close(tty);
   }

   setsid();
   ioctl(0, TIOCSCTTY, 0);
   ioctl(0, TIOCSPGRP, (char *)&pgrp);

   setpgrp(0,0);
   close(open(name, O_WRONLY, 0));
   setpgrp(0, pgrp);

//
// Set user and group just to be safe
//
   setuid(uid);
   setgid(gid);

//
// Restore the child handler
//
   signal(SIGCHLD, SIG_DFL);
   sigsetmask(omask);
