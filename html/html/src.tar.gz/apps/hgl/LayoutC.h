/*
 * $Id: LayoutC.h,v 1.1 1998/06/24 01:29:07 lang Exp $
 *
 * Copyright (c) 1993 HAL Computer Systems International, Ltd.
 * 
 *          HAL COMPUTER SYSTEMS INTERNATIONAL, LTD.
 *                  1315 Dell Avenue
 *                  Campbell, CA  95008
 *
 * Author: Greg Hilton
 * Contributors: Tom Lang, Frank Bieser, and others
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * http://www.gnu.org/copyleft/gpl.html
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#ifndef _LayoutC_h_
#define _LayoutC_h_

#include <X11/Intrinsic.h>
#include "StringC.h"


enum LayoutDirT  { LEFT_TO_RIGHT, RIGHT_TO_LEFT,
		   TOP_TO_BOTTOM, BOTTOM_TO_TOP };

// =====================================================================
// This class is used as an abstract class for the HalTreeC class as means
// to arrange HalTree Nodes and subsequently draw extra stuff like lines.
//
// NOTE** Any class using this as an abstract is responsible for doing
//        the following:
//          1) Set the "shown" value of each node, which should account
//             for the fact that a node can exist without a widget.
//          2) Setting the "numChildrenShown" for each node.  If done
//             during the Layout() phase this is painless.
//          3) Set the subregions of the individual nodes.
//          4) Determine the necessary size of the HalTree to fit
//             all the nodes.
// =====================================================================

class HalTreeC;
class HalTreeNodeC;
class HalTreeNodeListC;
class RectC;

class LayoutC
{
   protected:

      HalTreeC*	tree;
      StringC	name;		// name of type of layout
      int	childSpace;     // space between parent and child.
      int	siblingSpace;   // space between siblings.(each child)
      Boolean   redrawing;

//
// These are the private methods for the default pick routines.
//
   private:
      HalTreeNodeC* PickNode(HalTreeNodeC*, int, int);
      void          PickNode(HalTreeNodeC*, RectC&, HalTreeNodeListC&);

   public:

      LayoutC(HalTreeC*, char*);
      virtual  ~LayoutC() {}

      virtual  void  Draw()        = 0;  	// Layout and draw everything.
      virtual  void  Redraw()      = 0;  	// draw lines refresh, scroll
      void           DrawLine(HalTreeNodeC* node, int, int, int, int);

      void  SetChildSpacing(int);
      void  SetSiblingSpacing(int);

      inline  int  operator==(const LayoutC& i) const { return(name==i.name); }
      inline  int  operator!=(const LayoutC& i) const { return !(*this==i); }
      inline  int  compare(const LayoutC& i)    const { return(name==i.name); }
      inline  int  operator<(const LayoutC& i)  const { return(compare(i)<0); }
      inline  int  operator>(const LayoutC& i)  const { return(compare(i)>0); }
      // inline   int   compare(const LayoutC&)      const { return strcmp((char*)name,(char*)i.name); }

      HalTreeNodeC*     PickNode(int x, int y);
      int		PickNodes(RectC&, HalTreeNodeListC&);
   
   public:

      MEMBER_QUERY(StringC,	Name,			name);
         PTR_QUERY(HalTreeC*,	HalTree,		tree);
      MEMBER_QUERY(int,		ChildSpacing,		childSpace);
      MEMBER_QUERY(int,		SiblingSpacing,		siblingSpace);

   // friend HalTreeC;
};

//
// Method for printing a Layout type.
// 
inline ostream&
operator << (ostream& strm, const LayoutC& t) { strm << t.Name(); return strm; }
// operator << (ostream& strm, const LayoutC& t) { return t.Name(); }

#endif
