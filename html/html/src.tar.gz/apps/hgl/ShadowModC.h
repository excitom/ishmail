/*
 * $Id: ShadowModC.h,v 1.1 1998/06/24 01:29:07 lang Exp $
 *
 * Copyright (c) 1992 HAL Computer Systems International, Ltd.
 * 
 *          HAL COMPUTER SYSTEMS INTERNATIONAL, LTD.
 *                  1315 Dell Avenue
 *                  Campbell, CA  95008
 *
 * Author: Greg Hilton
 * Contributors: Tom Lang, Frank Bieser, and others
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * http://www.gnu.org/copyleft/gpl.html
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#ifndef _ShadowModC_h_
#define _ShadowModC_h_

#include "Base.h"

#include <Xm/Xm.h>

class ShadowModC {

   Widget	form;
   Widget	typeLabel;
   Widget	typeFrame;
   Widget	thickLabel;
   Widget	thickTF;
   Widget	typeRadioBox;
   Widget	inTB;
   Widget	outTB;
   Widget	etchInTB;
   Widget	etchOutTB;

//
// Current state
//
   unsigned char	type;

//
// Initial state
//
   struct {
      unsigned char	type;
      Dimension		thick;
   } init;

//
// Callbacks
//
   static void	SetType (Widget, ShadowModC*, XmToggleButtonCallbackStruct*);

public:

// Methods

   ShadowModC(Widget, const char*, ArgList argv=NULL, Cardinal argc=0);

//
// Cast to widget
//
   inline operator	Widget() const		{ return form;	}

//
// Return component widgets
//
   MEMBER_QUERY(Widget, Form,         form)
   MEMBER_QUERY(Widget, TypeLabel,    typeLabel)
   MEMBER_QUERY(Widget, TypeFrame,    typeFrame)
   MEMBER_QUERY(Widget, ThickLabel,   thickLabel)
   MEMBER_QUERY(Widget, ThickTF,      thickTF)
   MEMBER_QUERY(Widget, TypeRadioBox, typeRadioBox)
   MEMBER_QUERY(Widget, InTB,         inTB)
   MEMBER_QUERY(Widget, OutTB,        outTB)
   MEMBER_QUERY(Widget, EtchInTB,     etchInTB)
   MEMBER_QUERY(Widget, EtchOutTB,    etchOutTB)

//
// Return the settings
//
   inline unsigned char		Type()		{ return type; }
   Dimension			Thickness();

//
// Initialize settings
//
   void		Init(unsigned char, Dimension);

//
// Change settings back to initial values
//
   void		Reset();
};

#endif // _ShadowModC_h_
