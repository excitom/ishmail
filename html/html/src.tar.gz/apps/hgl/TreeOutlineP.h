/*
 * $Id: TreeOutlineP.h,v 1.1 1998/06/24 01:29:07 lang Exp $
 *
 * Copyright (c) 1991 HaL Computer Systems, Inc.  All rights reserved.
 * 
 *          HAL COMPUTER SYSTEMS INTERNATIONAL, LTD.
 *                  1315 Dell Avenue
 *                  Campbell, CA  95008
 *
 * Author: Greg Hilton
 * Contributors: Tom Lang, Frank Bieser, and others
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * http://www.gnu.org/copyleft/gpl.html
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
/*
 * $XConsortium: TreeP.h,v 1.13 90/04/13 16:39:54 jim Exp $
 *
 * Copyright 1990 Massachusetts Institute of Technology
 * Copyright 1989 Prentice Hall
 *
 * Permission to use, copy, modify, and distribute this software for any
 * purpose and without fee is hereby granted, provided that the above
 * copyright notice appear in all copies and that both the copyright notice
 * and this permission notice appear in supporting documentation.
 * 
 * M.I.T., Prentice Hall and the authors disclaim all warranties with regard
 * to this software, including all implied warranties of merchantability and
 * fitness.  In no event shall M.I.T., Prentice Hall or the authors be liable
 * for any special, indirect or cosequential damages or any damages whatsoever
 * resulting from loss of use, data or profits, whether in an action of
 * contract, negligence or other tortious action, arising out of or in
 * connection with the use or performance of this software.
 * 
 * Authors:  Jim Fulton, MIT X Consortium,
 *           based on a version by Douglas Young, Prentice Hall
 * 
 * This widget is based on the Tree widget described on pages 397-419 of
 * Douglas Young's book "The X Window System, Programming and Applications 
 * with Xt OSF/Motif Edition."  The layout code has been rewritten to use
 * additional blank space to make the structure of the graph easier to see
 * as well as to support vertical trees.
 */


#ifndef _XawTreeOutlineP_h
#define _XawTreeOutlineP_h

#include "TreeOutline.h"

typedef struct _TreeOutlineClassPart {
    int ignore;
} TreeOutlineClassPart;

typedef struct _TreeOutlineClassRec {
    CoreClassPart core_class;
    CompositeClassPart composite_class;
    ConstraintClassPart constraint_class;
    TreeOutlineClassPart treeOutline_class;
} TreeOutlineClassRec;

extern TreeOutlineClassRec treeOutlineClassRec;

typedef struct {
    /* fields available through resources */
    Dimension hpad;			/* hSpace/HSpace */
    Dimension vpad;			/* vSpace/VSpace */
    Dimension line_width;		/* lineWidth/LineWidth */
    Pixel foreground;			/* foreground/Foreground */
    XtGravity gravity;			/* gravity/Gravity */
    Boolean auto_reconfigure;		/* autoReconfigure/AutoReconfigure */
    XtTreeOutlineType tree_outline;	/* treeOutline/TreeOutline */
    /* private fields */
    GC gc;				/* used to draw lines */
    Widget treeOutline_root;			/* hidden root off all children */
    Dimension *largest;			/* list of largest per depth */
    int n_largest;			/* number of elements in largest */
    Dimension maxwidth, maxheight;	/* for shrink wrapping */
    unsigned int in_change_managed;	/* flag to prevent recursive calls to ChangedManaged */
    unsigned int internal_rm_count;	/* pending child removals we know about */
} TreeOutlinePart;


typedef struct _TreeOutlineRec {
    CorePart core;
    CompositePart composite;
    ConstraintPart constraint;
    TreeOutlinePart treeOutline;
}  TreeOutlineRec;


/*
 * structure attached to all children
 */
typedef struct _TreeOutlineConstraintsPart {
    /* resources */
    Widget parent;			/* treeOutlineParent/TreeOutlineParent */
    GC gc;				/* treeOutlineGC/TreeOutlineGC */
    /* private data */
    Widget *children;
    int n_children;
    int max_children;
    Dimension bbsubwidth, bbsubheight;	/* bounding box of sub treeOutline */
    Dimension bbwidth, bbheight;	/* bounding box including node */
    Position x, y;
    unsigned int internal_rm;
} TreeOutlineConstraintsPart;

typedef struct _TreeOutlineConstraintsRec {
   TreeOutlineConstraintsPart treeOutline;
} TreeOutlineConstraintsRec, *TreeOutlineConstraints;


/*
 * useful macros
 */

#define TREEOUTLINE_CONSTRAINT(w) \
                   ((TreeOutlineConstraints)((w)->core.constraints))

#define TREEOUTLINE_INITIAL_DEPTH 10		/* for allocating largest array */
#define TREEOUTLINE_HORIZONTAL_DEFAULT_SPACING 20
#define TREEOUTLINE_VERTICAL_DEFAULT_SPACING 6

#endif /* _XawTreeOutlineP_h */



