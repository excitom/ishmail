/*
 * $Id: StripChartModC.h,v 1.1 1998/06/24 01:29:07 lang Exp $
 *
 * Copyright (c) 1992 HAL Computer Systems International, Ltd.
 * 
 *          HAL COMPUTER SYSTEMS INTERNATIONAL, LTD.
 *                  1315 Dell Avenue
 *                  Campbell, CA  95008
 *
 * Author: Greg Hilton
 * Contributors: Tom Lang, Frank Bieser, and others
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * http://www.gnu.org/copyleft/gpl.html
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#ifndef _StripChartModC_h_
#define _StripChartModC_h_

#include "StripChartC.h"
#include "ModFormC.h"
#include "ValueC.h"

#include <Xm/Xm.h>

class FormatModC;
class ShadowModC;
class ColorModC;

class StripChartModC : public ModFormC {

   ShadowModC	*shadowForm;
   Widget	tick1LenLabel;
   Widget	tick1LenTF;
   Widget	tick2LenLabel;
   Widget	tick2LenTF;
   Widget	margWdLabel;
   Widget	margWdTF;
   Widget	margHtLabel;
   Widget	margHtTF;
   Widget	xFrame;
   Widget	xTitle;
   Widget	xForm;
   Widget	xTick1SpaceLabel;
   Widget	xTick1SpaceTF;
   Widget	xGrid1TB;
   Widget	xTick2SpaceLabel;
   Widget	xTick2SpaceTF;
   Widget	xGrid2TB;
   Widget	visCountLabel;
   Widget	visCountTF;
   Widget	maxCountLabel;
   Widget	maxCountTF;
   Widget	yFrame;
   Widget	yTitle;
   Widget	yForm;
   Widget	minLabel;
   Widget	minTF;
   Widget	maxLabel;
   Widget	maxTF;
   Widget	yTick1SpaceLabel;
   Widget	yTick1SpaceTF;
   Widget	yGrid1TB;
   Widget	yTick2SpaceLabel;
   Widget	yTick2SpaceTF;
   Widget	yGrid2TB;
   FormatModC	*formatForm;
   ColorModC	*colorForm[StripChartC::COLOR_ATTR_COUNT];
   StripChartC	*chart;

//
// Initial values
//
   struct {
      int		tick1Len;
      int		tick2Len;
      Dimension		marginWd;
      Dimension		marginHt;
      int		xTick1Space;
      int		xTick2Space;
      Boolean		xGrid1;
      Boolean		xGrid2;
      int		visCount;
      int		maxCount;
      ValueC		minVal;
      ValueC		maxVal;
      ValueC		yTick1Space;
      ValueC		yTick2Space;
      Boolean		yGrid1;
      Boolean		yGrid2;
   } init;

//
// Auto apply callbacks
//
   void		EnableAutoApply();
   void 	DisableAutoApply();
   void 	ChangeColor(StripChartC::StripChartColorAttr);

   static void	ChangeShadow	  (Widget, StripChartModC*,
                                   XmToggleButtonCallbackStruct*);
   static void	ChangeShadowThick (Widget, StripChartModC*, XtPointer);
   static void	ChangeTickLength  (Widget, StripChartModC*, XtPointer);
   static void	ChangeMargin      (Widget, StripChartModC*, XtPointer);
   static void	ChangeXTickSpace  (Widget, StripChartModC*, XtPointer);
   static void	ChangeXGrid       (Widget, StripChartModC*,
				   XmToggleButtonCallbackStruct*);
   static void	ChangeVisCount    (Widget, StripChartModC*, XtPointer);
   static void	ChangeMaxCount    (Widget, StripChartModC*, XtPointer);
   static void	ChangeRange       (Widget, StripChartModC*, XtPointer);
   static void	ChangeYTickSpace  (Widget, StripChartModC*, XtPointer);
   static void	ChangeYGrid       (Widget, StripChartModC*,
				   XmToggleButtonCallbackStruct*);
   static void	ChangeFormat	  (Widget, StripChartModC*,
                                   XmToggleButtonCallbackStruct*);
   static void	ChangeFormatPrecis(Widget, StripChartModC*, XtPointer);
   static void	ChangeBackground  (Widget, StripChartModC*, XtPointer);
   static void	ChangeChartColor  (Widget, StripChartModC*, XtPointer);
   static void	ChangeLineColor   (Widget, StripChartModC*, XtPointer);
   static void	ChangeAxisColor   (Widget, StripChartModC*, XtPointer);
   static void	ChangeLabelColor  (Widget, StripChartModC*, XtPointer);
   static void	ChangeTickColor   (Widget, StripChartModC*, XtPointer);
   static void	ChangeGridColor   (Widget, StripChartModC*, XtPointer);
   static void	ChangeMarkColor   (Widget, StripChartModC*, XtPointer);
   static void	ChangeTopShadow   (Widget, StripChartModC*, XtPointer);
   static void	ChangeBottomShadow(Widget, StripChartModC*, XtPointer);

public:

// Methods

   StripChartModC(Widget, const char*, ArgList argv=NULL, Cardinal argc=0);
   ~StripChartModC();

   MEMBER_QUERY(Widget,      MajorTickLengthLabel,   tick1LenLabel)
   MEMBER_QUERY(Widget,      MajorTickLengthTF,      tick1LenTF)
   MEMBER_QUERY(Widget,      MinorTickLengthLabel,   tick2LenLabel)
   MEMBER_QUERY(Widget,      MinorTickLengthTF,      tick2LenTF)
   MEMBER_QUERY(Widget,      MarginWidthLabel,       margWdLabel)
   MEMBER_QUERY(Widget,      MarginWidthTF,          margWdTF)
   MEMBER_QUERY(Widget,      MarginHeightLabel,      margHtLabel)
   MEMBER_QUERY(Widget,      MarginHeightTF,         margHtTF)
   MEMBER_QUERY(Widget,      XAxisFrame,             xFrame)
   MEMBER_QUERY(Widget,      XAxisTitle,             xTitle)
   MEMBER_QUERY(Widget,      XAxisForm,              xForm)
   MEMBER_QUERY(Widget,      MajorXTickSpacingLabel, xTick1SpaceLabel)
   MEMBER_QUERY(Widget,      MajorXTickSpacingTF,    xTick1SpaceTF)
   MEMBER_QUERY(Widget,      MajorXGridTB,           xGrid1TB)
   MEMBER_QUERY(Widget,      MinorXTickSpacingLabel, xTick2SpaceLabel)
   MEMBER_QUERY(Widget,      MinorXTickSpacingTF,    xTick2SpaceTF)
   MEMBER_QUERY(Widget,      MinorXGridTB,           xGrid2TB)
   MEMBER_QUERY(Widget,      VisibleValueCountLabel, visCountLabel)
   MEMBER_QUERY(Widget,      VisibleValueCountTF,    visCountTF)
   MEMBER_QUERY(Widget,      MaximumValueCountLabel, maxCountLabel)
   MEMBER_QUERY(Widget,      MaximumValueCountTF,    maxCountTF)
   MEMBER_QUERY(Widget,      YAxisFrame,             yFrame)
   MEMBER_QUERY(Widget,      YAxisTitle,             yTitle)
   MEMBER_QUERY(Widget,      YAxisForm,              yForm)
   MEMBER_QUERY(Widget,      MinLabel,               minLabel)
   MEMBER_QUERY(Widget,      MinTF,                  minTF)
   MEMBER_QUERY(Widget,      MaxLabel,               maxLabel)
   MEMBER_QUERY(Widget,      MaxTF,                  maxTF)
   MEMBER_QUERY(Widget,      MajorYTickSpacingLabel, yTick1SpaceLabel)
   MEMBER_QUERY(Widget,      MajorYTickSpacingTF,    yTick1SpaceTF)
   MEMBER_QUERY(Widget,      MajorYGridTB,           yGrid1TB)
   MEMBER_QUERY(Widget,      MinorYTickSpacingLabel, yTick2SpaceLabel)
   MEMBER_QUERY(Widget,      MinorYTickSpacingTF,    yTick2SpaceTF)
   MEMBER_QUERY(Widget,      MinorYGridTB,           yGrid2TB)
   MEMBER_QUERY(FormatModC&, FormatForm,            *formatForm)
   MEMBER_QUERY(ShadowModC&, ShadowForm,            *shadowForm)

   void		Apply(StripChartC&);
   void		Init(StripChartC&);
   void		Reset();
};

#endif // _StripChartModC_h_
