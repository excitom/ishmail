/*
 * $Id: TreeC.C,v 1.1 1998/06/24 01:29:07 lang Exp $
 *
 * Copyright (c) 1992 HAL Computer Systems International, Ltd.
 * 
 *          HAL COMPUTER SYSTEMS INTERNATIONAL, LTD.
 *                  1315 Dell Avenue
 *                  Campbell, CA  95008
 *
 * Author: Greg Hilton
 * Contributors: Tom Lang, Frank Bieser, and others
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * http://www.gnu.org/copyleft/gpl.html
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

# include <stream.h>
# include <stdlib.h>
# include <assert.h>
# include "TreeC.h"
# include <Xm/RowColumn.h>
# include <Xm/PushB.h>
# include <Xm/ScrolledW.h>

//////////////////////////////////////////////////////////
//  TreeItemC
///////////////////////////////////////////////////////////

TreeItemC::TreeItemC (TreeC &tree, TreeItemC *treeParent): _tree (tree) {
    //
    //  Housekeeping -- save the widget and add this guy to
    //  the tree's current list.
    //
    _widget = 0;
    _treeParent = treeParent;
}

TreeItemC::~TreeItemC () {
    _tree.items().remove (this);
    if (_widget) {
	XtRemoveCallback (_widget, XmNdestroyCallback, (XtCallbackProc) widgetDestroyedCB, (XtPointer) this);
	destroyed ();
	XawTreeOutlineDestroySubtree (_widget);
    }
}

void
TreeItemC::initialize () {
    assert (_widget != NULL);
    XtAddCallback (_widget, XmNdestroyCallback, (XtCallbackProc) widgetDestroyedCB, (XtPointer) this);
    XtAddEventHandler (_widget, StructureNotifyMask, False, (XtEventHandler) mapNotify, (XtPointer) this);
    _tree.items().add (this);

    //
    //  Set up the child so it appears in the correct place in the tree
    //
    if (_treeParent)
	XtVaSetValues (_widget, XtNtreeOutlineParent, (Widget) *_treeParent, NULL);

}

unsigned int
TreeItemC::depth () {
    TreeItemC *myParent = parent ();
    for (unsigned int i = 0; myParent != 0; i ++)
	myParent = myParent->parent ();
    return i;
}

TreeItemC *
TreeItemC::parent () {
    Widget myParent;
    XtVaGetValues (_widget, XtNtreeOutlineParent, &myParent, NULL);
    return _tree.items().lookup (myParent);
}

TreeItemListC
TreeItemC::children () {
    TreeItemListC kidItems;
    const TreeItemListC &items = _tree.items ();
    for (int i = 0; i < items.size (); i ++) {
	if (items[i]->parent () == this)
	    kidItems.add (items[i]);
    }
    return kidItems;
}

TreeItemListC
TreeItemC::siblings () {
    TreeItemC *myParent = parent ();
    TreeItemListC mySiblings;
    if (myParent)
	mySiblings = myParent->children ();
    else
	mySiblings = _tree.roots ();
    mySiblings.remove (this);
    return mySiblings;
}

void
TreeItemC::hide (Boolean layout) {
    if (XtIsManaged (_widget)) {
	XtUnmanageChild (_widget);
    }
    if (layout)
	_tree.layout();
}

void
TreeItemC::hideChildren (Boolean layout) {
    TreeItemListC kids = children ();
    for (int i = 0; i < kids.size (); i ++)
	if (XtIsManaged (kids[i]->_widget)) {
	    XtUnmanageChild (kids[i]->_widget);
	}
    if (layout)
	_tree.layout();
}

void
TreeItemC::hideSiblings (Boolean layout) {
    TreeItemListC sibs = siblings ();
    for (int i = 0; i < sibs.size (); i ++)
	if (XtIsManaged (sibs[i]->_widget))
	    XtUnmanageChild (sibs[i]->_widget);
    if (layout)
	_tree.layout();
}

void
TreeItemC::show (Boolean layout) {
    if (!XtIsManaged (_widget))
	XtManageChild (_widget);
    if (layout)
	_tree.layout();
}

//
//  Show Children. If we're in one-level mode
//  and this child has a parent, and the parent
//  is visible, we need to reparent this node
//  and hide the old root.
//
void
TreeItemC::showChildren (Boolean layout) {
    TreeItemListC kids = children ();
    if (kids.size () == 0)
	return;
    for (int i = 0; i < kids.size (); i ++)
	kids[i]->show (False);
    if (_tree.displayMode () == TREE_DISPLAY_ONE_LEVEL)
	hideParent (False);
    if (layout)
	_tree.layout();
}

void
TreeItemC::showDescendants (Boolean layout) {
    TreeItemListC kids = children ();
    for (int i = 0; i < kids.size (); i ++)
	kids[i]->recursiveShow ();
    if (layout)
	_tree.layout();
}

void
TreeItemC::showSubtree (Boolean layout) {
    recursiveShow ();
    if (layout)
	_tree.layout();
}

void
TreeItemC::showSiblings (Boolean layout) {
    TreeItemListC sibs = siblings ();
    for (int i = 0; i < sibs.size (); i ++) {
	if (!XtIsManaged (sibs[i]->_widget)) {
	    XtManageChild (sibs[i]->_widget);
	}
    }
    if (layout)
	_tree.layout();
}

//
//  Show parent -- if the parent is hidden, show
//  the parent and all of it's other siblings.
//
void
TreeItemC::showParent (Boolean layout) {
    if (!_treeParent || _treeParent->visible ())
	return;

    //
    //  The parent is invisible, meaning it has
    //  been pruned. Need to (1) reparent this
    //  item, (2) reparent the parent to be a
    //  root, (3) show the parent, and (4) show
    //  the parent's children.
    //
    XtVaSetValues (_widget, XtNtreeOutlineParent, (Widget) *_treeParent, NULL);
    XtVaSetValues (*_treeParent, XtNtreeOutlineParent, NULL, NULL);
    _treeParent->show (False);
    _treeParent->showChildren (False);
    if (_tree.displayMode () == TREE_DISPLAY_ONE_LEVEL)
	hideChildren (False);
    if (layout)
	_tree.layout();
}

//
//  Hide the parent of this node (and the entire ancestor tree)
//
void
TreeItemC::hideParent (Boolean layout) {
    if (!_treeParent || !(_treeParent->visible ()))
	return;
    TreeItemC *current, *parent;
    for (current = this, parent = current->parent (); parent; parent = current->parent ())
	current = parent;
    XtVaSetValues (_widget, XtNtreeOutlineParent, NULL, NULL);
    current->hide (False);
    if (layout)
	_tree.layout();
}

Boolean
TreeItemC::visible () {
    if (XtIsManaged (_widget))
	return True;
    return False;
}

Boolean
TreeItemC::anyChildrenShown () {
    TreeItemListC kids = children ();
    for (int i = 0; i < kids.size (); i ++)
	if (kids[i]->visible ())
	    return True;
    return False;
}

void
TreeItemC::removeChildren () {
    XawTreeOutlineDestroyChildren (_widget);
}

void
TreeItemC::recursiveShow () {
    if (!XtIsManaged (_widget))
	XtManageChild (_widget);
    TreeItemListC kids = children ();
    for (int i = 0; i < kids.size (); i ++)
	kids[i]->recursiveShow ();
}

TreeC &
TreeItemC::tree () {
    return _tree;
}

TreeItemC::operator Widget () {
    return _widget;
}

void
TreeItemC::hideSubtreeCB (Widget, TreeItemC *thisObj, XtPointer) {
    thisObj->hide ();
}

void
TreeItemC::hideChildrenCB (Widget, TreeItemC *thisObj, XtPointer) {
    thisObj->hideChildren ();
}

void
TreeItemC::hideSiblingsCB (Widget, TreeItemC *thisObj, XtPointer) {
    thisObj->hideSiblings ();
}

void
TreeItemC::showDescendantsCB (Widget, TreeItemC *thisObj, XtPointer) {
    thisObj->showDescendants ();
}

void
TreeItemC::showChildrenCB (Widget, TreeItemC *thisObj, XtPointer) {
    thisObj->showChildren ();
}

void
TreeItemC::showSiblingsCB (Widget, TreeItemC *thisObj, XtPointer) {
    thisObj->showSiblings ();
}

void
TreeItemC::widgetDestroyedCB (Widget, TreeItemC *thisObj, XtPointer) {
    thisObj->_widget = 0;
    thisObj->destroyed ();
    delete thisObj;
}

void
TreeItemC::mapNotify (Widget, TreeItemC *thisObj, XEvent *event, Boolean *) {
    if (event->type == MapNotify) {
	thisObj->shown ();
    } else if (event->type == UnmapNotify) {
	thisObj->hidden ();
    }
}

//////////////////////////////////////////////////////////
//  TreeItemListC
///////////////////////////////////////////////////////////

const int TreeItemListC::allocSize = 16;

TreeItemListC::TreeItemListC () {
    _listSize = 0;
    _nItems = 0;
    _items = 0;
}

TreeItemListC::TreeItemListC (const TreeItemListC &til) {
    _listSize = til._listSize;
    _nItems = til._nItems;
    _items = 0;
    if (_listSize) {
	_items = new TreeItemC *[_listSize];
	for (int i = 0; i < _nItems; i ++)
	    _items[i] = til._items[i];
    }
}

TreeItemListC::~TreeItemListC () {
    delete _items;
}

void
TreeItemListC::add (const TreeItemC *item) {
    if (_nItems == _listSize) {
	TreeItemC **newItems = new TreeItemC *[_listSize += allocSize];
	for (int i = 0; i < _nItems; i ++)
	    newItems[i] = _items[i];
	    delete _items;
	    _items = newItems;
    }
    _items[_nItems ++] = (TreeItemC *) item;
}

void
TreeItemListC::removeAll () {
    _nItems = 0;
}

void
TreeItemListC::remove (const TreeItemC *item) {
    for (int i = 0; i < _nItems; i ++)
	if (_items[i] == item)
	    break;
    for (i ++; i < _nItems; i ++)
	_items[i - 1] = _items[i];
    _nItems --;
}

unsigned int
TreeItemListC::size () const {
    return _nItems;
}

Boolean
TreeItemListC::inList (const TreeItemC *item) const {
    for (int i = 0; i < _nItems; i ++)
	if (_items[i] == item)
	    return True;
    return False;
}

TreeItemC *
TreeItemListC::lookup (Widget w) const {
    for (int i = 0; i < _nItems; i ++) {
	if (((Widget) *(_items[i])) == w)
	    return _items[i];
    }
    return 0;
}

TreeItemC *
TreeItemListC::operator [] (const int i) const {
    if (i < 0 || i >= _nItems) {
	cerr << "Bad index \"" << i << "\" in TreeItemListC::operator[]\n";
	abort ();
    }
    return _items[i];
}

TreeItemListC &
TreeItemListC::operator = (const TreeItemListC &l) {
    if (&l == this)
	return *this;
    delete _items;
    _items = 0;
    _nItems = l._nItems;
    _listSize = l._listSize;
    if (_listSize) {
	_items = new TreeItemC *[_listSize];
	for (int i = 0; i < _nItems; i ++)
	    _items[i] = l._items[i];
    }
    return *this;
}

//////////////////////////////////////////////////////////
//  Tree
///////////////////////////////////////////////////////////

TreeC::TreeC (Widget parent, char *name, TreeDisplayMode displayMode) {
    _sw = XtVaCreateManagedWidget (name, xmScrolledWindowWidgetClass, parent,
		XmNscrollBarDisplayPolicy, XmAUTOMATIC,
		XmNscrollingPolicy, XmSTATIC,
		XmNvisualPolicy, XmCONSTANT,
		NULL);
    _tree = XtVaCreateManagedWidget ("tree", treeOutlineWidgetClass, _sw,
		XtNautoReconfigure, False,
		XtNtreeOutline, XtOUTLINE,
		NULL);
    _displayMode = displayMode;
    _deferred    = False;
    _deferCount  = 0;
}

TreeC::~TreeC () {
    erase ();
    XtDestroyWidget (_tree);
}


void
TreeC::Defer(Boolean on) {
   if      ( on )       _deferCount++;
   else if ( _deferred ) _deferCount--;

   _deferred = (_deferCount > 0);

   if ( !_deferred ) layout();
}


void
TreeC::MakeEast () {
    XtVaSetValues(_tree, XtNgravity, WestGravity, NULL);	
    XawTreeOutlineForceLayout(_tree);
}


void
TreeC::MakeWest () {
    XtVaSetValues(_tree, XtNgravity, WestGravity, NULL);	
    XawTreeOutlineForceLayout(_tree);
}


void
TreeC::MakeNorth () {
    XtVaSetValues(_tree, XtNgravity, WestGravity, NULL);	
    XawTreeOutlineForceLayout(_tree);
}


void
TreeC::MakeSouth () {
    XtVaSetValues(_tree, XtNgravity, WestGravity, NULL);	
    XawTreeOutlineForceLayout(_tree);
}


void
TreeC::MakeTree () {
    XtTreeOutlineType type = XtTREE;
    XtVaSetValues(_tree, XtNtreeOutline, type, NULL);	
    XawTreeOutlineForceLayout(_tree);
}

void
TreeC::MakeOutline () {
    XtTreeOutlineType type = XtOUTLINE;
    XtVaSetValues(_tree, XtNtreeOutline, type, NULL);	
    XawTreeOutlineForceLayout(_tree);
}

void
TreeC::erase () {
    while (_list.size () > 0)
	delete _list[0];
}

TreeItemListC &
TreeC::items () {
    return _list;
}

TreeC::operator Widget () {
    return _tree;
}

Widget
TreeC::scrolledWindow () {
    return _sw;
}

void
TreeC::layout() {
    if ( !_deferCount && XtIsRealized (_tree)) {
	XawTreeOutlineForceLayout (_tree);
    }
}

TreeItemListC
TreeC::roots () {
    TreeItemListC theRoots;
    for (int i = 0; i < _list.size (); i ++)
	if (_list[i]->depth () == 0)
	    theRoots.add (_list[i]);
    return theRoots;
}

void
TreeC::displayMode (TreeDisplayMode newMode) {
    if (newMode == _displayMode || (_displayMode = newMode) == TREE_DISPLAY_MANUAL)
	return;
    //
    //  Trim the tree here.
    //
}

TreeDisplayMode
TreeC::displayMode () {
    return _displayMode;
}
