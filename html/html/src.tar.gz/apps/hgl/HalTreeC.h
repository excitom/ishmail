/*
 * $Id: HalTreeC.h,v 1.1 1998/06/24 01:29:07 lang Exp $
 *
 * Copyright (c) 1993 HAL Computer Systems International, Ltd.
 * 
 *          HAL COMPUTER SYSTEMS INTERNATIONAL, LTD.
 *                  1315 Dell Avenue
 *                  Campbell, CA  95008
 *
 * Author: Greg Hilton
 * Contributors: Tom Lang, Frank Bieser, and others
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * http://www.gnu.org/copyleft/gpl.html
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#ifndef _HalTreeC_h_
#define _HalTreeC_h_

#include <X11/Xlib.h>
#include <Xm/Xm.h>
#include <Xm/ScrollBar.h>
#include <Xm/DragDrop.h>

#include "HalTreeNodeListC.h"
#include "RectC.h"
#include "CallbackListC.h"
#include "StringC.h"

class LayoutC;
class TreeLayoutC;
class OutlineLayoutC;
class JoyStickC;
class HalTreeModC;

enum HalTreeSelectModeT {
 SINGLE_SELECT,
 DRAG_SELECT,
 REGION_SELECT
};

//
// This type is used to send data for a drag event
//
typedef struct {
   HalTreeNodeListC  dragNodeList;
    Widget       icon;
    Widget       widget;
    HalTreeC     *tree;
    XEvent       *event;

} TreeDragDataT;

//
// This type is used to send data for a drop event
//
typedef struct {

   HalTreeNodeC                 *item;
   HalTreeC                     *tree;
   XmDropProcCallbackStruct     *procData;

} TreeDropDataT;

//
// This type is used to send data for a drag motion
//
typedef struct {

   XmDragProcCallbackStruct	*dp;
   HalTreeNodeC			*node;

} TreeDragMotionDataT;

// =====================================================================
class HalTreeC
{
   friend LayoutC;
   friend TreeLayoutC;
   friend OutlineLayoutC;
   friend HalTreeNodeC;
   friend HalTreeModC;

   private:
      Widget		viewForm;
      Widget		viewDA;
      Widget		viewFrame;
      Widget		scrollForm;
      Widget		vScrollBar;
      Widget		hScrollBar;

      Widget            statusForm;
      Widget            totalLabel;
      Widget            totalVal;
      Widget            dispLabel;
      Widget            dispVal;
      Widget            selLabel;
      Widget            visVal;
      Widget            selVal;
      Widget            joyStickFrame;


   private:
      LayoutC*		layout;			// the current layout class
      TreeLayoutC*	treeLayout;
      OutlineLayoutC*	outlineLayout;
      HalTreeNodeC*	topLevelNode;           // invisible top level...
      JoyStickC*	joyStick;
      unsigned 		deferCount;
      Boolean 		deferred;
      Boolean 		statusShown;
      Boolean 		realized;
      Boolean 		changed;
      int 		busy;
      Boolean 		drawing;
      Boolean 		hasWidgetNodes;
      Boolean           callSelect;
      Boolean           callDeselect;

      int               daWd;
      int               daHt;
      int               marginWd;
      int               marginHt;

      int               world_ht;
      int               world_wd;
      int               world_x;
      int               world_y;
      int 		joyStickOn;      // is joyStick on...
      int 		vScrollInc;      // vert scroll bar increment.
      int 		hScrollInc;      // horz scroll bar increment.
      int 		vScrollOn;       // is vert scroll bar visible.
      int 		hScrollOn;       // is horz scroll bar visible.
      int 		vScrollValue;    // only used with virtual
      int 		hScrollValue;    // only used with virtual
      int 		vScrollMaxValue; // only used with virtual
      int 		hScrollMaxValue; // only used with virtual
      int               scrollRoff;      // Offset used if scrolling
      int               scrollBoff;      // Offset used if scrolling
      int               noScrollRoff;    // Offset used if not scrolling
      int               noScrollBoff;    // Offset used if not scrolling

      StringC           numNodesString;
      int               numNodes;         // total number of nodes.
      int               numNodesShown;    // number nodes w/shown = True.
      int               numNodesVisible;  // num node in visible dsp area.

      GC		viewGC;
      Window		viewWin;
      XmFontList	fontList;
      Pixmap		viewPm;
      Dimension		viewPmWd;
      Dimension		viewPmHt;
      Display		*viewDSP;
      Dimension		lineWidth;
      Pixel		lineColor;
      Pixel		lineEtchColor;	
      unsigned char	lineType;   // XmNO_LINE, XmSINGLE_LINE,
				    // XmSHADOW_ETCHED_IN, XmSHADOW_ETCHED_OUT

//
// Selection data
//
   private:
      GC			pickGC;
      RectC			pickRect;
      int			pickX;
      int			pickY;
      int			pickOffsetX;
      int			pickOffsetY;
      HalTreeNodeC*		pickNode;       // current pick node
      CallbackListC		selectCalls;
      CallbackListC		deselectCalls;
//
// List of routines for drag out and drop in events
//
      CallbackListC             dragCalls;
      CallbackListC             dropCalls;
      CallbackListC		dragMotionCalls;

      Boolean                   dragEnabled;
      Boolean                   dropEnabled;
      Atom                      *dropAtoms;
      int                       dropAtomCount;
      int                       dropAtomAlloc;

      int			buttonState;	// Modifiers of button event
      XtIntervalId		clickTimer;	// Id of timeout proc
      HalTreeSelectModeT	selectMode;
      HalTreeNodeListC		selectedList;

//
// Selection methods
//
      static void HandleMapChange(Widget, HalTreeC*, XEvent*, Boolean*);
      static void HandleResize(Widget, HalTreeC*, XtPointer);
      static void DoButtonPress(Widget, HalTreeC*, XButtonEvent*, Boolean*);
      static void DoButtonMotion(Widget, HalTreeC*, XMotionEvent*, Boolean*);
      static void DoButtonRelease(Widget, HalTreeC*, XButtonEvent*, Boolean*);
      static void HandleSingleClick(HalTreeC*, XtIntervalId*);
      static void HandleScroll(Widget, HalTreeC*, XmScrollBarCallbackStruct*);
      static void DoMoveJoyStick(void*, HalTreeC*);

//
// dragdrop callbacks
//
      static void  HandleDragOver(Widget, XtPointer, XmDragProcCallbackStruct*);
      static void  HandleDropIn  (Widget, XtPointer, XmDropProcCallbackStruct*);


      void         HandleButton2Press(XButtonEvent*);

      int         GetViewPortSize();
      void	  EnableVScroll();
      void	  EnableHScroll();
      void	  DisableHScroll();
      void	  DisableVScroll();
      void	  UpdateScrollBars();
      void	  InitPickGC();
      void	  FindVisRect();
      void	  UpdateSelection(int, HalTreeNodeListC&, Boolean callCallbacks = True);
      void	  HandleDoubleClick(XButtonEvent*);

//
// Public selection methods
//
   public:
      void	AddSelectHandler(Widget);
      void	SetSelectMode(HalTreeSelectModeT);

      inline void  AddSelectCallback(CallbackFn *fn, void *data) {
	 AddCallback(selectCalls, fn, data);
      }
      inline void  RemoveSelectCallback(CallbackFn *fn, void *data) {
	 RemoveCallback(selectCalls, fn, data);
      }
      inline void  AddDeselectCallback(CallbackFn *fn, void *data) {
 	 AddCallback(deselectCalls, fn, data);
      }
      inline void  RemoveDeselectCallback(CallbackFn *fn, void *data) {
 	 RemoveCallback(deselectCalls, fn, data);
      }
      inline void  CallSelectCallbacks() {
	 CallCallbacks(selectCalls, this);
      }
      inline void  CallDeselectCallbacks() {
 	 CallCallbacks(deselectCalls, this);
      }

//
// add dragdrop callbacks
//
      inline void  AddDragCallback(CallbackFn *fn, void *data) {
         AddCallback(dragCalls, fn, data);
      }
      inline void  AddDropCallback(CallbackFn *fn, void *data) {
         AddCallback(dropCalls, fn, data);
      }
      inline void  AddDragMotionCallback(CallbackFn *fn, void *data) {
         AddCallback(dragMotionCalls, fn, data);
      }

//
//Remove dragdrop callbacks
//
      inline void  RemoveDragCallback(CallbackFn *fn, void *data) {
         RemoveCallback(dragCalls, fn, data);
      }
      inline void  RemoveDropCallback(CallbackFn *fn, void *data) {
         RemoveCallback(dropCalls, fn, data);
      }
      inline void  RemoveDragMotionCallback(CallbackFn *fn, void *data) {
         RemoveCallback(dragMotionCalls, fn, data);
      }

//
// Call dragdrop callbacks
//
      inline void  CallDragCallbacks(TreeDragDataT *data) {
         CallCallbacks(dragCalls, data);
      }
      inline void  CallDropCallbacks(TreeDropDataT *data) {
         CallCallbacks(dropCalls, data);
      }
      inline void  CallDragMotionCallbacks(TreeDragMotionDataT *data) {
         CallCallbacks(dragMotionCalls, data);
      }


      PTR_QUERY(HalTreeNodeListC&,	SelectedNodes,	selectedList)

//
// The callbacks and event handlers.
//
   public:
      static void  DoExpose(Widget, HalTreeC*, XmDrawingAreaCallbackStruct*);
//
// for dropping COMPOUND_TEXT
//
      static Boolean ConvertProc(Widget, Atom*, Atom*, Atom*, XtPointer*,
		      unsigned long*, int*, unsigned long*, XtPointer, XtRequestId*);

//
// The private methods.
//
   private:
      void      SetStatusLabel(Widget label, unsigned count);

//
// The constructors & destructor.
//
   public:
      HalTreeC(Widget, char* name = "tree", ArgList argv=NULL, Cardinal argc=0);
     ~HalTreeC();

//
// The public methods.
//
   public:
      void	        Draw(Boolean do_layout = TRUE);
      inline void	Redraw() { Draw(FALSE); };
      void	        AddNode(HalTreeNodeC* node, HalTreeNodeC* parent, int pos=-1);
      void	        ScrollToNode(HalTreeNodeC* node);
      void	        RemoveNode(HalTreeNodeC* node);
      void	        Defer(Boolean on);
      void	        DeleteAll();
      void	        SetTreePosition(int, int);
      void	        SetLayout(LayoutC* layout);
      void	        SetRootNode(HalTreeNodeC*);
      void              SetBackgroundColor(Pixel);
      void              SetLineWidth(Dimension);
      void              SetLineColor(Pixel);
      void              SetLineEtchColor(Pixel);
      void              SetLineType(unsigned char);
      void              DefaultNode(HalTreeNodeC*);
      void              DefaultNodes();	// defaults the attributes of all nodes
      void              Erase();
      HalTreeNodeListC& Roots();
      void		SelectNode(HalTreeNodeC&, Boolean notify=True);
      void		SelectNodes(HalTreeNodeListC&, Boolean notify=True);
      void		SelectNodeOnly(HalTreeNodeC&, Boolean notify=True);
      void		SelectNodesOnly(HalTreeNodeListC&, Boolean notify=True);
      void		DeselectNode(HalTreeNodeC&, Boolean notify=True);
      void		DeselectNodes(HalTreeNodeListC&, Boolean notify=True);
      void		ToggleNode(HalTreeNodeC&, Boolean notify=True);
      void		ToggleNodes(HalTreeNodeListC&, Boolean notify=True);

      void              HideStatus();
      void              ShowStatus();
      void              UpdateStatus();
      Pixel             BackgroundColor();

//
// Set dragdrop stuff
//
      inline void  DisableDrag()                   { EnableDrag(False); }
      inline void  DisableDrop()                   { EnableDrop(False); }
      void         EnableDrag(Boolean val=True);
      void         EnableDrop(Boolean val=True);
      void         SetDropAtoms(Atom*, int);
      void	   ChangeDrop();

      inline operator Widget()	const { return viewForm; }

      MEMBER_QUERY ( int,		 X,	    	      world_x);
      MEMBER_QUERY ( int,		 Y,	     	      world_y);
      MEMBER_QUERY ( int,		 Width,	     	      world_wd);
      MEMBER_QUERY ( int,		 Height,	      world_ht);
      MEMBER_QUERY ( int,		 DAWidth,	      daWd);
      MEMBER_QUERY ( int,		 DAHeight,	      daHt);
      MEMBER_QUERY ( Widget,             JoyStickFrame,       joyStickFrame);
      MEMBER_QUERY ( Widget,             VerticalScrollBar,   vScrollBar);
      MEMBER_QUERY ( Widget,             HorizontalScrollBar, hScrollBar);
      MEMBER_QUERY ( Boolean,		 StatusShown,	      statusShown);
      MEMBER_QUERY ( Widget,             DrawingArea,	      viewDA);
      MEMBER_QUERY ( Widget,             ViewArea,	      viewDA);
      MEMBER_QUERY ( Widget,             WidgetParent,	      viewDA);
      MEMBER_QUERY ( unsigned char,	 LineType, 	      lineType);
      MEMBER_QUERY ( Dimension,		 LineWidth, 	      lineWidth);
         PTR_QUERY ( LayoutC*,		 GetLayout, 	      layout);
         PTR_QUERY ( TreeLayoutC*,	 TreeLayout, 	      treeLayout);
         PTR_QUERY ( OutlineLayoutC*,	 OutlineLayout,       outlineLayout);
      MEMBER_QUERY ( Pixel,		 LineColor, 	      lineColor);
      MEMBER_QUERY ( Pixel,		 LineEtchColor,       lineEtchColor);
         PTR_QUERY ( HalTreeNodeC*,	 TopLevelNode,        topLevelNode);
      MEMBER_QUERY ( HalTreeSelectModeT, SelectionMode,       selectMode);
      MEMBER_QUERY ( Pixmap,		 ViewPm,	      viewPm);
      MEMBER_QUERY ( XmFontList,	 FontList,	      fontList);

      MEMBER_QUERY ( Boolean,       	DragEnabled,            dragEnabled)
         PTR_QUERY ( Atom*,          	DropAtoms,              dropAtoms)
      MEMBER_QUERY ( int,            	DropAtomCount,          dropAtomCount)
         PTR_QUERY ( CallbackListC&, 	DropCallbacks,          dropCalls)
      MEMBER_QUERY ( Boolean,        	DropEnabled,            dropEnabled)

};

# endif
