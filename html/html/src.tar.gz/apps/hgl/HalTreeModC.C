/*
 * $Id: HalTreeModC.C,v 1.1 1998/06/24 01:29:07 lang Exp $
 *
 * Copyright (c) 1993 HAL Computer Systems International, Ltd.
 * 
 *          HAL COMPUTER SYSTEMS INTERNATIONAL, LTD.
 *                  1315 Dell Avenue
 *                  Campbell, CA  95008
 *
 * Author: Greg Hilton
 * Contributors: Tom Lang, Frank Bieser, and others
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * http://www.gnu.org/copyleft/gpl.html
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#ifdef ICL
#include <stddef.h>
#endif

#include "HalTreeModC.h"
#include "HalTreeC.h"
#include "TreeLayoutC.h"
#include "OutlineLayoutC.h"
#include "ColorModC.h"
#include "NumericFieldC.h"

#include "StringC.h"
#include "WArgList.h"
#include "rsrc.h"

#include <Xm/Form.h>
#include <Xm/Frame.h>
#include <Xm/Label.h>
#include <Xm/TextF.h>
#include <Xm/RowColumn.h>
#include <Xm/ToggleB.h>

#define Eprintf(a) printf a
#define Dprintf(a)


// =====================================================================
// The constructor for the HalTree Modifier class.
// =====================================================================
HalTreeModC::HalTreeModC(Widget parent, char *name, ArgList argv, Cardinal argc)
{
   WArgList	args;
   Widget       w;
   Dimension  	max_wd, wd;

   tree = NULL;

//
// Create the main form for the whole enchilada.
//
   mainForm = XmCreateForm(parent, name, argv, argc);

   autoApply = get_boolean("HalTreeModC", mainForm, "autoApply", False);

   args.Reset();
   args.TopAttachment(XmATTACH_FORM);
   args.LeftAttachment(XmATTACH_FORM);
   args.RightAttachment(XmATTACH_NONE);
   args.BottomAttachment(XmATTACH_FORM);
   Widget leftForm = XmCreateForm(mainForm, "leftForm", ARGS);

   args.Reset();
   args.TopAttachment(XmATTACH_FORM);
   args.LeftAttachment(XmATTACH_WIDGET,leftForm);
   args.RightAttachment(XmATTACH_FORM);
   args.BottomAttachment(XmATTACH_FORM);
   Widget rightForm = XmCreateForm(mainForm, "rightForm", ARGS);

//
   args.Reset();
   args.TopAttachment(XmATTACH_FORM);
   args.LeftAttachment(XmATTACH_FORM);
   args.RightAttachment(XmATTACH_FORM);
   args.BottomAttachment(XmATTACH_NONE);
   args.FractionBase(2);
   topForm = XmCreateForm(leftForm, "topForm", ARGS);

//
// Create an area for picking the tree display type.
//
   args.Reset();
   args.TopAttachment(XmATTACH_FORM);
   args.LeftAttachment(XmATTACH_FORM);
   args.RightAttachment(XmATTACH_POSITION, 1);
   args.BottomAttachment(XmATTACH_FORM);
   Widget typeFrame = XmCreateFrame(topForm, "typeFrame", ARGS);

   args.Reset();
   args.ChildType(XmFRAME_TITLE_CHILD);
   Widget typeFrameLabel = XmCreateLabel(typeFrame, "typeFrameLabel", ARGS);

   args.Reset();
   args.Orientation(XmVERTICAL);
   Widget typeRB = XmCreateRadioBox(typeFrame, "typeRB", ARGS);

   typeHalTreeTB = XmCreateToggleButton(typeRB, "typeHalTreeTB", 0,0);
   typeOutlineTB = XmCreateToggleButton(typeRB, "typeOutlineTB", 0,0);
   typeStepTB    = XmCreateToggleButton(typeRB, "typeStepTB",    0,0);

   XtAddCallback(typeHalTreeTB, XmNvalueChangedCallback, 
		 (XtCallbackProc)DoChangeType, (XtPointer)this);
   XtAddCallback(typeOutlineTB, XmNvalueChangedCallback,
		 (XtCallbackProc)DoChangeType, (XtPointer)this);
   XtAddCallback(typeStepTB, XmNvalueChangedCallback,
		 (XtCallbackProc)DoChangeType, (XtPointer)this);

   XtAddCallback(typeHalTreeTB, XmNvalueChangedCallback, 
		 (XtCallbackProc)DoAutoApply, (XtPointer)this);
   XtAddCallback(typeOutlineTB, XmNvalueChangedCallback,
		 (XtCallbackProc)DoAutoApply, (XtPointer)this);
   XtAddCallback(typeStepTB, XmNvalueChangedCallback,
		 (XtCallbackProc)DoAutoApply, (XtPointer)this);

   XtManageChild(typeHalTreeTB);
   XtManageChild(typeOutlineTB);
   XtManageChild(typeStepTB);
   XtManageChild(typeRB);
   XtManageChild(typeFrameLabel);
   XtManageChild(typeFrame);

//
// Create the selection stuff.
//
   args.Reset();
   args.TopAttachment(XmATTACH_FORM);
   args.LeftAttachment(XmATTACH_WIDGET, typeFrame);
   args.RightAttachment(XmATTACH_FORM);
   args.BottomAttachment(XmATTACH_FORM);
   Widget selectFrame = XmCreateFrame(topForm, "selectFrame", ARGS);

   args.Reset();
   args.ChildType(XmFRAME_TITLE_CHILD);
   Widget selectFrameLabel = XmCreateLabel(selectFrame, "selectFrameLabel", ARGS);
   XtManageChild(selectFrameLabel);

   args.Reset();
   args.Orientation(XmVERTICAL);
   Widget selectRB = XmCreateRadioBox(selectFrame, "selectModeRB", ARGS);

   w = selectRB;
   selectModeSingleTB = XmCreateToggleButton(w, "selectModeSingleTB", 0,0);
   selectModeRegionTB = XmCreateToggleButton(w, "selectModeRegionTB", 0,0);
   selectModeDragTB   = XmCreateToggleButton(w, "selectModeDragTB",   0,0);

   XtManageChild(selectModeSingleTB);
   XtManageChild(selectModeRegionTB);
   XtManageChild(selectModeDragTB);

   XtAddCallback(selectModeSingleTB, XmNvalueChangedCallback,
		 (XtCallbackProc)DoAutoApply, (XtPointer)this);
   XtAddCallback(selectModeRegionTB, XmNvalueChangedCallback,
		 (XtCallbackProc)DoAutoApply, (XtPointer)this);
   XtAddCallback(selectModeDragTB, XmNvalueChangedCallback,
		 (XtCallbackProc)DoAutoApply, (XtPointer)this);

   XtManageChild(selectRB);
   XtManageChild(selectFrame);


//
// Create an area for misc information.
//
   args.Reset();
   args.TopAttachment(XmATTACH_FORM);
   args.LeftAttachment(XmATTACH_FORM);
   args.RightAttachment(XmATTACH_FORM);
   args.BottomAttachment(XmATTACH_FORM);
   Widget miscFrame = XmCreateFrame(rightForm, "miscFrame", ARGS);

   args.Reset();
   args.ChildType(XmFRAME_TITLE_CHILD);
   Widget miscFrameLabel = XmCreateLabel(miscFrame, "miscFrameLabel", ARGS);

   args.Reset();
   Widget miscForm = XmCreateForm(miscFrame, "miscForm", ARGS);

   args.Reset();
   args.TopAttachment(XmATTACH_FORM);
   args.BottomAttachment(XmATTACH_NONE);
   args.RightAttachment(XmATTACH_FORM);
   args.LeftAttachment(XmATTACH_FORM);
   topRightForm = XmCreateForm(miscForm, "topRightForm", ARGS);

//
// Add the show status thingie.
//
   args.Reset();
   args.TopAttachment(XmATTACH_FORM);
   args.LeftAttachment(XmATTACH_FORM);
   args.RightAttachment(XmATTACH_NONE);
   args.BottomAttachment(XmATTACH_NONE);
   args.Alignment(XmALIGNMENT_BEGINNING);
   showStatusTB = XmCreateToggleButton(topRightForm, "showStatusTB", ARGS);
   XtManageChild(showStatusTB);

   XtAddCallback(showStatusTB, XmNvalueChangedCallback,
		 (XtCallbackProc)DoAutoApply, (XtPointer)this);

   args.TopAttachment(XmATTACH_WIDGET, showStatusTB);
   lineBreakTB  = XmCreateToggleButton(topRightForm, "lineBreakTB",  ARGS);
   XtManageChild(lineBreakTB);

   XtAddCallback(lineBreakTB, XmNvalueChangedCallback,
		 (XtCallbackProc)DoAutoApply, (XtPointer)this);

   args.TopAttachment(XmATTACH_WIDGET, lineBreakTB);
   compressedTB = XmCreateToggleButton(topRightForm, "compressedTB", ARGS);
   XtManageChild(compressedTB);

   XtAddCallback(compressedTB, XmNvalueChangedCallback,
		 (XtCallbackProc)DoAutoApply, (XtPointer)this);

   XtManageChild(topRightForm);

   args.Reset();
   args.TopAttachment(XmATTACH_WIDGET, topRightForm);
   args.LeftAttachment(XmATTACH_FORM);
   args.RightAttachment(XmATTACH_NONE);
   args.BottomAttachment(XmATTACH_NONE);
   layoutDirForm = XmCreateForm(miscForm, "layoutDirForm", ARGS);

   args.Reset();
   args.TopAttachment(XmATTACH_FORM);
   args.LeftAttachment(XmATTACH_FORM);
   args.RightAttachment(XmATTACH_NONE);
   args.BottomAttachment(XmATTACH_FORM);
   Widget layoutDirLabel = XmCreateLabel(layoutDirForm, "layoutDirLabel", ARGS);
   XtManageChild(layoutDirLabel);

   args.Reset();
   args.TopAttachment(XmATTACH_FORM);
   args.LeftAttachment(XmATTACH_WIDGET, layoutDirLabel);
   args.RightAttachment(XmATTACH_NONE);
   args.BottomAttachment(XmATTACH_FORM);
   args.Orientation(XmVERTICAL);
   args.Packing(XmPACK_COLUMN);
   args.NumColumns(2);
   Widget layoutRB = XmCreateRadioBox(layoutDirForm, "layoutRB", ARGS);

   w = layoutRB;
   layoutLeftToRightTB = XmCreateToggleButton(w, "layoutLeftToRightTB", 0,0);
   layoutRightToLeftTB = XmCreateToggleButton(w, "layoutRightToLeftTB", 0,0);
   layoutTopToBottomTB = XmCreateToggleButton(w, "layoutTopToBottomTB", 0,0);
   layoutBottomToTopTB = XmCreateToggleButton(w, "layoutBottomToTopTB", 0,0);

   XtAddCallback(layoutLeftToRightTB, XmNvalueChangedCallback,
		 (XtCallbackProc)DoAutoApply, (XtPointer)this);
   XtAddCallback(layoutRightToLeftTB, XmNvalueChangedCallback,
		 (XtCallbackProc)DoAutoApply, (XtPointer)this);
   XtAddCallback(layoutTopToBottomTB, XmNvalueChangedCallback,
		 (XtCallbackProc)DoAutoApply, (XtPointer)this);
   XtAddCallback(layoutBottomToTopTB, XmNvalueChangedCallback,
		 (XtCallbackProc)DoAutoApply, (XtPointer)this);

   XtManageChild(layoutLeftToRightTB);
   XtManageChild(layoutRightToLeftTB);
   XtManageChild(layoutTopToBottomTB);
   XtManageChild(layoutBottomToTopTB);
   XtManageChild(layoutRB);
   XtManageChild(layoutDirForm);

   args.Reset();
   args.TopAttachment(XmATTACH_WIDGET, layoutDirForm);
   args.LeftAttachment(XmATTACH_FORM);
   args.RightAttachment(XmATTACH_FORM);
   args.BottomAttachment(XmATTACH_NONE);
   args.MarginWidth(0);
   args.MarginHeight(0);
   Widget childSpaceForm = XmCreateForm(miscForm, "childSpaceForm", ARGS);

   args.Reset();
   args.TopAttachment(XmATTACH_FORM);
   args.LeftAttachment(XmATTACH_FORM);
   args.RightAttachment(XmATTACH_NONE);
   args.BottomAttachment(XmATTACH_FORM);
   Widget childSpaceLabel = XmCreateLabel(childSpaceForm, "childSpaceLabel", ARGS);
   XtManageChild(childSpaceLabel);

   args.Reset();
   args.TopAttachment(XmATTACH_FORM);
   args.LeftAttachment(XmATTACH_WIDGET, childSpaceLabel);
   args.RightAttachment(XmATTACH_NONE);
   args.BottomAttachment(XmATTACH_FORM);
   childSpaceNF = new NumericFieldC(childSpaceForm, "childSpaceNF", ARGS);
   childSpaceNF->SetMin(0);
   childSpaceNF->SetMax(512);
   XtManageChild(*childSpaceNF);
   XtManageChild(childSpaceForm);

   XtAddCallback(*childSpaceNF, XmNactivateCallback,
		 (XtCallbackProc)DoAutoApply, (XtPointer)this);

   args.Reset();
   args.TopAttachment(XmATTACH_FORM);
   args.LeftAttachment(XmATTACH_WIDGET, (Widget)*childSpaceNF);
   args.RightAttachment(XmATTACH_NONE);
   args.BottomAttachment(XmATTACH_FORM);
   Widget childUnitLabel = XmCreateLabel(childSpaceForm, "unitLabel", ARGS);
   XtManageChild(childUnitLabel);

   args.Reset();
   args.TopAttachment(XmATTACH_WIDGET, childSpaceForm);
   args.LeftAttachment(XmATTACH_FORM);
   args.RightAttachment(XmATTACH_FORM);
   args.BottomAttachment(XmATTACH_NONE);
   args.MarginWidth(0);
   args.MarginHeight(0);
   Widget siblingSpaceForm = XmCreateForm(miscForm, "siblingSpaceForm", ARGS);

   args.Reset();
   args.TopAttachment(XmATTACH_FORM);
   args.LeftAttachment(XmATTACH_FORM);
   args.RightAttachment(XmATTACH_NONE);
   args.BottomAttachment(XmATTACH_FORM);
   Widget siblingSpaceLabel = XmCreateLabel(siblingSpaceForm, "siblingSpaceLabel", ARGS);
   XtManageChild(siblingSpaceLabel);

   args.Reset();
   args.TopAttachment(XmATTACH_FORM);
   args.LeftAttachment(XmATTACH_WIDGET, siblingSpaceLabel);
   args.RightAttachment(XmATTACH_NONE);
   args.BottomAttachment(XmATTACH_FORM);
   siblingSpaceNF = new NumericFieldC(siblingSpaceForm, "siblingSpaceNF", ARGS);
   siblingSpaceNF->SetMin(0);
   siblingSpaceNF->SetMax(512);
   XtManageChild(*siblingSpaceNF);
   XtManageChild(siblingSpaceForm);

   XtAddCallback(*siblingSpaceNF, XmNactivateCallback,
		 (XtCallbackProc)DoAutoApply, (XtPointer)this);

   args.Reset();
   args.TopAttachment(XmATTACH_FORM);
   args.LeftAttachment(XmATTACH_WIDGET, (Widget)*siblingSpaceNF);
   args.RightAttachment(XmATTACH_NONE);
   args.BottomAttachment(XmATTACH_FORM);
   Widget siblingUnitLabel = XmCreateLabel(siblingSpaceForm, "unitLabel", ARGS);
   XtManageChild(siblingUnitLabel);

   args.Reset();
   args.TopAttachment(XmATTACH_WIDGET, siblingSpaceForm);
   args.LeftAttachment(XmATTACH_FORM);
   args.RightAttachment(XmATTACH_NONE);
   args.BottomAttachment(XmATTACH_NONE);
   args.MarginWidth(0);
   args.MarginHeight(0);
   lineOffsetForm = XmCreateForm(miscForm, "lineOffsetForm", ARGS);

   args.Reset();
   args.TopAttachment(XmATTACH_FORM);
   args.LeftAttachment(XmATTACH_FORM);
   args.RightAttachment(XmATTACH_NONE);
   args.BottomAttachment(XmATTACH_FORM);
   Widget lineOffsetLabel = XmCreateLabel(lineOffsetForm, "lineOffsetLabel", ARGS);
   XtManageChild(lineOffsetLabel);

   args.Reset();
   args.TopAttachment(XmATTACH_FORM);
   args.LeftAttachment(XmATTACH_WIDGET, lineOffsetLabel);
   args.RightAttachment(XmATTACH_NONE);
   args.BottomAttachment(XmATTACH_FORM);
   args.Columns(4);
   lineOffsetNF = new NumericFieldC(lineOffsetForm, "lineOffsetNF", ARGS);
   lineOffsetNF->SetMin(0);
   lineOffsetNF->SetMax(999);
   lineOffsetNF->SetValue(0);
   XtManageChild(*lineOffsetNF);
   XtManageChild(lineOffsetForm);

   XtAddCallback(*lineOffsetNF, XmNactivateCallback,
		 (XtCallbackProc)DoAutoApply, (XtPointer)this);

   args.Reset();
   args.TopAttachment(XmATTACH_FORM);
   args.LeftAttachment(XmATTACH_WIDGET, (Widget)*lineOffsetNF);
   args.RightAttachment(XmATTACH_NONE);
   args.BottomAttachment(XmATTACH_FORM);
   Widget lineUnitLabel = XmCreateLabel(lineOffsetForm, "unitLabel", ARGS);
   XtManageChild(lineUnitLabel);

   args.Reset();
   args.TopAttachment(XmATTACH_WIDGET, lineOffsetForm);
   args.LeftAttachment(XmATTACH_FORM);
   args.RightAttachment(XmATTACH_FORM);
   args.BottomAttachment(XmATTACH_NONE);
   bkgdColorMod = new ColorModC(miscForm, "bkgdColorMod", ARGS);
   XtManageChild(*bkgdColorMod);

   XtAddCallback(bkgdColorMod->TextField(), XmNactivateCallback,
		 (XtCallbackProc)DoAutoApply, (XtPointer)this);

//
// Resize the labels of the misc display.
//
   max_wd = 0;
   args.Reset();
   args.Add(XmNwidth, &wd);
// XtGetValues(bkgdColorMod->Label(), ARGS); if (wd>max_wd) max_wd = wd;
   XtGetValues(lineOffsetLabel,   ARGS);  if (wd>max_wd) max_wd = wd;
   XtGetValues(childSpaceLabel,   ARGS);  if (wd>max_wd) max_wd = wd;
   XtGetValues(siblingSpaceLabel, ARGS);  if (wd>max_wd) max_wd = wd;

   args.Reset();
   args.Width(max_wd);
   args.Alignment(XmALIGNMENT_END);
   args.RecomputeSize(False);
// XtSetValues(bkgdColorMod->Label(),  ARGS);
   XtSetValues(lineOffsetLabel,  ARGS);
   XtSetValues(childSpaceLabel,  ARGS);
   XtSetValues(siblingSpaceLabel,  ARGS);

   XtManageChild(miscForm);
   XtManageChild(miscFrameLabel);
   XtManageChild(miscFrame);

//
// Create an area for the default line attributes.
//
   args.Reset();
   args.TopAttachment(XmATTACH_WIDGET, topForm);
   args.LeftAttachment(XmATTACH_FORM);
   args.RightAttachment(XmATTACH_FORM);
   args.BottomAttachment(XmATTACH_FORM);
   Widget lineFrame = XmCreateFrame(leftForm, "lineFrame", ARGS);

   args.Reset();
   args.ChildType(XmFRAME_TITLE_CHILD);
   Widget lineFrameLabel = XmCreateLabel(lineFrame, "lineFrameLabel", ARGS);

   args.Reset();
   Widget lineForm = XmCreateForm(lineFrame, "lineForm", ARGS);

   args.Reset();
   args.TopAttachment(XmATTACH_FORM);
   args.LeftAttachment(XmATTACH_FORM);
   args.RightAttachment(XmATTACH_NONE);
   args.BottomAttachment(XmATTACH_NONE);
   defaultLinesTB = XmCreateToggleButton(lineForm, "defaultLinesTB", ARGS);
   XtManageChild(defaultLinesTB);

   XtAddCallback(defaultLinesTB, XmNvalueChangedCallback,
		 (XtCallbackProc)DoChangeDefaultLines, (XtPointer)this);

   args.Reset();
   args.TopAttachment(XmATTACH_WIDGET, defaultLinesTB);
   args.LeftAttachment(XmATTACH_FORM);
   args.RightAttachment(XmATTACH_NONE);
   args.BottomAttachment(XmATTACH_NONE);
   lineTypeForm = XmCreateForm(lineForm, "lineTypeForm", ARGS);

   args.Reset();
   args.TopAttachment(XmATTACH_FORM);
   args.LeftAttachment(XmATTACH_FORM);
   args.RightAttachment(XmATTACH_NONE);
   args.BottomAttachment(XmATTACH_FORM);
   Widget lineTypeLabel = XmCreateLabel(lineTypeForm, "lineTypeLabel", ARGS);
   XtManageChild(lineTypeLabel);
   
   args.Reset();
   args.TopAttachment(XmATTACH_FORM);
   args.LeftAttachment(XmATTACH_WIDGET, lineTypeLabel);
   args.RightAttachment(XmATTACH_NONE);
   args.BottomAttachment(XmATTACH_FORM);
   args.Packing(XmPACK_COLUMN);
   args.Orientation(XmVERTICAL);
   args.NumColumns(2);
   Widget lineTypeRB = XmCreateRadioBox(lineTypeForm, "lineTypeRB", ARGS);

   w = lineTypeRB;
   lineTypeNoLineTB     = XmCreateToggleButton(w, "lineTypeNoLineTB",     0,0);
   lineTypeSingleLineTB = XmCreateToggleButton(w, "lineTypeSingleLineTB", 0,0);
   lineTypeEtchedInTB   = XmCreateToggleButton(w, "lineTypeEtchedInTB",   0,0);
   lineTypeEtchedOutTB  = XmCreateToggleButton(w, "lineTypeEtchedOutTB",  0,0);

   XtManageChild(lineTypeNoLineTB);
   XtManageChild(lineTypeSingleLineTB);
   XtManageChild(lineTypeEtchedInTB);
   XtManageChild(lineTypeEtchedOutTB);
   XtManageChild(lineTypeRB);
   XtManageChild(lineTypeForm);

   XtAddCallback(lineTypeNoLineTB, XmNvalueChangedCallback,
		 (XtCallbackProc)DoAutoApply, (XtPointer)this);
   XtAddCallback(lineTypeSingleLineTB, XmNvalueChangedCallback,
		 (XtCallbackProc)DoAutoApply, (XtPointer)this);
   XtAddCallback(lineTypeEtchedInTB, XmNvalueChangedCallback,
		 (XtCallbackProc)DoAutoApply, (XtPointer)this);
   XtAddCallback(lineTypeEtchedOutTB, XmNvalueChangedCallback,
		 (XtCallbackProc)DoAutoApply, (XtPointer)this);

   args.Reset();
   args.TopAttachment(XmATTACH_WIDGET, lineTypeForm);
   args.LeftAttachment(XmATTACH_FORM);
   args.RightAttachment(XmATTACH_NONE);
   args.BottomAttachment(XmATTACH_NONE);
   args.MarginWidth(0);
   args.MarginHeight(0);
   Widget lineWidthForm = XmCreateForm(lineForm, "lineWidthForm", ARGS);

   args.Reset();
   args.TopAttachment(XmATTACH_FORM);
   args.LeftAttachment(XmATTACH_FORM);
   args.RightAttachment(XmATTACH_NONE);
   args.BottomAttachment(XmATTACH_FORM);
   Widget lineWidthLabel = XmCreateLabel(lineWidthForm, "lineWidthLabel", ARGS);
   XtManageChild(lineWidthLabel);

   args.Reset();
   args.TopAttachment(XmATTACH_FORM);
   args.LeftAttachment(XmATTACH_WIDGET, lineWidthLabel);
   args.RightAttachment(XmATTACH_FORM);
   args.BottomAttachment(XmATTACH_FORM);
   args.Columns(3);
   lineWidthNF = new NumericFieldC(lineWidthForm, "lineWidthNF", ARGS);
   lineWidthNF->SetMin(1);
   lineWidthNF->SetMax(10);
   lineWidthNF->SetValue(1);
   XtManageChild(*lineWidthNF);
   XtManageChild(lineWidthForm);

   XtAddCallback(*lineWidthNF, XmNactivateCallback,
		 (XtCallbackProc)DoAutoApply, (XtPointer)this);

   args.Reset();
   args.TopAttachment(XmATTACH_WIDGET, lineWidthForm);
   args.LeftAttachment(XmATTACH_FORM);
   args.RightAttachment(XmATTACH_FORM);
   args.BottomAttachment(XmATTACH_NONE);
   lineColorMod = new ColorModC(lineForm, "lineColorMod", ARGS);
   XtManageChild(*lineColorMod);

   args.Reset();
   args.TopAttachment(XmATTACH_WIDGET, (Widget)*lineColorMod);
   args.LeftAttachment(XmATTACH_FORM);
   args.RightAttachment(XmATTACH_FORM);
   args.BottomAttachment(XmATTACH_NONE);
   lineEtchColorMod = new ColorModC(lineForm, "lineEtchColorMod", ARGS);
   XtManageChild(*lineEtchColorMod);

   XtAddCallback(lineColorMod->TextField(), XmNactivateCallback,
		 (XtCallbackProc)DoAutoApply, (XtPointer)this);
   XtAddCallback(lineEtchColorMod->TextField(), XmNactivateCallback,
		 (XtCallbackProc)DoAutoApply, (XtPointer)this);

//
// Make these labels the same size.
//
   max_wd = 0;
   args.Reset();
   args.Add(XmNwidth, &wd);
   XtGetValues(lineTypeLabel, ARGS);             if (wd > max_wd) max_wd = wd;
   XtGetValues(lineWidthLabel, ARGS);            if (wd > max_wd) max_wd = wd;
   XtGetValues(lineColorMod->Label(), ARGS);     if (wd > max_wd) max_wd = wd;
   XtGetValues(lineEtchColorMod->Label(), ARGS); if (wd > max_wd) max_wd = wd;
   args.Reset();
   args.Width(max_wd);
   args.Alignment(XmALIGNMENT_END);
   args.RecomputeSize(False);
   XtSetValues(lineTypeLabel, ARGS);
   XtSetValues(lineWidthLabel, ARGS);
   XtSetValues(lineColorMod->Label(), ARGS);
   XtSetValues(lineEtchColorMod->Label(), ARGS);

   XtManageChild(lineForm);
   XtManageChild(lineFrameLabel);
   XtManageChild(lineFrame);

//
// Manage the main widgets in a good order.
//
   XtManageChild(topForm);
   XtManageChild(leftForm);
   XtManageChild(rightForm);
   XtManageChild(mainForm);

} // End HalTreeModC


// =====================================================================
//  Destructor
// =====================================================================
HalTreeModC::~HalTreeModC()
{
   delete lineColorMod;
   delete lineEtchColorMod;
   delete bkgdColorMod;
   delete childSpaceNF;
   delete siblingSpaceNF;
   delete lineWidthNF;
   delete lineOffsetNF;
}


// =====================================================================
// Method to apply tree changes
// =====================================================================
void
HalTreeModC::Apply()
{
   Dprintf(("***************\n"));
   Dprintf(("Entering Apply\n"));

   tree->Defer(True);

//
// Copy the current values to the undo ones.
//
   undo = curr;

//
// Get the layout type.
//
   if ( XmToggleButtonGetState(typeHalTreeTB) ) {
      if ( ! tree->TreeLayout() )
	 tree->treeLayout = new TreeLayoutC(tree);
      curr.layout = (LayoutC*)tree->TreeLayout();
      curr.stepMode = FALSE;
   }
   else if ( XmToggleButtonGetState(typeOutlineTB) ) {
      if ( ! tree->OutlineLayout() )
	 tree->outlineLayout = new OutlineLayoutC(tree);
      curr.layout = (LayoutC*)tree->OutlineLayout();
      curr.stepMode = FALSE;
   }
   else if ( XmToggleButtonGetState(typeStepTB) ) {
      if ( ! tree->TreeLayout() )
	 tree->treeLayout = new TreeLayoutC(tree);
      curr.layout = (LayoutC*)tree->TreeLayout();
      curr.stepMode = TRUE;
   }
   tree->SetLayout(curr.layout);

   if ( curr.layout == (LayoutC*)tree->TreeLayout() ) {
      tree->TreeLayout()->SetStepMode(curr.stepMode);
   }

   curr.showStatus = XmToggleButtonGetState(showStatusTB);
   if ( curr.showStatus )
      tree->ShowStatus();
   else
      tree->HideStatus();

//
// See if the layout direction has changed.
//
   if ( curr.layout == (LayoutC*)tree->TreeLayout() ) {
      if ( XmToggleButtonGetState(layoutLeftToRightTB) ) {
         curr.layoutDir = LEFT_TO_RIGHT;
      }
      else if ( XmToggleButtonGetState(layoutRightToLeftTB) ) {
         curr.layoutDir = RIGHT_TO_LEFT;
      }
      else if ( XmToggleButtonGetState(layoutTopToBottomTB) ) {
         curr.layoutDir = TOP_TO_BOTTOM;
      }
      else if ( XmToggleButtonGetState(layoutBottomToTopTB) ) {
         curr.layoutDir = BOTTOM_TO_TOP;
      }
      tree->TreeLayout()->SetLayoutDir(curr.layoutDir);

      curr.lineBreak = XmToggleButtonGetState(lineBreakTB);
      tree->TreeLayout()->SetLineBreak(curr.lineBreak);

      curr.compressed = XmToggleButtonGetState(compressedTB);
      tree->TreeLayout()->SetCompressed(curr.compressed);
   }

//
// Get the line type and set it.
//
   if ( XmToggleButtonGetState(lineTypeNoLineTB) ) {
      curr.lineType = XmNO_LINE;
   }
   else if ( XmToggleButtonGetState(lineTypeSingleLineTB) ) {
      curr.lineType = XmSINGLE_LINE;
   }
   else if ( XmToggleButtonGetState(lineTypeEtchedInTB) ) {
      curr.lineType = XmSHADOW_ETCHED_IN;
   }
   else if ( XmToggleButtonGetState(lineTypeEtchedOutTB) ) {
      curr.lineType = XmSHADOW_ETCHED_OUT;
   }
   tree->SetLineType(curr.lineType);

//
// See if the line colors have changed.
//
   if ( lineColorMod->Changed() ) {
      curr.lineColor = lineColorMod->Value();
      tree->SetLineColor(curr.lineColor);
   }

   if ( lineEtchColorMod->Changed() ) {
      curr.lineEtchColor = lineEtchColorMod->Value();
      tree->SetLineEtchColor(curr.lineEtchColor);
   }

   if ( bkgdColorMod->Changed() ) {
      curr.bkgdColor = bkgdColorMod->Value();
      tree->SetBackgroundColor(curr.bkgdColor);
   }

   curr.lineWidth = (int)*lineWidthNF;
   tree->SetLineWidth(curr.lineWidth);

   curr.childSpace   = (int)*childSpaceNF;
   curr.layout->SetChildSpacing(curr.childSpace);

   curr.siblingSpace = (int)*siblingSpaceNF;
   curr.layout->SetSiblingSpacing(curr.siblingSpace);

   if ( curr.layout == (LayoutC*)tree->OutlineLayout() ) {
      curr.lineOffset = (int)*lineOffsetNF;
      tree->OutlineLayout()->SetLineOffset(curr.lineOffset);   
//
//    Reset this since the values are limited.
//
      curr.lineOffset = tree->OutlineLayout()->LineOffset();
      lineOffsetNF->SetValue((int)curr.lineOffset);
      lineOffsetNF->SetMax((int)(curr.childSpace-1));
   }

//
// Get the selection type.
//
   if ( XmToggleButtonGetState(selectModeRegionTB) )
      curr.selectMode = REGION_SELECT;
   if ( XmToggleButtonGetState(selectModeSingleTB) )
      curr.selectMode = SINGLE_SELECT;
   if ( XmToggleButtonGetState(selectModeDragTB) )
      curr.selectMode = DRAG_SELECT;
   tree->SetSelectMode(curr.selectMode);

   if ( XmToggleButtonGetState(defaultLinesTB) ) {
      tree->DefaultNodes();
      curr.defaultLines = TRUE;
   }
   else {
      curr.defaultLines = FALSE;
   }

   tree->Defer(False);

   Dprintf(("Leaving Apply\n"));
   Dprintf(("***************\n"));
}


// =====================================================================
// Method to initialize the settings based on the given tree
// =====================================================================
void
HalTreeModC::Init(HalTreeC& t)
{
   tree = (HalTreeC*)&t;

//
// Set the init attributes with the tree values.
//
   init.layout         = t.GetLayout();
   if ( init.layout == (LayoutC*)t.TreeLayout() ) {
      init.lineBreak  = t.TreeLayout()->LineBreak();
      init.stepMode   = t.TreeLayout()->StepMode();
      init.compressed = t.TreeLayout()->Compressed();
   }
   else
      init.stepMode = False;

   if ( t.TreeLayout() )
      init.layoutDir = t.TreeLayout()->LayoutDir();
   else
      init.layoutDir = LEFT_TO_RIGHT;

   if ( t.OutlineLayout() ) {
      init.lineOffset = t.OutlineLayout()->LineOffset();
      lineOffsetNF->SetMax((int)(t.OutlineLayout()->ChildSpacing())-1);
   }
   else
      init.lineOffset = 0;

   init.defaultLines   = TRUE;
   init.selectMode     = t.SelectionMode();
   init.showStatus     = t.StatusShown();
   init.lineType       = t.LineType();
   init.lineWidth      = t.LineWidth();
   init.lineColor      = t.LineColor();
   init.bkgdColor      = t.BackgroundColor();
   init.lineEtchColor  = t.LineEtchColor();
   init.childSpace     = init.layout->ChildSpacing();
   init.siblingSpace   = init.layout->SiblingSpacing();

//
// Save the attributes.
//
   curr  = init;
   undo  = init;

   DisplayAtts(init);
}


// =====================================================================
// =====================================================================
void
HalTreeModC::DisplayAtts(HalTreeModAttsT& atts)
{
//
// Set the tree layout direction type toggle if there is a tree layout.
//
   if ( atts.layout == (LayoutC*)tree->TreeLayout() ) {
      if ( !XtIsSensitive(layoutDirForm) ) {
	 XtSetSensitive(layoutDirForm,True);
	 XtSetSensitive(compressedTB,True);
	 XtSetSensitive(lineBreakTB,True);
      }
      if ( XtIsSensitive(lineOffsetForm) ) {
	 XtSetSensitive(lineOffsetForm,False);
      }
      if ( atts.stepMode ) {
         XmToggleButtonSetState(typeStepTB,    True,  False);
         XmToggleButtonSetState(typeHalTreeTB, False, False);
      }
      else {
         XmToggleButtonSetState(typeStepTB,    False, False);
         XmToggleButtonSetState(typeHalTreeTB, True,  False);
      }
      XmToggleButtonSetState(typeOutlineTB, False, False);
   }
   else if ( atts.layout == (LayoutC*)tree->OutlineLayout() ) {
      if ( !XtIsSensitive(lineOffsetForm) ) {
         XtSetSensitive(lineOffsetForm,True);
      }
      if ( XtIsSensitive(layoutDirForm) ) {
	 XtSetSensitive(layoutDirForm,False);
	 XtSetSensitive(compressedTB,False);
	 XtSetSensitive(lineBreakTB,False);
      }
      XmToggleButtonSetState(typeStepTB,    False, False);
      XmToggleButtonSetState(typeHalTreeTB, False, False);
      XmToggleButtonSetState(typeOutlineTB, True,  False);
   }

//
// Set the tree layout direction toggle button, if there is a tree layout.
//
   switch ( atts.layoutDir ) {
      case LEFT_TO_RIGHT:
         XmToggleButtonSetState(layoutLeftToRightTB, True,  False);
         XmToggleButtonSetState(layoutRightToLeftTB, False, False);
         XmToggleButtonSetState(layoutTopToBottomTB, False, False);
         XmToggleButtonSetState(layoutBottomToTopTB, False, False);
	 break;
      case RIGHT_TO_LEFT:
         XmToggleButtonSetState(layoutLeftToRightTB, False, False);
         XmToggleButtonSetState(layoutRightToLeftTB, True,  False);
         XmToggleButtonSetState(layoutTopToBottomTB, False, False);
         XmToggleButtonSetState(layoutBottomToTopTB, False, False);
	 break;
      case TOP_TO_BOTTOM:
         XmToggleButtonSetState(layoutLeftToRightTB, False, False);
         XmToggleButtonSetState(layoutRightToLeftTB, False, False);
         XmToggleButtonSetState(layoutTopToBottomTB, True,  False);
         XmToggleButtonSetState(layoutBottomToTopTB, False, False);
	 break;
      case BOTTOM_TO_TOP:
         XmToggleButtonSetState(layoutLeftToRightTB, False, False);
         XmToggleButtonSetState(layoutRightToLeftTB, False, False);
         XmToggleButtonSetState(layoutTopToBottomTB, False, False);
         XmToggleButtonSetState(layoutBottomToTopTB, True,  False);
	 break;
   }

   XmToggleButtonSetState(showStatusTB, curr.showStatus, False);

   if ( atts.lineBreak )
      XmToggleButtonSetState(lineBreakTB, True,  False);
   else
      XmToggleButtonSetState(lineBreakTB, False, False);


   if ( atts.compressed )
      XmToggleButtonSetState(compressedTB, True,  False);
   else
      XmToggleButtonSetState(compressedTB, False, False);

//
// Set the line type.
//
   switch ( atts.lineType ) {
      case XmNO_LINE:
         XmToggleButtonSetState(lineTypeNoLineTB,     True,  False);
         XmToggleButtonSetState(lineTypeSingleLineTB, False, False);
         XmToggleButtonSetState(lineTypeEtchedInTB,   False, False);
         XmToggleButtonSetState(lineTypeEtchedOutTB,  False, False);
	 break;
      case XmSINGLE_LINE:
         XmToggleButtonSetState(lineTypeNoLineTB,     False, False);
         XmToggleButtonSetState(lineTypeSingleLineTB, True,  False);
         XmToggleButtonSetState(lineTypeEtchedInTB,   False, False);
         XmToggleButtonSetState(lineTypeEtchedOutTB,  False, False);
	 break;
      case XmSHADOW_ETCHED_IN:
         XmToggleButtonSetState(lineTypeNoLineTB,     False, False);
         XmToggleButtonSetState(lineTypeSingleLineTB, False, False);
         XmToggleButtonSetState(lineTypeEtchedInTB,   True,  False);
         XmToggleButtonSetState(lineTypeEtchedOutTB,  False, False);
	 break;
      case XmSHADOW_ETCHED_OUT:
         XmToggleButtonSetState(lineTypeNoLineTB,     False, False);
         XmToggleButtonSetState(lineTypeSingleLineTB, False, False);
         XmToggleButtonSetState(lineTypeEtchedInTB,   False, False);
         XmToggleButtonSetState(lineTypeEtchedOutTB,  True,  False);
	 break;
   }

//
// Set the selection mode type.
//
   switch ( atts.selectMode ) {
      case REGION_SELECT:
         XmToggleButtonSetState(selectModeRegionTB,  True,  False);
         XmToggleButtonSetState(selectModeDragTB,    False, False);
         XmToggleButtonSetState(selectModeSingleTB,  False, False);
	 break;
      case DRAG_SELECT:
         XmToggleButtonSetState(selectModeRegionTB,  False, False);
         XmToggleButtonSetState(selectModeDragTB,    True,  False);
         XmToggleButtonSetState(selectModeSingleTB,  False, False);
	 break;
      case SINGLE_SELECT:
         XmToggleButtonSetState(selectModeRegionTB,  False, False);
         XmToggleButtonSetState(selectModeDragTB,    False, False);
         XmToggleButtonSetState(selectModeSingleTB,  True,  False);
	 break;
   }

//
// Set the node line values.
//
   lineColorMod->Init(atts.lineColor);
   lineEtchColorMod->Init(atts.lineEtchColor);
   bkgdColorMod->Init(atts.bkgdColor);

   *lineOffsetNF   = (int)atts.lineOffset;
   *lineWidthNF    = (int)atts.lineWidth;
   *childSpaceNF   = atts.childSpace;
   *siblingSpaceNF = atts.siblingSpace;

   XmToggleButtonSetState(defaultLinesTB, atts.defaultLines, False);
}


// =====================================================================
// Method to reset the fields to their previous values
// =====================================================================
void
HalTreeModC::Undo()
{
   DisplayAtts(undo);
   if ( autoApply ) Apply();
}


// =====================================================================
// Method to reset the fields to their initial values
// =====================================================================
void
HalTreeModC::Reset()
{
   DisplayAtts(init);
   if ( autoApply ) Apply();
}


// =====================================================================
// =====================================================================
void
HalTreeModC::DoChangeType(Widget, HalTreeModC* This, XtPointer)
{
   if ( XmToggleButtonGetState(This->typeOutlineTB) ) {
      if ( !XtIsSensitive(This->lineOffsetForm) ) {
         XtSetSensitive(This->lineOffsetForm,True);
      }
      if ( XtIsSensitive(This->layoutDirForm) ) {
	 XtSetSensitive(This->layoutDirForm,False);
	 XtSetSensitive(This->compressedTB,False);
	 XtSetSensitive(This->lineBreakTB,False);
      }
   }
   else {
      if ( !XtIsSensitive(This->layoutDirForm) ) {
	 XtSetSensitive(This->layoutDirForm,True);
	 XtSetSensitive(This->compressedTB,True);
	 XtSetSensitive(This->lineBreakTB,True);
      }
      if ( XtIsSensitive(This->lineOffsetForm) ) {
         XtSetSensitive(This->lineOffsetForm,False);
      }
   }
}


// =====================================================================
// =====================================================================
void
HalTreeModC::DoChangeDefaultLines(Widget w, HalTreeModC* This, XtPointer)
{
   if ( XmToggleButtonGetState(w) ) {
      This->tree->DefaultNodes();
   }
}


// =====================================================================
// =====================================================================
void
HalTreeModC::SetAutoApply(Boolean val)
{
  autoApply = val;
}

// =====================================================================
// =====================================================================
void
HalTreeModC::DoAutoApply(Widget, HalTreeModC* This, XtPointer)
{
   if ( This->autoApply )
      This->Apply();
}
