/*
 * $Id: Db.h,v 1.1 1998/06/24 01:29:07 lang Exp $
 *
 * Copyright (c) 1992 HAL Computer Systems International, Ltd.
 * 
 *          HAL COMPUTER SYSTEMS INTERNATIONAL, LTD.
 *                  1315 Dell Avenue
 *                  Campbell, CA  95008
 *
 * Author: Greg Hilton
 * Contributors: Tom Lang, Frank Bieser, and others
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * http://www.gnu.org/copyleft/gpl.html
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#ifndef _Db_h_
#define _Db_h_

#include <stdlib.h>
#include <iostream.h>
#include <fstream.h>

class Db {

  public:

  Db();
  virtual ~Db();

  int openFile( const char *filename, const char *appName, Display * );
  void closeFile();

  int getCard( const char *cardName, char **locator, char *title,
	      char **helpText );

  int numHelpcards() { return( _numHelpcards ); }
  char **titles() { return( _titles ); }
  char **titlesCards() { return( _titlesCards ); }

  protected:

  private:
  
  ifstream _f;
  char _version[ 81 ];  // Version info for this db file.
  int _numHelpcards;    // Number of helpcards in this db file.
  char **_titles;       // Array of card titles.
  // This is needed since titles (in Index table) are in different order than
  // cards are (in Card table). 
  char **_titlesCards;       // Array of card titles -> card names.
  char **_cards;        // Array of card names.
  int *_offsets;        // Array of card offsets into this file.
  char **_locators;     // Array of card locators.
  int *_lengths;        // Array of card lengths.
};

#endif
