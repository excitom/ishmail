/*
 * $Id: HalTreeNodeC.h,v 1.1 1998/06/24 01:29:07 lang Exp $
 *
 * Copyright (c) 1993 HAL Computer Systems International, Ltd.
 * 
 *          HAL COMPUTER SYSTEMS INTERNATIONAL, LTD.
 *                  1315 Dell Avenue
 *                  Campbell, CA  95008
 *
 * Author: Greg Hilton
 * Contributors: Tom Lang, Frank Bieser, and others
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * http://www.gnu.org/copyleft/gpl.html
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#ifndef _HalTreeNodeC_h_
#define _HalTreeNodeC_h_

#include "Base.h"

#include <X11/Intrinsic.h>
#include <values.h>

class HalTreeC;
class HalTreeNodeC;
class HalTreeNodeListC;
class LayoutC;
class OutlineLayoutC;
class TreeLayoutC;

//
// This is the compare function type
//
typedef int     (*TreeCompareFn)(const void*, const void*);



// =====================================================================
class HalTreeNodeC
{
   friend HalTreeC;
   friend LayoutC;
   friend OutlineLayoutC;
   friend TreeLayoutC;

   protected:
     Widget		widget;		   // Widget.
     HalTreeC*		tree;		   // parent tree class.
     HalTreeNodeC*	parent;    	   // node parent of this node.
     HalTreeNodeListC*  children;	   // the children of this node.
     int		numChildrenShown;  // number of children show=T.
     int		depth;             // hierarchical level of this node.
     int		x;    		   // virtual x position of node
     int		y;    		   // virtual y position of node
     int		wd;    	  	   // width of this node only
     int		ht;    	           // height of this node only
     int		subWd; 		   // width of 1st level children.
     int		subHt; 		   // height of 1st level children.
     int		regWd; 		   // total width, w/ descendants.
     int		regHt; 		   // total height w/ descendants.
     Pixel		lineColor;	   // of lines to draw to children
     Pixel		lineEtchColor;	   // of lines to draw to children
     unsigned char	lineType;	   // of lines to draw to children
     Dimension		lineWidth;	   // of lines to draw to children
     unsigned 		inTree       : 1;  // has been added to tree
     unsigned 		selected     : 1;  // is currently selected
     unsigned 		picked       : 1;  // for drag/region
     unsigned 		highlighted  : 1;  // is highlighted
     unsigned 		deleting     : 1;  // is being deleted
     unsigned 		show         : 1;  // is currently shown
     unsigned 		autoDelete   : 1;  // delete widget if node deleted
     unsigned 		mapped       : 1;  // is mapped (widget only)
     unsigned 		opened       : 1;  // node is opened
     Boolean      validDropSite;  // True if drops allowed here
     Boolean      validDragSite;  // True if drags allowed here

//
// Function used to compare two VItemCs
//
     TreeCompareFn    compFunc;

//
// Callbacks, event handlers, etc..
//
   protected:
      static void DoDestroy   (Widget, HalTreeNodeC*, XtPointer);
      static void HandleResize(Widget, HalTreeNodeC*, XEvent*, Boolean*);

//
// the constructors and destructor.
//
   public:
      HalTreeNodeC(HalTreeC*);
      virtual ~HalTreeNodeC();

//
// the public methods.
//
   public:
      HalTreeNodeListC&	Siblings();
      void		DeleteChildren();
      virtual void	Show(int num_levels = 0);
      virtual void	Hide();
      virtual void	ShowDescendants();
      virtual void	ShowChildren(int num_levels = 1);
      virtual void	HideChildren();
      virtual void	ShowSiblings();
      virtual void	HideSiblings();
      void              SetWidget(Widget);
      void		SetParent(HalTreeNodeC*);
      void		SetPositionIndex(int);
      void              SetLineColor(Pixel);
      void              SetLineEtchColor(Pixel);
      void              SetLineType(unsigned char);
      void              SetLineWidth(Dimension);
      void		SetAutoDelete(Boolean);

      virtual int	AllowPick(int, int); // has default widget method
      virtual void	CalculateSize();     // has default widget method
      virtual char*	NodeName() const;    // has default widget method
      virtual void	Draw();              // has default widget method
      virtual void	Erase();             // has default widget method
      virtual void	Open() {}
      virtual void	Highlight() {}
      virtual void	Unhighlight() {}
// for dropping
      virtual char*	DragString(XEvent*);

//
// Specify the function used to compare two VItemCs
//
      inline void  SetCompareFunction(TreeCompareFn comp) { compFunc = comp; }


      int               NumChildren();

      MEMBER_QUERY ( int,		RegionWidth,	  regWd);
      MEMBER_QUERY ( int,		RegionHeight,     regHt);
      MEMBER_QUERY ( int,		Level,		  depth);
      MEMBER_QUERY ( int,		Depth,		  depth);
         PTR_QUERY ( HalTreeC&,		Tree,		  *tree);
         PTR_QUERY ( HalTreeNodeC&,	Parent,		  *parent);
         PTR_QUERY ( HalTreeNodeListC&,	Children,	  *children);
      MEMBER_QUERY ( Pixel,		LineColor,	  lineColor);
      MEMBER_QUERY ( Pixel,		LineEtchColor,	  lineEtchColor);
      MEMBER_QUERY ( Dimension,		LineWidth,	  lineWidth);
      MEMBER_QUERY ( unsigned char,	LineType,	  lineType);
      MEMBER_QUERY ( int,		NumChildrenShown, numChildrenShown);
      MEMBER_QUERY ( int,		Width, 	          wd);
      MEMBER_QUERY ( int,		Height, 	  ht);
      MEMBER_QUERY(Boolean,        ValidDropSite,  validDropSite)
      MEMBER_QUERY(Boolean,        ValidDragSite,  validDragSite)

      inline Boolean Opened()	   {return((opened)      ? TRUE : FALSE);}
      inline Boolean Mapped()	   {return((mapped)      ? TRUE : FALSE);}
      // inline Boolean Shown()	   {return((show&inTree) ? TRUE : FALSE);}
      inline Boolean Shown()	   {return((show)        ? TRUE : FALSE);}
      inline Boolean InTree()	   {return((inTree)      ? TRUE : FALSE);}
      inline Boolean Selected()	   {return((selected)    ? TRUE : FALSE);}
      inline Boolean Highlighted() {return((highlighted) ? TRUE : FALSE);}
      inline Boolean Deleting()    {return((deleting)    ? TRUE : FALSE);}
      inline Boolean AutoDelete()  {return((autoDelete)  ? TRUE : FALSE);}

//
// Specify whether drags are ok here
//
      inline void  ValidDropSite(Boolean val) { validDropSite = val; }
      inline void  ValidDragSite(Boolean val) { validDragSite = val; }

      inline operator Widget()	const { return widget; }

      int compare(const HalTreeNodeC&) const;
      inline int operator==(const HalTreeNodeC &t) const 
	{ return (compare(t) == 0); }
      inline int operator!=(const HalTreeNodeC &t) const 
	{ return (compare(t) != 0); }
      inline int operator<(const HalTreeNodeC &t) const 
	{ return (compare(t) < 0); }
      inline int operator>(const HalTreeNodeC &t) const 
	{ return (compare(t) > 0); }
      
};

// =====================================================================
// class HalTreeNodeListC
// =====================================================================
inline ostream& operator << (ostream& strm, const HalTreeNodeC&) { return(strm); }

#endif
