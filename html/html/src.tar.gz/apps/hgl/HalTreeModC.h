/*
 * $Id: HalTreeModC.h,v 1.1 1998/06/24 01:29:07 lang Exp $
 *
 * Copyright (c) 1993 HAL Computer Systems International, Ltd.
 * 
 *          HAL COMPUTER SYSTEMS INTERNATIONAL, LTD.
 *                  1315 Dell Avenue
 *                  Campbell, CA  95008
 *
 * Author: Greg Hilton
 * Contributors: Tom Lang, Frank Bieser, and others
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * http://www.gnu.org/copyleft/gpl.html
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#ifndef _HalTreeModC_h_
#define _HalTreeModC_h_

#include "HalTreeC.h"
#include "LayoutC.h"

#include <X11/Xlib.h>

class HalTreeC;
class ColorModC;
class NumericFieldC;

// =====================================================================
typedef struct {
   LayoutC*		layout;
   LayoutDirT		layoutDir;
   unsigned char	lineType;
   Dimension		lineOffset;
   Dimension		lineWidth;
   Pixel		lineColor;
   Pixel		lineEtchColor;
   Pixel		bkgdColor;
   Boolean		stepMode;
   Boolean		lineBreak;
   Boolean		compressed;
   Boolean		showStatus;
   Boolean		defaultLines;
   int			childSpace;
   int			siblingSpace;
   HalTreeSelectModeT	selectMode;
} HalTreeModAttsT;


// =====================================================================

class HalTreeModC
{
   protected:
      Boolean	autoApply;

//
// The protected display objects.
//
   protected:
      Widget  mainForm;
      Widget     topForm;

      Widget		topRightForm;
      Widget	      	lineOffsetForm;
      Widget	      	layoutDirForm;
      Widget		lineTypeForm;

      Widget	      	typeHalTreeTB;
      Widget	      	typeOutlineTB;
      Widget          	typeStepTB;
      Widget	      	layoutLeftToRightTB;
      Widget	      	layoutRightToLeftTB;
      Widget	      	layoutTopToBottomTB;
      Widget	      	layoutBottomToTopTB;
      NumericFieldC*  	childSpaceNF;
      NumericFieldC*  	siblingSpaceNF;
      Widget	      	showStatusTB;
      Widget	      	selectModeRegionTB;
      Widget	      	selectModeDragTB;
      Widget	      	selectModeSingleTB;
      Widget	      	defaultLinesTB;
      Widget	      	lineTypeNoLineTB;
      Widget	      	lineTypeSingleLineTB;
      Widget	      	lineTypeEtchedInTB;
      Widget	      	lineTypeEtchedOutTB;
      // Widget       	lineDrawTB;
      Widget            lineBreakTB;
      Widget            compressedTB;
      ColorModC*        lineColorMod;
      ColorModC*        lineEtchColorMod;
      ColorModC*        bkgdColorMod;
      NumericFieldC*    lineWidthNF;
      NumericFieldC*    lineOffsetNF;

//
// The protected parts.
//
   protected:

      HalTreeC*		tree;
      HalTreeModAttsT	init;
      HalTreeModAttsT	undo;
      HalTreeModAttsT	curr;

   protected:
      static void  DoChangeDefaultLines(Widget, HalTreeModC*, XtPointer);
      static void  DoChangeType(Widget, HalTreeModC*, XtPointer);
      static void  DoAutoApply(Widget, HalTreeModC*, XtPointer);

//
// The constructor & destructor.
//
   public:

      HalTreeModC(Widget, char*, ArgList argv=NULL, Cardinal argc=0);
     ~HalTreeModC();

//
// The public methods.
//
   public:

      void	SetAutoApply(Boolean val = True);
      void	DisplayAtts(HalTreeModAttsT&);
      void	Apply();
      void	Init(HalTreeC&);
      void	Reset();
      void	Undo();

         PTR_QUERY ( ColorModC*,       BackgroundColorMod,  bkgdColorMod);
         PTR_QUERY ( ColorModC*,       LineColorMod,        lineColorMod);
         PTR_QUERY ( ColorModC*,       LineEtchColorMod,    lineEtchColorMod);
         PTR_QUERY ( NumericFieldC*,   LineWidthField,      lineWidthNF);
         PTR_QUERY ( HalTreeModAttsT&, Attributes, 	    curr);
      MEMBER_QUERY ( Widget,	       MainForm, 	    mainForm);
      MEMBER_QUERY ( Boolean,	       AutoApply, 	    autoApply);

      inline	operator Widget() const { return mainForm; }
};

#endif // _HalTreeModC_h_
