/*
 * $Id: ColorModC.C,v 1.1 1998/06/24 01:29:07 lang Exp $
 *
 * Copyright (c) 1992 HAL Computer Systems International, Ltd.
 * 
 *          HAL COMPUTER SYSTEMS INTERNATIONAL, LTD.
 *                  1315 Dell Avenue
 *                  Campbell, CA  95008
 *
 * Author: Greg Hilton
 * Contributors: Tom Lang, Frank Bieser, and others
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * http://www.gnu.org/copyleft/gpl.html
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#include "ColorModC.h"
#include "WArgList.h"
#include "HalAppC.h"
#include "rsrc.h"

#include <Xm/DrawingA.h>
#include <Xm/Form.h>
#include <Xm/Label.h>
#include <Xm/TextF.h>
#include <Xm/PushB.h>

#include "ColorPickerC.h"
#include "HalDialogC.h"
static HalDialogC *colorPickerDialog = NULL;
static ColorPickerC *colorPicker = NULL;
static ColorModC *colorMod = NULL;
static int colorModCount = 0;
static Widget okPB;
static Widget applyPB;
static Widget cancelPB;
static Widget helpPB;


/*---------------------------------------------------------------
 *  Constructor
 */

ColorModC::ColorModC(Widget parent, const char *name, ArgList argv,
		     Cardinal argc)
{
   changed = False;

   WArgList	args;

//
// Create form hierarchy
//
//   form
//	Label		label
//	DrawingArea	da
//	TextField	tf
//	PushButton	pb
//
   StringC	wname(name);
   form = XmCreateForm(parent, wname, argv, argc);

   XtAddEventHandler(form, StructureNotifyMask, FALSE,
		     (XtEventHandler)HandleMapChange, (XtPointer)this);

//
// Add an event handler to the shell that this belongs to...
// if there is one.
//
   shell = parent;
   while ( shell && !XtIsShell(shell) ) shell=XtParent(shell);
   if ( shell ) {
      XtAddCallback(shell, XmNpopdownCallback,
		    (XtCallbackProc)DoHideColorPicker, (XtPointer)this);
   }

   args.Reset();
   args.LeftAttachment(XmATTACH_NONE);
   args.RightAttachment(XmATTACH_FORM);
   args.TopAttachment(XmATTACH_FORM);
   args.BottomAttachment(XmATTACH_FORM);
   pb = XmCreatePushButton(form, "colorModPB", ARGS);

   args.Reset();
   args.LeftAttachment(XmATTACH_FORM);
   args.TopAttachment(XmATTACH_FORM);
   args.BottomAttachment(XmATTACH_FORM);
   args.RightAttachment(XmATTACH_NONE);
   label = XmCreateLabel(form, "colorModLabel", ARGS);

   args.Reset();
   args.LeftAttachment(XmATTACH_NONE);
   args.RightAttachment(XmATTACH_WIDGET, pb);
   args.TopAttachment(XmATTACH_FORM);
   args.BottomAttachment(XmATTACH_NONE);
   tf = XmCreateTextField(form, "colorModTF", ARGS);

   Dimension	ht;
   XtVaGetValues(tf, XmNheight, &ht, NULL);

   args.Reset();
   args.LeftAttachment(XmATTACH_WIDGET, label);
   args.TopAttachment(XmATTACH_FORM);
   args.BottomAttachment(XmATTACH_FORM);
   args.RightAttachment(XmATTACH_NONE);
   args.Width(ht);
   args.TraversalOn(False);
   da = XmCreateDrawingArea(form, "colorModDA", ARGS);

   args.Reset();
   args.LeftAttachment(XmATTACH_WIDGET, da);
   XtSetValues(tf, ARGS);

   XtAddCallback(tf, XmNactivateCallback,
		 (XtCallbackProc)HandleNameChange, (XtPointer)this);
   XtAddCallback(pb, XmNactivateCallback,
		 (XtCallbackProc)DoShowColorPicker, (XtPointer)this);

   Widget	list[4];
   list[0] = pb;
   list[1] = tf;
   list[2] = da;
   list[3] = label;
   XtManageChildren(list, 4);	// form children

   colorModCount++;

   return;

} // End ColorModC ColorModC


/*---------------------------------------------------------------
 *  Destructor
 */

ColorModC::~ColorModC()
{
   if ( shell ) {
      XtRemoveCallback(shell, XmNpopdownCallback,
		       (XtCallbackProc)DoHideColorPicker, (XtPointer)this);
   }
   colorModCount--;
   if ( !colorModCount <= 0 && colorPickerDialog ) {
      colorPickerDialog->Hide();
      delete colorPicker;
      delete colorPickerDialog;
      colorPicker       = NULL;
      colorPickerDialog = NULL;
      colorModCount     = 0;
   }
}


/*---------------------------------------------------------------
 *  Callback to handle typing in a color text field.  Try to keep the
 *    drawing area color up to date with the name.
 */

void
ColorModC::HandleNameChange(Widget tf, ColorModC *cm, XtPointer)
{
//
// Get the string
//
   char	*cs = XmTextFieldGetString(tf);
   StringC	str(cs);
   XtFree(cs);

   if ( !str.size() ) return;

//
// Get the color
//
   if ( PixelValue(cm->da, str, &cm->value) ) {
      XtVaSetValues(cm->da, XmNbackground, cm->value, NULL);
      cm->name    = str;
      cm->changed = True;

//
// djl - Do not set the name string unless the colorPicker is currently up
// for this colorMod.
//
      if ( colorPickerDialog && colorPickerDialog->IsShown() && 
	   (colorMod == cm) ) {
	 colorPicker->SetColorName(str);
      }
   }

} // End ColorModC HandleNameChange


/*---------------------------------------------------------------
 *  Method to initialize fields from given pixel
 */

void
ColorModC::Init(Pixel val)
{
   init.value = value = val;
   init.name  = name  = ColorName(da, val);
   XtVaSetValues(da, XmNbackground, init.value, NULL);
   XmTextFieldSetString(tf, init.name);
   changed = False;
}

/*---------------------------------------------------------------
 *  Method to initialize fields from given color name
 */

void
ColorModC::Init(const char *n)
{
   Pixel	val;
   if ( !PixelValue(da, n, &val) ) return;

   init.value = value = val;
   init.name  = n;
   XtVaSetValues(da, XmNbackground, init.value, NULL);
   XmTextFieldSetString(tf, init.name);
   changed = False;
}

/*---------------------------------------------------------------
 *  Method to reset fields to initial state
 */

void
ColorModC::Reset()
{
   if ( init.value != value ) {
      XtVaSetValues(da, XmNbackground, init.value, NULL);
      value = init.value;
      XmTextFieldSetString(tf, init.name);
      name = init.name;
      changed = True;
      if ( colorPickerDialog && colorPickerDialog->IsShown() ) {
	 colorPicker->SetColorName(init.name);
      }
   } else {
      changed = False;
   }
}


/*---------------------------------------------------------------
 * This method creates the color picker with the color
 * of the attribute which the user is changing.
 */

void ColorModC::DoShowColorPicker(Widget, ColorModC *This, XtPointer)
{
   WArgList args;

   if ( !colorPickerDialog ) {
      colorPickerDialog = new HalDialogC("colorPickerDialog", *halApp);

      args.Reset();
      args.LeftAttachment(XmATTACH_FORM);
      args.RightAttachment(XmATTACH_FORM); 
      args.TopAttachment(XmATTACH_FORM);
      args.BottomAttachment(XmATTACH_FORM);
      colorPicker = new ColorPickerC(colorPickerDialog->AppForm(), "colorPicker", ARGS);

      XtAddCallback(colorPicker->NameList(), XmNdefaultActionCallback,
		    (XtCallbackProc)DoColorPickerAction, (XtPointer)0);

      colorPickerDialog->AddButtonBox();

      Widget p = colorPickerDialog->ButtonBox();
      okPB     = XmCreatePushButton(p, "okPB",      0,0);
      applyPB  = XmCreatePushButton(p, "applyPB",   0,0);
      cancelPB = XmCreatePushButton(p, "cancelPB",  0,0);
      helpPB   = XmCreatePushButton(p, "helpPB",    0,0);

      XtAddCallback(okPB, XmNactivateCallback,
		    (XtCallbackProc)DoColorPickerAction, (XtPointer)0);
      XtAddCallback(applyPB, XmNactivateCallback,
		    (XtCallbackProc)DoColorPickerAction, (XtPointer)0);
      XtAddCallback(cancelPB, XmNactivateCallback,
		    (XtCallbackProc)DoColorPickerAction, (XtPointer)0);
      XtAddCallback(helpPB, XmNactivateCallback,
		    (XtCallbackProc)DoColorPickerAction, (XtPointer)0);

      XtManageChild(okPB);
      XtManageChild(applyPB);
      XtManageChild(cancelPB);
      XtManageChild(helpPB);
      colorPickerDialog->HandleHelp();
   }
   colorMod = This;
   if ( ! colorPicker->SetColorName(This->name) ) {
      colorPicker->SetPixelValue(This->value);
   }
   colorPickerDialog->Show();
}


/*---------------------------------------------------------------
 * This callback is the one called to from the ColorPickerDialog.
 */
void ColorModC::DoColorPickerAction(Widget w, XtPointer, XtPointer)
{
   if ( w == cancelPB ) {
      colorPickerDialog->Hide();
      return;
   }
   if (w == helpPB) {
     halApp->DoHelp(w, "helpcard", NULL);
     return;
   }

//
// We're left with ok, apply or list default action...
//
   char *colorName = colorPicker->GetClosestColorName();
   XmTextFieldSetString(colorMod->tf, colorName);
   XtCallCallbacks(colorMod->tf, XmNactivateCallback, (XtPointer)colorMod);

   if ( w == okPB ) {
      colorPickerDialog->Hide();
   }
}


/*---------------------------------------------------------------
 * This callback is the one called to from the ColorPickerDialog.
 */
void ColorModC::DoHideColorPicker(Widget, ColorModC* This, XtPointer)
{
   if ( This == colorMod && colorPickerDialog &&
	colorPickerDialog->IsShown() ) {
      colorPickerDialog->Hide();
      colorMod = NULL;
   }
}


/*---------------------------------------------------------------
 * This callback is the one called to from the ColorPicker when
 * a color has been selected from the list...
 */
void ColorModC::HandleMapChange(Widget, ColorModC *This, XEvent *ev, Boolean*)
{
   if ( ev->type == UnmapNotify && This == colorMod &&
        colorPickerDialog && colorPickerDialog->IsShown() ) {
      colorPickerDialog->Hide();
      colorMod = NULL;
   }
}
