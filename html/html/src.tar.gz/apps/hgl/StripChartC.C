/*
 * $Id: StripChartC.C,v 1.1 1998/06/24 01:29:07 lang Exp $
 *
 * Copyright (c) 1992 HAL Computer Systems International, Ltd.
 * 
 *          HAL COMPUTER SYSTEMS INTERNATIONAL, LTD.
 *                  1315 Dell Avenue
 *                  Campbell, CA  95008
 *
 * Author: Greg Hilton
 * Contributors: Tom Lang, Frank Bieser, and others
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * http://www.gnu.org/copyleft/gpl.html
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#include "HalAppC.h"
#include "StripChartC.h"
#include "WArgList.h"
#include "Shadow.h"
#include "rsrc.h"
#include "IntListC.h"
#include "RegexC.h"
#include "StringListC.h"
#include "WorkingBoxC.h"

#include <Xm/Form.h>
#include <Xm/DrawingA.h>
#include <Xm/ScrollBar.h>

#define BLACK	BlackPixel(halApp->display, DefaultScreen(halApp->display))
#define WHITE	WhitePixel(halApp->display, DefaultScreen(halApp->display))

/*----------------------------------------------------------------------
 * Constructor
 */

StripChartC::StripChartC(Widget parent, const char *name, ArgList argv,
			 Cardinal argc)
: GraphC(BuildWidgets(parent, name, argv, argc))
{
//
// Read attributes
//
   char	*cl = "StripChartC";
   colors[BACKGROUND]    = get_color(cl, da, "background", WHITE);
   colors[TOP_SHADOW]    = get_color(cl, da, "topShadowColor", WHITE);
   colors[BOTTOM_SHADOW] = get_color(cl, da, "bottomShadowColor", BLACK);
   colors[CHART_COLOR]   = get_color(cl, da, "chartColor", colors[BACKGROUND]);
   colors[LINE_COLOR]    = get_color(cl, da, "lineColor",  BLACK);
   colors[AXIS_COLOR]    = get_color(cl, da, "axisColor",  BLACK);
   colors[LABEL_COLOR]   = get_color(cl, da, "labelColor", BLACK);
   colors[TICK_COLOR]    = get_color(cl, da, "tickColor",  BLACK);
   colors[GRID_COLOR]    = get_color(cl, da, "gridColor",  BLACK);
   colors[MARK_COLOR]    = get_color(cl, da, "markColor",  BLACK);

   StringC	fstr = get_string(cl, da, "font", "fixed");
   font	= XLoadQueryFont(halApp->display, fstr);
   if ( !font ) font = halApp->font;
   shadowType        = get_shadow_type(cl, da, "shadowType",    XmSHADOW_OUT);
   shadowThickness   = get_int    (cl, da, "shadowThickness",   2);
   labelOffset	     = get_int    (cl, da, "labelOffset",       2);
   majorTickLen      = get_int    (cl, da, "majorTickLength",   8);
   minorTickLen      = get_int    (cl, da, "minorTickLength",   4);
   majorXTickSpacing = get_int    (cl, da, "majorXTickSpacing", 0);
   minorXTickSpacing = get_int    (cl, da, "minorXTickSpacing", 0);
   majorYTickSpacing = get_float  (cl, da, "majorYTickSpacing", 0.0);
   minorYTickSpacing = get_float  (cl, da, "minorYTickSpacing", 0.0);
   majorXGridVis     = get_boolean(cl, da, "majorXGridVisible", False);
   minorXGridVis     = get_boolean(cl, da, "minorXGridVisible", False);
   majorYGridVis     = get_boolean(cl, da, "majorYGridVisible", False);
   minorYGridVis     = get_boolean(cl, da, "minorYGridVisible", False);
   minValue	     = get_float  (cl, da, "minValue", 0.0);
   maxValue	     = get_float  (cl, da, "maxValue", minValue + 1.0);
   valRangeInv       = 1.0 / (maxValue - minValue);
   visCount	     = get_int    (cl, da, "visibleValueCount", 0);
   maxCount	     = get_int    (cl, da, "maximumValueCount", 0);
   int precis        = get_int    (cl, da, "decimalPlaces", 2);
   formatVal.SetPrecision(precis);
   minIndex = 0;
   maxIndex = 0;

//
// Get color names
//
   colorNames[BACKGROUND]    = ColorName(da, colors[BACKGROUND]);
   colorNames[CHART_COLOR]   = ColorName(da, colors[CHART_COLOR]);
   colorNames[LINE_COLOR]    = ColorName(da, colors[LINE_COLOR]);
   colorNames[AXIS_COLOR]    = ColorName(da, colors[AXIS_COLOR]);
   colorNames[LABEL_COLOR]   = ColorName(da, colors[LABEL_COLOR]);
   colorNames[TICK_COLOR]    = ColorName(da, colors[TICK_COLOR]);
   colorNames[GRID_COLOR]    = ColorName(da, colors[GRID_COLOR]);
   colorNames[MARK_COLOR]    = ColorName(da, colors[MARK_COLOR]);
   colorNames[TOP_SHADOW]    = ColorName(da, colors[TOP_SHADOW]);
   colorNames[BOTTOM_SHADOW] = ColorName(da, colors[BOTTOM_SHADOW]);

//
// Turn off the scroll bar if all values are visible
//
   if ( visCount < 2 ) {
      XtVaSetValues(da, XmNbottomAttachment, XmATTACH_FORM, NULL);
      XtUnmanageChild(scrollBar);
   }

   return;

} // End StripChartC StripChartC

/*----------------------------------------------------------------------
 * Destructor
 */

StripChartC::~StripChartC()
{
   if ( halApp->xRunning )
      XFreeFont(halApp->display, font);
}

/*----------------------------------------------------------------------
 * Callback to build drawing area widget
 */

Widget
StripChartC::BuildWidgets(Widget parent, const char *name, ArgList argv,
			  Cardinal argc)
{
   WArgList	args;		// Used to set all resources at once

//
// Create form
//
   StringC	nameStr = name;
   nameStr += "Form";
   form = XmCreateForm(parent, nameStr, argv, argc);
   args.Reset();
   args.MarginWidth(0);
   args.MarginHeight(0);
   XtSetValues(form, ARGS);

//
// Create scroll bar
//
   nameStr = name;
   nameStr += "SB";
   args.Reset();
   args.Orientation(XmHORIZONTAL);
   args.LeftAttachment(XmATTACH_FORM);
   args.RightAttachment(XmATTACH_FORM);
   args.TopAttachment(XmATTACH_NONE);
   args.BottomAttachment(XmATTACH_FORM);
   scrollBar = XmCreateScrollBar(form, nameStr, ARGS);
   XtManageChild(scrollBar);

   XtAddCallback(scrollBar, XmNvalueChangedCallback, (XtCallbackProc)ScrollCB,
		 (XtPointer)this);
   XtAddCallback(scrollBar, XmNdragCallback,         (XtCallbackProc)ScrollCB,
		 (XtPointer)this);

//
// Create drawing area
//
   args.Reset();
   args.LeftAttachment(XmATTACH_FORM, 0);
   args.RightAttachment(XmATTACH_FORM, 0);
   args.TopAttachment(XmATTACH_FORM, 0);
   args.BottomAttachment(XmATTACH_WIDGET, scrollBar);
   da = XmCreateDrawingArea(form, (char *)name, ARGS);
   XtManageChild(da);

   return da;

} // End StripChartC BuildWidgets

/*----------------------------------------------------------------------
 * Callback to handle scroll bar value change
 */

void
StripChartC::ScrollCB(Widget, StripChartC *sp, XmScrollBarCallbackStruct *sb)
{
   if ( sp->visCount > 1 ) {
      sp->minIndex = sb->value;
      sp->maxIndex = sp->minIndex + sp->visCount - 1;
      sp->Draw();
   }
}

/*----------------------------------------------------------------------
 * Method to draw strip chart
 */

void
StripChartC::Draw()
{
   if ( !gc || obscured ) return;

   XSetForeground(halApp->display, gc, colors[BACKGROUND]);
   XFillRectangle(halApp->display, pixmap, gc, 0, 0, daWd, daHt);

//
// Create label strings
//
   formatVal = minValue;
   StringC	minStr = formatVal;
   formatVal = maxValue;
   StringC	maxStr = formatVal;

   int		dir, asc, dsc;
   XCharStruct	minSize, maxSize;
   XTextExtents(font, minStr, minStr.size(), &dir, &asc, &dsc, &minSize);
   XTextExtents(font, maxStr, maxStr.size(), &dir, &asc, &dsc, &maxSize);
   int	labelWd = MAX(maxSize.width, minSize.width);

//
// Compute space need for y axis annotations
//
   int	leftMargin = marginWd + labelWd + labelOffset;
   if ( majorTickLen > minorTickLen ) {
      if      ( majorYTickSpacing > 0.0 ) leftMargin += majorTickLen;
      else if ( minorYTickSpacing > 0.0 ) leftMargin += minorTickLen;
   } else {
      if      ( minorYTickSpacing > 0.0 ) leftMargin += minorTickLen;
      else if ( majorYTickSpacing > 0.0 ) leftMargin += majorTickLen;
   }

//
// If first label on x axis is too wide, move y axis over
//
   if ( labelList.size() > 0 ) {
      StringC		*label = labelList[minIndex];
      XCharStruct	cSize;
      XTextExtents(font, *label, label->size(), &dir, &asc, &dsc, &cSize);
      cSize.width /= 2;
      if ( cSize.width > leftMargin ) leftMargin = cSize.width + 1;
   }

//
// Subtract for value label on right
//
   int	rightMargin = marginWd + labelWd + labelOffset;

//
// If last label on x axis is too wide, move right margin over
//
   if ( labelList.size() > 1 ) {
      StringC		*label = labelList[maxIndex];
      XCharStruct	cSize;
      XTextExtents(font, *label, label->size(), &dir, &asc, &dsc, &cSize);
      cSize.width /= 2;
      if ( cSize.width > rightMargin ) rightMargin = cSize.width + 1;
   }

   int	axisX1 = leftMargin;
   int	axisX2 = daWd - rightMargin - 1;
   int	axisWd = axisX2 - axisX1 + 1;
   int	valX1  = axisX1 + shadowThickness;
   int	valX2  = axisX2 - shadowThickness;
   int	valWd  = valX2 - valX1 + 1;

   int	fontHt = font->ascent + font->descent;
   int	fontHt2 = fontHt / 2;

   int	topMargin    = marginHt + fontHt2;
   int	bottomMargin = marginHt + fontHt + labelOffset;
   if ( majorTickLen > minorTickLen ) {
      if      ( majorXTickSpacing > 0 ) bottomMargin += majorTickLen;
      else if ( minorXTickSpacing > 0 ) bottomMargin += minorTickLen;
   } else {
      if      ( minorXTickSpacing > 0 ) bottomMargin += minorTickLen;
      else if ( majorXTickSpacing > 0 ) bottomMargin += majorTickLen;
   }

   int	axisY1 = topMargin;
   int	axisY2 = daHt - bottomMargin - 1;
   int	axisHt = axisY2 - axisY1 + 1;
   int	valY1  = axisY1 + shadowThickness;
   int	valY2  = axisY2 - shadowThickness;
   int	valHt  = valY2 - valY1 + 1;

//
// Draw Y-axis ticks
//
   XSetForeground(halApp->display, gc, colors[TICK_COLOR]);
   if ( majorYTickSpacing > 0.0 ) {
      int	tx1 = axisX1 - majorTickLen;
      for (float val = minValue; val <= maxValue; val += majorYTickSpacing) {
	 int	ty = valY2 - (int)(NormalizeValue(val) * valHt);
	 XDrawLine(halApp->display, pixmap, gc, tx1, ty, axisX1-1, ty);
      }

   } // End if major ticks

   if ( minorYTickSpacing > 0.0 ) {
      int	tx1 = axisX1 - minorTickLen;
      for (float val = minValue; val <= maxValue; val += minorYTickSpacing) {
	 int	ty = valY2 - (int)(NormalizeValue(val) * valHt);
	 XDrawLine(halApp->display, pixmap, gc, tx1, ty, axisX1-1, ty);
      }

   } // End if minor ticks

//
// Calculate X-axis spacing
//
   int	count;
   int	vcount = valueList.size();
   if ( visCount > 1 ) count = MIN(visCount, vcount);
   else		       count = vcount;

   float	xincr = (float)(valWd - 1);
   if ( count > 1 ) xincr /= (float)(count-1);

//
// Draw X-axis ticks
//
   if ( majorXTickSpacing > 0 ) {
      int	ty = axisY2 + majorTickLen + 1;
      for (int i=0; i<count; i+=majorXTickSpacing) {
	 int	tx = valX1 + (int)(xincr * i);
	 XDrawLine(halApp->display, pixmap, gc, tx, axisY2+1, tx, ty);
      }
   }

   if ( minorXTickSpacing > 0 ) {
      int	ty = axisY2 + minorTickLen + 1;
      for (int i=0; i<count; i+=minorXTickSpacing) {
	 int	tx = valX1 + (int)(xincr * i);
	 XDrawLine(halApp->display, pixmap, gc, tx, axisY2+1, tx, ty);
      }
   }

//
// Draw Y-axis labels
//
   XSetForeground(halApp->display, gc, colors[LABEL_COLOR]);

   int	x = axisX1 - labelOffset - maxSize.width;
   if ( majorTickLen > minorTickLen ) {
      if      ( majorYTickSpacing > 0.0 ) x -= majorTickLen;
      else if ( minorYTickSpacing > 0.0 ) x -= minorTickLen;
   } else {
      if      ( minorYTickSpacing > 0.0 ) x -= minorTickLen;
      else if ( majorYTickSpacing > 0.0 ) x -= majorTickLen;
   }

   int	y = valY1 + font->ascent - fontHt2;
   XDrawString(halApp->display, pixmap, gc, x, y, maxStr, maxStr.size());
   int	topY = y - font->descent;

   x += (maxSize.width - minSize.width);
   y = valY2 + font->ascent - fontHt2;
   XDrawString(halApp->display, pixmap, gc, x, y, minStr, minStr.size());
   int	botY = y + font->ascent;

//
// Draw the interior labels
//
   if ( majorYTickSpacing > 0.0 ) {
      x += minSize.width;
      for (float val=minValue+majorYTickSpacing; val<maxValue;
	   val+=majorYTickSpacing) {
	 formatVal = val;
	 StringC valStr = formatVal;
	 XCharStruct	size;
	 XTextExtents(font, valStr, valStr.size(), &dir, &asc, &dsc, &size);
	 x -= size.width;
	 y = valY2 - (int)(NormalizeValue(val) * valHt) + font->ascent-fontHt2;
//
// Draw only if it doesn't overlap another
//
	 if ( (y-size.ascent)>topY && (y+size.descent)<botY ) {
	    XDrawString(halApp->display, pixmap, gc,x,y, valStr, valStr.size());
	    botY = y + size.ascent;
	 }
	 x += size.width;

      } // End for each major value
   } // End if there are major ticks

//
// Draw X-axis labels
//
   unsigned	lcount = labelList.size();
   if ( lcount > 0 ) {

      y = axisY2 + labelOffset + font->ascent + 1;
      if ( majorTickLen > minorTickLen ) {
	 if      ( majorXTickSpacing > 0 ) y += majorTickLen;
	 else if ( minorXTickSpacing > 0 ) y += minorTickLen;
      } else {
	 if      ( minorXTickSpacing > 0 ) y += minorTickLen;
	 else if ( majorXTickSpacing > 0 ) y += majorTickLen;
      }

//
// Draw the first label
//
      StringC	*label = labelList[minIndex];
      XCharStruct	cSize;
      XTextExtents(font, *label, label->size(), &dir, &asc, &dsc, &cSize);

      x = valX1 - cSize.width/2;		// Center at valX1
      XDrawString(halApp->display, pixmap, gc, x, y, *label, label->size());

      // Mark the end of the label
      int	leftX = x + cSize.width + labelOffset;

//
// Draw the last label
//
      if ( lcount > 1 ) {

	 label = labelList[maxIndex];
	 XTextExtents(font, *label, label->size(), &dir, &asc, &dsc, &cSize);

//
// Draw it only if it doesn't overlap the first label
//
	 x = valX2 - cSize.width/2;	// Center at valX2
	 if ( x > leftX )
	    XDrawString(halApp->display, pixmap, gc,x,y, *label, label->size());

         if ( majorXTickSpacing > 0 ) {
	    int	rightX = x - labelOffset;   // Mark the beginning of the label
//
// Draw the interior labels
//
	    for (int i=minIndex+majorXTickSpacing; i<=maxIndex;
		 i+=majorXTickSpacing) {

	       label = labelList[i];
	       XTextExtents(font, *label, label->size(), &dir, &asc, &dsc,
			    &cSize);

//
// Draw only if it doesn't overlap another
//
	       x = valX1 + (int)(xincr * (i-minIndex)) - cSize.width/2;
	       if ( x > leftX && (x + cSize.width) < rightX ) {
		  XDrawString(halApp->display, pixmap, gc, x, y, *label,
			      label->size());
		  leftX = x + cSize.width + labelOffset;
	       }

	    } // End if there are major x ticks
	 } // End for each x label
      } // End if at least 2 labels
   } // End if at least 1 label

//
// Draw chart background
//
   XSetForeground(halApp->display, gc, colors[CHART_COLOR]);
   XFillRectangle(halApp->display, pixmap, gc, axisX1, axisY1, axisWd, axisHt);

//
// Draw chart shadow if necessary
//
   if ( shadowThickness > 0 ) {

      DrawShadow(halApp->display, pixmap, gc, colors[TOP_SHADOW],
		 colors[BOTTOM_SHADOW], axisX1, axisY1, axisWd, axisHt,
		 shadowThickness, shadowType);

   } else { // Draw axis lines

      XSetForeground(halApp->display, gc, colors[AXIS_COLOR]);
      XDrawLine(halApp->display, pixmap, gc, axisX1-1, axisY1, axisX1-1,axisY2);
      XDrawLine(halApp->display, pixmap, gc, axisX1-1, axisY2+1, axisX2,
		axisY2+1);
   }

//
// Set clipping window
//
   XRectangle	rect;
   rect.x      = (short)valX1;
   rect.y      = (short)valY1;
   rect.width  = (unsigned short)valWd;
   rect.height = (unsigned short)valHt;
   XSetClipRectangles(halApp->display, gc, 0, 0, &rect, 1, Unsorted);

//
// Connect points
//
   float	val = 0;
   if ( vcount > 0 ) val = *valueList[minIndex];
   float	curx = (float)valX1 + xincr;
   int		y1 = valY2 - (int)(NormalizeValue(val) * valHt);
   int		x1 = valX1;

   XSetForeground(halApp->display, gc, colors[LINE_COLOR]);
   for (int i=minIndex+1; i<=maxIndex; i++) {
      val = *valueList[i];
      int	y2 = valY2 - (int)(NormalizeValue(val) * valHt);
      int	x2 = (int)curx;
      XDrawLine(halApp->display, pixmap, gc, x1, y1, x2, y2);
      x1 = x2;
      y1 = y2;
      curx += xincr;
   }

   XSetClipMask(halApp->display, gc, None);

//
// Draw grid lines
//
   XSetForeground(halApp->display, gc, colors[GRID_COLOR]);
   XSetLineAttributes(halApp->display, gc,0, LineOnOffDash, CapButt, JoinMiter);

   if ( majorYTickSpacing > 0.0 && majorYGridVis ) {
      for (float val=minValue; val<=maxValue; val+=majorYTickSpacing) {
	 int	ty = valY2 - (int)(NormalizeValue(val) * valHt);
	 XDrawLine(halApp->display, pixmap, gc, valX1, ty, valX2, ty);
      }
   } // End if major y grid lines

   if ( minorYTickSpacing > 0.0 && minorYGridVis ) {
      for (float val=minValue; val<=maxValue; val+=minorYTickSpacing) {
	 int	ty = valY2 - (int)(NormalizeValue(val) * valHt);
	 XDrawLine(halApp->display, pixmap, gc, valX1, ty, valX2, ty);
      }
   } // End if minor y grid lines

   if ( majorXTickSpacing > 0 && majorXGridVis ) {
      for (int i=0; i<count; i+=majorXTickSpacing) {
	 int	tx = valX1 + (int)(xincr * i);
	 XDrawLine(halApp->display, pixmap, gc, tx, valY1, tx, valY2);
      }
   }

   if ( minorXTickSpacing > 0 && minorXGridVis ) {
      for (int i=0; i<count; i+=minorXTickSpacing) {
	 int	tx = valX1 + (int)(xincr * i);
	 XDrawLine(halApp->display, pixmap, gc, tx, valY1, tx, valY2);
      }
   }

   XSetLineAttributes(halApp->display, gc, 0, LineSolid, CapButt, JoinMiter);

//
// Draw marks
//
   XSetForeground(halApp->display, gc, colors[MARK_COLOR]);

   fontHt = font->ascent + font->descent;
   fontHt2 = fontHt / 2;
   x = axisX2 + labelOffset;
   unsigned	mcount = markList.size();
   for (i=0; i<mcount; i++) {

      val = *markList[i];

      int	y = valY2 - (int)(NormalizeValue(val) * valHt);
      if ( y >= valY1 && y <= valY2 ) {
	 XDrawLine(halApp->display, pixmap, gc, axisX1, y, axisX2, y);

	 formatVal = val;
	 StringC valStr = formatVal;
	 int		dir, asc, dsc;
	 XCharStruct	size;
	 XTextExtents(font, valStr, valStr.size(), &dir, &asc, &dsc, &size);

	 y += font->ascent - fontHt2;
	 XDrawString(halApp->display, pixmap, gc, x, y, valStr, valStr.size());
      }

   } // End for each mark

//
// Draw current value label
//
   if ( valueList.size() > 0 ) {
      XSetForeground(halApp->display, gc, colors[LABEL_COLOR]);
      float	val = *valueList[maxIndex];
      int	y = valY2 - (int)(NormalizeValue(val) * valHt);
      if ( y >= valY1 && y <= valY2 ) {
	 formatVal = val;
	 StringC valStr = formatVal;
	 int		dir, asc, dsc;
	 XCharStruct	size;
	 XTextExtents(font, valStr, valStr.size(), &dir, &asc, &dsc, &size);

	 y += font->ascent - fontHt2;
	 XDrawString(halApp->display, pixmap, gc, x, y, valStr, valStr.size());
      }

   } // End if there are values

   XCopyArea(halApp->display, pixmap, win, gc, 0, 0, daWd, daHt, 0, 0);

//
// Position the scroll bar
//
   int	sliderSize = MAX(count,1);
   int	sliderInc  = sliderSize;
   int	sliderMax  = MAX(vcount, sliderSize);

   WArgList	args;
   args.LeftOffset(leftMargin);
   args.RightOffset(rightMargin);
   args.Maximum(sliderMax);
   args.Value(minIndex);
   args.SliderSize(sliderSize);
   args.PageIncrement(sliderInc);
   XtSetValues(scrollBar, ARGS);

} // End StripChartC Draw

/*----------------------------------------------------------------------
 * Method to convert value into range 0.0 to 1.0
  */

float
StripChartC::NormalizeValue(float val)
{
   return ((val - minValue) * valRangeInv);
}

/*----------------------------------------------------------------------
 * Method to add a mark
 */

void
StripChartC::AddMark(const ValueC val)
{
   float	fval = val;
   markList.append(fval);
   if ( !deferred ) Draw();
}

/*----------------------------------------------------------------------
 * Method to add a value
 */

void
StripChartC::AddValue(const ValueC val, const char *label)
{
//
// Add value to end
//
   float	fval = val;
   valueList.append(fval);
   StringC	str(label);
   labelList.append(str);
   unsigned	vCount = valueList.size();

//
// Remove value from beginning if we've exceeded the maximum
//
   if ( maxCount>0 && vCount>maxCount ) {

      valueList.remove((unsigned)0);
      labelList.remove((int)0);
      vCount--;

   } else {

//
// Update visible region if necessary
//
      if ( visCount > 1 ) {

//
// If the last value was visible, keep it that way
//
	 if ( maxIndex == vCount-2 ) {
	    maxIndex++;
	    minIndex = maxIndex - visCount + 1;
	    if ( minIndex < 0 ) minIndex = 0;
	 } else if ( minIndex == 0 ) {
	    maxIndex = minIndex + visCount - 1;
	    if ( maxIndex >= vCount ) maxIndex = vCount - 1;
	 }

      } else {
	 maxIndex = vCount - 1;
      }

   } // End if not at maximum capacity

   if ( !deferred ) Draw();
}

/*----------------------------------------------------------------------
 * Method to set the shadow thickness
 */

void
StripChartC::SetShadowThickness(Dimension thick)
{
   if ( thick != shadowThickness ) {
      shadowThickness = thick;
      if ( !deferred ) Draw();
   }
}

/*----------------------------------------------------------------------
 * Method to set the shadow type
 */

void
StripChartC::SetShadowType(unsigned char type)
{
   if ( type != shadowType ) {
      shadowType = type;
      if ( !deferred ) Draw();
   }
}

/*----------------------------------------------------------------------
 * Method to set the spacing between labels and the strip chart
 */

void
StripChartC::SetLabelOffset(int offset)
{
   if ( offset != labelOffset ) {
      labelOffset = offset;
      if ( !deferred ) Draw();
   }
}

/*----------------------------------------------------------------------
 * Method to set the margin width and height
 */

void
StripChartC::SetMargins(Dimension wd, Dimension ht)
{
   if ( wd != marginWd || ht != marginHt ) {
      marginWd = wd;
      marginHt = ht;
      if ( !deferred ) Draw();
   }

   return;
}

/*----------------------------------------------------------------------
 * Methods to set mark values
 */

void
StripChartC::SetMarks(const IntListC& list)
{
   markList.removeAll();

   unsigned	count = list.size();
   for (int i=0; i<count; i++) {
      float	fval = *list[i];
      markList.append(fval);
   }

   if ( !deferred ) Draw();
}

void
StripChartC::SetMarks(const FloatListC& list)
{
   markList = list;
   if ( !deferred ) Draw();
}

/*----------------------------------------------------------------------
 * Method to set the maximum number of stored values
 */

void
StripChartC::SetMaximumValueCount(unsigned count)
{
   if ( count == maxCount ) return;

   maxCount = count;
   if ( maxCount < 1 ) return;

//
// Remove extra values if necessary
//
   while ( valueList.size() > maxCount ) valueList.remove((unsigned)0);

   UpdateVisibleRange();

   if ( !deferred ) Draw();

} // End StripChartC SetMaximumValueCount

/*----------------------------------------------------------------------
 * Method to set the numeric output format to INT, HEX or FLOAT
 */

void
StripChartC::SetOutputFormat(ValueC::ValueFormat newFormat)
{
   if ( newFormat != formatVal.Format() ) {
      formatVal.SetFormat(newFormat);
      if ( !deferred ) Draw();
   }
}

/*----------------------------------------------------------------------
 * Methods to set the number of decimal places for float output
 */

void
StripChartC::SetPrecision(int places)
{
   if ( places != formatVal.Precision() ) {
      formatVal.SetPrecision(places);
      if ( !deferred && formatVal.Format() == ValueC::FLOAT ) Draw();
   }
}

/*----------------------------------------------------------------------
 * Method to set the minimum and maximum values for the strip chart
 */

void
StripChartC::SetRange(const ValueC min, const ValueC max)
{
   if ( (float)max <= (float)min ) return;

   minValue = min;
   maxValue = max;
   valRangeInv = 1.0/(maxValue - minValue);

   if ( !deferred ) Draw();
}

/*----------------------------------------------------------------------
 * Method to set the major and minor tick lengths
 */

void
StripChartC::SetTickLength(int maj, int min)
{
   if ( maj != majorTickLen || min != minorTickLen ) {
      majorTickLen = maj;
      minorTickLen = min;
      if ( !deferred ) Draw();
   }
}

/*----------------------------------------------------------------------
 * Methods to set the major and minor tick spacings
 */

void
StripChartC::SetXTickSpacing(int maj, int min)
{
   if ( maj != majorXTickSpacing || min != minorXTickSpacing ) {
      majorXTickSpacing = maj;
      minorXTickSpacing = min;
      if ( !deferred ) Draw();
   }
}

void
StripChartC::SetYTickSpacing(const ValueC maj, const ValueC min)
{
   if ( (float)maj != majorYTickSpacing || (float)min != minorYTickSpacing ) {
      majorYTickSpacing = maj;
      minorYTickSpacing = min;
      if ( !deferred ) Draw();
   }
}

/*----------------------------------------------------------------------
 * Methods to set the major and minor grid visibilities
 */

void
StripChartC::SetXGridVis(Boolean maj, Boolean min)
{
   if ( maj != majorXGridVis || min != minorXGridVis ) {
      majorXGridVis = maj;
      minorXGridVis = min;
      if ( !deferred ) Draw();
   }
}

void
StripChartC::SetYGridVis(Boolean maj, Boolean min)
{
   if ( maj != majorYGridVis || min != minorYGridVis ) {
      majorYGridVis = maj;
      minorYGridVis = min;
      if ( !deferred ) Draw();
   }
}

/*----------------------------------------------------------------------
 * Methods to set the current values
 */

void
StripChartC::SetValues(const FloatListC& values, const StringListC& labels)
{
   unsigned	vCount = values.size();
   unsigned	lCount = labels.size();

//
// Clear lists
//
   valueList.removeAll();
   labelList.removeAll();

//
// Copy only as many as we can save
//
   int	i;
   if ( vCount > maxCount ) i = vCount - maxCount;
   else                     i = 0;

//
// Copy values that have labels
//
   unsigned	minCount = MIN(vCount, lCount);
   for (; i<minCount; i++) {
      valueList.append(*values[i]);
      labelList.append(*labels[i]);
   }

//
// Copy values that don't have labels
//
   StringC	tmp("");
   for (; i<vCount; i++) {
      valueList.append(*values[i]);
      labelList.append(tmp);
   }

   UpdateVisibleRange();

   if ( !deferred ) Draw();

} // End StripChartC SetValues

void
StripChartC::SetValues(const IntListC& values, const StringListC& labels)
{
   unsigned	vCount = values.size();
   unsigned	lCount = labels.size();

//
// Clear lists
//
   valueList.removeAll();
   labelList.removeAll();

//
// Copy only as many as we can save
//
   int	i;
   if ( vCount > maxCount ) i = vCount - maxCount;
   else                     i = 0;

//
// Copy values that have labels
//
   unsigned	minCount = MIN(vCount, lCount);
   for (; i<minCount; i++) {
      float	fval = *values[i];
      valueList.append(fval);
      labelList.append(*labels[i]);
   }

//
// Copy values that don't have labels
//
   StringC	tmp("");
   for (; i<vCount; i++) {
      float	fval = *values[i];
      valueList.append(fval);
      labelList.append(tmp);
   }

   UpdateVisibleRange();

   if ( !deferred ) Draw();

} // End StripChartC SetValues

/*----------------------------------------------------------------------
 * Method to set the number of visible values
 */

void
StripChartC::SetVisibleValueCount(unsigned count)
{
   if ( count == visCount ) return;

   visCount = count;

   UpdateVisibleRange();

//
// Turn off the scroll bar if all values are visible
//
   WArgList	args;
   if ( visCount < 2 ) {
      args.Reset();
      args.BottomAttachment(XmATTACH_FORM);
      XtSetValues(da, ARGS);
      XtUnmanageChild(scrollBar);
   } else {
      XtManageChild(scrollBar);
      args.Reset();
      args.BottomAttachment(XmATTACH_WIDGET, scrollBar);
      XtSetValues(da, ARGS);
   }

   if ( !deferred ) Draw();

} // End StripChartC SetVisibleValueCount

/*----------------------------------------------------------------------
 * Method to recalculate the range of visible values
 */

void
StripChartC::UpdateVisibleRange()
{
   if ( visCount>1 && visCount<valueList.size() ) {
      if ( maxIndex >= valueList.size() ) maxIndex = valueList.size() - 1;
      minIndex = maxIndex - visCount + 1;
      if ( minIndex < 0 ) {
	 minIndex = 0;
	 maxIndex = minIndex + visCount - 1;
      }
   } else {
      minIndex = 0;
      maxIndex = valueList.size() - 1;
   }

} // End StripChartC UpdateVisibleRange

/*----------------------------------------------------------------------
 * Methods to set the requested color
 */

void
StripChartC::SetColor(StripChartC::StripChartColorAttr attr, Pixel color)
{
   if ( colors[attr] == color ) return;

   colors[attr]	    = color;
   colorNames[attr] = ColorName(da, color);

   switch (attr) {

      case (BACKGROUND):
	 XtVaSetValues(da, XmNbackground, color, NULL);

      default:
	 if ( !deferred ) Draw();
	 break;

   } // End switch color attribute
}

void
StripChartC::SetColor(StripChartC::StripChartColorAttr attr, const char *name)
{
   Pixel	color;
   if ( PixelValue(da, name, &color) ) SetColor(attr, color);
}

/*----------------------------------------------------------------------
 * Method to return the requested pixel value
 */

Pixel
StripChartC::GetColor(StripChartC::StripChartColorAttr attr) const
{
   return colors[attr];
}

/*----------------------------------------------------------------------
 * Method to return the requested color name
 */

StringC
StripChartC::GetColorName(StripChartC::StripChartColorAttr attr) const
{
   return colorNames[attr];
}

/*----------------------------------------------------------------------
 * Method to return the margin width and height
 */

void
StripChartC::GetMargins(Dimension *wd, Dimension *ht) const
{
   *wd = marginWd;
   *ht = marginHt;
   return;
}

/*-----------------------------------------------------------------------
 *  Methods to return the min and max values
 */

void
StripChartC::GetRange(ValueC *min, ValueC *max) const
{
   *min = minValue;
   *max = maxValue;
}

void
StripChartC::GetRange(StringC *min, StringC *max) const
{
   ValueC	tmp(formatVal);
   tmp = minValue;
   *min = (StringC)tmp;
   tmp = maxValue;
   *max = (StringC)tmp;
}

void
StripChartC::GetRange(int *min, int *max) const
{
   *min = (int)minValue;
   *max = (int)maxValue;
}

void
StripChartC::GetRange(long *min, long *max) const
{
   *min = (long)minValue;
   *max = (long)maxValue;
}

void
StripChartC::GetRange(float *min, float *max) const
{
   *min = minValue;
   *max = maxValue;
}

/*-----------------------------------------------------------------------
 *  Method to return the major and minor tick lengths
 */

void
StripChartC::GetTickLength(int *maj, int *min) const
{
   *maj = majorTickLen;
   *min = minorTickLen;
}

/*-----------------------------------------------------------------------
 *  Methods to return the major and minor grid visibilities
 */

void
StripChartC::GetXGridVis(Boolean *maj, Boolean *min) const
{
   *maj = majorXGridVis;
   *min = minorXGridVis;
}

void
StripChartC::GetYGridVis(Boolean *maj, Boolean *min) const
{
   *maj = majorYGridVis;
   *min = minorYGridVis;
}

/*-----------------------------------------------------------------------
 *  Methods to return the major and minor tick spacings
 */

void
StripChartC::GetXTickSpacing(StringC *maj, StringC *min) const
{
   ValueC	tmp(formatVal);
   tmp = majorXTickSpacing;
   *maj = (StringC)tmp;
   tmp = minorXTickSpacing;
   *min = (StringC)tmp;
}

void
StripChartC::GetXTickSpacing(int *maj, int *min) const
{
   *maj = (int)majorXTickSpacing;
   *min = (int)minorXTickSpacing;
}

void
StripChartC::GetYTickSpacing(ValueC *maj, ValueC *min) const
{
   *maj = majorYTickSpacing;
   *min = minorYTickSpacing;
}

void
StripChartC::GetYTickSpacing(StringC *maj, StringC *min) const
{
   ValueC	tmp(formatVal);
   tmp = majorYTickSpacing;
   *maj = (StringC)tmp;
   tmp = minorYTickSpacing;
   *min = (StringC)tmp;
}

void
StripChartC::GetYTickSpacing(int *maj, int *min) const
{
   *maj = (int)majorYTickSpacing;
   *min = (int)minorYTickSpacing;
}

void
StripChartC::GetYTickSpacing(long *maj, long *min) const
{
   *maj = (long)majorYTickSpacing;
   *min = (long)minorYTickSpacing;
}

void
StripChartC::GetYTickSpacing(float *maj, float *min) const
{
   *maj = majorYTickSpacing;
   *min = minorYTickSpacing;
}

/*----------------------------------------------------------------------
 * Method to copy the attributes of another strip chart
 */

StripChartC&
StripChartC::operator=(const StripChartC& that)
{
   marginWd          = that.marginWd;
   marginHt          = that.marginHt;
   shadowType        = that.shadowType;
   shadowThickness   = that.shadowThickness;
   labelOffset       = that.labelOffset;
   majorTickLen	     = that.majorTickLen;
   minorTickLen	     = that.minorTickLen;
   majorXTickSpacing = that.majorXTickSpacing;
   minorXTickSpacing = that.minorXTickSpacing;
   majorYTickSpacing = that.majorYTickSpacing;
   minorYTickSpacing = that.minorYTickSpacing;
   majorXGridVis     = that.majorXGridVis;
   minorXGridVis     = that.minorXGridVis;
   majorYGridVis     = that.majorYGridVis;
   minorYGridVis     = that.minorYGridVis;
   minValue	     = that.minValue;
   maxValue	     = that.maxValue;
   valRangeInv	     = that.valRangeInv;
   formatVal	     = that.formatVal;

   Defer(True);
   SetVisibleValueCount(that.visCount);
   SetMaximumValueCount(that.maxCount);
   Defer(False);

   for (int i=0; i<COLOR_ATTR_COUNT; i++) {
      colors[i]	    = that.colors[i];
      colorNames[i] = that.colorNames[i];
   }
   XtVaSetValues(da, XmNbackground, colors[BACKGROUND], NULL);

   if ( !deferred ) Draw();

   return *this;

} // End StripChartC operator=

/*----------------------------------------------------------------------
 * Method to write resources to a file
 */

void
StripChartC::Write(FILE *fp, const char *prefix)
{
//
// Create next level prefix
//
   StringC	prefix2 = prefix; prefix2 += "\t";

//
// Write data
//
   fprintf(fp, "%s{STRIPCHART\n", prefix);

   WriteResource  (fp, prefix2 + "background",		colorNames[BACKGROUND]);
   WriteResource  (fp, prefix2 + "chartColor",	colorNames[CHART_COLOR]);
   WriteResource  (fp, prefix2 + "lineColor",		colorNames[LINE_COLOR]);
   WriteResource  (fp, prefix2 + "axisColor",		colorNames[AXIS_COLOR]);
   WriteResource  (fp, prefix2 + "labelColor",	colorNames[LABEL_COLOR]);
   WriteResource  (fp, prefix2 + "tickColor",		colorNames[TICK_COLOR]);
   WriteResource  (fp, prefix2 + "gridColor",		colorNames[GRID_COLOR]);
   WriteResource  (fp, prefix2 + "markColor",		colorNames[MARK_COLOR]);
   WriteResource  (fp, prefix2 + "topShadowColor",	colorNames[TOP_SHADOW]);
   WriteResource  (fp, prefix2 + "bottomShadowColor",colorNames[BOTTOM_SHADOW]);

   WriteResource  (fp, prefix2 + "values",		valueList);
   WriteResource  (fp, prefix2 + "labels",		labelList);
   WriteResource  (fp, prefix2 + "minValue",		minValue);
   WriteResource  (fp, prefix2 + "maxValue",		maxValue);
   WriteResource  (fp, prefix2 + "outputFormat",	formatVal.FormatName());
   WriteResource  (fp, prefix2 + "decimalPlaces",	formatVal.Precision());
   WriteResource  (fp, prefix2 + "marks",		markList);
//   WriteResource  (fp, prefix2 + "font",		fontName);
   WriteShadowType(fp, prefix2 + "shadowType",		shadowType);
   WriteResource  (fp, prefix2 + "shadowThickness",	shadowThickness);
   WriteResource  (fp, prefix2 + "majorTickLength",	majorTickLen);
   WriteResource  (fp, prefix2 + "minorTickLength",	minorTickLen);
   WriteResource  (fp, prefix2 + "majorXTickSpacing",	majorXTickSpacing);
   WriteResource  (fp, prefix2 + "minorXTickSpacing",	minorXTickSpacing);
   WriteResource  (fp, prefix2 + "majorYTickSpacing",	majorYTickSpacing);
   WriteResource  (fp, prefix2 + "minorYTickSpacing",	minorYTickSpacing);
   WriteResource  (fp, prefix2 + "majorXGridVisible",	majorXGridVis);
   WriteResource  (fp, prefix2 + "minorXGridVisible",	minorXGridVis);
   WriteResource  (fp, prefix2 + "majorYGridVisible",	majorYGridVis);
   WriteResource  (fp, prefix2 + "minorYGridVisible",	minorYGridVis);
   WriteResource  (fp, prefix2 + "visibleValueCount",	visCount);
   WriteResource  (fp, prefix2 + "maximumValueCount",	maxCount);
   WriteResource  (fp, prefix2 + "labelOffset",		labelOffset);
   WriteResource  (fp, prefix2 + "marginWidth",		marginWd);
   WriteResource  (fp, prefix2 + "marginHeight",	marginHt);

   fprintf(fp, "%sSTRIPCHART}\n", prefix);

} // End StripChartC Write

/*----------------------------------------------------------------------
 * Method to read resources from a file
 */

int
StripChartC::Read(FILE *fp, WorkingBoxC *wb)
{
   StringC		line;
   static RegexC	*pair = NULL;
   static RegexC	*end  = NULL;

   if ( !pair ) {
      end  = new RegexC("[ \t]*STRIPCHART}[ \t]*$");
      pair = new RegexC("[ \t]*\\([^:]+\\):[ \t]*\\(.*\\)");  // rsrc: val
   }

//
// Read resources until next "}" line
//
   StringListC	rsrcList;
   StringListC	rvalList;
   rsrcList.AllowDuplicates(TRUE);
   rvalList.AllowDuplicates(TRUE);

   line.Clear();
   int	status = line.GetLine(fp);
   while ( status != EOF && !end->match(line) && (!wb || !wb->Cancelled()) ) {

      if ( pair->match(line) ) {
	 StringC	tmp = line((*pair)[1]);
	 tmp.toLower();
	 rsrcList.append(tmp);
	 tmp = line((*pair)[2]);
	 rvalList.append(tmp);
      }

      line.Clear();
      status = line.GetLine(fp);
   }

   static RegexC	*word = NULL;
   if ( !word ) word = new RegexC("[^ \t]+");

//
// Extract resources from resource string
//
   Defer(True);
   while ( rsrcList.size() > 0 && (!wb || !wb->Cancelled()) ) {

      StringC	*rsrc  = rsrcList[0];
      StringC	*value = rvalList[0];
      StringC	tmp;
      int	index;

      if      ( *rsrc == "background"        ) SetColor(BACKGROUND,     *value);
      else if ( *rsrc == "chartcolor"        ) SetColor(CHART_COLOR,          *value);
      else if ( *rsrc == "linecolor"         ) SetColor(LINE_COLOR,           *value);
      else if ( *rsrc == "axiscolor"         ) SetColor(AXIS_COLOR,           *value);
      else if ( *rsrc == "labelcolor"        ) SetColor(LABEL_COLOR,          *value);
      else if ( *rsrc == "tickcolor"         ) SetColor(TICK_COLOR,           *value);
      else if ( *rsrc == "gridcolor"         ) SetColor(GRID_COLOR,           *value);
      else if ( *rsrc == "markcolor"         ) SetColor(MARK_COLOR,           *value);
      else if ( *rsrc == "topshadowcolor"    ) SetColor(TOP_SHADOW,     *value);
      else if ( *rsrc == "bottomshadowcolor" ) SetColor(BOTTOM_SHADOW,  *value);

      else if ( *rsrc == "minvalue" || *rsrc == "maxvalue" ) {

	 if ( *rsrc == "minvalue" ) {
	    minValue = atof(*value);
	 } else {
	    tmp = "minvalue";
	    index = rsrcList.indexOf(tmp);
	    if ( index != rsrcList.NULL_INDEX ) {
		minValue = atoi(*rvalList[index]);
		rsrcList.remove(index);
		rvalList.remove(index);
	    }
	 }

	 if ( *rsrc == "maxvalue" ) {
	    maxValue = atof(*value);
	 } else {
	    tmp = "maxvalue";
	    index = rsrcList.indexOf(tmp);
	    if ( index != rsrcList.NULL_INDEX ) {
		maxValue = atoi(*rvalList[index]);
		rsrcList.remove(index);
		rvalList.remove(index);
	    }
	 }

	 valRangeInv = 1.0/(maxValue - minValue);

      } // End if resource is min or max value

      else if ( *rsrc == "outputformat"  ) formatVal.SetFormat(*value);
      else if ( *rsrc == "decimalplaces" ) formatVal.SetPrecision(atoi(*value));

      else if ( *rsrc == "values" ) {

	 valueList.removeAll();
	 while ( word->search(*value) >= 0 ) {
	    float	fval = atof((*value)((*word)[0]));
	    valueList.append(fval);
	    (*value)((*word)[0]) = "";
	 }

      } else if ( *rsrc == "labels" ) {

	 labelList.removeAll();
	 while ( word->search(*value) >= 0 ) {
	    labelList.append((*value)((*word)[0]));
	    (*value)((*word)[0]) = "";
	 }

      } else if ( *rsrc == "marks" ) {

	 markList.removeAll();
	 while ( word->search(*value) >= 0 ) {
	    float	mark = atof((*value)((*word)[0]));
	    markList.append(mark);
	    (*value)((*word)[0]) = "";
	 }
      }
//      else if ( *rsrc == "font"         ) fontName = *value;

      else if ( *rsrc == "shadowtype" ) {

	 XrmValue	from, to;
	 unsigned char	result;
	 from.addr = (XPointer)(char *)*value;
	 from.size = strlen(*value) + 1;
	 to.addr	= (XPointer)&result;
	 to.size	= sizeof(unsigned char);
	 if ( XtConvertAndStore(da, XmRString, &from, XmRShadowType, &to) )
	    shadowType = result;
      }

      else if ( *rsrc == "shadowthickness"   ) shadowThickness   = atoi(*value);
      else if ( *rsrc == "majorticklength"   ) majorTickLen      = atoi(*value);
      else if ( *rsrc == "minorticklength"   ) minorTickLen      = atoi(*value);
      else if ( *rsrc == "majorxtickspacing" ) majorXTickSpacing = atoi(*value);
      else if ( *rsrc == "minorxtickspacing" ) minorXTickSpacing = atoi(*value);
      else if ( *rsrc == "majorytickspacing" ) majorYTickSpacing = atof(*value);
      else if ( *rsrc == "minorytickspacing" ) minorYTickSpacing = atof(*value);
      else if ( *rsrc == "visiblevaluecount" )
					     SetVisibleValueCount(atoi(*value));
      else if ( *rsrc == "maximumvaluecount" )
					     SetMaximumValueCount(atoi(*value));
      else if ( *rsrc == "labeloffset"       ) labelOffset       = atoi(*value);
      else if ( *rsrc == "marginwidth"       ) marginWd          = atoi(*value);
      else if ( *rsrc == "marginheight"      ) marginHt          = atoi(*value);

      else if ( *rsrc == "majorxgridvisible" || *rsrc == "minorxgridvisible" ||
	        *rsrc == "majorygridvisible" || *rsrc == "minorygridvisible" ) {

	 XrmValue	from, to;
	 Boolean	result;
	 from.addr = (XPointer)(char *)*value;
	 from.size = value->size() + 1;
	 to.addr   = (XPointer)&result;
	 to.size   = sizeof(Boolean);
	 if ( XtConvertAndStore(da, XtRString, &from, XtRBoolean, &to) ) {
	    if      ( *rsrc == "majorxgridvisible" ) majorXGridVis = result;
	    else if ( *rsrc == "minorxgridvisible" ) minorXGridVis = result;
	    else if ( *rsrc == "majorygridvisible" ) majorYGridVis = result;
	    else				     minorYGridVis = result;
	 }

      } // End if grid visibility resource

//
// Remove current entry
//
      rsrcList.remove((int)0);
      rvalList.remove((int)0);
   }

   Defer(False);
   return status;

} // End StripChartC Read
