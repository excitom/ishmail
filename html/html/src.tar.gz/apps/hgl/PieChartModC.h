/*
 * $Id: PieChartModC.h,v 1.1 1998/06/24 01:29:07 lang Exp $
 *
 * Copyright (c) 1992 HAL Computer Systems International, Ltd.
 * 
 *          HAL COMPUTER SYSTEMS INTERNATIONAL, LTD.
 *                  1315 Dell Avenue
 *                  Campbell, CA  95008
 *
 * Author: Greg Hilton
 * Contributors: Tom Lang, Frank Bieser, and others
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * http://www.gnu.org/copyleft/gpl.html
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#ifndef _PieChartModC_h_
#define _PieChartModC_h_

#include "PieChartC.h"
#include "ModFormC.h"
#include "NumericFieldC.h"

#include <Xm/Xm.h>

// =====================================================================
// =====================================================================
class ValueTypeModC
{
   Widget                      form;
   Widget                      label;
   Widget                      frame;
   Widget                      radioBox;
   Widget                      noneTB;
   Widget                      percentTB;
   Widget                      intTB;
   Widget                      hexTB;
   Widget                      floatTB;
   Widget                      precisionLabel;
   Widget                      precisionTF;
   PieSliceC::ValueType        valueType;
   int                         precision;

   static void	DoSelectTB (Widget, ValueTypeModC*, XtPointer);
   static void	DoChangePrecision (Widget, ValueTypeModC*, XtPointer);

   public:
      ValueTypeModC(Widget parent, char* name);
      ~ValueTypeModC();

      void Precision(int prec);
      void Type(PieSliceC::ValueType, int precision = 0);

      PieSliceC::ValueType Type()   const { return valueType; }
      inline operator Widget()           const { return form;      }

      MEMBER_QUERY(int,		Precision,       precision)
      MEMBER_QUERY(Widget,	Label,	         label)
      MEMBER_QUERY(Widget,	Form,	         form)
      MEMBER_QUERY(Widget,	Frame,	         frame)
      MEMBER_QUERY(Widget,	RadioBox,        radioBox)
      MEMBER_QUERY(Widget,	NoneTB,          noneTB)
      MEMBER_QUERY(Widget,	PercentTB,       percentTB)
      MEMBER_QUERY(Widget,	FloatTB,         floatTB)
      MEMBER_QUERY(Widget,	IntTB,           intTB)
      MEMBER_QUERY(Widget,	PrecisionLabel,  precisionLabel)
      MEMBER_QUERY(Widget,	PrecisionTF,     precisionTF)
};


// =====================================================================
// =====================================================================
class ColorModC;

class PieChartModC
{
   PieChartC*	pieChart;

   Widget     topForm;
   Widget	 paramFrame;
   Widget	    paramFrameLabel;
   Widget	    paramForm;
   Widget	       titleLabel;
   NumericFieldC*      totalNF;
   Widget	       titleTF;
   Widget	       thicknessLabel;
   Widget	       thicknessTF;
   Widget	       lineWidthLabel;
   Widget	       lineWidthTF;
   Widget	       declinationLabel;
   Widget	       declinationTF;
   Widget	       rotationLabel;
   Widget	       rotationTF;
   Widget	       visFrame;
   Widget	       visRC;
   Widget                 legendVisTB;
   Widget                 legendTextShadowTB;
   Widget                 titleTextShadowTB;
   Widget                 labelTextShadowTB;
   ValueTypeModC*      labelValueTypeMod;
   ValueTypeModC*      legendValueTypeMod;

   Widget	       colorFrame;
   Widget	       colorFrameLabel;
   Widget	       colorForm;
   ColorModC*             backgroundColorMod;
   ColorModC*             legendTextColorMod;
   ColorModC*             legendShadowColorMod;
   ColorModC*             lineColorMod;
   ColorModC*             titleTextColorMod;
   ColorModC*             titleShadowColorMod;
   ColorModC*             labelTextColorMod;
   ColorModC*             labelShadowColorMod;

   Widget	       sliceFrame;
   Widget	          sliceFrameLabel;
   Widget	          sliceForm;
   Widget	             sliceListSW;
   Widget	                sliceList;
   Widget	             sliceLabelForm;
   Widget	                sliceLabelLabel;
   Widget	                sliceLabelTF;
   Widget	             sliceValueForm;
   Widget	                sliceValueLabel;
   Widget	                sliceValueTF;
   Widget	             sliceOffsetForm;
   Widget	                sliceOffsetLabel;
   Widget	                sliceOffsetTF;
   NumericFieldC*            sliceLineWidthNF;
   ColorModC*                sliceTopColorMod;
   ColorModC*                sliceInnerColorMod;
   ColorModC*                sliceOuterColorMod;

//
// Initial values
//
   struct {
      Boolean		         showLegend;
      Boolean			 labelTextShadow;
      Boolean			 titleTextShadow;
      Boolean			 legendTextShadow;
      Pixel		         backgroundColor;
      Pixel		         labelShadowColor;
      Pixel		         legendTextColor;
      Pixel		         legendShadowColor;
      Pixel		         lineColor;
      Pixel		         titleShadowColor;
      Pixel		         titleTextColor;
      StringC		         title;
      PieSliceC::ValueType	 labelValueType;
      PieSliceC::ValueType	 legendValueType;
      float			 total;
      int		         declination;
      int		         labelPrecision;
      int		         legendPrecision;
      int		         lineWidth;
      int		         rotation;
      int		         thickness;

      PieSliceC*	         slice;
      StringC		         sliceLabel;
      float		         sliceValue;
      int		         sliceOffset;
      int		         sliceLineWidth;
   } init;

   static void	DoSelectSlice(Widget, PieChartModC*, XmListCallbackStruct*);

public:

// Methods

   PieChartModC(Widget, const char*, ArgList argv=NULL, Cardinal argc=0);
   ~PieChartModC();

   MEMBER_QUERY(Widget,		SliceList,	   sliceList)
   MEMBER_QUERY(Widget,		TitleLabel,	   titleLabel)
   MEMBER_QUERY(Widget,		TitleTF,	   titleTF)
   MEMBER_QUERY(Widget,		ThicknessLabel,	   thicknessLabel)
   MEMBER_QUERY(Widget,		ThicknessTF,	   thicknessTF)
   MEMBER_QUERY(Widget,		LineWidthLabel,	   lineWidthLabel)
   MEMBER_QUERY(Widget,		LineWidthTF,	   lineWidthTF)
   MEMBER_QUERY(Widget,		DeclinationLabel,  declinationLabel)
   MEMBER_QUERY(Widget,		DeclinationTF,	   declinationTF)
   MEMBER_QUERY(Widget,		RotationLabel,	   rotationLabel)
   MEMBER_QUERY(Widget,		RotationTF,	   rotationTF)

   void		Apply(PieChartC&);
   void		Init(const PieChartC&);
   void		Reset();
   Widget       LabeledTextField(Widget, char*, Widget*, Widget*);
   inline	operator Widget() const 	{ return topForm; }
};



#endif // _PieChartModC_h_
