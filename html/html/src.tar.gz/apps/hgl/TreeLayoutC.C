/*
 * $Id: TreeLayoutC.C,v 1.1 1998/06/24 01:29:07 lang Exp $ *
 * Copyright (c) 1993 HAL Computer Systems International, Ltd.
 * 
 *          HAL COMPUTER SYSTEMS INTERNATIONAL, LTD.
 *                  1315 Dell Avenue
 *                  Campbell, CA  95008
 *
 * Author: Greg Hilton
 * Contributors: Tom Lang, Frank Bieser, and others
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * http://www.gnu.org/copyleft/gpl.html
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#include "rsrc.h"
#include "HalTreeC.h"
#include "TreeLayoutC.h"

#include <X11/Intrinsic.h>
#include <Xm/Xm.h>

#ifdef debug
#define dprintf(a) printf a
#else
#define dprintf(a)
#endif

// #define DRAW_REGION
// #define DRAW_SUBREGION
// #define DOUBLE_COMPRESS


// =====================================================================
// Constructor for the tree class.
// =====================================================================
TreeLayoutC::TreeLayoutC (HalTreeC* t, char *name)
: LayoutC(t,name)
{
//
// Set and get the resources of the tree.
//
   depthBounds     = NULL;
   depthBoundsCnt  = 0;
   compressOffset  = 0;

   Widget w = t->WidgetParent();
   lineBreak      = get_boolean(w, "lineBreak",  FALSE);
   compressed     = get_boolean(w, "compressed", FALSE);
   stepMode       = get_boolean(w, "stepMode",   FALSE);
   StringC dirstr = get_string (w, "layoutDir", "Left_To_Right");

   if      ( dirstr[0] == 'R' )    layoutDir = RIGHT_TO_LEFT;
   else if ( dirstr[0] == 'T' )    layoutDir = TOP_TO_BOTTOM;
   else if ( dirstr[0] == 'B' )    layoutDir = BOTTOM_TO_TOP;
   else /* ( dirstr[0] == 'L' ) */ layoutDir = LEFT_TO_RIGHT;

   InitDimensions(get_int(w, "defaultDepth", 8));
}


// =====================================================================
// =====================================================================
void
TreeLayoutC::Draw()
{
   dprintf(("***** Entering TreeLayoutC::Draw *****\n"));
//
// Initialize the size of the world.
//
   int old_world_wd = tree->world_wd;
   int old_world_ht = tree->world_ht;
   tree->world_wd = 0;
   tree->world_ht = 0;
   redrawing = FALSE;

//
// Initialize the max depth dimensions.
//
   int *p = depthBounds;
   for (register int i=0; i<depthBoundsCnt; i++, *p++=0)
   InitDimensions(depthBoundsCnt);

//
// Compute the regions of the tree nodes.
//
   numLevels = 0;
   ComputeNodeRegion(tree->TopLevelNode(), 0);

//
// Layout the nodes starting at the margins.
//
   ArrangeSubTree(tree->TopLevelNode(), 0, tree->marginWd, tree->marginHt);

//
// Update the scroll bars if the world has changed.
//
   //SKB if ( old_world_wd != tree->world_wd || old_world_ht != tree->world_ht ){
      //SKB tree->UpdateScrollBars();
   //SKB }

//
// If the user wants to compress the layout then do so...
//
   tree->numNodesVisible = 0;
   if ( compressed ) {
      CompressTree();
      if ( old_world_wd != tree->world_wd || old_world_ht != tree->world_ht )
         tree->UpdateScrollBars();
   }
   else {
      if ( old_world_wd != tree->world_wd || old_world_ht != tree->world_ht )
         tree->UpdateScrollBars();
      PositionNode(tree->TopLevelNode(), 0);
   }

   dprintf(("***** Leaving TreeLayoutC::Draw *****\n"));
}


// =====================================================================
// =====================================================================
void
TreeLayoutC::Redraw()
{
   redrawing = TRUE;
   tree->numNodesVisible = 0;
   PositionNode(tree->TopLevelNode(), 0);
   redrawing = FALSE;
}


// =====================================================================
// Each child is "shrink-wrapped" with a minimal bounding rectangle,
// laid next to its siblings (with a small about of padding in between)
// and then wrapped with their parent.  Parents are centered about their
// children (or vice versa if the parent is larger than the children).
// =====================================================================
void
TreeLayoutC::ComputeNodeRegion(HalTreeNodeC* node, int level)
{
   dprintf(("***** Entering ComputeNodeRegion *****\n"));
   dprintf(("  %s  level: %d\n", node->NodeName(), level));

   if ( level+1 > numLevels ) numLevels = level+1;

//
// Add a new level if we exceed the max levels.
//
   if ( numLevels >= depthBoundsCnt ) {
      InitDimensions(numLevels);
   }

   node->depth = level;

#ifdef LATER
//
// See if we have anything to work with.
//
   if ( node->wd <=0 && node->ht <= 0 ) {
      node->regWd = 0;
      node->regHt = 0;
      dprintf(("  node has no size\n"));
      if ( level != 0 ) return;
   }
#endif

   int horiz = IsHorizontal();

   node->subWd = 0;
   node->subHt = 0;

   if ( level > 0 ) {
//
//    See if this node changes this levels max dimensions.
//
      int dim = (horiz ? node->wd : node->ht);
      if ( dim > depthBounds[level] )
         depthBounds[level] = dim;
      dprintf(("  depthBounds[%d]: %d\n", level, depthBounds[level]));

//
//    Initialize the size of this node's region to the node size.
//
      node->regWd = node->wd;
      node->regHt = node->ht;
   }
   else {
//
//    The level 0 node is not displayed so set personal dims are 0.
//
      depthBounds[0] = 0;
      node->regWd = 0;
      node->regHt = 0;
   }
   dprintf(("  start region: %d %d\n", node->regWd, node->regHt));
   dprintf(("  num_children: %d\n", node->NumChildren()));

//
// Figure the size of the opposite dimension (vertical if tree is 
// horizontal, or vice versa).  The other dimension will be set 
// in the second pass once we know the region dimensions.
//
   int num_children = node->NumChildren();
   if ( num_children ) {
      int new_regWd = 0;
      int new_regHt = 0;
      HalTreeNodeListC& children = node->Children();
      for ( register int i=0; i<num_children; i++) {

         HalTreeNodeC* child = children[i];
         if ( child->Shown() ) {
            ComputeNodeRegion(child, level+1);
            dprintf(("  child reg: %d %d\n", child->regWd, child->regHt));
//
//          Account for the affects of this child on this nodes region.
//
            if ( horiz ) {
               if ( child->regWd > new_regWd ) new_regWd = child->regWd;
	       if ( child->wd > node->subWd ) node->subWd = child->wd;
	       new_regHt   += siblingSpace + child->regHt;
               node->subHt += siblingSpace + child->regHt;
            } else {
               if ( child->regHt > new_regHt ) new_regHt = child->regHt;
	       if ( child->ht > node->subHt ) node->subHt = child->ht;
	       new_regWd   += siblingSpace + child->regWd;
               node->subWd += siblingSpace + child->regWd;
            }
         }
      }
      node->regWd = node->wd;
      node->regHt = node->ht;

//
//    Determine the extension of the size of this node according
//    to the direction of the tree layout.
//
      if ( horiz ) {
         if ( node->numChildrenShown > 0 ) {
            node->regWd += childSpace + new_regWd;
            node->subHt -= siblingSpace;
            new_regHt   -= siblingSpace;
            if ( new_regHt > node->regHt ) node->regHt = new_regHt;
         }
      }
      else {
         if ( node->numChildrenShown > 0 ) {
            node->regHt += childSpace + new_regHt;
            new_regWd   -= siblingSpace;
            node->subWd -= siblingSpace;
            if ( new_regWd > node->regWd ) node->regWd = new_regWd;
         }
      }
      dprintf(("  region: %d %d\n", node->regWd, node->regHt));
   }
   dprintf(("***** Leaving ComputeNodeRegion *****\n"));
}


// =====================================================================
// Portions of the positions are determined during the ComputeNodeRegion
// and then this is called to set the node values.  This is the last
// pass in the laying of the nodes.
// =====================================================================
void
TreeLayoutC::PositionNode (HalTreeNodeC* node, int level)
{
   dprintf(("***** Entering PositionNode *****\n"));
   dprintf(("  %d: %s\n", level, node->NodeName()));
   dprintf(("  pos: %d %d\n", node->x, node->y));
   dprintf(("  size: %d %d\n", node->wd, node->ht));

   int horiz = IsHorizontal();
   int dx = 0;
   int dy = 0;

   if ( level > 0 ) {

      if ( !node->Shown() ) {
         return;
      }

      if ( !redrawing ) {

	 if ( compressed && tree->TopLevelNode()->NumChildren()>1 ) {
//
//          Compressing may change the bounds.
//
            int dim;
	    if ( horiz ) {
	       node->y -= compressOffset;
               dim = node->y + node->ht;
	       int ht = dim + tree->marginHt;
	       if ( ht > tree->world_ht ) tree->world_ht = ht;
	    }
	    else {
               node->x -= compressOffset;
               dim = node->x + node->wd;
	       int wd = dim + tree->marginWd;
	       if ( wd > tree->world_wd ) tree->world_wd = wd;
	    }
            if ( dim > compressBounds[level] )
               compressBounds[level] = dim;
	    dprintf(("  compress reposition: %d %d\n", node->x, node->y));
	 }

	 else if ( level > 1 ) {
//
//          Make sure the children are centered within the parent region.
//
            if ( horiz ) {
               dy = (node->parent->regHt - node->parent->subHt)/2;
	       if ( dy > 0 ) node->y += dy; 
	    }
	    else {
               dx = (node->parent->regWd - node->parent->subWd)/2;
	       if ( dx > 0 ) node->x += dx; 
	    }
	 }

//
//       RePosition this node.
//
         switch ( layoutDir ) {
            case RIGHT_TO_LEFT:
               node->x = tree->world_wd - node->wd - node->x;
               break;
   
            case BOTTOM_TO_TOP:
               node->y = tree->world_ht - node->ht - node->y;
               break;
         }
      }

#ifdef DRAW_REGION
      XSetLineAttributes(tree->viewDSP, tree->viewGC, 2,
                         LineSolid, CapButt, JoinBevel);
      static Pixel region_clr = 3;
      region_clr = ((region_clr+1)%10)+3;
      XSetForeground(tree->viewDSP, tree->viewGC, region_clr);
      XDrawRectangle(tree->viewDSP, tree->viewWin, tree->viewGC,
		     (node->x - tree->world_x),
		     (node->y+node->ht/2-node->regHt/2) - tree->world_y,
                      node->regWd+1, node->regHt+1);
      XSetLineAttributes(tree->viewDSP, tree->viewGC, node->lineWidth,
                         LineSolid, CapButt, JoinBevel);
#endif
#ifdef DRAW_SUBREGION
      if ( node->subWd && node->subHt ) {
      XSetLineAttributes(tree->viewDSP, tree->viewGC, 2,
                         LineSolid, CapButt, JoinBevel);
      static Pixel region_clr = 3;
      region_clr = ((region_clr+1)%10)+3;
      XSetForeground(tree->viewDSP, tree->viewGC, region_clr);
      XDrawRectangle(tree->viewDSP, tree->viewWin, tree->viewGC,
		     (node->x + node->wd - tree->world_x + childSpace)-1,
		     (node->y+node->ht/2-node->subHt/2) - tree->world_y-1,
                      node->subWd+2, node->subHt+2);
      XSetLineAttributes(tree->viewDSP, tree->viewGC, node->lineWidth,
                         LineSolid, CapButt, JoinBevel);
      }
#endif

//
//    See if the node is visible within the display window.
//
      int node_visible = TRUE;
      if ((node->x > (tree->world_x+tree->daWd)) ||
          (node->y > (tree->world_y+tree->daHt)) ||
	  (tree->world_x > node->x+node->wd ) ||
	  (tree->world_y > node->y+node->ht )) {
         node_visible = FALSE;
      }
      else {
         tree->numNodesVisible++;
      }

//
//    Draw the node...or not.
//
      tree->busy++;
      if ( node_visible ) {
         node->Draw();
      } else {
	 node->Erase();
      }
      tree->busy--;
   }

//
// Draw lines and set the positions of this nodes children.
//
   HalTreeNodeC* topNode = NULL;
   //HalTreeNodeC* btmNode = NULL;
   int num_children = node->NumChildren();
   dprintf(("  num_children: %d\n", num_children));
   if ( num_children ) {
//
//    Compute the source position of a line coming from this node.
//
      int dst_x;
      int dst_y;
      int src_x;
      int src_y;
      int top_x;
      int top_y;
      switch ( layoutDir ) {
         case LEFT_TO_RIGHT:
	    src_x = node->x + node->wd;
	    src_y = node->y + ((node->ht+1)/2);
   	    break;
         case TOP_TO_BOTTOM:
	    src_x = node->x + ((node->wd+1)/2);
	    src_y = node->y + (node->ht);
            break;
         case RIGHT_TO_LEFT:
	    src_x = node->x;
	    src_y = node->y + ((node->ht+1)/2);
            break;
         case BOTTOM_TO_TOP:
	    src_x = node->x + ((node->wd+1)/2);
	    src_y = node->y;
            break;
      }
//
//    Now draw a line to each of the children.
//
      HalTreeNodeListC& children = node->Children();
      HalTreeNodeC* child;
      for ( register int i=0; i<num_children; i++ ) {
         child = children[i];
         if ( child->Shown() ) {
            PositionNode(child, level+1);
	    if ( level > 0 ) {
               if ( !topNode ) {
                  if ( lineBreak ) {
                     switch ( layoutDir ) {
                        case LEFT_TO_RIGHT:
                           dst_x  = src_x;
                           dst_y  = src_y + dy;			//SKB
                           src_x += (childSpace/2);
                           break;
                        case TOP_TO_BOTTOM:
                           dst_x  = src_x + dx;			//SKB
                           dst_y  = src_y;
                           src_y += (childSpace/2);
                           break;
                        case RIGHT_TO_LEFT:
                           dst_x  = src_x;
                           dst_y  = src_y + dy; 		//SKB
                           src_x -= (childSpace/2);
                           break;
                        case BOTTOM_TO_TOP:
                           dst_x  = src_x + dx;			//SKB
                           dst_y  = src_y;
                           src_y -= (childSpace/2);
                           break;
                     }
//
//                   Draw a line from the parent half-way to the children.
//
                     DrawLine(node, dst_x, dst_y, src_x, src_y);
                  }
               }
//
//             Draw a line to the child.
//
               switch ( layoutDir ) {
                  case LEFT_TO_RIGHT:
                     dst_x = child->x;
                     dst_y = child->y + ((child->ht+1)/2) + dy;
                     if ( lineBreak ) src_y = dst_y;
                     break;
                  case TOP_TO_BOTTOM:
                     dst_x = child->x + ((child->wd+1)/2) + dx;
                     dst_y = child->y;
                     if ( lineBreak ) src_x = dst_x;
                     break;
                  case RIGHT_TO_LEFT:
                     dst_x = child->x + child->wd;
                     dst_y = child->y + ((child->ht+1)/2) + dy;
                     if ( lineBreak ) src_y = dst_y;
                     break;
                  case BOTTOM_TO_TOP:
                     dst_x = child->x + ((child->wd+1)/2) + dx;
                     dst_y = child->y + child->ht;
                     if ( lineBreak ) src_x = dst_x;
                     break;
               }

               if ( !topNode ) {
                  top_x = src_x;
                  top_y = src_y;
                  topNode = child;
               }
               //btmNode = child;
               DrawLine(node, src_x, src_y, dst_x, dst_y);
            }
            //SKB PositionNode(child, level+1);
	 }
      }

//
//    Draw a line spanning the top to bottom node.
//
      if ( level > 0 && lineBreak && topNode ) {
	 DrawLine(node, top_x, top_y, src_x, src_y);
      }
   }
   dprintf(("***** Leaving PositionNode *****\n"));
}


// =====================================================================
// This routine uses the input position to figure out where the heck to
// place the node and the children of this node.  This pass uses each
// child's bounding box is stacked on top of (if horizontal, else next to) on
// on top of its siblings.  The parent is centered between the first & last
// child.
// =====================================================================
void
TreeLayoutC::ArrangeSubTree(HalTreeNodeC* node, int level, int x, int y)
{
   dprintf(("***** Entering ArrangeSubTree level %d *****\n", level));

   if ( !node->Shown() ) {
      dprintf(("  node not shown\n"));
      return;
   }

//
// Initialize the position to the input one, if this has no children,
// then this is where it will stay.
//
   node->x = x;
   node->y = y;
   dprintf(("  pos: %d %d\n",  node->x, node->y));
   dprintf(("  size: %d %d\n", node->wd, node->ht));
   dprintf(("  region: %d %d\n", node->regWd, node->regHt));

   int horiz = IsHorizontal();
   Boolean reposition = TRUE;
   if ( stepMode )
      reposition = FALSE;

//
// See if we have out grown our current space.
//
   if ( level > 0 ) {
      if ( horiz ) {
         if ( node->ht > node->regHt ) {
            y += ((node->ht - (node->regHt)/2));
            reposition = FALSE;
         }
      } else {
         if ( node->wd > node->regWd ) {
            x += node->wd - (node->regWd)/2;
	    reposition = FALSE;
         }
      }
   }

//
// See if this extends the world boundaries.
//
   if ( compressed ) { 
      if ( horiz ) {
         int wd = x + node->wd + tree->marginWd;
         if ( wd > tree->world_wd )
            tree->world_wd = wd;
      }
      else {
         int ht = y + node->ht + tree->marginHt;
         if ( ht > tree->world_ht )
            tree->world_ht = ht;
      }
   }
   else {
      int wd = x + node->wd + tree->marginWd;
      int ht = y + node->ht + tree->marginHt;
      if ( wd > tree->world_wd )
         tree->world_wd = wd;
      if ( ht > tree->world_ht )
         tree->world_ht = ht;
   }

//
// If this has no children shown then we're done.
//
   if ( node->numChildrenShown <= 0 ) return;

//
// Since this has some children with show=T we are going to lay them
// out first, so determine the starting position of the first child.
//
   int next_x, next_y;
   dprintf(("  depthBounds[%d]: %d\n", level, depthBounds[level]));
   if ( horiz ) {
      next_x = x + depthBounds[level];
      if ( level > 0 ) next_x += childSpace;
      next_y = y;
   }
   else {
      next_x = x;
      next_y = y + depthBounds[level];
      if ( level > 0 ) next_y += childSpace;
   }

//
// Since this node gets positioned between its first and last
// child, we need to know who those lucky children are.
//
   HalTreeNodeC *topNode = NULL;
   HalTreeNodeC *btmNode = NULL;

//
// Let's get busy...
//
   int num_children = node->NumChildren();
   dprintf(("  num_children: %d\n", num_children));
   HalTreeNodeListC& children = node->Children();
   for ( register int i=0; i<num_children; i++ ) {

      register HalTreeNodeC* child = children[i];

      if ( child->Shown() ) {

         if ( !topNode ) topNode = child;

#ifdef DOUBLE_COMPRESS
//
//       If we are compressing and this child has no children, then
//       it can go right next to its sibling rather than at the end
//       of the sibling's boundaries.
//
         if ( compressed && !child->numChildrenShown && btmNode ) {
            if ( horiz ) {
               next_y = btmNode->y + siblingSpace + btmNode->ht;
            }
            else {
               next_x = btmNode->x + siblingSpace + btmNode->wd;
            }
         }
#endif

         btmNode = child;

//
//       Advance the next layout position to the next child...
//
         ArrangeSubTree(child, level+1, next_x, next_y);
         if ( horiz )
            next_y += siblingSpace + child->regHt;
         else
            next_x += siblingSpace + child->regWd;
      }
   }

//
// If we are compressing then reset the sub region to include
// the span of the immediate children and NOT the entire line
// of descendants (which it does otherwise), because we will
// use this information later.
//
   if ( compressed ) {
      if ( horiz ) {
         node->regHt = btmNode->y + node->ht - topNode->y;
      }
      else {
         node->regWd = btmNode->x + node->wd - topNode->x;
      }
   }

//
// Now layout parent between first and last child, if we need to.
//
   if ( reposition ) {
//
//    Adjustments are disallowed if they result in a position
//    overlapping the originally requested position, because
//    this could result in a terrible, horrible collision.
//
      int adj;

      if ( horiz ) {
         node->x = x;
         adj = topNode->y + ((btmNode->y + btmNode->ht - topNode->y - node->ht+1)/2);
	 dprintf(("  adjustment pos: %d\n", adj));
         if ( adj > node->y ) node->y = adj;
      }
      else {
         node->y = y;
         adj = topNode->x + ((btmNode->x + btmNode->wd - topNode->x - node->wd+1)/2);
         if ( adj > node->x ) node->x = adj;
	 dprintf(("  adjustment pos: %d\n", adj));
      }
      dprintf(("  reposition: %d %d=n", node->x, node->y));
   }
   dprintf(("***** Leaving ArrangeSubTree *****\n"));
}


//=====================================================================
// This allocates the memory for keeping the max width or height 
// of each level of the tree.
//=====================================================================
void
TreeLayoutC::InitDimensions(int n)
{
   dprintf(("***** Entering InitDimensions, depth %d *****\n", n));
   dprintf(("  depthBoundsCnt: %d\n", depthBoundsCnt));
   if ( !depthBounds ) {
      depthBounds = (int*)XtCalloc((Cardinal)n, (Cardinal)sizeof(int));
      depthBoundsCnt = ((depthBounds) ? n : 0);
   }
   else {
      if ( n > depthBoundsCnt ) {
         depthBounds = (int*) XtRealloc((char*)depthBounds,
					(unsigned int)(n*sizeof(int)));
         if ( !depthBounds ) {
            depthBoundsCnt = 0;
	    return;
         }
//
//       Initialize the new ones to zero.
//
         for ( register int i=depthBoundsCnt; i<n; i++)
            depthBounds[i] = 0;
         depthBoundsCnt = n;
      }
   }
   dprintf(("***** Leaving InitDimensions *****\n"));
}


//=====================================================================
//=====================================================================
void
TreeLayoutC::SetLayoutDir(LayoutDirT d)
{
   if ( d != layoutDir ) {
      layoutDir = d;
      tree->Erase();
      tree->Draw(TRUE);
   }
}


//=====================================================================
// The destructor.
//=====================================================================
TreeLayoutC::~TreeLayoutC()
{
//
// Free up the level boundaries.
//
   if (depthBounds) XtFree((char*)depthBounds);
}


//=====================================================================
//=====================================================================
void
TreeLayoutC::SetStepMode(Boolean step_mode)
{
   if ( step_mode != stepMode ) {
      stepMode = step_mode;
      tree->Draw(TRUE);
   }
}


//=====================================================================
//=====================================================================
void
TreeLayoutC::SetLineBreak(Boolean v)
{
   if ( v != lineBreak ) {
      lineBreak = v;
      tree->Erase();
      tree->Redraw();
   }
}



// =====================================================================
// =====================================================================
void
TreeLayoutC::SetCompressed(Boolean v)
{
   if ( v != compressed ) {
      compressed = v;
      tree->Draw(TRUE);
   }
}


// =====================================================================
// This routine is used to compress the area that the layout of the
// tree nodes takes up.  This checks to see if any of the sub-regions
// a each of the root nodes overlaps rather than the entire region
// (including children) of the root nodes overlap.
//   Check each root node to see if its in the "best position" that it
// could be in. If a node is not where it should be, then initialize the
// offset value that it would take to move the node to this position.
// Then each sub-level of the node see how much of the offset it can be
// moved without crashing into the previous root nodes sub-levels.  If
// the move offset becomes 0 then it cannot be moved.  If there is room
// to move the root then it must be moved in incrementes of the root
// node size + it's sibling distance.
// =====================================================================
void
TreeLayoutC::CompressTree()
{
   dprintf(("***** Entering CompressTree *****\n"));
//
// We can only do this if there is more than one root node.
//
   Boolean horiz = IsHorizontal();

   int numRoots = tree->TopLevelNode()->NumChildren();
   if ( numLevels && numRoots > 1 ) {
      dprintf(("  numLevels: %d\n", numLevels));
      compressBounds = new int[numLevels];

//
//    Initialize the moving edge positions to be the margin.
//
      int margin;
      if ( horiz )
         margin = tree->marginWd;
      else
         margin = tree->marginHt;
      for ( int i=0; i<numLevels; i++) compressBounds[i] = (int)margin;

//
//    We are going to set the positions of the roots.
//
      compressOffset = 0;
      HalTreeNodeC* prev = NULL;
      HalTreeNodeListC& children = tree->TopLevelNode()->Children();
      for ( i=0; i<numRoots; i++) {
	 HalTreeNodeC* node = children[i];
	 if ( !node->Shown() ) continue;

         dprintf(("\n Compress branch: %s\n", (char*)node->NodeName() ));
	 if ( !prev ) {
	    prev = node;
	    PositionNode(node, 1);
	 }
	 else {
	    int offset;
//
//          First see if we can compress this node, by seeing how
//          far off the node is from being directly "under" the previous.
//          This is the distance from the current root node to the
//          the previous node plus the sibling distance.
//
            dprintf((" prev pos: %d %d\n", prev->x, prev->y));
            dprintf((" node pos: %d %d\n", node->x, node->y));
            if ( horiz ) {
	       offset = node->y - (prev->y + prev->ht + siblingSpace);
            }
            else {
	       offset = node->x - (prev->x + prev->wd + siblingSpace);
            }
	    dprintf(("  Root# %d top level offset: %d\n", i, offset));

//
//          If there is a potential compression offset then make
//          sure that all the subregions of this node will not
//          overlap previous regions.
//
	    if ( offset > 0 ) {
	       CompressNode(node,&offset,1);
	       dprintf(("  offset after compression: %d\n", offset));
	       compressOffset = offset;
	    }
	    dprintf((" Compressing branch offset: %d\n", compressOffset));

	    PositionNode(node, 1);
	    prev = node;
	 }
      }
      delete compressBounds;
   }
   else {
      compressOffset = 0;
      PositionNode(tree->TopLevelNode(), 0);
   }
   dprintf(("***** Leaving CompressTree *****\n"));
}


// =====================================================================
// =====================================================================
void
TreeLayoutC::CompressNode(HalTreeNodeC* node, int* offset, int level)
{
   dprintf(("***** Entering CompressNode *****\n"));
   dprintf(("  Name: %s\n", (char*)node->NodeName()));
   dprintf(("  level: %d offset: %d\n", level, *offset));

   if ( *offset <= 0 || !node->Shown() || node->numChildrenShown<1 ) {
      dprintf(("***** Leaving CompressNode *****\n"));
      return;
   }

//
// See if the sub region of this node overlaps the level+1 edge.
// If this overlaps then we've failed, but see if we can
// salvage some type of offset out of it.
//
   int tst_pos;
   if ( IsHorizontal() )
      tst_pos = (node->y + node->ht/2) - (node->subHt/2 + *offset);
   else
      tst_pos = (node->x + node->wd/2) - (node->subWd/2 + *offset);
   dprintf(("  node subReg: %d %d\n", node->subWd, node->subHt));
   dprintf(("  tst_pos: %d bound: %d\n", tst_pos, compressBounds[level+1]));
   int d = tst_pos - (compressBounds[level+1]+siblingSpace);
   if ( d < 0 ) {
      dprintf(("  FAILURE...by %d units!!!!\n", d));
      *offset = *offset + d;
      dprintf(("  potential new offset: %d\n", *offset));
      if ( *offset < 0 ) {
         *offset = 0;
         dprintf(("***** Leaving CompressNode *****\n"));
         return;
      }
   }
   dprintf(("  SUCCESS...by %d units!!!!\n", d));

//
// Check all the children in the next levels of this node
// to see if there is room to compress the root node by the
// desired offset amount;
//
   int num_children  = node->NumChildren();
   if ( num_children ) {
      HalTreeNodeListC& children = node->Children();
      for ( int i=0; i<num_children; i++) {
	 CompressNode(children[i],offset,level+1);
      }
   }
   dprintf(("***** Leaving CompressNode *****\n"));
}

// TreeLayoutC.C EOF
