/*
 * $Id: GridC.C,v 1.1 1998/06/24 01:29:07 lang Exp $
 *
 * Copyright (c) 1992 HAL Computer Systems International, Ltd.
 * 
 *          HAL COMPUTER SYSTEMS INTERNATIONAL, LTD.
 *                  1315 Dell Avenue
 *                  Campbell, CA  95008
 *
 * Author: Greg Hilton
 * Contributors: Tom Lang, Frank Bieser, and others
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * http://www.gnu.org/copyleft/gpl.html
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#include "HalAppC.h"
#include "GridC.h"
#include "rsrc.h"

#include <Xm/BulletinB.h>
#include <X11/IntrinsicP.h>
#include <X11/CoreP.h>

#include <memory.h>

/*----------------------------------------------------------------------
 * Method to build the widget hierarchy
 */

GridC::GridC(Widget parent, const char *name)
{
   childTooLarge = False;
   deferCount    = 0;
   deferred      = False;
   childOrderList.AllowDuplicates(FALSE);
   childOrderList.SetSorted(FALSE);

//
// Create bulletin board
//
   gridBB = XmCreateBulletinBoard(parent, (char *)name, 0,0);

   gridWd = get_int("GridC", gridBB, "width",        0);
   gridHt = get_int("GridC", gridBB, "height",       0);
   cellWd = get_int("GridC", gridBB, "cellWidth",  100);
   cellHt = get_int("GridC", gridBB, "cellHeight", 100);
   if ( cellWd < 1 ) cellWd = 1;
   if ( cellHt < 1 ) cellHt = 1;

   rowCnt = (int)gridWd/cellWd;
   colCnt = (int)gridHt/cellHt;
   rowCnt = get_int("GridC", gridBB, "rows", rowCnt);
   colCnt = get_int("GridC", gridBB, "cols", colCnt);
   if ( rowCnt < 1 ) rowCnt = 1;
   if ( colCnt < 1 ) colCnt = 1;

   marginWd  = get_int    ("GridC", gridBB, "marginWidth",       3);
   marginHt  = get_int    ("GridC", gridBB, "marginHeight",      3);
   spacingWd = get_int    ("GridC", gridBB, "horizontalSpacing", 5);
   spacingHt = get_int    ("GridC", gridBB, "verticalSpacing",   5);
   vResize   = get_boolean("GridC", gridBB, "resizeVertical",    False);
   hResize   = get_boolean("GridC", gridBB, "resizeHorizontal",  False);

//   cellWd += spacingWd;
//   cellHt += spacingHt;

   alloc    = 0;
   cellUsed = NULL;
   AllocateCells();

   return;

} // End GridC GridC

/*----------------------------------------------------------------------
 * GridC destructor
 */

GridC::~GridC()
{
   if ( cellUsed ) delete[] cellUsed;
   if ( halApp->xRunning )
      XtDestroyWidget(gridBB);

} // End GridC ~GridC

/*----------------------------------------------------------------------
 * Method to set cell size.  Returns false if children will not fit.
 */

Boolean
GridC::SetCellSize(int wd, int ht)
{
   if ( wd < 1 || ht < 1 ) return False;
   if ( wd == cellWd && ht == cellHt ) return True;

   cellWd = wd;
   cellHt = ht;

   if ( !deferred ) return SetPositions();
   return True;

} // End GridC SetCellSize

/*----------------------------------------------------------------------
 * Method to set cell count.  Returns false if children will not fit.
 */

Boolean
GridC::SetCellCount(int rows, int cols)
{
   if ( rows < 1 || cols < 1 ) return False;
   if ( rows == rowCnt && cols == colCnt ) return True;

   rowCnt = rows;
   colCnt = cols;

   AllocateCells();

   if ( !deferred ) return SetPositions();
   return True;

} // End GridC SetCellCount

/*----------------------------------------------------------------------
 * Method to reset cell usage array
 */

void
GridC::ClearCells()
{
   memset(cellUsed, 0, alloc*sizeof(Boolean));
}

/*----------------------------------------------------------------------
 * Method to add a child to the grid.  Returns false if child will not fit.
 */

Boolean
GridC::ManageChild(Widget child)
{
   XtManageChild(child);

//
// Set up event handler to detect resize
//
   XtAddEventHandler(child, StructureNotifyMask, False,
		     (XtEventHandler)HandleChildResize, (XtPointer)this);

//
// Add callback to detect destruction
//
   XtAddCallback(child, XmNdestroyCallback, (XtCallbackProc)HandleChildDeath,
		 (XtPointer)this);

//
// Place widget
//
   if ( deferred ) return True;

   return SetPositions();

} // End GridC ManageChild

/*----------------------------------------------------------------------
 * Method to remove a child from the grid.
 */

void
GridC::UnmanageChild(Widget child)
{
//
// Remove resize event handler and destroy callback
//
   XtRemoveEventHandler(child, StructureNotifyMask, False,
			(XtEventHandler)HandleChildResize, (XtPointer)this);
   XtRemoveCallback(child, XmNdestroyCallback, (XtCallbackProc)HandleChildDeath,
		 (XtPointer)this);
   XtUnmanageChild(child);

//
// Reposition remaining widgets
//
   if ( !deferred ) SetPositions();

} // End GridC UnmanageChild

/*----------------------------------------------------------------------
 * Method to position a widget on the grid.  Returns false if widget will
 *    not fit.
 */

Boolean
GridC::SetPosition(Widget child)
{
//
// Get child size
//
   Dimension	wd, ht;
   //XtVaGetValues(child, XmNwidth, &wd, XmNheight, &ht, NULL);
   wd = child->core.width;
   ht = child->core.height;
   wd += spacingWd;
   ht += spacingHt;

//
// Determine number of cells needed
//
   int	colsNeeded = (int)wd / cellWd;
   int	rowsNeeded = (int)ht / cellHt;

   if ( cellWd * colsNeeded < (int)wd ) colsNeeded++;
   if ( cellHt * rowsNeeded < (int)ht ) rowsNeeded++;

//
// If we're not allowed to resize vertically or horizontally, this may not
//    even be possible.
//
   childTooLarge = (!vResize && rowsNeeded > rowCnt) ||
		   (!hResize && colsNeeded > colCnt);
   if ( childTooLarge ) return False;

   int	x, y;
   if ( FindPosition(rowsNeeded, colsNeeded, &x, &y) ) {
      XtVaSetValues(child, XmNx, (Position)x, XmNy, (Position)y, NULL);
      return True;
   } else {
      return False;
   }

} // End GridC SetPosition

/*----------------------------------------------------------------------
 * Method to lay out children.  Returns false if children will not fit.
 */

Boolean
GridC::SetPositions()
{
   halApp->BusyCursor(True);

//
// Get list of children.  Use ordered list if specified, otherwise get list
//    from bulletin board widget.
//
   WidgetList	list;
   Cardinal	count;
   if ( childOrderList.size() ) {
      list  = childOrderList.start();
      count = childOrderList.size();
   } else {
      XtVaGetValues(gridBB, XmNnumChildren, &count, XmNchildren, &list, 0);
   }

//
// Loop until finished
//
   int		tries  = 0;
   Boolean	failed = True;
   Boolean	done   = False;
   while ( !done ) {

//
// Reset grid
//
      ClearCells();

//
// Try to position all children
//
      tries++;
      failed = False;
      for (int i=0; !failed && i<count; i++) {
	 Widget	w = list[i];
	 if ( XtIsManaged(w) ) failed = !SetPosition(w);
	 if ( failed && childTooLarge ) {
	    halApp->BusyCursor(False);
	    return False;
	 }
      }

//
// If we failed to do the layout, see if we can automatically adjust
//
      if ( failed ) {
	 if ( vResize ) rowCnt++;
	 if ( hResize ) colCnt++;
	 done = !(vResize || hResize) || (tries>10000);	// Give up hope
	 if ( !done ) AllocateCells();
      } else {
	 done = True;
      }

   } // End while not done

   halApp->BusyCursor(False);
   return !failed;

} // End GridC SetPositions

/*----------------------------------------------------------------------
 * Method to find space for the given number of rows and columns.  Returns
 *    false if space not found.
 */

Boolean
GridC::FindPosition(int rows, int cols, int *x, int *y)
{
//
// Loop through cells
//
   for (int r=0; r<rowCnt; r++) {
      for (int c=0; c<colCnt; c++) {

	 if ( CellsFree(r, c, rows, cols) ) {
	    MarkCells(r, c, rows, cols);
	    *x = marginWd + c * cellWd;
	    *y = marginHt + r * cellHt;
	    return True;
	 }

      } // End for each column
   } // End for each row

#if 0
   cout <<"FindPosition failed for rows: " <<rows <<", cols: " <<cols NL;
   cout <<"Cell array is: " NL;

   for (r=0; r<rowCnt; r++) {
      int	offset = r * colCnt;
      for (int c=0; c<colCnt; c++) {
	 if ( cellUsed[offset+c] ) cout <<'*';
	 else                      cout <<'.';
      }
      cout NL;
   }
#endif

   return False;

} // End GridC FindPosition

/*----------------------------------------------------------------------
 * Method to determine if the given range of cells is free.  Returns false
 *    if range not free.
 */

Boolean
GridC::CellsFree(int startRow, int startCol, int rows, int cols)
{
   if ( startCol+cols > colCnt || startRow+rows > rowCnt ) return False;

   int	endRow = startRow + rows - 1;
   int	endCol = startCol + cols - 1;

   for (int r=startRow; r<=endRow; r++) {

      int	offset = r * colCnt;
      for (int c=startCol; c<=endCol; c++) {

	 if ( cellUsed[offset+c] ) return False;

      } // End for each column
   } // End for each row

   return True;

} // End GridC CellsFree

/*----------------------------------------------------------------------
 * Method to mark the cells in the given range.
 */

void
GridC::MarkCells(int startRow, int startCol, int rows, int cols)
{
   int	endRow = startRow + rows - 1;
   int	endCol = startCol + cols - 1;

   if ( endRow >= rowCnt ) endRow = rowCnt-1;
   if ( endCol >= colCnt ) endCol = colCnt-1;

   for (int r=startRow; r<=endRow; r++) {

      int	offset = r * colCnt;
      for (int c=startCol; c<=endCol; c++) {

	 cellUsed[offset+c] = True;

      } // End for each column
   } // End for each row

   return;

} // End GridC MarkCells

/*----------------------------------------------------------------------
 * Callback to handle the resize of a child
 */

void
GridC::HandleChildResize(Widget, GridC *This, XEvent*, Boolean*)
{
   if ( !This->deferred ) This->SetPositions();
}

/*----------------------------------------------------------------------
 * Callback to handle the death of a child
 */

void
GridC::HandleChildDeath(Widget child, GridC *This, XtPointer)
{
   XtRemoveEventHandler(child, StructureNotifyMask, False,
			(XtEventHandler)HandleChildResize, (XtPointer)This);
   XtRemoveCallback(child, XmNdestroyCallback, (XtCallbackProc)HandleChildDeath,
		    (XtPointer)This);
   if ( XtIsManaged(child) ) XtUnmanageChild(child);

//
// Reposition remaining widgets
//
   if ( !This->deferred ) This->SetPositions();

} // End GridC HandleChildDeath

/*-----------------------------------------------------------------------
 *  Method to set deferral mode
 */

Boolean
GridC::Defer(Boolean on)
{
   if	   ( on )	deferCount++;
   else if ( deferred ) deferCount--;

   deferred = (deferCount > 0);

   if ( !deferred ) return SetPositions();
   return True;

} // End GridC Defer

/*-----------------------------------------------------------------------
 *  Method to set deferral mode
 */

Boolean
GridC::SetChildOrder(WidgetListC& list)
{
   childOrderList.removeAll();
   childOrderList = list;

   if ( !deferred ) return SetPositions();
   return True;

} // End GridC SetChildOrder

/*-----------------------------------------------------------------------
 *  Method to allocate memory for cells
 */

void
GridC::AllocateCells()
{
//
// Reallocate memory if necessary
//
   if ( rowCnt * colCnt <= alloc ) return;

   if ( cellUsed ) delete[] cellUsed;
   alloc = rowCnt * colCnt;
   cellUsed = new Boolean[alloc];
   ClearCells();

} // End GridC AllocateCells
