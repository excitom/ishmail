/*
 * $Id: ValueC.h,v 1.1 1998/06/24 01:29:07 lang Exp $
 *
 * Copyright (c) 1992 HAL Computer Systems International, Ltd.
 * 
 *          HAL COMPUTER SYSTEMS INTERNATIONAL, LTD.
 *                  1315 Dell Avenue
 *                  Campbell, CA  95008
 *
 * Author: Greg Hilton
 * Contributors: Tom Lang, Frank Bieser, and others
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * http://www.gnu.org/copyleft/gpl.html
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#ifndef _ValueC_h_
#define _ValueC_h_

#include "StringC.h"

//----------------------------------------------------------------------------
// Class to hold a value which can be interpreted as an integer, long or a
//   float
//

class ValueC {

public:

//
// Format type
//
   enum ValueFormat { INT, HEX, FLOAT };

protected:

   float	val;
   ValueFormat	format;
   int		precis;		// Number of float decimal places

public:

//
// Set the value
//
   inline void		operator=(const ValueC& v)
	{ val = v.val; format = v.format; precis = v.precis; }
   inline void		operator=(float    v) { val = v; }
   inline void		operator=(int      v) { val = (float)v; }
   inline void		operator=(long     v) { val = (float)v; }
   inline void		operator=(double   v) { val = (float)v; }
   inline void		operator=(unsigned v) { val = (float)v; }

//
// Constructors
//
   inline ValueC() { val = 0; format = INT; precis = 2; }
   inline ValueC(const ValueC& v) { *this = v; }
   inline ValueC(float v, ValueFormat f=FLOAT, int p=2)
		{ val = v; format = f; precis = p; }
   inline ValueC(int   v, ValueFormat f=INT)
		{ val = (float)v; format = f; precis = 0; }
   inline ValueC(long  v, ValueFormat f=INT)
		{ val = (float)v; format = f; precis = 0; }
   inline ValueC(double v, ValueFormat f=FLOAT, int p=2)
		{ val = (float)v; format = f; precis = p; }
   inline ValueC(unsigned  v, ValueFormat f=HEX)
		{ val = (float)v; format = f; precis = 0; }

//
// Set the format and precision
//
   inline void		SetFormat(ValueFormat f, int p)
				{ format = f; precis = p; }
   inline void		SetFormat(ValueFormat f) { format = f; }
   void			SetFormat(StringC);
   inline void		SetPrecision(int p) { precis = p; }

//
// Query the value
//
   inline operator	float()    const { return val;		 }
   inline operator	int()      const { return (int)val;	 }
   inline operator	long()     const { return (long)val;	 }
   inline operator	double()   const { return (double)val;	 }
   inline operator	unsigned() const { return (unsigned)val; }

//
// Query the format and precision
//
   ValueFormat		Format()    const	{ return format; }
   inline int		Precision() const	{ return precis; }
   StringC		FormatName() const;

//
// Return a string representation of the value
//
   operator		StringC() const;
};

#endif // _ValueC_h_
