/*
 * $Id: HistogramC.C,v 1.1 1998/06/24 01:29:07 lang Exp $
 *
 * Copyright (c) 1992 HAL Computer Systems International, Ltd.
 * 
 *          HAL COMPUTER SYSTEMS INTERNATIONAL, LTD.
 *                  1315 Dell Avenue
 *                  Campbell, CA  95008
 *
 * Author: Greg Hilton
 * Contributors: Tom Lang, Frank Bieser, and others
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * http://www.gnu.org/copyleft/gpl.html
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#include "HalAppC.h"
#include "HistogramC.h"
#include "WArgList.h"
#include "Shadow.h"
#include "rsrc.h"
#include "RegexC.h"
#include "StringListC.h"
#include "WorkingBoxC.h"

#include <Xm/Form.h>
#include <Xm/DrawingA.h>
#include <Xm/ScrollBar.h>

#define BLACK	BlackPixel(halApp->display, DefaultScreen(halApp->display))
#define WHITE	WhitePixel(halApp->display, DefaultScreen(halApp->display))

/*----------------------------------------------------------------------
 * Method to build the widget hierarchy
 */

HistogramC::HistogramC(Widget parent, const char *name, ArgList argv,
		       Cardinal argc)
: GraphC(BuildWidgets(parent, name, argv, argc))
{
   minIndex    = 0;
   maxIndex    = 0;
   minCount    = 0;
   maxCount    = 0;
   countRangeInv = 1.0;
   userBuckets = False;
   bucketList.AllowDuplicates(TRUE);
   labelList.AllowDuplicates(TRUE);
   valueList.AllowDuplicates(TRUE);

//
// Read attributes
//
   char	*cl = "HistogramC";
   Pixel	bg;
   colors[BACKGROUND] = bg   = get_color(cl, da, "background",        WHITE);
   colors[TOP_SHADOW]        = get_color(cl, da, "topShadowColor",    WHITE);
   colors[BOTTOM_SHADOW]     = get_color(cl, da, "bottomShadowColor", BLACK);
   colors[CHART_COLOR]       = get_color(cl, da, "chartColor",        bg);
   colors[BAR_COLOR]         = get_color(cl, da, "barColor",          BLACK);
   colors[BAR_BORDER_COLOR]  = get_color(cl, da, "barBorderColor",    BLACK);
   colors[AXIS_COLOR]        = get_color(cl, da, "axisColor",         BLACK);
   colors[LABEL_COLOR]       = get_color(cl, da, "labelColor",        BLACK);
   colors[TICK_COLOR]        = get_color(cl, da, "tickColor",         BLACK);
   colors[GRID_COLOR]        = get_color(cl, da, "gridColor",         BLACK);
   colors[MARK_COLOR]        = get_color(cl, da, "markColor",         BLACK);
   colors[BAR_TOP_SHADOW]    = get_color(da, "barTopShadowColor",     WHITE);
   colors[BAR_BOTTOM_SHADOW] = get_color(da, "barBottomShadowColor",  BLACK);

   StringC	fstr = get_string(cl, da, "font", "fixed");
   font	= XLoadQueryFont(halApp->display, fstr);
   if ( !font ) font = halApp->font;
   shadowType          = get_shadow_type(cl, da, "shadowType",    XmSHADOW_IN);
   shadowThickness     = get_int    (cl, da, "shadowThickness",    2);
   barShadowType       = get_shadow_type(cl, da, "barShadowType", XmSHADOW_OUT);
   barShadowThickness  = get_int    (cl, da, "barShadowThickness", 2);
   bucketWidth	       = get_float  (cl, da, "bucketWidth",        1.0);
   compress            = get_boolean(cl, da, "compressCountRange", False);
   labelOffset	       = get_int    (cl, da, "labelOffset",        2);
   majorTickLen        = get_int    (cl, da, "majorTickLength",    8);
   minorTickLen        = get_int    (cl, da, "minorTickLength",    4);
   majorCountTickSpace = get_int    (cl, da, "majorCountTickSpacing", 0);
   minorCountTickSpace = get_int    (cl, da, "minorCountTickSpacing", 0);
   majorValueTickSpace = get_float  (cl, da, "majorValueTickSpacing",   0);
   minorValueTickSpace = get_float  (cl, da, "minorValueTickSpacing",   0);
   majorGridVis        = get_boolean(cl, da, "majorGridVisible",   False);
   minorGridVis        = get_boolean(cl, da, "minorGridVisible",   False);
   orientation	       = get_orient (cl, da, "orientation", XmVERTICAL);
   int precis	       = get_int    (cl, da, "decimalPlaces", 2);
   valueFormat.SetPrecision(precis);
   visCount	       = get_int    (cl, da, "visibleBucketCount", 0);
   maxValues	       = get_int    (cl, da, "maximumValueCount",  0);
   deferred	       = get_boolean(cl, da, "deferred", False);
   deferCount	       = deferred ? 1 : 0;

   if ( bucketWidth == 0.0 ) bucketWidth = 1.0;
   minValue    = 0.0;
   maxValue    = bucketWidth;
   valRangeInv = 1.0/(maxValue - minValue);

//
// Get color names
//
   colorNames[BACKGROUND]        = ColorName(da, colors[BACKGROUND]);
   colorNames[CHART_COLOR]	 = ColorName(da, colors[CHART_COLOR]);
   colorNames[BAR_COLOR]	 = ColorName(da, colors[BAR_COLOR]);
   colorNames[BAR_BORDER_COLOR]  = ColorName(da, colors[BAR_BORDER_COLOR]);
   colorNames[AXIS_COLOR]	 = ColorName(da, colors[AXIS_COLOR]);
   colorNames[LABEL_COLOR]	 = ColorName(da, colors[LABEL_COLOR]);
   colorNames[TICK_COLOR]	 = ColorName(da, colors[TICK_COLOR]);
   colorNames[GRID_COLOR]	 = ColorName(da, colors[GRID_COLOR]);
   colorNames[MARK_COLOR]	 = ColorName(da, colors[MARK_COLOR]);
   colorNames[TOP_SHADOW]        = ColorName(da, colors[TOP_SHADOW]);
   colorNames[BOTTOM_SHADOW]     = ColorName(da, colors[BOTTOM_SHADOW]);
   colorNames[BAR_TOP_SHADOW]    = ColorName(da, colors[BAR_TOP_SHADOW]);
   colorNames[BAR_BOTTOM_SHADOW] = ColorName(da, colors[BAR_BOTTOM_SHADOW]);

//
// Set up the scroll bar
//
   if ( orientation == XmHORIZONTAL ) {

      WArgList	args;
      args.Orientation(XmHORIZONTAL);
      args.LeftAttachment(XmATTACH_FORM);
      args.RightAttachment(XmATTACH_FORM);
      args.TopAttachment(XmATTACH_NONE);
      args.BottomAttachment(XmATTACH_FORM);
      args.Height(scrollBarSpan);
      XtSetValues(scrollBar, ARGS);

      args.Reset();
      args.LeftAttachment(XmATTACH_FORM, 0);
      args.RightAttachment(XmATTACH_FORM, 0);
      args.TopAttachment(XmATTACH_FORM, 0);
      args.BottomAttachment(XmATTACH_WIDGET, scrollBar);
      XtSetValues(da, ARGS);
   }

//
// Turn off the scroll bar if all values are visible
//
   if ( visCount < 1 ) {
      WArgList	args;
      if ( orientation == XmVERTICAL ) args.LeftAttachment(XmATTACH_FORM);
      else			       args.BottomAttachment(XmATTACH_FORM);
      XtSetValues(da, ARGS);
      XtUnmanageChild(scrollBar);
   }

   return;

} // End HistogramC HistogramC

/*----------------------------------------------------------------------
 * Destructor
 */

HistogramC::~HistogramC()
{
   if ( halApp->xRunning )
      XFreeFont(halApp->display, font);
}

/*----------------------------------------------------------------------
 * Callback to build drawing area widget
 */

Widget
HistogramC::BuildWidgets(Widget parent, const char *name, ArgList argv,
			 Cardinal argc)
{
   WArgList	args;		// Used to set all resources at once

//
// Create form
//
   StringC	nameStr = name;
   nameStr += "Form";
   form = XmCreateForm(parent, nameStr, argv, argc);
   args.Reset();
   args.MarginWidth(0);
   args.MarginHeight(0);
   XtSetValues(form, ARGS);

//
// Create scroll bar
//
   nameStr = name;
   nameStr += "SB";
   args.Reset();
   args.Orientation(XmVERTICAL);
   args.LeftAttachment(XmATTACH_FORM);
   args.RightAttachment(XmATTACH_NONE);
   args.TopAttachment(XmATTACH_FORM);
   args.BottomAttachment(XmATTACH_FORM);
   scrollBar = XmCreateScrollBar(form, nameStr, ARGS);
   XtManageChild(scrollBar);

   XtAddCallback(scrollBar, XmNvalueChangedCallback, (XtCallbackProc)ScrollCB,
		 (XtPointer)this);
   XtAddCallback(scrollBar, XmNdragCallback,         (XtCallbackProc)ScrollCB,
		 (XtPointer)this);

   XtVaGetValues(scrollBar, XmNwidth, &scrollBarSpan, NULL);

//
// Create drawing area
//
   args.Reset();
   args.LeftAttachment(XmATTACH_WIDGET, scrollBar);
   args.RightAttachment(XmATTACH_FORM, 0);
   args.TopAttachment(XmATTACH_FORM, 0);
   args.BottomAttachment(XmATTACH_FORM, 0);
   da = XmCreateDrawingArea(form, (char *)name, ARGS);
   XtManageChild(da);

   return da;

} // End HistogramC BuildWidgets

/*----------------------------------------------------------------------
 * Callback to handle scroll bar value change
 */

void
HistogramC::ScrollCB(Widget, HistogramC *sp, XmScrollBarCallbackStruct *sb)
{
   if ( sp->visCount > 0 ) {
      sp->minIndex = sb->value;
      sp->maxIndex = sp->minIndex + sp->visCount - 1;
      sp->Draw();
   }
}

/*----------------------------------------------------------------------
 * Method to draw histogram
 */

void
HistogramC::Draw()
{
   if ( !gc || obscured ) return;

   XSetForeground(halApp->display, gc, colors[BACKGROUND]);
   XFillRectangle(halApp->display, pixmap, gc, 0, 0, daWd, daHt);

   if ( orientation == XmVERTICAL ) DrawVertical();
   else				    DrawHorizontal();

   XCopyArea(halApp->display, pixmap, win, gc, 0, 0, daWd, daHt, 0, 0);
}

/*----------------------------------------------------------------------
 * Method to draw vertical histogram
 */

void
HistogramC::DrawVertical()
{
   StringC	minYStr, maxYStr;
   XCharStruct	minYSize, maxYSize;
   int		dir, asc, dsc;
   XCharStruct	size;
   int		lcount = labelList.size();	// User label count

//
// Compute maximum value label size
//
   if ( userBuckets ) {
      if ( lcount > 0 ) minYStr = *labelList[minIndex];
      else		minYStr = "";
      if ( lcount > 1 ) maxYStr = *labelList[maxIndex];
      else		maxYStr = "";
   } else { // Calculate labels
      valueFormat = minValue;
      minYStr = (StringC)valueFormat;
      valueFormat = maxValue;
      maxYStr = (StringC)valueFormat;
   }

   XTextExtents(font, minYStr, minYStr.size(), &dir, &asc, &dsc, &minYSize);
   XTextExtents(font, maxYStr, maxYStr.size(), &dir, &asc, &dsc, &maxYSize);
   int	maxLabelWd = MAX(maxYSize.width, minYSize.width);

//
// Compute space needed for left margin
//
   int	leftMargin = marginWd + maxLabelWd + labelOffset;
   if ( !userBuckets ) {
      if ( majorTickLen > minorTickLen ) {
	 if      ( majorValueTickSpace > 0.0 ) leftMargin += majorTickLen;
	 else if ( minorValueTickSpace > 0.0 ) leftMargin += minorTickLen;
      } else {
	 if      ( minorValueTickSpace > 0.0 ) leftMargin += minorTickLen;
	 else if ( majorValueTickSpace > 0.0 ) leftMargin += majorTickLen;
      }
   }

//
// If first x label is too wide, increase left margin
//
   countFormat = minCount;
   StringC	minXStr = countFormat;
   XCharStruct	minXSize;
   int		minWd2;
   XTextExtents(font, minXStr, minXStr.size(), &dir, &asc, &dsc, &minXSize);
   minWd2 = minXSize.width / 2;
   if ( minWd2 > leftMargin ) leftMargin = minWd2 + 1;

//
// Compute space needed for right margin
//
   int	rightMargin = marginWd;
   if ( !userBuckets && valueMarkList.size() > 0 )
      rightMargin += maxLabelWd + labelOffset;

//
// If last x label is too wide, increase right margin
//
   countFormat = maxCount;
   StringC	maxXStr = countFormat;
   XCharStruct	maxXSize;
   int		maxWd2;
   XTextExtents(font, maxXStr, maxXStr.size(), &dir, &asc, &dsc, &maxXSize);
   maxWd2 = maxXSize.width / 2;
   if ( maxWd2 > rightMargin ) rightMargin = maxWd2 + 1;

   int	axisX1 = leftMargin;
   int	axisX2 = daWd - rightMargin - 1;
   int	axisWd = axisX2 - axisX1 + 1;
   int	valX1  = axisX1 + shadowThickness;
   int	valX2  = axisX2 - shadowThickness;
   int	valWd  = valX2 - valX1 + 1;

//
// Calculate top and bottom margins
//
   int	fontHt = font->ascent + font->descent;
   int	fontHt2 = fontHt / 2;

   int	topMargin = marginHt;
   if ( countMarkList.size() > 0 ) topMargin += fontHt + labelOffset;
   else				   topMargin += fontHt2;

   int	bottomMargin = marginHt + fontHt + labelOffset;
   if ( majorTickLen > minorTickLen ) {
      if      ( majorCountTickSpace > 0 ) bottomMargin += majorTickLen;
      else if ( minorCountTickSpace > 0 ) bottomMargin += minorTickLen;
   } else {
      if      ( minorCountTickSpace > 0 ) bottomMargin += minorTickLen;
      else if ( majorCountTickSpace > 0 ) bottomMargin += majorTickLen;
   }

   int	axisY1 = topMargin;
   int	axisY2 = daHt - bottomMargin - 1;
   int	axisHt = axisY2 - axisY1 + 1;
   int	valY1  = axisY1 + shadowThickness;
   int	valY2  = axisY2 - shadowThickness;
   int	valHt  = valY2 - valY1 + 1;

//
// Draw Count/X axis ticks
//
   XSetForeground(halApp->display, gc, colors[TICK_COLOR]);

   if ( majorCountTickSpace > 0 ) {
      int	y1 = axisY2 + 1;
      int	y2 = axisY2 + majorTickLen;
      for (int val=minCount; val<=maxCount; val+=majorCountTickSpace) {
	 int	x = valX1 + (int)(NormalizeCount(val) * valWd);
	 XDrawLine(halApp->display, pixmap, gc, x, y1, x, y2);
      }
   }

   if ( minorCountTickSpace > 0 ) {
      int	y1 = axisY2 + 1;
      int	y2 = axisY2 + minorTickLen;
      for (int val=minCount; val<=maxCount; val+=minorCountTickSpace) {
	 int	x = valX1 + (int)(NormalizeCount(val) * valWd);
	 XDrawLine(halApp->display, pixmap, gc, x, y1, x, y2);
      }
   }

//
// Calculate Y-axis spacing
//
   int	vcount;
   int	bcount = bucketList.size();
   if ( visCount > 0 ) vcount = MIN(visCount, bcount);
   else		       vcount = bcount;

   float	yincr = (float)(valHt-1);
   if ( vcount > 1 ) yincr /= (float)vcount;

   int		offset = valY1 - (int)(yincr * minIndex);
   float	range = yincr * bucketList.size();

//
// Draw Y-axis ticks
//
   if ( !userBuckets ) {

      if ( majorValueTickSpace > 0 ) {
	 int	x1 = axisX1 - majorTickLen;
	 int	x2 = axisX1 - 1;
	 for (float val=minValue; val<=maxValue; val+=majorValueTickSpace) {
	    int	y = offset + (int)(NormalizeValue(val) * range);
	    if ( y >= valY1 && y <= valY2 )
	       XDrawLine(halApp->display, pixmap, gc, x1, y, x2, y);
	 }
      }

      if ( minorValueTickSpace > 0 ) {
	 int	x1 = axisX1 - minorTickLen;
	 int	x2 = axisX1 - 1;
	 for (float val=minValue; val<=maxValue; val+=minorValueTickSpace) {
	    int	y = offset + (int)(NormalizeValue(val) * range);
	    if ( y >= valY1 && y <= valY2 )
	       XDrawLine(halApp->display, pixmap, gc, x1, y, x2, y);
	 }
      }
   }

//
// Draw X-axis labels
//
   XSetForeground(halApp->display, gc, colors[LABEL_COLOR]);

   int	y = axisY2 + labelOffset + font->ascent;
   if ( majorTickLen > minorTickLen ) {
      if      ( majorCountTickSpace > 0 ) y += majorTickLen;
      else if ( minorCountTickSpace > 0 ) y += minorTickLen;
   } else {
      if      ( minorCountTickSpace > 0 ) y += minorTickLen;
      else if ( majorCountTickSpace > 0 ) y += majorTickLen;
   }

   int	x = valX1 - minWd2;
   XDrawString(halApp->display, pixmap, gc, x, y, minXStr, minXStr.size());
   int	leftX = x + minXSize.width;

   x = valX2 - maxWd2;
   if ( x > leftX ) {
      XDrawString(halApp->display, pixmap, gc, x, y, maxXStr, maxXStr.size());
      int	rightX = x;

//
// Draw the interior labels
//
      if ( majorCountTickSpace > 0 ) {
	 for (int val=minCount+majorCountTickSpace; val<maxCount;
	      val+=majorCountTickSpace) {
	    countFormat = val;
	    StringC valStr = countFormat;
	    XTextExtents(font, valStr, valStr.size(), &dir, &asc, &dsc, &size);
	    x = valX1 + (int)(NormalizeCount(val) * valWd) - size.width/2;
//
// Draw only if it doesn't overlap another
//
	    if ( (x>leftX) && (x+size.width)<rightX ) {
	       XDrawString(halApp->display, pixmap, gc, x, y, valStr,
			   valStr.size());
	       leftX = x + size.width;
	    }
	 } // End for each major value
      } // End if there are major ticks
   } // End if space for interior labels

//
// Draw Y-axis labels
//
   if ( userBuckets ) {

      if ( lcount > 0 ) {

	 x = axisX1 - labelOffset;

//
// Draw the first and last labels
//
	 StringC	*label = labelList[minIndex];
	 XTextExtents(font, *label, label->size(), &dir, &asc, &dsc, &size);

	 float	yincr2 = yincr * 0.5;
	 y = valY1 + (int)yincr2 + font->ascent - fontHt2;
	 x -= size.width;
	 XDrawString(halApp->display, pixmap, gc, x, y, *label, label->size());
	 x += size.width;
	 int	topY = y + font->descent;

//
// Draw the last label
//
	 if ( lcount > 1 ) {

	    label = labelList[maxIndex];
	    XTextExtents(font, *label, label->size(), &dir, &asc, &dsc, &size);
	    y = valY2 - (int)yincr2 + font->ascent - fontHt2;
	    x -= size.width;
	    XDrawString(halApp->display, pixmap, gc, x, y, *label,
			label->size());
	    x += size.width;
	    int	botY = y - font->descent;
//
// Draw the interior labels
//
	    for (int i=minIndex+1; i<maxIndex; i++) {

	       label = labelList[i];
	       XTextExtents(font, *label, label->size(), &dir,&asc,&dsc, &size);

//
// Draw only if it doesn't overlap another
//
	       y = valY1 + (int)(yincr * (i-minIndex) + yincr2) + font->ascent
		 - fontHt2;
	       if ( (y-font->ascent) > topY && (y+font->descent) < botY ) {
		  x -= size.width;
		  XDrawString(halApp->display, pixmap, gc, x, y, *label,
			      label->size());
		  x += size.width;
		  topY = y + font->descent;
	       }

	    } // End for each bar label
	 } // End if at least 2 labels
      } // End if at least 1 label

   } else { // Calculate labels

      x = axisX1 - labelOffset;
      if ( majorTickLen > minorTickLen ) {
	 if      ( majorValueTickSpace > 0.0 ) x -= majorTickLen;
	 else if ( minorValueTickSpace > 0.0 ) x -= minorTickLen;
      } else {
	 if      ( minorValueTickSpace > 0.0 ) x -= minorTickLen;
	 else if ( majorValueTickSpace > 0.0 ) x -= majorTickLen;
      }

      int	topY = 0;
      int	botY = daHt;
      float	val;

//
// Match labels to tick marks if possible
//
      if ( majorValueTickSpace > 0.0 ) {


	 for (val=minValue; val<=maxValue; val+=majorValueTickSpace) {

	    valueFormat = val;
	    StringC valStr = valueFormat;
	    XTextExtents(font, valStr, valStr.size(), &dir, &asc, &dsc, &size);

//
// Draw only if it doesn't overlap another
//
	    y = offset + (int)(NormalizeValue(val) * range) + font->ascent
	      - fontHt2;
	    if ( (y-font->ascent) > topY && (y+font->descent) < botY ) {
	       x -= size.width;
	       XDrawString(halApp->display, pixmap, gc, x, y, valStr,
			   valStr.size());
	       x += size.width;
	       topY = y + font->descent;
	    }

	 } // End for each value label
      } // End if there are value ticks

      else {	// Draw top and bottom labels only

//
// Find the top-most visible label
//
	 Boolean	found = False;
	 for (val=minValue; !found && val<=maxValue; ) {
	    int	y = offset + (int)(NormalizeValue(val) * range);
	    if ( (y-font->ascent) > topY && (y+font->descent) < botY )
	       found = True;
	    else
	       val += bucketWidth;
	 }

	 if ( found ) {
	    valueFormat = val;
	    StringC valStr = valueFormat;
	    XTextExtents(font, valStr, valStr.size(), &dir, &asc, &dsc, &size);
	    x -= size.width;
	    y = valY1 + font->ascent - fontHt2;
	    XDrawString(halApp->display, pixmap, gc, x, y, valStr,
			valStr.size());
	    x += size.width;
	    topY = y + font->descent;
	 }

//
// Find the bottom-most visible label
//
	 found = False;
	 for (val=maxValue; !found && val>minValue; ) {
	    int	y = offset + (int)(NormalizeValue(val) * range);
	    if ( (y-font->ascent) > topY && (y+font->descent) < botY )
	       found = True;
	    else
	       val -= bucketWidth;
	 }

	 if ( found ) {
	    valueFormat = val;
	    StringC valStr = valueFormat;
	    XTextExtents(font, valStr, valStr.size(), &dir, &asc, &dsc, &size);
	    x -= size.width;
	    y = valY2 + font->ascent - fontHt2;
	    XDrawString(halApp->display, pixmap, gc, x, y, valStr,
			valStr.size());
	    x += size.width;
	 }

      } // End if drawing top and bottom labels only

   } // End if we are calculating the labels

//
// Draw chart background
//
   XSetForeground(halApp->display, gc, colors[CHART_COLOR]);
   XFillRectangle(halApp->display, pixmap, gc, axisX1, axisY1, axisWd, axisHt);

//
// Draw chart shadow if necessary
//
   if ( shadowThickness > 0 ) {

      DrawShadow(halApp->display, pixmap, gc, colors[TOP_SHADOW],
		 colors[BOTTOM_SHADOW], axisX1, axisY1, axisWd, axisHt,
		 shadowThickness, shadowType);

   } else { // Draw axis lines

      XSetForeground(halApp->display, gc, colors[AXIS_COLOR]);
      XDrawLine(halApp->display, pixmap,gc, axisX1-1, axisY1, axisX1-1, axisY2);
      XDrawLine(halApp->display, pixmap,gc, axisX1-1, axisY2+1, axisX2,
		axisY2+1);
   }

   if ( bucketList.size() > 0 ) {

//
// Set clipping window
//
      XRectangle	rect;
      rect.x      = (short)valX1;
      rect.y      = (short)valY1;
      rect.width  = (unsigned short)valWd;
      rect.height = (unsigned short)valHt;
      XSetClipRectangles(halApp->display, gc, 0, 0, &rect, 1, Unsorted);

//
// Draw bars
//
      float	offset = 0;
      for (int i=minIndex; i<=maxIndex; i++, offset+=yincr) {
	 int	y  = valY1 + (int)offset + 1;
	 int	y2 = valY1 + (int)(offset + yincr);
	 int	ht = y2 - y;
	 int	wd = (int)(NormalizeCount(*bucketList[i]) * valWd);

	 XSetForeground(halApp->display, gc, colors[BAR_COLOR]);
	 XFillRectangle(halApp->display, pixmap, gc, valX1, y, wd, ht);

	 if ( barShadowThickness > 0 ) {
	    DrawShadow(halApp->display, pixmap, gc, colors[BAR_TOP_SHADOW],
		       colors[BAR_BOTTOM_SHADOW], valX1, y, wd, ht,
		       barShadowThickness, barShadowType);
	 } else {
	    XSetForeground(halApp->display, gc, colors[BAR_BORDER_COLOR]);
	    XDrawRectangle(halApp->display, pixmap, gc, valX1, y, wd-1, ht-1);
	 }
      }

      XSetClipMask(halApp->display, gc, None);

   } // End if at least one bucket

//
// Draw grid lines
//
   XSetForeground(halApp->display, gc, colors[GRID_COLOR]);
   XSetLineAttributes(halApp->display, gc,0, LineOnOffDash, CapButt, JoinMiter);

   if ( majorCountTickSpace > 0 && majorGridVis ) {
      for (int val=minCount; val<=maxCount; val+=majorCountTickSpace) {
	 int	x = valX1 + (int)(NormalizeCount(val) * valWd);
	 XDrawLine(halApp->display, pixmap, gc, x, valY1, x, valY2);
      }
   }

   if ( minorCountTickSpace > 0 && minorGridVis ) {
      for (int val=minCount; val<=maxCount; val+=minorCountTickSpace) {
	 int	x = valX1 + (int)(NormalizeCount(val) * valWd);
	 XDrawLine(halApp->display, pixmap, gc, x, valY1, x, valY2);
      }
   }

   XSetLineAttributes(halApp->display, gc, 0, LineSolid, CapButt, JoinMiter);

//
// Draw count axis marks
//
   XSetForeground(halApp->display, gc, colors[MARK_COLOR]);

   y = axisY1 - labelOffset - font->descent;
   int	mcount = countMarkList.size();
   for (int i=0; i<mcount; i++) {

      int	val = *countMarkList[i];
      int	x = valX1 + (int)(NormalizeCount(val) * valWd);
      if ( x >= valX1 && x <= valX2 ) {
	 XDrawLine(halApp->display, pixmap, gc, x, axisY1, x, axisY2);

	 countFormat = val;
	 StringC valStr = countFormat;
	 XTextExtents(font, valStr, valStr.size(), &dir, &asc, &dsc, &size);

	 x -= size.width/2;
	 XDrawString(halApp->display, pixmap, gc, x, y, valStr, valStr.size());
      }

   } // End for each count mark

//
// Draw value axis marks
//
   if ( !userBuckets ) {

      x = axisX1 + labelOffset;
      int	mcount = valueMarkList.size();
      for (i=0; i<mcount; i++) {

	 float	val = *valueMarkList[i];
	 int	y = valY1 + (int)(NormalizeValue(val) * valHt);
	 if ( y >= valY1 && y <= valY2 ) {
	    XDrawLine(halApp->display, pixmap, gc, axisX1, y, axisX2, y);

	    valueFormat = val;
	    StringC valStr = valueFormat;
	    XTextExtents(font, valStr, valStr.size(), &dir, &asc, &dsc, &size);

	    y += (font->ascent - fontHt2);
	    XDrawString(halApp->display, pixmap, gc,x,y, valStr, valStr.size());
	 }

      } // End for each value mark
   } // End if not user defined buckets

//
// Position the scroll bar
//
   int	sliderSize = MAX(vcount,1);
   int	sliderInc  = sliderSize;
   int	sliderMax  = MAX(bcount, sliderSize);

   WArgList	args;
   args.TopOffset(topMargin);
   args.BottomOffset(bottomMargin);
   args.Maximum(sliderMax);
   args.Value(minIndex);
   args.SliderSize(sliderSize);
   args.PageIncrement(sliderInc);
   XtSetValues(scrollBar, ARGS);

} // End HistogramC DrawVertical

/*----------------------------------------------------------------------
 * Method to draw horizontal histogram
 */

void
HistogramC::DrawHorizontal()
{
   int	lcount = labelList.size();

//
// Compute maximum count/y label size
//
   int		dir, asc, dsc;
   XCharStruct	minYSize, maxYSize;
   countFormat = minCount;
   StringC	minYStr = countFormat;
   countFormat = maxCount;
   StringC	maxYStr = countFormat;
   XTextExtents(font, minYStr, minYStr.size(), &dir, &asc, &dsc, &minYSize);
   XTextExtents(font, maxYStr, maxYStr.size(), &dir, &asc, &dsc, &maxYSize);
   int		maxLabelWd = MAX(minYSize.width, maxYSize.width);

//
// Get min and max labels for value/x axis
//
   StringC	minXStr, maxXStr;
   XCharStruct	minXSize, maxXSize;
   XCharStruct	size;

   if ( userBuckets ) {
      if ( lcount > 0 ) minXStr = *labelList[minIndex];
      else		minXStr = "";
      if ( lcount > 1 ) maxXStr = *labelList[maxIndex];
      else		maxXStr = "";
   } else { // Calculate labels
      valueFormat = minValue;
      minXStr = (StringC)valueFormat;
      valueFormat = maxValue;
      maxXStr = (StringC)valueFormat;
   }

//
// Compute space needed for left margin
//
   int	leftMargin = marginWd + maxLabelWd + labelOffset;
   if ( majorTickLen > minorTickLen ) {
      if      ( majorCountTickSpace > 0 ) leftMargin += majorTickLen;
      else if ( minorCountTickSpace > 0 ) leftMargin += minorTickLen;
   } else {
      if      ( minorCountTickSpace > 0 ) leftMargin += minorTickLen;
      else if ( majorCountTickSpace > 0 ) leftMargin += majorTickLen;
   }

//
// If first x label is too wide, increase left margin
//
   XTextExtents(font, minXStr, minXStr.size(), &dir, &asc, &dsc, &minXSize);
   int	minWd2  = minXSize.width / 2;
   if ( minWd2 > leftMargin ) leftMargin = minWd2 + 1;

//
// Compute space needed for right margin
//
   int	rightMargin = marginWd;
   if ( countMarkList.size() > 0 ) rightMargin += maxLabelWd + labelOffset;

//
// If last x label is too wide, increase right margin
//
   XTextExtents(font, maxXStr, maxXStr.size(), &dir, &asc, &dsc, &maxXSize);
   int	maxWd2 = maxXSize.width / 2;
   if ( maxWd2 > rightMargin ) rightMargin = maxWd2 + 1;

   int	axisX1 = leftMargin;
   int	axisX2 = daWd - rightMargin - 1;
   int	axisWd = axisX2 - axisX1 + 1;
   int	valX1  = axisX1 + shadowThickness;
   int	valX2  = axisX2 - shadowThickness;
   int	valWd  = valX2 - valX1 + 1;

//
// Calculate top and bottom margins
//
   int	fontHt = font->ascent + font->descent;
   int	fontHt2 = fontHt / 2;

   int	topMargin = marginHt;
   if ( !userBuckets && valueMarkList.size() > 0 )
      topMargin += fontHt + labelOffset;
   else
      topMargin += fontHt2;

   int	bottomMargin = marginHt + fontHt + labelOffset;
   if ( !userBuckets ) {
      if ( majorTickLen > minorTickLen ) {
	 if      ( majorValueTickSpace > 0.0 ) bottomMargin += majorTickLen;
	 else if ( minorValueTickSpace > 0.0 ) bottomMargin += minorTickLen;
      } else {
	 if      ( minorValueTickSpace > 0.0 ) bottomMargin += minorTickLen;
	 else if ( majorValueTickSpace > 0.0 ) bottomMargin += majorTickLen;
      }
   }

   int	axisY1 = topMargin;
   int	axisY2 = daHt - bottomMargin - 1;
   int	axisHt = axisY2 - axisY1 + 1;
   int	valY1  = axisY1 + shadowThickness;
   int	valY2  = axisY2 - shadowThickness;
   int	valHt  = valY2 - valY1 + 1;

//
// Draw Count/Y axis ticks
//
   XSetForeground(halApp->display, gc, colors[TICK_COLOR]);

   if ( majorCountTickSpace > 0 ) {
      int	x1 = axisX1 - majorTickLen;
      int	x2 = axisX1 - 1;
      for (int val=minCount; val<=maxCount; val+=majorCountTickSpace) {
	 int	y = valY2 - (int)(NormalizeCount(val) * valHt);
	 XDrawLine(halApp->display, pixmap, gc, x1, y, x2, y);
      }
   }

   if ( minorCountTickSpace > 0 ) {
      int	x1 = axisX1 - minorTickLen;
      int	x2 = axisX1 - 1;
      for (int val=minCount; val<=maxCount; val+=minorCountTickSpace) {
	 int	y = valY2 - (int)(NormalizeCount(val) * valHt);
	 XDrawLine(halApp->display, pixmap, gc, x1, y, x2, y);
      }
   }

//
// Calculate Value/X axis spacing
//
   int	vcount;
   int	bcount = bucketList.size();
   if ( visCount > 0 ) vcount = MIN(visCount, bcount);
   else		       vcount = bcount;

   float	xincr = (float)(valWd-1);
   if ( vcount > 1 ) xincr /= (float)vcount;

   int		offset = valX1 - (int)(xincr * minIndex);
   float	range = xincr * bucketList.size();

//
// Draw value/X axis ticks
//
   if ( !userBuckets ) {

      if ( majorValueTickSpace > 0 ) {
	 int	y1 = axisY2 + 1;
	 int	y2 = axisY2 + majorTickLen;
	 for (float val=minValue; val<=maxValue; val+=majorValueTickSpace) {
	    int x = offset + (int)(NormalizeValue(val) * range);
	    if ( x >= valX1 && x <= valX2 )
	       XDrawLine(halApp->display, pixmap, gc, x, y1, x, y2);
	 }

      }

      if ( minorValueTickSpace > 0 ) {
	 int	y1 = axisY2 + 1;
	 int	y2 = axisY2 + minorTickLen;
	 for (float val=minValue; val<=maxValue; val+=minorValueTickSpace) {
	    int x = offset + (int)(NormalizeValue(val) * range);
	    if ( x >= valX1 && x <= valX2 )
	       XDrawLine(halApp->display, pixmap, gc, x, y1, x, y2);
	 }
      }

   } // End if not user-defined buckets

//
// Draw Count/Y axis labels
//
   XSetForeground(halApp->display, gc, colors[LABEL_COLOR]);

   int	x = axisX1 - labelOffset;
   if ( majorTickLen > minorTickLen ) {
      if      ( majorCountTickSpace > 0 ) x -= majorTickLen;
      else if ( minorCountTickSpace > 0 ) x -= minorTickLen;
   } else {
      if      ( minorCountTickSpace > 0 ) x -= minorTickLen;
      else if ( majorCountTickSpace > 0 ) x -= majorTickLen;
   }

   int	y = valY2 + font->ascent - fontHt2;
   x -= minYSize.width;
   XDrawString(halApp->display, pixmap, gc, x, y, minYStr, minYStr.size());
   x += minYSize.width;
   int	botY = y - font->ascent;

   y = valY1 + font->ascent - fontHt2;
   if ( y+font->descent < botY ) {

      x -= maxYSize.width;
      XDrawString(halApp->display, pixmap, gc, x, y, maxYStr, maxYStr.size());
      x += maxYSize.width;
      int	topY = y + font->descent;

//
// Draw the interior labels
//
      if ( majorCountTickSpace > 0.0 ) {
	 for (int val=minCount+majorCountTickSpace; val<maxCount;
	      val+=majorCountTickSpace) {
	    countFormat = val;
	    StringC valStr = countFormat;
	    XTextExtents(font, valStr, valStr.size(), &dir, &asc, &dsc, &size);
	    y = valY2 - (int)(NormalizeCount(val) * valHt) + font->ascent
	      - fontHt2;

//
// Draw only if it doesn't overlap another
//
	    if ( (y+font->descent<botY) && (y-font->ascent)>topY ) {
	       x -= size.width;
	       XDrawString(halApp->display, pixmap, gc, x, y, valStr,
			   valStr.size());
	       x += size.width;
	       botY = y - font->ascent;
	    }

	 } // End for each major value
      } // End if there are major ticks
   } // End if no overlap

//
// Draw Value/X axis labels
//
   if ( userBuckets ) {

      if ( lcount > 0 ) {

	 y = axisY2 + labelOffset + font->ascent;
	 if ( majorTickLen > minorTickLen ) {
	    if      ( majorValueTickSpace > 0 ) y += majorTickLen;
	    else if ( minorValueTickSpace > 0 ) y += minorTickLen;
	 } else {
	    if      ( minorValueTickSpace > 0 ) y += minorTickLen;
	    else if ( majorValueTickSpace > 0 ) y += majorTickLen;
	 }

//
// Draw the first and last labels
//
	 float	xincr2 = xincr * 0.5;
	 x = valX1 + (int)xincr2 - minWd2;
	 XDrawString(halApp->display, pixmap, gc, x,y, minXStr, minXStr.size());
	 int	leftX = x + minXSize.width;

//
// Draw the last label
//
	 if ( lcount > 1 ) {

	    x = valX2 - (int)xincr2 - maxWd2;
	    XDrawString(halApp->display, pixmap, gc, x, y, maxXStr,
			maxXStr.size());
	    int	rightX = x;
//
// Draw the interior labels
//
	    for (int i=minIndex+1; i<maxIndex; i++) {

	       StringC	*label = labelList[i];
	       XTextExtents(font, *label, label->size(), &dir,&asc,&dsc, &size);

//
// Draw only if it doesn't overlap another
//
	       x = valX1 + (int)(xincr * (i-minIndex) + xincr2) - size.width/2;
	       if ( x > leftX && (x+size.width) < rightX ) {
		  XDrawString(halApp->display, pixmap, gc, x, y, *label,
			      label->size());
		  leftX = x + size.width;
	       }

	    } // End for each bar label
	 } // End if at least 2 labels
      } // End if at least 1 label

   } else { // Calculate labels

      y = axisY2 + labelOffset + font->ascent;
      if ( majorTickLen > minorTickLen ) {
	 if      ( majorValueTickSpace > 0.0 ) y += majorTickLen;
	 else if ( minorValueTickSpace > 0.0 ) y += minorTickLen;
      } else {
	 if      ( minorValueTickSpace > 0.0 ) y += minorTickLen;
	 else if ( majorValueTickSpace > 0.0 ) y += majorTickLen;
      }

      int	leftX  = 0;
      int	rightX = daWd;
      float	val;

//
// Match labels to tick marks if possible
//
      if ( majorValueTickSpace > 0.0 ) {

	 for (val=minValue; val<=maxValue; val+=majorValueTickSpace) {

            valueFormat = val;
            StringC valStr = valueFormat;
            XTextExtents(font, valStr, valStr.size(), &dir, &asc, &dsc, &size);

//
// Draw only if it doesn't overlap another
//
            x = offset + (int)(NormalizeValue(val) * range) - size.width/2;
            if ( x > leftX && (x+size.width) < rightX ) {
	       XDrawString(halApp->display, pixmap, gc, x, y, valStr,
			   valStr.size());
	       leftX = x + size.width;
	    }

	 } // End for each value label
      } // End if there are value ticks

      else {	// Draw top and bottom labels only

//
// Find the left-most visible label
//
         Boolean	found = False;
	 for (val=minValue; !found && val<=maxValue; ) {
            int x = offset + (int)(NormalizeValue(val) * range);
            if ( x > leftX && x < rightX ) found = True;
            else			   val += bucketWidth;
         }

         if ( found ) {
            valueFormat = val;
            StringC valStr = valueFormat;
            XTextExtents(font, valStr, valStr.size(), &dir, &asc, &dsc, &size);
            x = valX1 - size.width/2;
            XDrawString(halApp->display, pixmap, gc,x,y, valStr, valStr.size());
            leftX = x + size.width;
	 }

//
// Find the right-most visible label
//
         found = False;
	 for (val=maxValue; !found && val>minValue; ) {
            int x = offset + (int)(NormalizeValue(val) * range);
            if ( x > leftX && x < rightX ) found = True;
            else			   val -= bucketWidth;
         }

         if ( found ) {
            valueFormat = val;
            StringC valStr = valueFormat;
            XTextExtents(font, valStr, valStr.size(), &dir, &asc, &dsc, &size);
            x = valX2 - size.width/2;
            XDrawString(halApp->display, pixmap, gc,x,y, valStr, valStr.size());
            leftX = x + size.width;
	 }

      } // End if drawing top and bottom labels only

   } // End if we are calculating the labels

//
// Draw chart background
//
   XSetForeground(halApp->display, gc, colors[CHART_COLOR]);
   XFillRectangle(halApp->display, pixmap, gc, axisX1, axisY1, axisWd, axisHt);

//
// Draw chart shadow if necessary
//
   if ( shadowThickness > 0 ) {

      DrawShadow(halApp->display, pixmap, gc, colors[TOP_SHADOW],
		 colors[BOTTOM_SHADOW], axisX1, axisY1, axisWd, axisHt,
		 shadowThickness, shadowType);

   } else { // Draw axis lines

      XSetForeground(halApp->display, gc, colors[AXIS_COLOR]);
      XDrawLine(halApp->display, pixmap,gc, axisX1-1, axisY1, axisX1-1, axisY2);
      XDrawLine(halApp->display, pixmap,gc, axisX1-1, axisY2+1, axisX2,
		axisY2+1);
   }

   if ( bucketList.size() > 0 ) {

//
// Set clipping window
//
      XRectangle	rect;
      rect.x      = (short)valX1;
      rect.y      = (short)valY1;
      rect.width  = (unsigned short)valWd;
      rect.height = (unsigned short)valHt;
      XSetClipRectangles(halApp->display, gc, 0, 0, &rect, 1, Unsorted);

//
// Draw bars
//
      float	offset = 0;
      for (int i=minIndex; i<=maxIndex; i++, offset+=xincr) {

	 int	x  = valX1 + (int)offset + 1;
	 int	x2 = valX1 + (int)(offset + xincr);
	 int	wd = x2 - x;
	 int	ht = (int)(NormalizeCount(*bucketList[i]) * valHt);
	 int	y  = valY2 - ht + 1;

	 XSetForeground(halApp->display, gc, colors[BAR_COLOR]);
	 XFillRectangle(halApp->display, pixmap, gc, x, y, wd, ht);

	 if ( barShadowThickness > 0 ) {
	    DrawShadow(halApp->display, pixmap, gc, colors[BAR_TOP_SHADOW],
		       colors[BAR_BOTTOM_SHADOW], x, y, wd, ht,
		       barShadowThickness, barShadowType);
	 } else {
	    XSetForeground(halApp->display, gc, colors[BAR_BORDER_COLOR]);
	    XDrawRectangle(halApp->display, pixmap, gc, x, y, wd-1, ht-1);
	 }
      }

      XSetClipMask(halApp->display, gc, None);

   } // End if at least 1 point

//
// Draw grid lines
//
   XSetForeground(halApp->display, gc, colors[GRID_COLOR]);
   XSetLineAttributes(halApp->display, gc,0, LineOnOffDash, CapButt, JoinMiter);

   if ( majorCountTickSpace > 0 && majorGridVis ) {
      for (int val=minCount; val<=maxCount; val+=majorCountTickSpace) {
	 int	y = valY2 - (int)(NormalizeCount(val) * valHt);
	 XDrawLine(halApp->display, pixmap, gc, valX1, y, valX2, y);
      }
   }

   if ( minorCountTickSpace > 0 && minorGridVis ) {
      for (int val=minCount; val<=maxCount; val+=minorCountTickSpace) {
	 int	y = valY2 - (int)(NormalizeCount(val) * valHt);
	 XDrawLine(halApp->display, pixmap, gc, valX1, y, valX2, y);
      }
   }

   XSetLineAttributes(halApp->display, gc, 0, LineSolid, CapButt, JoinMiter);

//
// Draw count axis marks
//
   XSetForeground(halApp->display, gc, colors[MARK_COLOR]);

   x = axisX2 + labelOffset;
   int	mcount = countMarkList.size();
   for (int i=0; i<mcount; i++) {

      int	val = *countMarkList[i];
      int	y = valY2 - (int)(NormalizeCount(val) * valHt);
      if ( y >= valY1 && y <= valY2 ) {
	 XDrawLine(halApp->display, pixmap, gc, axisX1, y, axisX2, y);

	 countFormat = val;
	 StringC valStr = countFormat;
	 XTextExtents(font, valStr, valStr.size(), &dir, &asc, &dsc, &size);

	 y += font->ascent - fontHt2;
	 XDrawString(halApp->display, pixmap, gc, x, y, valStr, valStr.size());
      }

   } // End for each count mark

//
// Draw value axis marks
//
   if ( !userBuckets ) {

      y = axisY1 - labelOffset - font->descent;
      int	mcount = valueMarkList.size();
      for (int i=0; i<mcount; i++) {

	 float	val = *valueMarkList[i];
	 int	x = valX1 + (int)(NormalizeValue(val) * valWd);
	 if ( x >= valX1 && x <= valX2 ) {
	    XDrawLine(halApp->display, pixmap, gc, x, axisY1, x, axisY2);

	    valueFormat = val;
	    StringC valStr = valueFormat;
	    XTextExtents(font, valStr, valStr.size(), &dir, &asc, &dsc, &size);

	    x -= size.width/2;
	    XDrawString(halApp->display, pixmap, gc,x,y, valStr, valStr.size());
	 }

      } // End for each value mark

   } // End if calculating values

//
// Position the scroll bar
//
   int	sliderSize = MAX(vcount,1);
   int	sliderInc  = sliderSize;
   int	sliderMax  = MAX(bcount, sliderSize);

   WArgList	args;
   args.LeftOffset(leftMargin);
   args.RightOffset(rightMargin);
   args.Maximum(sliderMax);
   args.Value(minIndex);
   args.SliderSize(sliderSize);
   args.PageIncrement(sliderInc);
   XtSetValues(scrollBar, ARGS);

} // End HistogramC DrawHorizontal

/*----------------------------------------------------------------------
 * Methods to convert value and count into range 0.0 to 1.0
  */

float
HistogramC::NormalizeValue(float val)
{
   return ((val - minValue) * valRangeInv);
}

float
HistogramC::NormalizeCount(int count)
{
   return ((count - minCount) * countRangeInv);
}

/*----------------------------------------------------------------------
 * Method to place the values into buckets
  */

void
HistogramC::RefillBuckets()
{
   bucketList.removeAll();
   minCount = 0;
   maxCount = 0;
   countRangeInv = 1.0;
   unsigned	vcount = valueList.size();

   if ( vcount <= 0 ) {
      minValue    = 0.0;
      maxValue    = bucketWidth;
      valRangeInv = 1.0/(maxValue - minValue);
      return;
   }

//
// Set up the first bucket
//
   float	val = *valueList[0];
   minValue = ((int)((float)val / bucketWidth)) * bucketWidth;
   maxValue = minValue + bucketWidth;
   valRangeInv = 1.0/(maxValue - minValue);
   int	tmp = 1;
   bucketList.append(tmp);

//
// Loop through remaining values
//
   for (int i=1; i<vcount; i++) IncrementBucket(*valueList[i]);

//
// Find minimum sized bucket if necessary
//
   unsigned	bcount = bucketList.size();
   if ( compress ) {

      minCount = maxCount;
      for (int i=0; i<bcount; i++) {
	 int	size = *(bucketList[i]);
	 if ( size < minCount ) minCount = size;
      }
   }

   if ( maxCount != minCount ) countRangeInv = 1.0/(maxCount - minCount);
   else			       countRangeInv = 1.0;

   minIndex = 0;
   if ( visCount>0 ) maxIndex = MIN(visCount-1, bcount-1);
   else		     maxIndex = bcount-1;

} // End HistogramC RefillBuckets

/*----------------------------------------------------------------------
 * Methods to increment the bucket count for the given value
 */

void
HistogramC::IncrementBucket(float val)
{
//
// Find correct bucket for this value
//
   int	bucketNum = (int)((val - minValue)/ bucketWidth);

//
// Add buckets at beginning of list if necessary
//
   while ( bucketNum < 0 ) {
      bucketList.insert((int)0, (unsigned)0);
      bucketNum++;
      minValue -= bucketWidth;
   }

//
// Add buckets at end of list if necessary
//
   unsigned	bcount = bucketList.size();
   int		tmp = 0;
   while ( bcount <= bucketNum ) {
      bucketList.append(tmp);
      bcount++;
      maxValue += bucketWidth;
   }

//
// Update range inverse
//
   valRangeInv = 1.0/(maxValue - minValue);

//
// Increment size of current bucket
//
   int	*bucketSize = bucketList[bucketNum];
   (*bucketSize)++;
   if ( *bucketSize > maxCount ) {
      maxCount = *bucketSize;
      if ( maxCount != minCount ) countRangeInv = 1.0/(maxCount - minCount);
      else			  countRangeInv = 1.0;
   }

} // HistogramC IncrementBucket

/*----------------------------------------------------------------------
 * Methods to decrement the bucket count for the given value
 */

void
HistogramC::DecrementBucket(float val)
{
//
// Find correct bucket for this value
//
   int	bucketNum = (int)((val - minValue)/ bucketWidth);

//
// Decrement size of current bucket
//
   int	*bucketSize = bucketList[bucketNum];
   if ( *bucketSize <= 0 ) return;

   (*bucketSize)--;
   if ( compress && *bucketSize < minCount ) {
      minCount = *bucketSize;
      if ( maxCount != minCount ) countRangeInv = 1.0/(maxCount - minCount);
      else			  countRangeInv = 1.0;
   }

// Graph hops up and down if this is done

#if 0
//
// Find maximum sized bucket if necessary
//
   if ( *bucketSize+1 == maxCount ) {

      maxCount = minCount;
      unsigned	bcount = bucketList.size();
      for (int i=0; i<bcount; i++) {
	 int	size = *(bucketList[i]);
	 if ( size > maxCount ) maxCount = size;
      }
      if ( maxCount != minCount ) countRangeInv = 1.0/(maxCount - minCount);
      else			  countRangeInv = 1.0;
   }
#endif

} // HistogramC DecrementBucket

/*----------------------------------------------------------------------
 * Methods to add marks
 */

void
HistogramC::AddCountMark(int val)
{
   countMarkList.append(val);
   if ( !deferred ) Draw();
}

void
HistogramC::AddValueMark(const ValueC val)
{
   float	fval = val;
   valueMarkList.append(fval);
   if ( !deferred ) Draw();
}

/*----------------------------------------------------------------------
 * Method to add a value
 */

void
HistogramC::AddValue(const ValueC val)
{
   userBuckets = False;
   float	fval = val;
   valueList.append(fval);
   unsigned	vcount = valueList.size();

//
// Remove value from beginning if we've exceeded the maximum
//
   if ( maxValues>0 && vcount>maxValues ) {
      DecrementBucket(*valueList[0]);
      valueList.remove((unsigned)0);
      vcount--;
   }

//
// Get bucket count
//
   unsigned	bcount = bucketList.size();
   unsigned	ocount = bcount;	// To see if size changes later

//
// If this is the first value, set up the list
//
   if ( bcount == 0 ) {

      minValue = ((int)(fval / bucketWidth)) * bucketWidth;
      maxValue = minValue + bucketWidth;
      valRangeInv = 1.0/(maxValue - minValue);
      int	tmp = 1;
      bucketList.append(tmp);

   } else { // Add value to a bucket

      IncrementBucket(val);
      bcount = bucketList.size();

//
// Find minimum sized bucket if necessary
//
      if ( compress ) {

	 minCount = maxCount;
	 for (int i=0; i<bcount; i++) {
	    int	size = *(bucketList[i]);
	    if ( size < minCount ) minCount = size;
	 }
	 if ( maxCount != minCount ) countRangeInv = 1.0/(maxCount - minCount);
	 else			     countRangeInv = 1.0;
      }

   } // End if adding value to bucket list

//
// Update visible buckets if necessary
//
   if ( ocount != bcount ) {

      if ( visCount > 0 ) {

	 maxIndex = minIndex + visCount - 1;
	 if ( maxIndex >= bcount ) {
	    maxIndex = bcount - 1;
	    minIndex = maxIndex - visCount + 1;
	    if ( minIndex < 0 ) minIndex = 0;
	 }

      } else {
	 maxIndex = bcount - 1;
      }
   }

   if ( !deferred ) Draw();

} // End HistogramC AddValue

/*----------------------------------------------------------------------
 * Methods to set the shadow thickness
 */

void
HistogramC::SetBarShadowThickness(Dimension thick)
{
   if ( thick != barShadowThickness ) {
      barShadowThickness = thick;
      if ( !deferred ) Draw();
   }
}

void
HistogramC::SetShadowThickness(Dimension thick)
{
   if ( thick != shadowThickness ) {
      shadowThickness = thick;
      if ( !deferred ) Draw();
   }
}

/*----------------------------------------------------------------------
 * Methods to set the shadow type
 */

void
HistogramC::SetBarShadowType(unsigned char type)
{
   if ( type != barShadowType ) {
      barShadowType = type;
      if ( !deferred ) Draw();
   }
}

void
HistogramC::SetShadowType(unsigned char type)
{
   if ( type != shadowType ) {
      shadowType = type;
      if ( !deferred ) Draw();
   }
}

/*----------------------------------------------------------------------
 * Method to set the width of the buckets
 */

void
HistogramC::SetBucketWidth(const ValueC width)
{
   if ( (float)width != bucketWidth ) {
      bucketWidth = width;
      RefillBuckets();
      if ( !deferred ) Draw();
   }
}

/*----------------------------------------------------------------------
 * Method to set the count values
 */

void
HistogramC::SetBuckets(const IntListC& counts, const StringListC& labels)
{
   userBuckets = True;

//
// Copy values
//
   unsigned	bcount = counts.size();
   if ( bcount != labels.size() ) {
      bcount = MIN(bcount, labels.size());
      bucketList.removeAll();
      labelList.removeAll();
      for (int i=0; i<bcount; i++) {
	 bucketList.append(*counts[i]);
	 labelList.append(*labels[i]);
      }
   } else {
      labelList = labels;
      bucketList = counts;
   }

//
// Update max count
//
   maxCount = 0;
   for (int i=0; i<bcount; i++) {
      int	count = *counts[i];
      if ( count > maxCount ) maxCount = count;
   }

//
// Update min count if necessary
//
   if ( compress ) {
      minCount = maxCount;
      for (int i=0; i<bcount; i++) {
	 int	count = *(bucketList[i]);
	 if ( count < minCount ) minCount = count;
      }
   } else {
      minCount = 0;
   }

   if ( maxCount != minCount ) countRangeInv = 1.0/(maxCount - minCount);
   else			       countRangeInv = 1.0;

//
// Update the visible range
//
   if ( visCount > 0 ) {
      minIndex = maxIndex - visCount + 1;
      if ( minIndex < 0 ) {
	 minIndex = 0;
	 maxIndex = minIndex + visCount - 1;
	 if ( maxIndex >= bcount ) maxIndex = bcount - 1;
      }
   } else {
      minIndex = 0;
      maxIndex = bcount - 1;
   }

   if ( !deferred ) Draw();

} // End HistogramC SetBuckets

/*----------------------------------------------------------------------
 * Methods to set the requested color
 */

void
HistogramC::SetColor(HistogramC::HistogramColorAttr attr, Pixel color)
{
   if ( colors[attr] == color ) return;

   colors[attr]	    = color;
   colorNames[attr] = ColorName(da, color);

   switch (attr) {

      case (BACKGROUND):
	 XtVaSetValues(da, XmNbackground, color, NULL);

      default:
	 if ( !deferred ) Draw();
	 break;

   } // End switch color attribute
}

void
HistogramC::SetColor(HistogramC::HistogramColorAttr attr, const char *name)
{
   Pixel	color;
   if ( PixelValue(da, name, &color) ) SetColor(attr, color);
}

/*----------------------------------------------------------------------
 * Method to set whether the '0' count value is displayed
 */

void
HistogramC::SetCountCompress(Boolean comp)
{
   if ( comp != compress ) {
      compress = comp;
      if ( compress ) {
	 minCount = maxCount;
	 unsigned	bcount = bucketList.size();
	 for (int i=0; i<bcount; i++) {
	    int	count = *(bucketList[i]);
	    if ( count < minCount ) minCount = count;
	 }
      } else {
	 minCount = 0;
      }

      if ( maxCount != minCount ) countRangeInv = 1.0/(maxCount - minCount);
      else			  countRangeInv = 1.0;

      if ( !deferred ) Draw();
   }

} // End HistogramC SetCountCompress

/*----------------------------------------------------------------------
 * Method to set marks on the count and value axes
 */

void
HistogramC::SetCountMarks(const IntListC& list)
{
   countMarkList = list;
   if ( !deferred ) Draw();
}

void
HistogramC::SetValueMarks(const FloatListC& list)
{
   valueMarkList = list;
   if ( !deferred ) Draw();
}

void
HistogramC::SetValueMarks(const IntListC& list)
{
   valueMarkList.removeAll();
   unsigned	count = list.size();
   for (int i=0; i<count; i++) {
      float	fval = *list[i];
      valueMarkList.append(fval);
   }

   if ( !deferred ) Draw();
}

/*----------------------------------------------------------------------
 * Methods to set the major and minor tick spacings
 */

void
HistogramC::SetCountTickSpacing(int maj, int min)
{
   if ( maj != majorCountTickSpace || min != minorCountTickSpace ) {
      majorCountTickSpace = maj;
      minorCountTickSpace = min;
      if ( !deferred ) Draw();
   }
}

void
HistogramC::SetValueTickSpacing(const ValueC maj, const ValueC min)
{
   if ( (float)maj != majorValueTickSpace ||
	(float)min != minorValueTickSpace ) {
      majorValueTickSpace = maj;
      minorValueTickSpace = min;
      if ( !deferred ) Draw();
   }
}

/*----------------------------------------------------------------------
 * Methods to set the major and minor grid visibilities
 */

void
HistogramC::SetGridVis(Boolean maj, Boolean min)
{
   if ( maj != majorGridVis || min != minorGridVis ) {
      majorGridVis = maj;
      minorGridVis = min;
      if ( !deferred ) Draw();
   }
}

/*----------------------------------------------------------------------
 * Method to set the spacing between labels and the histogram
 */

void
HistogramC::SetLabelOffset(int offset)
{
   if ( offset != labelOffset ) {
      labelOffset = offset;
      if ( !deferred ) Draw();
   }
}

/*----------------------------------------------------------------------
 * Method to set the margin width and height
 */

void
HistogramC::SetMargins(Dimension wd, Dimension ht)
{
   if ( wd != marginWd || ht != marginHt ) {
      marginWd = wd;
      marginHt = ht;
      if ( !deferred ) Draw();
   }

   return;
}

/*----------------------------------------------------------------------
 * Method to set the maximum number of stored values
 */

void
HistogramC::SetMaximumValueCount(unsigned count)
{
   if ( count == maxValues ) return;

   maxValues = count;
   if ( maxValues < 1 ) return;

//
// Remove extra values if necessary
//
   if ( !userBuckets && valueList.size() > maxValues ) {
      while ( valueList.size() > maxValues ) valueList.remove((unsigned)0);
      RefillBuckets();
      if ( !deferred ) Draw();
   }

} // End StripChartC SetMaximumValueCount

/*----------------------------------------------------------------------
 * Method to set the orientation
 */

void
HistogramC::SetOrientation(unsigned char orient)
{
   if ( (orient != XmVERTICAL && orient != XmHORIZONTAL) ||
	orient == orientation ) return;

   orientation = orient;

//
// Set up the scroll bar
//
   WArgList	args;
   if ( orientation == XmHORIZONTAL ) {

      args.Orientation(XmHORIZONTAL);
      args.LeftAttachment(XmATTACH_FORM);
      args.RightAttachment(XmATTACH_FORM);
      args.TopAttachment(XmATTACH_NONE);
      args.BottomAttachment(XmATTACH_FORM);
      args.Height(scrollBarSpan);
      XtSetValues(scrollBar, ARGS);

      args.Reset();
      if ( visCount < 1 ) args.BottomAttachment(XmATTACH_FORM);
      else		  args.BottomAttachment(XmATTACH_WIDGET, scrollBar);
      args.LeftAttachment(XmATTACH_FORM, 0);
      args.RightAttachment(XmATTACH_FORM, 0);
      args.TopAttachment(XmATTACH_FORM, 0);
      XtSetValues(da, ARGS);

   } else {

      args.Orientation(XmVERTICAL);
      args.LeftAttachment(XmATTACH_FORM);
      args.RightAttachment(XmATTACH_NONE);
      args.TopAttachment(XmATTACH_FORM);
      args.BottomAttachment(XmATTACH_FORM);
      args.Width(scrollBarSpan);
      XtSetValues(scrollBar, ARGS);

      args.Reset();
      if ( visCount < 1 ) args.LeftAttachment(XmATTACH_FORM);
      else		  args.LeftAttachment(XmATTACH_WIDGET, scrollBar);
      args.RightAttachment(XmATTACH_FORM, 0);
      args.TopAttachment(XmATTACH_FORM, 0);
      args.BottomAttachment(XmATTACH_FORM, 0);
      XtSetValues(da, ARGS);

   } // End if vertical orientation

   if ( visCount < 1 ) XtUnmanageChild(scrollBar);

   if ( !deferred ) Draw();

} // End HistogramC SetOrientation

/*----------------------------------------------------------------------
 * Methods to set the numeric output formats
 */

void
HistogramC::SetCountFormat(ValueC::ValueFormat newFormat)
{
   if ( newFormat == ValueC::FLOAT ) return;

   if ( newFormat != countFormat.Format() ) {
      countFormat.SetFormat(newFormat);
      if ( !deferred ) Draw();
   }
}

void
HistogramC::SetValueFormat(ValueC::ValueFormat newFormat)
{
   if ( newFormat != valueFormat.Format() ) {
      valueFormat.SetFormat(newFormat);
      if ( !deferred ) Draw();
   }
}

/*----------------------------------------------------------------------
 * Method to set the major and minor tick lengths
 */

void
HistogramC::SetTickLength(int maj, int min)
{
   if ( maj != majorTickLen || min != minorTickLen ) {
      majorTickLen = maj;
      minorTickLen = min;
      if ( !deferred ) Draw();
   }
}

/*----------------------------------------------------------------------
 * Method to set the number of decimal points for the value axis
 */

void
HistogramC::SetValuePrecision(int precis)
{
   if ( precis != valueFormat.Precision() ) {
      valueFormat.SetPrecision(precis);
      if ( !deferred ) Draw();
   }
}

/*----------------------------------------------------------------------
 * Methods to set the sample values
 */

void
HistogramC::SetValues(const IntListC& values)
{
   userBuckets = False;

   valueList.removeAll();
   unsigned	count = values.size();

//
// Copy only as many as we can save
//
   int	i;
   if ( count > maxValues ) i = count - maxValues;
   else                     i = 0;

//
// Copy values
//
   for (; i<count; i++) {
      float	fval = *values[i];
      valueList.append(fval);
   }

   RefillBuckets();
   if ( !deferred ) Draw();
}

void
HistogramC::SetValues(const FloatListC& values)
{
   userBuckets = False;

   valueList.removeAll();
   unsigned	count = values.size();

//
// Copy only as many as we can save
//
   int	i;
   if ( count > maxValues ) i = count - maxValues;
   else                     i = 0;

//
// Copy values
//
   for (; i<count; i++) valueList.append(*values[i]);

   RefillBuckets();
   if ( !deferred ) Draw();
}

/*----------------------------------------------------------------------
 * Method to set the number of visible buckets
 */

void
HistogramC::SetVisibleBucketCount(unsigned count)
{
   if ( count != visCount ) {
      visCount = count;

      if ( visCount > 0 && visCount < bucketList.size() ) {
	 minIndex = maxIndex - visCount + 1;
	 if ( minIndex < 0 ) {
	    minIndex = 0;
	    maxIndex = minIndex + visCount - 1;
	 }
      } else {
	 minIndex = 0;
	 maxIndex = bucketList.size() - 1;
	 if ( maxIndex < 0 ) maxIndex = 0;
      }

//
// Turn off the scroll bar if all values are visible
//
      WArgList	args;
      if ( visCount < 1 ) {
	 args.Reset();
	 if ( orientation == XmVERTICAL )
	    args.LeftAttachment  (XmATTACH_FORM);
	 else
	    args.BottomAttachment(XmATTACH_FORM);
	 XtSetValues(da, ARGS);
	 XtUnmanageChild(scrollBar);
      } else {
	 XtManageChild(scrollBar);
	 args.Reset();
	 if ( orientation == XmVERTICAL )
	    args.LeftAttachment  (XmATTACH_WIDGET, scrollBar);
	 else
	    args.BottomAttachment(XmATTACH_WIDGET, scrollBar);
	 XtSetValues(da, ARGS);
      }

      if ( !deferred ) Draw();
   }

} // End HistogramC SetVisibleBucketCount

/*----------------------------------------------------------------------
 * Method to return the requested pixel value
 */

Pixel
HistogramC::GetColor(HistogramC::HistogramColorAttr attr) const
{
   return colors[attr];
}

/*----------------------------------------------------------------------
 * Method to return the requested color name
 */

StringC
HistogramC::GetColorName(HistogramC::HistogramColorAttr attr) const
{
   return colorNames[attr];
}

/*-----------------------------------------------------------------------
 *  Methods to return the major and minor tick spacings
 */

void
HistogramC::GetCountTickSpacing(StringC *maj, StringC *min) const
{
   ValueC	tmp(countFormat);
   tmp = majorCountTickSpace;
   *maj = (StringC)tmp;
   tmp = minorCountTickSpace;
   *min = (StringC)tmp;
}

void
HistogramC::GetCountTickSpacing(int *maj, int *min) const
{
   *maj = majorCountTickSpace;
   *min = minorCountTickSpace;
}

void
HistogramC::GetValueTickSpacing(ValueC *maj, ValueC *min) const
{
   *maj = majorValueTickSpace;
   *min = minorValueTickSpace;
}

void
HistogramC::GetValueTickSpacing(StringC *maj, StringC *min) const
{
   ValueC	tmp(valueFormat);
   tmp = majorValueTickSpace;
   *maj = (StringC)tmp;
   tmp = minorValueTickSpace;
   *min = (StringC)tmp;
}

void
HistogramC::GetValueTickSpacing(int *maj, int *min) const
{
   *maj = (int)majorValueTickSpace;
   *min = (int)minorValueTickSpace;
}

/*-----------------------------------------------------------------------
 *  Methods to return the major and minor grid visibilities
 */

void
HistogramC::GetGridVis(Boolean *maj, Boolean *min) const
{
   *maj = majorGridVis;
   *min = minorGridVis;
}

/*----------------------------------------------------------------------
 * Method to return the margin width and height
 */

void
HistogramC::GetMargins(Dimension *wd, Dimension *ht) const
{
   *wd = marginWd;
   *ht = marginHt;
   return;
}

/*-----------------------------------------------------------------------
 *  Method to return the major and minor tick lengths
 */

void
HistogramC::GetTickLength(int *maj, int *min) const
{
   *maj = majorTickLen;
   *min = minorTickLen;
}

/*----------------------------------------------------------------------
 * Method to copy the attributes of another histogram
 */

HistogramC&
HistogramC::operator=(const HistogramC& that)
{
   marginWd            = that.marginWd;
   marginHt            = that.marginHt;
   shadowType          = that.shadowType;
   shadowThickness     = that.shadowThickness;
   barShadowType       = that.barShadowType;
   barShadowThickness  = that.barShadowThickness;
   compress            = that.compress;
   labelOffset         = that.labelOffset;
   majorTickLen	       = that.majorTickLen;
   minorTickLen	       = that.minorTickLen;
   majorCountTickSpace = that.majorCountTickSpace;
   minorCountTickSpace = that.minorCountTickSpace;
   majorValueTickSpace = that.majorValueTickSpace;
   minorValueTickSpace = that.minorValueTickSpace;
   majorGridVis	       = that.majorGridVis;
   minorGridVis	       = that.minorGridVis;
   countFormat	       = that.countFormat;
   valueFormat	       = that.valueFormat;
   scrollBarSpan       = that.scrollBarSpan;

   Defer(True);
   SetBucketWidth(that.bucketWidth);
   SetVisibleBucketCount(that.visCount);
   SetMaximumValueCount(that.maxValues);
   SetOrientation(that.orientation);
   Defer(False);

   for (int i=0; i<COLOR_ATTR_COUNT; i++) {
      colors[i]	    = that.colors[i];
      colorNames[i] = that.colorNames[i];
   }
   XtVaSetValues(da, XmNbackground, colors[BACKGROUND], NULL);

   if ( !deferred ) Draw();

   return *this;

} // End HistogramC operator=

/*----------------------------------------------------------------------
 * Method to write resources to a file
 */

void
HistogramC::Write(FILE *fp, const char *prefix)
{
//
// Create next level prefix
//
   StringC	prefix2 = prefix; prefix2 += "\t";

//
// Write data
//
   fprintf(fp, "%s{HISTOGRAM\n", prefix);

   WriteResource(fp, prefix2 + "background",	colorNames[BACKGROUND]);
   WriteResource(fp, prefix2 + "chartColor",	colorNames[CHART_COLOR]);
   WriteResource(fp, prefix2 + "barColor",	colorNames[BAR_COLOR]);
   WriteResource(fp, prefix2 + "barBorderColor",colorNames[BAR_BORDER_COLOR]);
   WriteResource(fp, prefix2 + "axisColor",	colorNames[AXIS_COLOR]);
   WriteResource(fp, prefix2 + "labelColor",	colorNames[LABEL_COLOR]);
   WriteResource(fp, prefix2 + "tickColor",	colorNames[TICK_COLOR]);
   WriteResource(fp, prefix2 + "gridColor",	colorNames[GRID_COLOR]);
   WriteResource(fp, prefix2 + "markColor",	colorNames[MARK_COLOR]);
   WriteResource(fp, prefix2 + "topShadowColor",colorNames[TOP_SHADOW]);
   WriteResource(fp, prefix2 + "bottomShadowColor",colorNames[BOTTOM_SHADOW]);
   WriteResource(fp, prefix2 + "barTopShadowColor",colorNames[BAR_TOP_SHADOW]);
   WriteResource(fp, prefix2 + "barBottomShadowColor",
						colorNames[BAR_BOTTOM_SHADOW]);

   WriteOrientation(fp, prefix2 + "orientation",	orientation);
   WriteResource  (fp, prefix2 + "countFormat",	countFormat.FormatName());
   WriteResource  (fp, prefix2 + "valueFormat",	valueFormat.FormatName());
   WriteResource  (fp, prefix2 + "decimalPlaces",valueFormat.Precision());
   WriteResource  (fp, prefix2 + "countMarks",		countMarkList);
   WriteResource  (fp, prefix2 + "valueMarks",		valueMarkList);
//   WriteResource  (fp, prefix2 + "font",		fontName);
   WriteShadowType(fp, prefix2 + "shadowType",		shadowType);
   WriteResource  (fp, prefix2 + "shadowThickness",	shadowThickness);
   WriteShadowType(fp, prefix2 + "barshadowType",	barShadowType);
   WriteResource  (fp, prefix2 + "barshadowThickness",	barShadowThickness);
   WriteResource  (fp, prefix2 + "bucketWidth",		bucketWidth);
   WriteResource  (fp, prefix2 + "compressCountRange",	compress);
   WriteResource  (fp, prefix2 + "majorTickLength",	majorTickLen);
   WriteResource  (fp, prefix2 + "minorTickLength",	minorTickLen);
   WriteResource  (fp, prefix2 + "majorCountTickSpacing",majorCountTickSpace);
   WriteResource  (fp, prefix2 + "minorCountTickSpacing",minorCountTickSpace);
   WriteResource  (fp, prefix2 + "majorValueTickSpacing",majorValueTickSpace);
   WriteResource  (fp, prefix2 + "minorValueTickSpacing",minorValueTickSpace);
   WriteResource  (fp, prefix2 + "majorGridVisible",	majorGridVis);
   WriteResource  (fp, prefix2 + "minorGridVisible",	minorGridVis);
   WriteResource  (fp, prefix2 + "visibleBucketCount",	visCount);
   WriteResource  (fp, prefix2 + "maximumValueCount",	maxValues);
   WriteResource  (fp, prefix2 + "labelOffset",		labelOffset);
   WriteResource  (fp, prefix2 + "marginWidth",		marginWd);
   WriteResource  (fp, prefix2 + "marginHeight",	marginHt);
   WriteResource  (fp, prefix2 + "scrollBarThickness",	scrollBarSpan);

   fprintf(fp, "%sHISTOGRAM}\n", prefix);

} // End HistogramC Write

/*----------------------------------------------------------------------
 * Method to read resources from a file
 */

int
HistogramC::Read(FILE *fp, WorkingBoxC *wb)
{
   StringC		line;
   static RegexC	*pair = NULL;
   static RegexC	*end  = NULL;

   if ( !pair ) {
      end  = new RegexC("[ \t]*HISTOGRAM}[ \t]*$");
      pair = new RegexC("[ \t]*\\([^:]+\\):[ \t]*\\(.*\\)");  // rsrc: val
   }

//
// Read resources until next "}" line
//
   StringListC	rsrcList;
   StringListC	valueList;
   rsrcList.AllowDuplicates(TRUE);
   valueList.AllowDuplicates(TRUE);

   line.Clear();
   int	status = line.GetLine(fp);
   while ( status != EOF && !end->match(line) && (!wb || !wb->Cancelled()) ) {

      if ( pair->match(line) ) {
	 StringC	tmp = line((*pair)[1]);
	 tmp.toLower();
	 rsrcList.append(tmp);
	 tmp = line((*pair)[2]);
	 valueList.append(tmp);
      }

      line.Clear();
      status = line.GetLine(fp);
   }

//
// Extract resources from resource string
//
   Defer(True);
   while ( rsrcList.size() > 0 && (!wb || !wb->Cancelled()) ) {

      StringC	*rsrc  = rsrcList[0];
      StringC	*value = valueList[0];

      if      ( *rsrc == "background"       ) SetColor(BACKGROUND,     *value);
      else if ( *rsrc == "chartcolor"       ) SetColor(CHART_COLOR,    *value);
      else if ( *rsrc == "barcolor"         ) SetColor(BAR_COLOR,      *value);
      else if ( *rsrc == "barbordercolor"   ) SetColor(BAR_BORDER_COLOR,*value);
      else if ( *rsrc == "axiscolor"        ) SetColor(AXIS_COLOR,     *value);
      else if ( *rsrc == "labelcolor"       ) SetColor(LABEL_COLOR,    *value);
      else if ( *rsrc == "tickcolor"        ) SetColor(TICK_COLOR,     *value);
      else if ( *rsrc == "gridcolor"        ) SetColor(GRID_COLOR,     *value);
      else if ( *rsrc == "markcolor"        ) SetColor(MARK_COLOR,     *value);
      else if ( *rsrc == "topshadowcolor"   ) SetColor(TOP_SHADOW,     *value);
      else if ( *rsrc == "bottomshadowcolor") SetColor(BOTTOM_SHADOW,  *value);
      else if ( *rsrc == "bartopshadowcolor") SetColor(BAR_TOP_SHADOW, *value);
      else if ( *rsrc == "barbottomshadowcolor" )
					   SetColor(BAR_BOTTOM_SHADOW,  *value);
 
      else if ( *rsrc == "orientation" ) {

	 XrmValue	from, to;
	 unsigned char	result;
	 from.addr = (XPointer)(char *)*value;
	 from.size = strlen(*value) + 1;
	 to.addr	= (XPointer)&result;
	 to.size	= sizeof(unsigned char);
	 if ( XtConvertAndStore(da, XmRString, &from, XtROrientation, &to) )
            SetOrientation(result);
      }

      else if ( *rsrc == "countformat" ) {
	 value->toLower();
	 if ( *value != "float" ) countFormat.SetFormat(*value);
      }

      else if (*rsrc == "valueformat"  ) valueFormat.SetFormat(*value);
      else if (*rsrc == "decimalplaces") valueFormat.SetPrecision(atoi(*value));

      else if ( *rsrc == "countmarks" ) {

	 static RegexC	*word = NULL;
	 if ( !word ) word = new RegexC("[^ \t]+");

	 countMarkList.removeAll();
	 while ( word->search(*value) >= 0 ) {
	    int	countMark = atoi((*value)((*word)[0]));
	    countMarkList.append(countMark);
	    (*value)((*word)[0]) = "";
	 }
      }

      else if ( *rsrc == "valuemarks" ) {

	 static RegexC	*word = NULL;
	 if ( !word ) word = new RegexC("[^ \t]+");

	 valueMarkList.removeAll();
	 while ( word->search(*value) >= 0 ) {
	    float	valueMark = atof((*value)((*word)[0]));
	    valueMarkList.append(valueMark);
	    (*value)((*word)[0]) = "";
	 }
      }

//      else if ( *rsrc == "font"         ) fontName = *value;

      else if ( *rsrc == "shadowtype" || *rsrc == "barshadowtype" ) {

	 XrmValue	from, to;
	 unsigned char	result;
	 from.addr = (XPointer)(char *)*value;
	 from.size = strlen(*value) + 1;
	 to.addr	= (XPointer)&result;
	 to.size	= sizeof(unsigned char);
	 if ( XtConvertAndStore(da, XmRString, &from, XmRShadowType, &to) ) {
	    if ( *rsrc == "shadowtype" ) shadowType    = result;
	    else			 barShadowType = result;
         }
      }

      else if ( *rsrc == "shadowthickness"   ) shadowThickness   = atoi(*value);
      else if ( *rsrc == "barshadowthickness") barShadowThickness= atoi(*value);
      else if ( *rsrc == "bucketwidth"       ) SetBucketWidth(atof(*value));
      else if ( *rsrc == "majorticklength"   ) majorTickLen      = atoi(*value);
      else if ( *rsrc == "minorticklength"   ) minorTickLen      = atoi(*value);

      else if ( *rsrc == "majorcounttickspacing" )
					     majorCountTickSpace = atoi(*value);
      else if ( *rsrc == "minorcounttickspacing" )
					     minorCountTickSpace = atoi(*value);
      else if ( *rsrc == "majorvaluetickspacing" )
					     majorValueTickSpace = atof(*value);
      else if ( *rsrc == "minorvaluetickspacing" )
					     minorValueTickSpace = atof(*value);

      else if ( *rsrc == "visiblebucketcount" )
					    SetVisibleBucketCount(atoi(*value));
      else if ( *rsrc == "maximumvaluecount" )
					    SetMaximumValueCount(atoi(*value));
      else if ( *rsrc == "labeloffset"       ) labelOffset       = atoi(*value);
      else if ( *rsrc == "marginwidth"       ) marginWd          = atoi(*value);
      else if ( *rsrc == "marginheight"      ) marginHt          = atoi(*value);
      else if ( *rsrc == "scrollbarthickness") scrollBarSpan     = atoi(*value);

      else if ( *rsrc == "compresscountrange" ||
	        *rsrc == "majorgridvisible" || *rsrc == "minorgridvisible" ) {

	 XrmValue	from, to;
	 Boolean	result;
	 from.addr = (XPointer)(char *)*value;
	 from.size = value->size() + 1;
	 to.addr   = (XPointer)&result;
	 to.size   = sizeof(Boolean);
	 if ( XtConvertAndStore(da, XtRString, &from, XtRBoolean, &to) ) {
	    if      ( *rsrc == "compresscountrange" ) SetCountCompress(result);
	    else if ( *rsrc == "majorgridvisible"   ) majorGridVis = result;
	    else				      minorGridVis = result;
	 }

      } // End if boolean resource

//
// Remove current entry
//
      rsrcList.remove((int)0);
      valueList.remove((int)0);
   }

   Defer(False);
   return status;

} // End HistogramC Read
