/*
 * $Id: DoubleListC.h,v 1.1 1998/06/24 01:29:07 lang Exp $
 *
 * Copyright (c) 1992 HaL Computer Systems, Inc.  All rights reserved.
 * 
 *          HAL COMPUTER SYSTEMS INTERNATIONAL, LTD.
 *                  1315 Dell Avenue
 *                  Campbell, CA  95008
 *
 * Author: Greg Hilton
 * Contributors: Tom Lang, Frank Bieser, and others
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * http://www.gnu.org/copyleft/gpl.html
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#ifndef _DoubleListC_h_
#define _DoubleListC_h_

#include "StringListC.h"
#include "WArgList.h"

class DoubleListC {

   Widget	mainForm;

   Widget	list1Box;
   Widget	list1Title;
   Widget	rightArrow;
   Widget	leftArrow;
   Widget	list2Box;
   Widget	list2Title;

   int list1count;
   int list2count;

   int list1SelCount;
   int list2SelCount;

   StringListC list1selected;
   StringListC list2selected;

   StringListC list1strs;
   StringListC list2strs;

// Callback functions

   static void		DoMoveRight(Widget, DoubleListC *, XtPointer);
   static void		DoMoveLeft (Widget, DoubleListC *, XtPointer);
   static void	DoList1Selection(Widget,DoubleListC *,XmListCallbackStruct*);
   static void	DoList2Selection(Widget,DoubleListC *,XmListCallbackStruct*);

// Constructor helper function
   void			Build(Widget, const StringC&);

   void		SetList(Widget, const StringListC&);
   StringListC&	GetList(Widget, StringListC&);

public:

// Methods

   inline DoubleListC(Widget parent, const StringC& name) {
      Build(parent, name);
   };
   inline DoubleListC(Widget parent, const char *name) {
      StringC	tmp(name);
      Build(parent, tmp);
   };

   virtual ~DoubleListC();

   void		Clear();
   void		SetList1(const StringListC&);
   void		SetList2(const StringListC&);
   StringListC&	GetList1(StringListC&);
   StringListC&	GetList2(StringListC&);
   void		MoveToList1(StringC&);
   void		MoveToList2(StringC&);
   void		DeleteFromLists(StringC&);
   void		AddToList1(StringC&);
   void		AddToList2(StringC&);

   StringListC& List1Strs() {return (list1strs); };
   StringListC& List2Strs() {return (list2strs); };

   inline void	Set(const WArgList& args) { XtSetValues(mainForm, ARGS); }

   MEMBER_QUERY(Widget, List1Box, list1Box)
   MEMBER_QUERY(Widget, List1Title, list1Title)
   MEMBER_QUERY(Widget, List2Box, list2Box)
   MEMBER_QUERY(Widget, List2Title, list2Title)
   MEMBER_QUERY(Widget, RightArrow, rightArrow)
   MEMBER_QUERY(Widget, LeftArrow, leftArrow)
};

#endif // _DoubleListC_h_


