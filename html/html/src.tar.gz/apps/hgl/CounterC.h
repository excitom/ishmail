/*
 * $Id: CounterC.h,v 1.1 1998/06/24 01:29:07 lang Exp $
 *
 * Copyright (c) 1993 HAL Computer Systems International, Ltd.
 * 
 *          HAL COMPUTER SYSTEMS INTERNATIONAL, LTD.
 *                  1315 Dell Avenue
 *                  Campbell, CA  95008
 *
 * Author: Greg Hilton
 * Contributors: Tom Lang, Frank Bieser, and others
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * http://www.gnu.org/copyleft/gpl.html
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#ifndef _CounterC_h_
#define _CounterC_h_

#include "GraphC.h"
#include "ValueC.h"
#include "StringC.h"

#include <Xm/Xm.h>

class MatrixC;
class WorkingBoxC;

//----------------------------------------------------------------------------
// Class definition

class CounterC : public GraphC {

public:

   enum CounterColorAttr {
      BACKGROUND = 0,
      DIGIT_BG,
      DIGIT_FG,
      TOP_SHADOW,
      BOTTOM_SHADOW,
      COLOR_ATTR_COUNT
   };

protected:

   friend class CounterModC;

// Number of segments in COUNTER digit

   enum SegmentCount {
      SEGMENT_COUNT = 9
   };

//
// Drawing attributes
//
   Pixel		colors[COLOR_ATTR_COUNT];
   StringC		colorNames[COLOR_ATTR_COUNT];
   unsigned char	shadowType;
   Dimension		shadowThickness;
   int			digitCount;
   int			prefHt;
   static Boolean	segmentTable[128][SEGMENT_COUNT];
   ValueC		value;

//
// Private methods
//
   void			DrawDigit(char, const MatrixC&);
   void			DrawSegment(int, const MatrixC&);

public:

//
// Constructor and destructor
//
   CounterC(Widget par, const char *name, ArgList argv=NULL, Cardinal argc=0);

//
// Assignment from another counter
//
   CounterC&		operator=(const CounterC&);

//
// Read from and write to a file
//
   int			Read(FILE*, WorkingBoxC *wb=NULL);
   void			Write(FILE*, const char *prefix="");

//
// Methods to modify the counter
//
   void			Draw();
   void			SetColor(CounterC::CounterColorAttr, Pixel);
   void			SetColor(CounterC::CounterColorAttr, const char *);
   void			SetDigitCount(int);
   void			SetDigitHeight(int);
   void			SetOutputFormat(ValueC::ValueFormat);
   void			SetPrecision(int);
   void			SetShadowThickness(Dimension);
   void			SetShadowType(unsigned char);
   void			SetValue(const ValueC);

//
// Methods to query the counter
//
   MEMBER_QUERY(int,			DigitCount,	digitCount)
   MEMBER_QUERY(int,			DigitHeight,	prefHt)
   MEMBER_QUERY(int,			Precision,	value.Precision())
   MEMBER_QUERY(Dimension,		ShadowThickness, shadowThickness)
   MEMBER_QUERY(unsigned char,		ShadowType,	shadowType)
   MEMBER_QUERY(float,			Value,		value)
   MEMBER_QUERY(StringC,		ValueString,	value)
   MEMBER_QUERY(ValueC::ValueFormat,	OutputFormat,	value.Format())

   Pixel		GetColor    (CounterC::CounterColorAttr) const;
   StringC		GetColorName(CounterC::CounterColorAttr) const;
   inline GraphType	Type() const { return COUNTER_GRAPH; }
};

#endif // _CounterC_h_
