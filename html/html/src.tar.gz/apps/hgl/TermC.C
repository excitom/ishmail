/*
 * $Id: TermC.C,v 1.1 1998/06/24 01:29:07 lang Exp $
 *
 * Copyright (c) 1992 HaL Computer Systems, Inc.  All rights reserved.
 * 
 *          HAL COMPUTER SYSTEMS INTERNATIONAL, LTD.
 *                  1315 Dell Avenue
 *                  Campbell, CA  95008
 *
 * Author: Greg Hilton
 * Contributors: Tom Lang, Frank Bieser, and others
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * http://www.gnu.org/copyleft/gpl.html
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#include "HalAppC.h" 
#include "TermC.h"
#include "WArgList.h"
#include "rsrc.h"
#include "RegexC.h"
#include "IntListC.h"
#include "SysErr.h"

#include <X11/keysym.h>
#include <X11/cursorfont.h>
#include <X11/Xatom.h>
#include <X11/Xmu/Atoms.h>
#include <X11/Xmu/StdSel.h>
#include <X11/Xmu/CharSet.h>

#include <Xm/Form.h>
#include <Xm/ScrollBar.h>
#include <Xm/Frame.h>
#include <Xm/DrawingA.h>
#include <Xm/RowColumn.h>
#include <Xm/ToggleB.h>
#include <Xm/PushB.h>
#include <Xm/Separator.h>

#include <memory.h>
#include <fcntl.h>
#include <signal.h>
#include <unistd.h>
#include <stdio.h>
#include <errno.h>
#include <termio.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/stat.h>		// For chmod

#if defined LINUX
#   include <sys/ioctl.h>	/* stream ioctls */
#elif defined SUN_OS
#   include <sys/filio.h>
#elif defined SVR4 || defined SOLARIS
#   include <sys/stropts.h>	/* stream ioctls */
#   include <wait.h> 
#endif

#ifdef OSF1
   extern "C" pid_t vfork(void);
#endif

#define MIN_ROWS		2
#define MIN_COLS		8
#define DEFAULT_ROWS		24
#define DEFAULT_COLS		80
#define DEFAULT_SAVE_LINES	64
#define DEFAULT_TABSTOP		8
#define DEFAULT_LINE_SPACING	0
#define DEFAULT_FG_COLOR	BlackPixel(display, DefaultScreen(display))
#define DEFAULT_BG_COLOR	WhitePixel(display, DefaultScreen(display))
#define DEFAULT_CURSOR_COLOR	BlackPixel(display, DefaultScreen(display))
#define BG_INDEX		COLOR_COUNT
#define FG_INDEX		(COLOR_COUNT+1)

static int	zero = 0;

extern int	debuglev;

/*----------------------------------------------------------------------
 * double click table for cut and paste in 8 bits
 *
 * This table is divided in four parts :
 *
 *	- control characters	[0,0x1f] U [0x80,0x9f]
 *	- separators		[0x20,0x3f] U [0xa0,0xb9]
 *	- binding characters	[0x40,0x7f] U [0xc0,0xff]
 *  	- execeptions
 */

int TermC::charClass[256] = {
/* NUL  SOH  STX  ETX  EOT  ENQ  ACK  BEL */
    32,   1,   1,   1,   1,   1,   1,   1,
/*  BS   HT   NL   VT   NP   CR   SO   SI */
     1,  32,   1,   1,   1,   1,   1,   1,
/* DLE  DC1  DC2  DC3  DC4  NAK  SYN  ETB */
     1,   1,   1,   1,   1,   1,   1,   1,
/* CAN   EM  SUB  ESC   FS   GS   RS   US */
     1,   1,   1,   1,   1,   1,   1,   1,
/*  SP    !    "    #    $    %    &    ' */
    32,  33,  34,  35,  36,  37,  38,  39,
/*   (    )    *    +    ,    -    .    / */
    40,  41,  42,  43,  44,  45,  46,  47,
/*   0    1    2    3    4    5    6    7 */
    48,  48,  48,  48,  48,  48,  48,  48,
/*   8    9    :    ;    <    =    >    ? */
    48,  48,  58,  59,  60,  61,  62,  63,
/*   @    A    B    C    D    E    F    G */
    64,  48,  48,  48,  48,  48,  48,  48,
/*   H    I    J    K    L    M    N    O */
    48,  48,  48,  48,  48,  48,  48,  48,
/*   P    Q    R    S    T    U    V    W */ 
    48,  48,  48,  48,  48,  48,  48,  48,
/*   X    Y    Z    [    \    ]    ^    _ */
    48,  48,  48,  91,  92,  93,  94,  48,
/*   `    a    b    c    d    e    f    g */
    96,  48,  48,  48,  48,  48,  48,  48,
/*   h    i    j    k    l    m    n    o */
    48,  48,  48,  48,  48,  48,  48,  48,
/*   p    q    r    s    t    u    v    w */
    48,  48,  48,  48,  48,  48,  48,  48,
/*   x    y    z    {    |    }    ~  DEL */
    48,  48,  48, 123, 124, 125, 126,   1,
/* x80  x81  x82  x83  IND  NEL  SSA  ESA */
     1,   1,   1,   1,   1,   1,   1,   1,
/* HTS  HTJ  VTS  PLD  PLU   RI  SS2  SS3 */
     1,   1,   1,   1,   1,   1,   1,   1,
/* DCS  PU1  PU2  STS  CCH   MW  SPA  EPA */
     1,   1,   1,   1,   1,   1,   1,   1,
/* x98  x99  x9A  CSI   ST  OSC   PM  APC */
     1,   1,   1,   1,   1,   1,   1,   1,
/*   -    i   c/    L   ox   Y-    |   So */
   160, 161, 162, 163, 164, 165, 166, 167,
/*  ..   c0   ip   <<    _        R0    - */
   168, 169, 170, 171, 172, 173, 174, 175,
/*   o   +-    2    3    '    u   q|    . */
   176, 177, 178, 179, 180, 181, 182, 183,
/*   ,    1    2   >>  1/4  1/2  3/4    ? */
   184, 185, 186, 187, 188, 189, 190, 191,
/*  A`   A'   A^   A~   A:   Ao   AE   C, */
    48,  48,  48,  48,  48,  48,  48,  48,
/*  E`   E'   E^   E:   I`   I'   I^   I: */
    48,  48,  48,  48,  48,  48,  48,  48,
/*  D-   N~   O`   O'   O^   O~   O:    X */ 
    48,  48,  48,  48,  48,  48,  48, 216,
/*  O/   U`   U'   U^   U:   Y'    P    B */
    48,  48,  48,  48,  48,  48,  48,  48,
/*  a`   a'   a^   a~   a:   ao   ae   c, */
    48,  48,  48,  48,  48,  48,  48,  48,
/*  e`   e'   e^   e:    i`  i'   i^   i: */
    48,  48,  48,  48,  48,  48,  48,  48,
/*   d   n~   o`   o'   o^   o~   o:   -: */
    48,  48,  48,  48,  48,  48,  48,  248,
/*  o/   u`   u'   u^   u:   y'    P   y: */
    48,  48,  48,  48,  48,  48,  48,  48};

XtActionsRec	TermC::actions[29] = {
   "TermC-bell",			(XtActionProc)HandleBell,
   "TermC-clear-saved-lines",		(XtActionProc)HandleResetClear,
   "TermC-hard-reset",			(XtActionProc)HandleHardReset,
   "TermC-insert-selection",		(XtActionProc)HandleInsertSelection,
   "TermC-popup-menu",			(XtActionProc)HandlePopupMenu,
   "TermC-redraw",			(XtActionProc)HandleRedraw,
   "TermC-scroll-back",			(XtActionProc)HandleScrollBack,
   "TermC-scroll-forw",			(XtActionProc)HandleScrollForw,
   "TermC-select-end",			(XtActionProc)HandleSelectEnd,
   "TermC-select-extend",		(XtActionProc)HandleSelectExtend,
   "TermC-select-start",		(XtActionProc)HandleSelectStart,
   "TermC-send-signal",			(XtActionProc)HandleSendSignal,
   "TermC-set-allow132",		(XtActionProc)HandleSetAllow132,
   "TermC-set-appcursor",		(XtActionProc)HandleSetAppCursor,
   "TermC-set-appkeypad",		(XtActionProc)HandleSetAppKeypad,
   "TermC-set-autowrap",		(XtActionProc)HandleSetAutoWrap,
   "TermC-set-jumpscroll",		(XtActionProc)HandleSetJumpScroll,
   "TermC-set-logging",			(XtActionProc)HandleSetLogging,
   "TermC-set-margin-bell",		(XtActionProc)HandleSetMarginBell,
   "TermC-set-reverse-video",		(XtActionProc)HandleSetReverseVideo,
   "TermC-set-reversewrap",		(XtActionProc)HandleSetReverseWrap,
   "TermC-set-scroll-on-key", 		(XtActionProc)HandleSetScrollOnKey,
   "TermC-set-scroll-on-tty-output",	(XtActionProc)HandleSetScrollOnTty,
   "TermC-set-scrollbar",		(XtActionProc)HandleSetScrollBar,
   "TermC-set-visual-bell",		(XtActionProc)HandleSetVisualBell,
   "TermC-soft-reset",			(XtActionProc)HandleSoftReset,
   "TermC-start-extend",		(XtActionProc)HandleStartExtend,
   "TermC-string",			(XtActionProc)HandleString,
   "TermC-visual-bell",			(XtActionProc)HandleVisualBell,
};

/*----------------------------------------------------------------------
 * Methods to examine TermCharT attributes
 */

inline Boolean
TermC::Inverted(TermCharT attr) {
   return ( (attr.flags&INVERSE) == INVERSE);
}

inline Boolean
TermC::Selected(TermCharT attr) {
   return ( (attr.flags&SELECTED) == SELECTED);
}

inline Boolean	
TermC::Bold(TermCharT attr) {
   return ( (attr.flags&BOLD) == BOLD);
}

inline Boolean
TermC::Underlined(TermCharT attr) {
   return ( (attr.flags&UNDERLINE) == UNDERLINE);
}

inline Boolean	
TermC::Drawn(TermCharT attr) {
   return ( (attr.flags&DRAWN) == DRAWN);
}

inline Pixel
TermC::FgColor(TermCharT attr) {
//
// Return the background color if an odd number of the inverted, selected and
//    reverse video flags is set
//
   return ((Inverted(attr) != Selected(attr)) == flags.reverseVideo) ?
      colors[attr.bg] : colors[attr.fg];
}

inline Pixel
TermC::BgColor(TermCharT attr) {
//
// Return the foreground color if an odd number of the inverted, selected and
//    reverse video flags is set
//
   return ((Inverted(attr) != Selected(attr)) == flags.reverseVideo) ?
      colors[attr.fg] : colors[attr.bg];
}

inline int
TermC::Ascent(TermCharT attr) {
   return (Bold(attr) ? boldFont->ascent : font->ascent);
}

inline Font
TermC::FontId(TermCharT attr) {
   return (Bold(attr) ? boldFont->fid : font->fid);
}

inline Boolean
TermC::AttrEqual(TermCharT a, TermCharT b) {
   return ((a.flags == b.flags) && (a.fg == b.fg) && (a.bg == b.bg));
}

/*----------------------------------------------------------------------
 * Method to initialize character memory
 */

inline void
TermC::FillCharMem(TermCharT *mem, TermCharT val, int count)
{
   for (int i=0; i<count; i++) *mem++ = val;
}

/*----------------------------------------------------------------------
 * Method to build the widget hierarchy
 */

TermC::TermC(Widget parent, const char *name)
{
   WArgList	args;		// Used to set all resources at once

   focusHere	   = False;
   cursorOn	   = False;
   hideCnt	   = 1;		// Initially hidden
   termWin	   = (Window)NULL;
   termPixmap      = (Pixmap)NULL;
   termGC          = NULL;
   deferCopy	   = 0;
   textSelected    = False;
   clickCount      = 0;
   clickTimer      = (XtIntervalId)NULL;
#if 0
   masterFd        = -1;
   slaveFd         = -1;
#endif
   inputFd	   = -1;
   outputFd	   = -1;
   inputId         = (XtInputId)NULL;
   errorId         = (XtInputId)NULL;
   selectStartLine =
   selectEndLine   =
   selectStartCol  =
   selectEndCol    = 0;
   bellActive      = False;
   inputFromUser   = False;
   userInputCalls.AllowDuplicates(TRUE);
   shellExitCalls.AllowDuplicates(TRUE);

//
// Create form
//
   form = XmCreateForm(parent, (char *)name, 0,0);
   XtManageChild(form);

//
// Get the shell parent
//
   topLevel = parent;
   while ( !XtIsTopLevelShell(topLevel) ) {
      topLevel = XtParent(topLevel);
   }
   display = XtDisplay(topLevel);
   context = XtWidgetToApplicationContext(topLevel);

//
// Create scroll bar
//
   args.Reset();
   args.Orientation(XmVERTICAL);
   args.TopAttachment(XmATTACH_FORM);
   args.BottomAttachment(XmATTACH_FORM);
   args.LeftAttachment(XmATTACH_NONE);
   args.RightAttachment(XmATTACH_FORM);
   scrollBar = XmCreateScrollBar(form, "scrollBar", ARGS);
   XtManageChild(scrollBar);

   XtAddCallback(scrollBar, XmNdecrementCallback,
		 (XtCallbackProc)HandleScroll, (XtPointer)this);
   XtAddCallback(scrollBar, XmNincrementCallback,
		 (XtCallbackProc)HandleScroll, (XtPointer)this);
   XtAddCallback(scrollBar, XmNpageDecrementCallback,
		 (XtCallbackProc)HandleScroll, (XtPointer)this);
   XtAddCallback(scrollBar, XmNpageIncrementCallback,
		 (XtCallbackProc)HandleScroll, (XtPointer)this);
   XtAddCallback(scrollBar, XmNtoTopCallback,
		 (XtCallbackProc)HandleScroll, (XtPointer)this);
   XtAddCallback(scrollBar, XmNtoBottomCallback,
		 (XtCallbackProc)HandleScroll, (XtPointer)this);
   XtAddCallback(scrollBar, XmNdragCallback,
		 (XtCallbackProc)HandleScroll, (XtPointer)this);

//
// Create frame around drawing area widget
//
   args.Reset();
   args.TopAttachment(XmATTACH_FORM);
   args.BottomAttachment(XmATTACH_FORM);
   args.LeftAttachment(XmATTACH_FORM);
   args.RightAttachment(XmATTACH_WIDGET, scrollBar);
   args.ShadowType(XmSHADOW_IN);
   args.MarginWidth(0);
   args.MarginHeight(0);
   termFrame = XmCreateFrame(form, "termFrame", ARGS);
   XtManageChild(termFrame);

//
// Add actions if necessary
//
   static Boolean	actionsAdded = False;
   if ( !actionsAdded ) {
      XtAppAddActions(context, actions, XtNumber(actions));
      actionsAdded = True;
   }

//
// Create drawing area widget
//
   static char	*termTrans = "\
		    <Key> Tab   : DrawingAreaInput()\n\
		    <Key> Prior : TermC-scroll-back(1,halfpage)\n\
		    <Key> Next  : TermC-scroll-forw(1,halfpage)\n\
		    <Key> Up    : TermC-scroll-back(1,line)\n\
		    <Key> Down  : TermC-scroll-forw(1,line)\n\
       !Shift       <Btn1Down>  : TermC-start-extend()\n\
       ~Meta ~Shift <Btn1Down>  : TermC-select-start()\n\
       ~Meta        <Btn1Motion>: TermC-select-extend()\n\
       ~Meta ~Shift <Btn1Up>    : TermC-select-end()\n\
       ~Meta ~Shift <Btn2Up>    : TermC-insert-selection()\n\
       !Ctrl        <Btn3Down>  : TermC-popup-menu(vtMenu)\n\
       !Ctrl        <Btn2Down>  : TermC-popup-menu(mainMenu)\n\
       ";

   args.Reset();
   args.UserData(this);
   termArea = XmCreateDrawingArea(termFrame, "termArea", ARGS);
   XtOverrideTranslations(termArea, XtParseTranslationTable(termTrans));
   XtManageChild(termArea);

   XtAddCallback(termArea, XmNexposeCallback, (XtCallbackProc)HandleExpose,
		 (XtPointer)this);
   XtAddCallback(termArea, XmNinputCallback, (XtCallbackProc)HandleInput,
		 (XtPointer)this);
   XtAddCallback(termArea, XmNresizeCallback, (XtCallbackProc)HandleResize,
		 (XtPointer)this);

//
// Read attributes
//
   char	*cl = "TermC";
   tabstop           = get_int(cl, termArea, "tabstop", DEFAULT_TABSTOP);
   lineSpacing       = get_int(cl, termArea, "lineSpacing", DEFAULT_LINE_SPACING);
   sunFKeys          = get_boolean(cl, termArea, "sunFunctionKeys", False);
   bellSuppressTime  = get_int(cl, termArea, "bellSuppressTime", 200);
   charClassDef	     = get_string(cl, termArea, "charClass", "");
   logFile	     = get_string(cl, termArea, "logFile", "TermCLog.XXXXX");
   logInhibit	     = get_boolean(cl, termArea, "logInhibit", False);
   multiClickTime    = get_int(cl, termArea, "multiClickTime", 250);
   marginBellRange   = get_int(cl, termArea, "nMarginBell", 8);
   termCursor        = get_cursor(cl, termArea, "pointerShape", "xterm");
   resizeGravity     = get_gravity(cl, termArea, "resizeGravity", "SouthWest");

   SetCharClasses(charClassDef);

//
// Initialize terminal flags
//
   iflags.allow132	= get_boolean(cl, termArea, "c132",                 False);
   iflags.altScrnOn	= False;
   iflags.appCursor	= get_boolean(cl, termArea, "appcursorDefault",     False);
   iflags.appKeypad	= get_boolean(cl, termArea, "appkeypadDefault",     False);
   iflags.autoRepeat	= get_boolean(cl, termArea, "autoRepeat",           True);
   iflags.autoWrap	= get_boolean(cl, termArea, "autoWrap",             True);
   iflags.cutNewline	= get_boolean(cl, termArea, "cutNewline",           True);
   iflags.cutToLeft	= get_boolean(cl, termArea, "cutToBeginningOfLine", True);
   iflags.fixCurses	= get_boolean(cl, termArea, "curses",               False);
   iflags.hiliteMouse	= False;
   iflags.logging	= get_boolean(cl, termArea, "logging",              False);
   iflags.marginBell	= get_boolean(cl, termArea, "marginBell",           False);
   iflags.originCursor	= get_boolean(cl, termArea, "originCursor",         False);
   iflags.reverseVideo	= get_boolean(cl, termArea, "reverseVideo",         False);
   iflags.reverseWrap	= get_boolean(cl, termArea, "reverseWrap",          False);
   iflags.sendXYonPress	= False;
   iflags.sendXYonRelease = False;
   iflags.smoothScroll	= get_boolean(cl, termArea, "jumpScroll",           False);
   iflags.scrollBarOn	= get_boolean(cl, termArea, "scrollBar",            False);
   iflags.scrollOnTty	= get_boolean(cl, termArea, "scrollTtyOutput",      True);
   iflags.scrollOnKey	= get_boolean(cl, termArea, "scrollKey",            False);
   iflags.signalInhibit	= get_boolean(cl, termArea, "signalInhibit",        False);
   iflags.visualBell	= get_boolean(cl, termArea, "visualBell",           False);
   flags = sflags = iflags;

//
// Create popup menus
//
   args.Reset();
   args.MenuPost("<Btn3Down>");
   vtMenu   = XmCreatePopupMenu(termArea, "vtMenu", ARGS);

   args.MenuPost("Ctrl <Btn3Down>");
   mainMenu = XmCreatePopupMenu(termArea, "mainMenu", ARGS);

//
// Add buttons to main menu
//
   args.Reset();
   args.Set(flags.logging);
   loggingTB = XmCreateToggleButton(mainMenu, "loggingTB", ARGS);
   Widget redrawPB    = XmCreatePushButton(mainMenu, "redrawPB", 0,0);
   Widget mainMenuSep = XmCreateSeparator(mainMenu, "mainMenuSep", 0,0);
   sigStopPB = XmCreatePushButton(mainMenu, "sigStopPB", 0,0);
   sigContPB = XmCreatePushButton(mainMenu, "sigContPB", 0,0);
   sigIntPB  = XmCreatePushButton(mainMenu, "sigIntPB",  0,0);
   sigHupPB  = XmCreatePushButton(mainMenu, "sigHupPB",  0,0);
   sigTermPB = XmCreatePushButton(mainMenu, "sigTermPB", 0,0);
   sigKillPB = XmCreatePushButton(mainMenu, "sigKillPB", 0,0);

   XtAddCallback(loggingTB, XmNvalueChangedCallback, (XtCallbackProc)LoggingCB,
		 (XtPointer)this);
   XtAddCallback(redrawPB, XmNactivateCallback, (XtCallbackProc)RedrawCB,
		 (XtPointer)this);
   XtAddCallback(sigStopPB, XmNactivateCallback, (XtCallbackProc)SigStopCB,
		 (XtPointer)this);
   XtAddCallback(sigContPB, XmNactivateCallback, (XtCallbackProc)SigContCB,
		 (XtPointer)this);
   XtAddCallback(sigIntPB, XmNactivateCallback, (XtCallbackProc)SigIntCB,
		 (XtPointer)this);
   XtAddCallback(sigHupPB, XmNactivateCallback, (XtCallbackProc)SigHupCB,
		 (XtPointer)this);
   XtAddCallback(sigTermPB, XmNactivateCallback, (XtCallbackProc)SigTermCB,
		 (XtPointer)this);
   XtAddCallback(sigKillPB, XmNactivateCallback, (XtCallbackProc)SigKillCB,
		 (XtPointer)this);

   XtManageChild(loggingTB);
   XtManageChild(redrawPB);
   XtManageChild(mainMenuSep);
   XtManageChild(sigStopPB);
   XtManageChild(sigContPB);
   XtManageChild(sigIntPB);
   XtManageChild(sigHupPB);
   XtManageChild(sigTermPB);
   XtManageChild(sigKillPB);

   if ( flags.signalInhibit ) {
      XtSetSensitive(sigStopPB, False);
      XtSetSensitive(sigContPB, False);
      XtSetSensitive(sigIntPB, False);
      XtSetSensitive(sigHupPB, False);
      XtSetSensitive(sigTermPB, False);
      XtSetSensitive(sigKillPB, False);
   }

//
// Add buttons to vt menu
//
   args.Reset();
   args.Set(flags.scrollBarOn);
   scrollBarTB = XmCreateToggleButton(vtMenu, "scrollBarTB", ARGS);
   args.Set(!flags.smoothScroll);
   jumpScrollTB = XmCreateToggleButton(vtMenu, "jumpScrollTB", ARGS);
   args.Set(flags.reverseVideo);
   reverseVideoTB = XmCreateToggleButton(vtMenu, "reverseVideoTB", ARGS);
   args.Set(flags.autoWrap);
   autoWrapTB = XmCreateToggleButton(vtMenu, "autoWrapTB", ARGS);
   args.Set(flags.reverseWrap);
   reverseWrapTB = XmCreateToggleButton(vtMenu, "reverseWrapTB", ARGS);
   args.Set(flags.appCursor);
   appCursorTB = XmCreateToggleButton(vtMenu, "appCursorTB", ARGS);
   args.Set(flags.appKeypad);
   appKeypadTB = XmCreateToggleButton(vtMenu, "appKeypadTB", ARGS);
   args.Set(flags.scrollOnKey);
   scrollOnKeyTB = XmCreateToggleButton(vtMenu, "scrollKeyTB", ARGS);
   args.Set(flags.scrollOnTty);
   scrollOnTtyTB = XmCreateToggleButton(vtMenu, "scrollTtyOutputTB", ARGS);
   args.Set(flags.allow132);
   allow132TB = XmCreateToggleButton(vtMenu, "c132TB", ARGS);
   args.Set(flags.fixCurses);
   fixCursesTB = XmCreateToggleButton(vtMenu, "cursesTB", ARGS);
   args.Set(flags.visualBell);
   visualBellTB = XmCreateToggleButton(vtMenu, "visualBellTB", ARGS);
   args.Set(flags.marginBell);
   marginBellTB = XmCreateToggleButton(vtMenu, "marginBellTB", ARGS);
   args.Set(flags.cutNewline);
   cutNewlineTB = XmCreateToggleButton(vtMenu, "cutNewlineTB", ARGS);
   args.Set(flags.cutToLeft);
   cutToLeftTB = XmCreateToggleButton(vtMenu, "cutToBeginningOfLineTB", ARGS);
   args.Set(flags.signalInhibit);
   signalInhibitTB = XmCreateToggleButton(vtMenu, "signalInhibitTB", ARGS);
   Widget vtMenuSep    = XmCreateSeparator(vtMenu, "vtMenuSep", 0,0);
   Widget softResetPB  = XmCreatePushButton(vtMenu, "softResetPB", 0,0);
   Widget fullResetPB  = XmCreatePushButton(vtMenu, "fullResetPB", 0,0);
   Widget resetClearPB = XmCreatePushButton(vtMenu, "resetClearPB", 0,0);

   XtManageChild(scrollBarTB);
   //XtManageChild(jumpScrollTB);
   XtManageChild(reverseVideoTB);
   XtManageChild(autoWrapTB);
   //XtManageChild(reverseWrapTB);
   XtManageChild(appCursorTB);
   XtManageChild(appKeypadTB);
   XtManageChild(scrollOnKeyTB);
   XtManageChild(scrollOnTtyTB);
   XtManageChild(allow132TB);
   //XtManageChild(fixCursesTB);
   XtManageChild(visualBellTB);
   XtManageChild(marginBellTB);
   XtManageChild(cutNewlineTB);
   XtManageChild(cutToLeftTB);
   XtManageChild(signalInhibitTB);
   XtManageChild(vtMenuSep);
   XtManageChild(softResetPB);
   XtManageChild(fullResetPB);
   XtManageChild(resetClearPB);

   XtAddCallback(scrollBarTB, XmNvalueChangedCallback,
		 (XtCallbackProc)ScrollBarCB, (XtPointer)this);
   XtAddCallback(jumpScrollTB, XmNvalueChangedCallback,
		 (XtCallbackProc)JumpScrollCB, (XtPointer)this);
   XtAddCallback(reverseVideoTB, XmNvalueChangedCallback,
		 (XtCallbackProc)ReverseVideoCB, (XtPointer)this);
   XtAddCallback(autoWrapTB, XmNvalueChangedCallback,
		 (XtCallbackProc)AutoWrapCB, (XtPointer)this);
   XtAddCallback(reverseWrapTB, XmNvalueChangedCallback,
		 (XtCallbackProc)ReverseWrapCB, (XtPointer)this);
   XtAddCallback(appCursorTB, XmNvalueChangedCallback,
		 (XtCallbackProc)AppCursorCB, (XtPointer)this);
   XtAddCallback(appKeypadTB, XmNvalueChangedCallback,
		 (XtCallbackProc)AppKeypadCB, (XtPointer)this);
   XtAddCallback(scrollOnKeyTB, XmNvalueChangedCallback,
		 (XtCallbackProc)ScrollOnKeyCB, (XtPointer)this);
   XtAddCallback(scrollOnTtyTB, XmNvalueChangedCallback,
		 (XtCallbackProc)ScrollOnTtyCB, (XtPointer)this);
   XtAddCallback(allow132TB, XmNvalueChangedCallback,
		 (XtCallbackProc)Allow132CB, (XtPointer)this);
   XtAddCallback(fixCursesTB, XmNvalueChangedCallback,
		 (XtCallbackProc)FixCursesCB, (XtPointer)this);
   XtAddCallback(visualBellTB, XmNvalueChangedCallback,
		 (XtCallbackProc)VisualBellCB, (XtPointer)this);
   XtAddCallback(marginBellTB, XmNvalueChangedCallback,
		 (XtCallbackProc)MarginBellCB, (XtPointer)this);
   XtAddCallback(cutNewlineTB, XmNvalueChangedCallback,
		 (XtCallbackProc)CutNewlineCB, (XtPointer)this);
   XtAddCallback(cutToLeftTB, XmNvalueChangedCallback,
		 (XtCallbackProc)CutToLeftCB, (XtPointer)this);
   XtAddCallback(signalInhibitTB, XmNvalueChangedCallback,
		 (XtCallbackProc)SignalInhibitCB, (XtPointer)this);

   XtAddCallback(softResetPB, XmNactivateCallback, (XtCallbackProc)SoftResetCB,
		 (XtPointer)this);
   XtAddCallback(fullResetPB, XmNactivateCallback, (XtCallbackProc)FullResetCB,
		 (XtPointer)this);
   XtAddCallback(resetClearPB, XmNactivateCallback,(XtCallbackProc)ResetClearCB,
		 (XtPointer)this);

   XtVaGetValues(termArea, XmNmarginWidth, &marginWd, XmNmarginHeight,
		 &marginHt, NULL);

//
// Read colors
//
   fgColor          = get_color(cl, termArea, "foreground", DEFAULT_FG_COLOR);
   bgColor          = get_color(cl, termArea, "background", DEFAULT_BG_COLOR);
   cursorColor      = get_color(cl, termArea, "cursorColor", DEFAULT_CURSOR_COLOR);
   pointerFgColor   = get_color(cl, termArea, "pointerColor", XtDefaultForeground);
   pointerBgColor   = get_color(cl, termArea, "pointerColorBackground",
			        XtDefaultBackground);
   colors[0]        = get_color(cl, termArea, "color0", "Black");
   colors[1]        = get_color(cl, termArea, "color1", "Red");
   colors[2]        = get_color(cl, termArea, "color2", "Green");
   colors[3]        = get_color(cl, termArea, "color3", "Yellow");
   colors[4]        = get_color(cl, termArea, "color4", "Blue");
   colors[5]        = get_color(cl, termArea, "color5", "Magenta");
   colors[6]        = get_color(cl, termArea, "color6", "Cyan");
   colors[7]        = get_color(cl, termArea, "color7", "White");
   colors[BG_INDEX] = bgColor;
   colors[FG_INDEX] = fgColor;

   curAttr.c	 = 0;
   curAttr.flags = DRAWN;
   curAttr.bg	 = BG_INDEX;
   curAttr.fg	 = FG_INDEX;

   initChar	 = curAttr;

//
// Load fonts
//
   StringC	fontName = get_string(cl, termArea, "font", "9x15");
   font = XLoadQueryFont(display, fontName);
   if ( !font ) font = halApp->font;

   fontName = get_string(cl, termArea, "boldFont", "9x15bold");
   boldFont = XLoadQueryFont(display, fontName);
   if ( !boldFont ) boldFont = halApp->font;

//
// Get the maximum character size
//
   charWd = font->max_bounds.rbearing - font->min_bounds.lbearing;
   charHt = font->max_bounds.ascent   + font->max_bounds.descent;
   int	cwd = boldFont->max_bounds.rbearing - boldFont->min_bounds.lbearing;
   int	cht = boldFont->max_bounds.ascent   + boldFont->max_bounds.descent;
   if ( cwd > charWd ) charWd = cwd;
   if ( cht > charHt ) charHt = cht;

//
// Read the number of rows and columns
//
   rowCnt = get_int(cl, termArea, "rows",    DEFAULT_ROWS);
   colCnt = get_int(cl, termArea, "columns", DEFAULT_COLS);
   if ( rowCnt <= MIN_ROWS ) rowCnt = MIN_ROWS;
   if ( colCnt <= MIN_COLS ) colCnt = MIN_COLS;
   allocCols = colCnt;
   sflags.colCnt = colCnt;

//
// Calculate the size of the drawing area
//
   areaWd = (marginWd*2) + (charWd * colCnt);
   areaHt = (marginHt*2) + (charHt * rowCnt) + (lineSpacing * (rowCnt-1));
   XtVaSetValues(termArea, XmNwidth, areaWd, XmNheight, areaHt, NULL);

//
// Set the scale of the scrollbar to correspond to the terminal
//
   XtVaSetValues(scrollBar, XmNminimum, 0, XmNmaximum, rowCnt,
			    XmNsliderSize, rowCnt, XmNvalue, 0, NULL);

   if ( !flags.scrollBarOn ) {
      XtVaSetValues(termFrame, XmNrightAttachment, XmATTACH_FORM, NULL);
      XtUnmanageChild(scrollBar);
   }

//
// Initialize primary screen
//
   regScrn.curLine = regScrn.curCol = 0;
   regScrn.topLine = 0;
   regScrn.botLine = rowCnt - 1;
   regScrn.lineCnt = rowCnt;

//
// Allocate memory for screen
//
   saveLines = get_int(cl, termArea, "saveLines", DEFAULT_SAVE_LINES);
   regScrn.maxLines   =
   regScrn.allocLines = rowCnt + saveLines;
   regScrn.memSize = regScrn.maxLines * colCnt;
   regScrn.charMem = new TermCharT[regScrn.maxLines * colCnt];
   if ( !regScrn.charMem ) {
      cerr <<"TermC: Out of memory" NL;
      exit(1);
   }

//
// Initialize screen memory
//
   FillCharMem(regScrn.charMem, initChar, regScrn.memSize);

//
// Allocate memory for line pointers
//
   regScrn.charLines = new TermCharT*[regScrn.maxLines];
   if ( !regScrn.charLines ) {
      cerr <<"TermC: Out of memory" NL;
      exit(1);
   }

//
// Initialize line pointers
//
   TermCharT	*charMemPtr = regScrn.charMem;
   //cout <<"Regular screen @ " <<hex <<(unsigned)&regScrn <<dec NL;
   //cout <<"Regular lines  @ " <<hex <<(unsigned)regScrn.charLines <<dec NL;
   for (int i=0; i<regScrn.maxLines; i++) {
      regScrn.charLines[i] = charMemPtr;
      //cout <<"   charLines[" <<i <<"] @ " <<hex
	   //<<(unsigned)regScrn.charLines[i] <<dec NL;
      charMemPtr += colCnt;
   }

   regScrn.curCharLine = regScrn.charLines[0];

//
// Initialize alternate screen
//
   altScrn.curLine = altScrn.curCol = 0;
   altScrn.topLine = 0;
   altScrn.botLine = regScrn.botLine;
   altScrn.lineCnt = rowCnt;

//
// Allocate memory for alternate screen
//
   altScrn.maxLines   =
   altScrn.allocLines = rowCnt;
   altScrn.memSize = altScrn.maxLines * colCnt;
   altScrn.charMem = new TermCharT[altScrn.maxLines * colCnt];
   if ( !altScrn.charMem ) {
      cerr <<"TermC: Out of memory" NL;
      exit(1);
   }

//
// Initialize screen memory
//
   FillCharMem(altScrn.charMem, initChar, altScrn.memSize);

//
// Allocate memory for line pointers
//
   altScrn.charLines = new TermCharT*[altScrn.maxLines];
   if ( !altScrn.charLines ) {
      cerr <<"TermC: Out of memory" NL;
      exit(1);
   }

//
// Initialize line pointers
//
   charMemPtr = altScrn.charMem;
   //cout <<"Alternate screen @ " <<hex <<(unsigned)&altScrn <<dec NL;
   //cout <<"Alternate lines  @ " <<hex <<(unsigned)altScrn.charLines <<dec NL;
   for (i=0; i<altScrn.maxLines; i++) {
      altScrn.charLines[i] = charMemPtr;
      //cout <<"   charLines[" <<i <<"] @ "
	   //<<hex <<(unsigned)altScrn.charLines[i] <<dec NL;
      charMemPtr += colCnt;
   }

   altScrn.curCharLine = altScrn.charLines[0];

//
// Point to the primary screen
//
   scrn = &regScrn;

//
// Allocate memory for tabstops
//
   tabs = new Boolean[allocCols];
   if ( !tabs ) {
      cerr <<"TermC: Out of memory" NL;
      exit(1);
   }

//
// Initialize tabs
//
   memset(tabs, 0, allocCols*sizeof(Boolean));
   for (i=tabstop; i<allocCols; i+=tabstop) tabs[i] = True;

   return;

} // End TermC::TermC(parent)

/*----------------------------------------------------------------------
 * Term destructor
 */

TermC::~TermC()
{
   RemoveSignalCallback(SIGCHLD, (CallbackFn*)ChildDone, this);

   CloseTty();

   if ( kill(pid, 0) == 0 ) kill(pid, SIGKILL);

   if ( halApp->xRunning ) {
      //XFreeCursor(display, termCursor);  // This causes a crash if multiple
					   // Terms in the same process use the
					   // same cursor and all try to free it
      if ( termPixmap ) XFreePixmap(display, termPixmap);
      XFreeFont(display, font);
      XFreeFont(display, boldFont);
      if ( termGC ) XtReleaseGC(termArea, termGC);
   }

   delete [] regScrn.charMem;
   delete [] regScrn.charLines;

   delete [] altScrn.charMem;
   delete [] altScrn.charLines;

   delete [] tabs;

} // End destructor

/*----------------------------------------------------------------------
 * Initial display
 */

void
TermC::Initialize()
{
//
// Get keyboard focus policy
//
   unsigned char	focusPolicy;
   XtVaGetValues(topLevel, XmNkeyboardFocusPolicy, &focusPolicy, NULL);

   if ( focusPolicy == XmEXPLICIT ) {
//
// Add event handler for keyboard focus change
//
      XtAddEventHandler(termArea, FocusChangeMask, False,
                        (XtEventHandler)HandleFocusChange, (XtPointer)this);

   } else { // XmPOINTER

      XtAddEventHandler(termArea, EnterWindowMask|LeaveWindowMask,
                        False, (XtEventHandler)HandleFocusChange,
                        (XtPointer)this);
   }

//
// Create graphics context
//
   termWin = XtWindow(termArea);

//
// Create graphics contexts for drawing
//
   XtGCMask	fixMask = GCClipMask | GCPlaneMask | GCLineStyle
			| GCLineWidth | GCFillStyle | GCGraphicsExposures;
   XtGCMask	modMask = GCForeground | GCFont | GCFunction;
   XtGCMask	naMask  = GCArcMode | GCCapStyle | GCClipXOrigin
			| GCClipYOrigin | GCDashList | GCDashOffset
			| GCBackground
			| GCFillRule | GCJoinStyle | GCStipple | GCSubwindowMode
			| GCTile | GCTileStipXOrigin | GCTileStipYOrigin;
   XGCValues fixVals;
   fixVals.clip_mask          = None;
   fixVals.function           = GXcopy;
   fixVals.plane_mask         = AllPlanes;
   fixVals.graphics_exposures = TRUE;
   fixVals.font               = font->fid;
   fixVals.foreground         = fgColor;
   fixVals.fill_style         = FillSolid;
   fixVals.line_style         = LineSolid;
   fixVals.line_width         = 0;

   termGC = XtAllocateGC(termArea, 0, fixMask, &fixVals, modMask, naMask);

//
// Create off-screen pixmap to be used for drawing.
//
   unsigned	depth = DefaultDepth(display, DefaultScreen(display));
   termPixmap = XCreatePixmap(display, termWin, areaWd, areaHt, depth);
   pixmapWd = areaWd;
   pixmapHt = areaHt;

   ClearScreen();		// Clear the screen
   OpenTty();			// Set up a new tty
   SpawnChild();		// Start the child process
   ShowCursor();		// Turn on the text cursor

//
// Define the pointer cursor
//
   XDefineCursor(display, termWin, termCursor);

//
// Set the pointer cursor colors
//
   XColor	colordefs[2];	// 0 is foreground, 1 is background

   colordefs[0].pixel = pointerFgColor;
   colordefs[1].pixel = pointerBgColor;
   XQueryColors (display, DefaultColormap(display, DefaultScreen(display)),
	         colordefs, 2);
   XRecolorCursor(display, termCursor, colordefs, colordefs+1);

//
// Execute initial command
//
   if ( initialCmd.size() ) {
      Exec(initialCmd);
      initialCmd = "";
   }

   return;

} // End Initialize

/*----------------------------------------------------------------------
 * Create new tty
 */

Boolean
TermC::OpenTty()
{
#ifndef HPUX_PIPE
   if ( !FindPty() ) return False;

//
// Add callbacks to monitor input
//
   inputId = XtAppAddInput(context, inputFd, (XtPointer)XtInputReadMask,
			      (XtInputCallbackProc)PtyInput, (XtPointer)this);
   errorId = XtAppAddInput(context, inputFd, (XtPointer)XtInputExceptMask,
			      (XtInputCallbackProc)PtyError, (XtPointer)this);

//
// Update pty size
//
   struct winsize	size;
   size.ws_row = rowCnt;
   size.ws_col = colCnt;
   ioctl(outputFd, TIOCSWINSZ, &size);
#endif

   return True;

} // End OpenTty

/*----------------------------------------------------------------------
 * Close tty
 */

void
TermC::CloseTty()
{
//
// Stop looking for input
//
   if ( halApp->xRunning ) {
      if ( inputId ) XtRemoveInput(inputId);
      if ( errorId ) XtRemoveInput(errorId);
   }

   inputId = (XtInputId)NULL;
   errorId = (XtInputId)NULL;

//
// Exit the shell
//
   if ( outputFd >= 0 )
      write(outputFd, "exit\n", 5);

//
// Close the files
//
   if ( outputFd >= 0 ) {
      if ( debuglev > 0 ) cout <<"Closing output: " <<outputFd <<endl;
      close(outputFd);
   }
   if ( inputFd >= 0 && inputFd != outputFd ) {
      if ( debuglev > 0 ) cout <<"Closing input: " <<inputFd <<endl;
      close(inputFd);
   }

   inputFd  = -1;
   outputFd = -1;
#if 0
   if ( slaveFd  >= 0 ) close(slaveFd);

   masterFd = -1;
   slaveFd  = -1;
#endif

} // End CloseTty

/*----------------------------------------------------------------------
 * Find a free pty device
 */

Boolean
TermC::FindPty()
{
#if defined SOLARIS

   int	masterFd = open("/dev/ptmx", O_RDWR);
   if ( masterFd >= 0 ) {

      char	*cs = ptsname(masterFd);
      if ( cs ) {
	 name = cs;
	 inputFd = outputFd = masterFd;
	 return True;
      }

      close(masterFd);
   }

#else
//
// Brute force test for a free pty
//
#ifdef HPUX
# define FIRST  "pqrstuvwxyzPQRSTUVWXYZ"
# define SECOND "0123456789abcdef"
# define PTYPAT "/dev/ptym/pty%c%c"
# define TTYPAT "/dev/pty/tty%c%c"
#else
# define FIRST  "zyxwvutsrqp"
# define SECOND "fedcba9876543210"
# define PTYPAT "/dev/pty%c%c"
# define TTYPAT "/dev/tty%c%c"
#endif

   char	buf[16];
   for (char *c1=FIRST; *c1; c1++) {
      for (char *c2=SECOND; *c2; c2++) {

//
// Check master side
//
	 sprintf(buf, PTYPAT, *c1, *c2);
	 int	masterFd = open(buf, O_RDWR, 0);
	 if ( masterFd >= 0 ) {

//
// Check slave side
//
	    sprintf(buf, TTYPAT, *c1, *c2);
	    int	slaveFd = open(buf, O_RDWR, 0);
	    if ( slaveFd >= 0 ) {

	       name = buf;
	       if ( debuglev > 0 ) {
		  cout <<"Using tty " <<name <<endl;
		  cout <<"Master: " <<masterFd <<endl;
		  cout <<"Slave : " <<slaveFd <<endl;
	       }

	       inputFd = outputFd = masterFd;

#ifdef HPUX_BLOCK
	       int	mode = 1;

	       mode = fcntl(slaveFd, F_GETFL, 0);
	       if ( mode == -1 ) {
		  perror("Couldn't get initial pty mode");
	       }
	       else {
		  mode |= O_NDELAY;
		  if ( fcntl(slaveFd, F_SETFL, mode) == -1 )
		     perror("Couldn't set initial pty mode to non-blocking");
	       }
#endif
	       return True;

	    } // End if slave opened

	    if ( debuglev > 0 ) cout <<"Closing master: " <<masterFd <<endl;
	    close(masterFd);

	 } // End if master opened
      } // End for each second digit
   } // End for each first digit

#endif

#if 0
   masterFd = -1;
   slaveFd  = -1;
#else
   inputFd  = -1;
   outputFd = -1;
#endif

   return False;

} // End FindPty

/*----------------------------------------------------------------------
 * Method to create terminal process
 */

void
TermC::SpawnChild()
{
//
// Set the terminal type in the environment
//
   char	*cs = getenv("TERM");
   if ( !cs ) {
      static char	*termstr = "TERM=xterm";
      char		*envstr  = new char[strlen(termstr)+1];
      strcpy(envstr, termstr);
      putenv(envstr);
   }

//
// Delay sigchild
//
   AddSignalCallback(SIGCHLD, (CallbackFn*)ChildDone, this);

#if defined SUN_OS || defined LINUX || defined OSF1
   int	omask = sigblock(sigmask(SIGCHLD));
#elif defined HPUX
   long	omask = sigblock(sigmask(SIGCHLD));
#endif

#ifdef SIGTTOU
   signal(SIGTTOU,SIG_IGN);
#endif

//
// Save user and group
//
   uid_t	uid = getuid();
   gid_t	gid = getgid();

#ifdef HPUX_PIPE
//
// Create two pipes for communicating
//
   int	pipe1[2];	// Pipe to   the shell.  Read 0, write 1
   int	pipe2[2];	// Pipe from the shell.  Read 0, write 1

   if ( pipe(pipe1) == -1 || pipe(pipe2) == -1 ) {
      cerr <<"TermC::SpawnChild: error = " <<SystemErrorMessage(errno) <<endl;
      return;
   }

   int	child_in  = pipe1[0];
   outputFd       = pipe1[1];
   inputFd        = pipe2[0];
   int	child_out = pipe2[1];

//
// Add callbacks to monitor input
//
   inputId = XtAppAddInput(context, inputFd, (XtPointer)XtInputReadMask,
			      (XtInputCallbackProc)PtyInput, (XtPointer)this);
   errorId = XtAppAddInput(context, inputFd, (XtPointer)XtInputExceptMask,
			      (XtInputCallbackProc)PtyError, (XtPointer)this);
#endif

#ifdef AIX
   pid = fork();
#else
   pid = vfork();
#endif
   switch (pid) {

      case -1:
	 cerr <<"TermC::SpawnChild: error = " <<SystemErrorMessage(errno)
	      <<endl;
#ifdef HPUX_PIPE
	 close(outputFd);
	 close(inputFd);
	 close(child_out);
	 close(child_in);
#endif
	 return;

      case 0: 
      {

#if defined SUN_OS
# include "TermC-sun.C"
#elif defined SOLARIS
# include "TermC-sol.C"
#elif defined OSF1
# include "TermC-osf1.C"
#elif defined LINUX
# include "TermC-linux.C"
#elif defined HPUX
# include "TermC-hp.C"
#elif defined AIX
# include "TermC-aix.C"
#elif defined SVR4
# include "TermC-svr4.C"
#endif

//
// Start the process
//
	 char   *shell = getenv("SHELL");
	 if (!shell) shell = "/bin/sh";

	 execlp(shell, shell, (char*)0);
	 _exit(1);
      }

      default:
	 if ( debuglev > 0 ) cout << "Child process: " << pid NL;
	 break;
   }

#ifdef HPUX_PIPE
//
// Close the child sides
//
   close(child_out);
   close(child_in);
#endif

//
// Restore SIGCHILD
//
#if defined SUN_OS || defined HPUX || defined LINUX || defined OSF1
   sigsetmask(omask);
#endif

   return;

} // End SpawnChild

/*-----------------------------------------------------------------------
 *  Callback to handle death of child process
 */

void
TermC::ChildDone(SignalDataT *sd, TermC *This)
{
   if ( debuglev > 0 )
      cout <<"Child process exited with status: " <<sd->status <<endl;

//
// Make sure this is the right signal
//
   if ( sd->signum != SIGCHLD || sd->pid != This->pid ) return;

//
// Remove this handler
//
   RemoveSignalCallback(SIGCHLD, (CallbackFn*)ChildDone, This);

//
// Use a timeout since there are X calls to be made.  X calls cannot be made
//    from a signal handler.
//
   XtAppAddTimeOut(halApp->context, 0, (XtTimerCallbackProc)ChildDone2,
		   (XtPointer)This);
}

/*-----------------------------------------------------------------------
 *  TimeOut used to finish processing in X thread.  Can't do this stuff in
 *     signal handler due to the fact that there may be X calls in the user
 *     callback.
 */

void
TermC::ChildDone2(TermC *This, XtIntervalId*)
{
   CallCallbacks(This->shellExitCalls, This);
}

/*----------------------------------------------------------------------
 * Restart
 */

void
TermC::Restart()
{
   RemoveSignalCallback(SIGCHLD, (CallbackFn*)ChildDone, this);

   CloseTty();

   if ( kill(pid, 0) == 0 ) kill(pid, SIGKILL);
   pid = 0;

   OpenTty();
   SpawnChild();
}

/*----------------------------------------------------------------------
 * Callback to process input
 */

#define	BUF_SIZE	4096

void
TermC::PtyInput(TermC *tp, int, int)
{
   char    buf[BUF_SIZE + 1];
   int     n;

   n = read(tp->inputFd, buf, BUF_SIZE);

   if ( n <= 0 ) {
      if ( n < 0 && errno != EIO ) perror("read");
      else if ( n == 0 ) cerr << "EOF detected on pty" NL;
      return;
   }

   if ( debuglev > 1 ) cout << "PtyInput: " << n << " characters" NL;

   buf[n] = 0;
   tp->AddString(buf);

   return;

} // End TermC PtyInput

#define	FLUSH_STRING { \
   if ( drawStr.size() ) { \
      DrawString(scrn->curLine, drawCol, drawStr, drawAttr); \
      drawStr = ""; \
      drawAttr = curAttr; \
      drawCol = scrn->curCol; \
   } \
}

/*----------------------------------------------------------------------
 * Callback to handle an error in the input stream
 */

void
TermC::PtyError(TermC *tp, int, int)
{
   cerr << "Error on pty" <<endl;
   tp->Restart();
}

/*----------------------------------------------------------------------
 * Method to display string in drawing area
 */

void
TermC::AddString(const char *str)
{
   if ( debuglev > 2 ) cout << "AddString" <<endl;

   HideCursor();

//
// Finish processing escape sequence if in middle
//
   if ( escStr.size() ) str = HandleEscape(str);

   StringC	drawStr;
   int		drawCol = scrn->curCol;
   TermCharT	drawAttr = curAttr;

//
// Loop through characters
//
   while (*str) {

      //cout <<"Adding char: " <<hex << (int)*str <<dec <<endl;

//
// Process current character
//
      switch (*str) {

	 case (''):						// Bell
	    FLUSH_STRING
	    Bell();
	    break;

	 case ('\b'):						// Backspace
	    FLUSH_STRING
	    if ( scrn->curCol > 0 ) {
	       scrn->curCol--;
	       drawCol = scrn->curCol;
	    }
	    break;

	 case ('\t'): {						// Horiz. Tab
	    FLUSH_STRING

//
// Move to next tab stop
//
	    int	new_col = scrn->curCol + 1;
	    while ( new_col < colCnt && !tabs[new_col] ) new_col++;

//
// Move to next line if wrapping
//
	    if ( new_col >= colCnt ) {
	       DownLine();
	       scrn->curCol = 0;
	    } else {
	       scrn->curCol = new_col;
	    }

	    drawCol = scrn->curCol;
	 } break;

	 case (''):						// Vertical Tab
	 case (''):						// Form Feed
	    FLUSH_STRING
	    DownLine();
	    break;

	 case ('\n'):						// Newline
	    FLUSH_STRING
	    DownLine();
	    scrn->curCol = 0;
	    drawCol = 0;
	    break;

	 case ('\r'):						// Return
	    FLUSH_STRING
	    scrn->curCol = 0;
	    drawCol = 0;
	    break;

	 case (''):						// G1 charset
	    FLUSH_STRING
	    Unimplemented("^N");
	    break;

	 case (''):						// G0 charset
	    FLUSH_STRING
	    Unimplemented("^O");
	    break;

	 case (''):						// ESC
	    FLUSH_STRING
	    str = HandleEscape(str+1);
	    drawCol = scrn->curCol;		// These could have changed
	    drawAttr = curAttr;
	    continue;

         default:
	    if ( debuglev > 1 ) cout << "Char: " << *str <<endl;
//
// Move to next line if wrapping
//
            if ( scrn->curCol >= colCnt ) {
	       FLUSH_STRING
	       DownLine();
	       scrn->curCol = 0;
	       drawCol = 0;
	    }

//
// Add character to log
//
            AddChar(*str);

//
// Draw character on screen
//
	    if ( !AttrEqual(drawAttr, curAttr) ) {
	       FLUSH_STRING
	       drawAttr = curAttr;
	    }
	    drawStr += *str;
	    //DrawChar(scrn->curLine, scrn->curCol, *str, curAttr);
	    scrn->curCol++;
	    break;

      } // End switch current character

      str++;

   } // End for each character in string

   FLUSH_STRING
   ShowCursor();

   return;

} // End TermC AddString

/*----------------------------------------------------------------------
 * Method to add character to line history
 */

void
TermC::AddChar(char c)
{
//   if ( debuglev > 2 ) {
//      int	*ip = (int*)&curAttr;
//      cout <<"AddChar(" <<c <<") with attr: " <<hex <<*ip <<dec <<endl;
//   }

//
// See if scrolling is to be attempted
//
   if ( (inputFromUser && flags.scrollOnKey) ||
       (!inputFromUser && flags.scrollOnTty) ) {

//
// Scroll to make visible if not so
//
      Boolean	scrolled = False;
      if ( scrn->curLine > scrn->botLine ) {
	 ScrollDown(scrn->curLine - scrn->botLine);
	 scrolled = True;
      } else if ( scrn->curLine < scrn->topLine ) {
	 ScrollUp(scrn->topLine - scrn->curLine);
	 scrolled = True;
      }

//
// Update slider if necessary
//
      if ( scrolled ) {
	 //cout <<"ScrollBar val: " <<scrn->topLine NL;
	 XtVaSetValues(scrollBar, XmNvalue, scrn->topLine, NULL);
      }

   } // End if need to scroll

//
// Replace character in current position
//
   //cout <<"Placing character in line[" <<scrn->curCol <<"]" NL;
   TermCharT	*tc = &scrn->curCharLine[scrn->curCol];
   *tc   = curAttr;
   tc->c = c;

   return;

} // End TermC AddChar

/*----------------------------------------------------------------------
 * Callback to process scroll bar events
 */

void
TermC::HandleScroll(Widget, TermC *tp, XmScrollBarCallbackStruct *sb)
{
   //cout << "HandleScroll" NL;

//
// Adjust the top line based on the event that caused this callback
//
   int	incr;
   switch (sb->reason) {

      case XmCR_DECREMENT:
	 XtVaGetValues(tp->scrollBar, XmNincrement, &incr, NULL);
	 tp->ScrollUp(incr);
	 break;

      case XmCR_INCREMENT:
	 XtVaGetValues(tp->scrollBar, XmNincrement, &incr, NULL);
	 tp->ScrollDown(incr);
	 break;

      case XmCR_PAGE_DECREMENT:
	 XtVaGetValues(tp->scrollBar, XmNpageIncrement, &incr, NULL);
	 tp->ScrollUp(incr);
	 break;

      case XmCR_PAGE_INCREMENT:
	 XtVaGetValues(tp->scrollBar, XmNpageIncrement, &incr, NULL);
	 tp->ScrollDown(incr);
	 break;

      case XmCR_TO_TOP:
	 tp->ScrollUp(tp->scrn->topLine);
	 break;

      case XmCR_TO_BOTTOM:
	 if ( tp->scrn->botLine < tp->scrn->lineCnt-1 )
	    tp->ScrollDown(tp->scrn->lineCnt - 1 - tp->scrn->botLine);
	 break;

      case XmCR_DRAG:
	 if ( sb->value < tp->scrn->topLine )
	    tp->ScrollUp(tp->scrn->topLine - sb->value);
	 else
	    tp->ScrollDown(sb->value - tp->scrn->topLine);
	 break;

   } // End switch scroll reason

   return;

} // End TermC HandleScroll

/*----------------------------------------------------------------------
 * Method to scroll up
 */

void
TermC::ScrollUp(int incr)
{
   if ( scrn->topLine <= 0 ) return;
   //cout <<"ScrollUp(" <<incr <<")" NL;

   if ( scrn->topLine - incr < 0 ) {
      incr = scrn->topLine;
      //cout <<" new incr is " <<incr NL;
   }
   //cout <<" cur line is " <<scrn->curLine NL;

   scrn->topLine -= incr;
   scrn->botLine -= incr;
   //cout <<" new top, bot: " <<scrn->topLine SP scrn->botLine NL;

//
// Do a pixel copy to move lines down
//
   int	ht = incr * (charHt + lineSpacing);
   XCopyArea(display, termPixmap, termPixmap, termGC, /*srcx*/0, /*srcy*/0,
	     areaWd, areaHt-ht, /*dstx*/0, /*dsty*/ht);

//
// Clear the old area
//
   XSetForeground(display, termGC, bgColor);
   XFillRectangle(display, termPixmap, termGC, 0, 0, areaWd, ht);

//
// Draw new lines
//
   deferCopy++;
   DrawLines(scrn->topLine, scrn->topLine + incr);

// Copy to visible screen

   deferCopy--;
   if ( !deferCopy ) {
      XCopyArea(display, termPixmap, termWin, termGC, /*srcx*/0, /*srcy*/0,
		areaWd, areaHt, /*dstx*/0, /*dsty*/0);
   }

   return;

} // End TermC ScrollUp

/*----------------------------------------------------------------------
 * Method to scroll down
 */

void
TermC::ScrollDown(int incr)
{
   if ( scrn->botLine >= scrn->maxLines-1 ) return;
   //cout <<"ScrollDown(" <<incr <<")" NL;

   if ( scrn->botLine + incr >= scrn->lineCnt-1 ) {
      incr = scrn->lineCnt - 1 - scrn->botLine;
      //cout <<" new incr is " <<incr NL;
   }
   //cout <<" cur line is " <<scrn->curLine NL;

   scrn->topLine += incr;
   scrn->botLine += incr;
   //cout <<" new top, bot: " <<scrn->topLine SP scrn->botLine NL;

//
// Do a pixel copy to move lines up
//
   int	ht = incr * (charHt + lineSpacing);
   XCopyArea(display, termPixmap, termPixmap, termGC, /*srcx*/0, /*srcy*/ht,
	     areaWd, areaHt-ht, /*dstx*/0, /*dsty*/0);

//
// Clear the old area
//
   XSetForeground(display, termGC, bgColor);
   XFillRectangle(display, termPixmap, termGC, 0, areaHt-ht, areaWd, ht);

//
// Draw new lines
//
   deferCopy++;
   DrawLines(scrn->botLine - incr + 1, scrn->botLine);

// Copy to visible screen

   deferCopy--;
   if ( !deferCopy ) {
      XCopyArea(display, termPixmap, termWin, termGC, /*srcx*/0, /*srcy*/0,
		areaWd, areaHt, /*dstx*/0, /*dsty*/0);
   }

   return;

} // End TermC ScrollDown

/*----------------------------------------------------------------------
 * Expose Callback
 */

void
TermC::HandleExpose(Widget, TermC *tp, XmDrawingAreaCallbackStruct *da)
{
   //cout << "HandleExpose" NL;

   if ( !tp->termWin ) tp->Initialize();

   XExposeEvent	*ev = (XExposeEvent*)da->event;

//
// Convert the expose region to rows and columns
//
   int	startLine, endLine;
   int	startCol, endCol;
   tp->XYtoLC(ev->x, ev->y, startLine, startCol);
   tp->XYtoLC(ev->x + ev->width, ev->y + ev->height, endLine, endCol);
   //cout << "Expose region: " << ev->x SP ev->y SP ev->width SP ev->height
	//<< " converts to rows: " << startLine SP endLine
	//<< " and cols: " << startCol SP endCol NL;

//
// Loop through rows and draw lines
//
   tp->DrawLines(startLine, endLine, startCol, endCol);

   return;

} // End TermC HandleExpose

/*----------------------------------------------------------------------
 * Method to convert a pixel x/y to a character line/col
 */

void
TermC::XYtoLC(int x, int y, int& line, int& col)
{
   col = (int)(x - marginWd) / (int)charWd;
   if ( col < 0 ) col = 0;
   if ( col >= colCnt ) col = colCnt - 1;

   line = (int)(y - marginHt) / (int)(charHt + lineSpacing);
   if ( line < 0 ) line = 0;
   if ( line >= rowCnt ) line = rowCnt-1;
   line += scrn->topLine;

   return;

} // End TermC PixelToChar

/*----------------------------------------------------------------------
 * Resize Callback
 */

void
TermC::HandleResize(Widget, TermC *tp, XtPointer)
{
   if ( !tp->termWin ) return;

   tp->Resize();

   return;

} // End TermC HandleResize

/*----------------------------------------------------------------------
 * Resize Method
 */

void
TermC::Resize()
{
   //cout <<"Resize" NL;

//
// Get new size
//
   //cout <<"Old size is: " <<areaWd <<" by " <<areaHt
	//<<" pixels and " <<colCnt <<" by " <<rowCnt <<" chars" NL;
   XtVaGetValues(termArea, XmNwidth, &areaWd, XmNheight, &areaHt, NULL);

//
// Recreate off-screen pixmap
//
   if ( termPixmap && (pixmapWd < areaWd || pixmapHt < areaHt) ) {
      XFreePixmap(display, termPixmap);
      unsigned	depth = DefaultDepth(display, DefaultScreen(display));
      termPixmap = XCreatePixmap(display, termWin, areaWd, areaHt, depth);
      pixmapWd = areaWd;
      pixmapHt = areaHt;
   }

//
// Calculate rows and columns for new size
//
   int	newColCnt = (int)(areaWd - marginWd*2) / (int)charWd;
   if ( newColCnt < 1 ) newColCnt = 1;

   int	newRowCnt = (int)(areaHt - marginHt*2) / (int)(charHt + lineSpacing);
   if ( newRowCnt < 1 ) newRowCnt = 1;

   //cout <<"    New size is: " <<areaWd <<" by " <<areaHt
	//<<" pixels and " <<newColCnt <<" by " <<newRowCnt <<" chars" NL;

//
// Return if no changes
//
   if ( newRowCnt == rowCnt && newColCnt == colCnt ) return;

#ifndef HPUX_PIPE
//
// Update pty size
//
   if ( outputFd > 0 ) {
      struct winsize	size;
      size.ws_row = newRowCnt;
      size.ws_col = newColCnt;
      ioctl(outputFd, TIOCSWINSZ, &size);
   }
#endif

//
// Reallocate char and line memory
//
   ReallocateScreen(&regScrn, newColCnt, newRowCnt + saveLines);
   ReallocateScreen(&altScrn, newColCnt, newRowCnt);

//
// See if width has changed
//
   if ( newColCnt != colCnt ) {

//
// Reallocate tab memory if width has increased
//
      if ( newColCnt > allocCols ) {

	 ReallocateTabs(newColCnt);
	 allocCols = newColCnt;

      } // End if width has increased beyond allocation

      colCnt = newColCnt;

//
// Move cursor if off screen
//
      if (scrn->curCol >= newColCnt) {
	 HideCursor();
	 scrn->curCol = newColCnt - 1;
	 ShowCursor();
      }

      if (regScrn.curCol >= newColCnt) regScrn.curCol = newColCnt - 1;
      if (altScrn.curCol >= newColCnt) altScrn.curCol = newColCnt - 1;

   } // End if column count changed

//
// See if height has changed
//
   if ( newRowCnt != rowCnt ) {

//
// See which line stays fixed
//
      if ( resizeGravity == NorthWestGravity ) {

//
// Determine new bottom line
//
	 regScrn.botLine = regScrn.topLine + newRowCnt - 1;
	 altScrn.botLine = altScrn.topLine + newRowCnt - 1;

//
// Must have at least one screens worth of lines
//
	 if ( regScrn.lineCnt < regScrn.botLine+1 )
	    regScrn.lineCnt = regScrn.botLine + 1;;
	 if ( altScrn.lineCnt < altScrn.botLine+1 )
	    altScrn.lineCnt = altScrn.botLine + 1;;

      } else {		// SouthWestGravity

//
// Determine new top line
//
	 regScrn.topLine = regScrn.botLine - newRowCnt + 1;
	 altScrn.topLine = altScrn.botLine - newRowCnt + 1;

	 if ( regScrn.topLine < 0 ) {
	    regScrn.topLine = 0;
	    regScrn.botLine = newRowCnt - 1;
	 }

	 if ( altScrn.topLine < 0 ) {
	    altScrn.topLine = 0;
	    altScrn.botLine = newRowCnt - 1;
	 }

//
// Must have at least one screens worth of lines
//
	 if ( regScrn.lineCnt < newRowCnt ) regScrn.lineCnt = newRowCnt;
	 if ( altScrn.lineCnt < newRowCnt ) altScrn.lineCnt = newRowCnt;

      } // End if SouthWest gravity

      //cout <<"New reg topLine: " <<regScrn.topLine
	     //<<". New reg botLine: " <<regScrn.botLine NL;
      //cout <<"New alt topLine: " <<altScrn.topLine
	     //<<". New alt botLine: " <<altScrn.botLine NL;

//
// Update scrollbar
//
      int	max = MAX(newRowCnt, scrn->lineCnt);
      //cout <<"ScrollBar max: " <<max <<", size: " <<newRowCnt <<", val: "
	   //<<scrn->topLine NL;
      XtVaSetValues(scrollBar, XmNmaximum, max,
				   XmNvalue, scrn->topLine,
				   XmNsliderSize, newRowCnt,
				   NULL);

      rowCnt = newRowCnt;

   } // End if row count changed

//
// Redraw window
//
   Refresh();

   return;

} // End TermC Resize

/*----------------------------------------------------------------------
 * Method to reallocate memory for given screen
 */

void
TermC::ReallocateScreen(ScreenStateT *sp, int newColCnt, int maxLines)
{
   //cout <<"ReallocateScreen(" <<hex <<(unsigned)sp <<", " <<dec <<newColCnt
	//<<", " <<maxLines <<")" NL;

   Boolean	newMem = False;

//
// Reallocate character memory if necessary
//
   if ( newColCnt > allocCols ) {

      int	memSize = maxLines * newColCnt;
      TermCharT	*charMem = new TermCharT[maxLines * newColCnt];
      if ( !charMem ) {
	cerr <<"TermC: Out of memory" NL;
	exit(1);
      }

//
// Initialize new memory
//
      FillCharMem(charMem, initChar, memSize);

//
// Determine which lines to copy.
//
      int	startLine, endLine;
      if ( sp->lineCnt < maxLines ) {	// copy all lines

	 startLine = 0;
	 endLine = sp->lineCnt - 1;

      } else { // Not enough space for existing lines

//
//   Copy top lines if NorthWest gravity, bottom lines if SouthWest
//
	 if ( resizeGravity == NorthWestGravity ) {
	    startLine = 0;
	    endLine = maxLines - 1;
	 } else {
	    startLine = sp->lineCnt - maxLines;
	    endLine = sp->lineCnt - 1;
         }

      } // End if can't copy all lines

//
// Copy old lines to new memory
//
      TermCharT	*charMemPtr = charMem;
      for (int i=startLine; i<=endLine; i++) {
	 //cout <<"   copying charLines[" <<i <<"] from "
	      //<<hex <<(unsigned)sp->charLines[i] <<" to "
	      //<<hex <<(unsigned)charMemPtr <<dec NL;
	 memcpy(charMemPtr, sp->charLines[i], colCnt*sizeof(TermCharT));
	 charMemPtr += newColCnt;
      }

//
// Delete old memory and point to new
//
      delete [] sp->charMem;
      sp->charMem = charMem;

      newMem = True;

   } // End if number of columns has changed

//
// Reallocate line pointers if max number of lines has changed
//
   if ( maxLines > sp->allocLines ) {

      TermCharT	**charLines = new TermCharT*[maxLines];
      if ( !charLines ) {
	 cerr <<"TermC: Out of memory" NL;
	 exit(1);
      }
      delete [] sp->charLines;
      sp->charLines = charLines;
      //cout <<"New char lines @ " <<hex <<(unsigned)sp->charLines <<dec NL;

      sp->allocLines = maxLines;
      newMem = True;

   } // End if maximum number of lines has changed

   sp->maxLines = maxLines;

//
// Update line pointers if necessary
//
   if ( newMem ) {

      TermCharT	*charMemPtr = sp->charMem;
      for (int i=0; i<sp->maxLines; i++) {
	 sp->charLines[i] = charMemPtr;
	 //cout <<"   new charLines[" <<i <<"] @ "
	      //<<hex <<(unsigned)sp->charLines[i] <<dec NL;
	 charMemPtr += newColCnt;
      }
      sp->curCharLine = sp->charLines[sp->curLine];

   } // End if new memory has been allocated

   return;

} // End TermC ReallocateScreen

/*----------------------------------------------------------------------
 * Method to reallocate tabs
 */

void
TermC::ReallocateTabs(int newColCnt)
{
//
// Allocate and clear new memory
//
   Boolean	*new_tabs = new Boolean[newColCnt];
   memset(new_tabs, 0, newColCnt*sizeof(Boolean));

//
// Copy current tabs to new memory
//
   memcpy(new_tabs, tabs, allocCols*sizeof(Boolean));

//
// Set default tabs in uncopied part of new memory only
//
   for (int i=tabstop; i<allocCols; i+=tabstop);
   for (; i<newColCnt; i+=tabstop) new_tabs[i] = True;

//
// Free old memory
//
   delete [] tabs;
   tabs = new_tabs;

   return;

} // End TermC ReallocateTabs

/*----------------------------------------------------------------------
 * Input Callback
 */

void
TermC::HandleInput(Widget, TermC *tp, XmDrawingAreaCallbackStruct *da)
{
   if ( debuglev > 2 ) cout << "HandleInput" <<endl;

   if ( da->event->type != KeyPress ) return;

//
// Keypad mappings
//
   static char	*numKeys =
	" XXXXXXXX\tXXX\rXXXxxxxXXXXXXXXXXXXXXXXXXXXX*+,-.\\0123456789XXX=";
   static char	*applKeys =
	" ABCDEFGHIJKLMNOPQRSTUVWXYZ??????abcdefghijklmnopqrstuvwxyzXXX";
   static char	*curKeys = "DACB";

//
// Translate event info keysym
//
   XKeyEvent	*ev = (XKeyEvent *)da->event;
   char		buf[BUFSIZ];
   KeySym	keysym;
   int	byteCnt = XLookupString(ev, buf, BUFSIZ, &keysym, NULL);

   StringC	reply;
   Boolean	isKey = False;

//
// Parse keysym
//
   if ( IsPFKey(keysym) ) {

      reply = "O";
      reply += (char)(keysym - XK_KP_F1 + 'P');
      isKey = True;

   } else if ( IsKeypadKey(keysym) ) {

      if ( tp->flags.appKeypad ) {
	 reply = "O";
	 reply += applKeys[keysym - XK_KP_Space];
      } else  {
	 reply = numKeys[keysym - XK_KP_Space];
      }
      isKey = True;

   } else if ( IsCursorKey(keysym) && keysym != XK_Prior && keysym != XK_Next ){

      reply = "";
      reply += tp->flags.appCursor ? 'O' : '[';
      reply += curKeys[keysym - XK_Left];
      isKey = True;

   } else if ( IsFunctionKey(keysym) || IsMiscFunctionKey(keysym) ||
	       keysym == XK_Prior || keysym == XK_Next ) {

      reply = "";
      if ( tp->sunFKeys ) {
	 reply += tp->SunFKeyValue(keysym);
	 reply += 'z';
      } else {
	 reply += tp->FKeyValue(keysym);
	 reply += '~';
      }
      reply += (int)reply.size();
      isKey = True;

   } else if ( byteCnt ) { // Send raw text
      buf[byteCnt] = 0;
      reply = buf;
      isKey = True;
   }

//
// Ring margin bell if necessary
//
   if ( isKey && tp->flags.marginBell &&
	(tp->scrn->curCol + tp->marginBellRange >= tp->colCnt) ) {
      tp->Bell();
   }

//
// Process string
//
   if ( reply.size() ) {
      if ( debuglev > 2 ) cout <<"   Writing to pty" <<endl;

//
// Send input to terminal
//
      tp->inputFromUser = True;
      write(tp->outputFd, (char*)reply, reply.size());
      tp->inputFromUser = False;

//
// Call callbacks for user input if necessary
//
      CallCallbacks(tp->userInputCalls, &reply);
   }

   return;

} // End TermC HandleInput

/*----------------------------------------------------------------------
 * Handler for focus events
 */

void
TermC::HandleFocusChange(Widget, TermC *tp, XFocusChangeEvent *ev, Boolean*)
{
   //cout << "HandleFocusChange" NL;

   switch (ev->type) {

      case (FocusIn):
      case (EnterNotify):
	 tp->focusHere = True;
	 tp->DrawCursor();
	 break;

      case (FocusOut):
      case (LeaveNotify):
	 tp->focusHere = False;
	 tp->DrawCursor();
	 break;

   } // End switch event type

   return;

} // End TermC HandleFocusChange

/*----------------------------------------------------------------------
 * Method to move cursor down 1 line
 */

void
TermC::DownLine()
{
   //cout <<"DownLine" NL;
   //cout <<" topLine, botLine: " <<scrn->topLine SP scrn->botLine NL;
   //cout <<" curLine, lineCnt: " <<scrn->curLine SP scrn->lineCnt NL;

   if ( scrn->curLine >= scrn->botLine ) {

      //cout <<" scrolling" NL;

//
// Do a pixel copy to move the existing lines up
//
      XCopyArea(display, termPixmap, termPixmap, termGC, /*srcx*/0,
		/*srcy*/charHt, areaWd, areaHt-charHt, /*dstx*/0, /*dsty*/0);

//
// Clear the bottom line
//
      XSetForeground(display, termGC, bgColor);
      XFillRectangle(display, termPixmap, termGC, 0, areaHt-charHt, areaWd,
		     charHt);

//
// If the line list is full, move all lines up by 1, then clear the last line
//
      if ( scrn->lineCnt >= scrn->maxLines ) {

	 memcpy(scrn->charLines[0], scrn->charLines[1],
		(scrn->maxLines-1) * allocCols * sizeof(TermCharT));
	 FillCharMem(scrn->charLines[scrn->maxLines-1], initChar, colCnt);

	 scrn->curLine--;
      }

//
// Update the top and bottom if necessary
//
      if ( scrn->botLine < scrn->maxLines-1 ) {
	 scrn->topLine++;
	 scrn->botLine++;
      }

      //cout <<" new topLine, botLine: " <<scrn->topLine SP scrn->botLine NL;

//
// Draw last line if current line is off the bottom
//
      if ( scrn->curLine >= scrn->botLine ) {
	 DrawLine(scrn->botLine);
      }

// Copy to visible screen

      if ( !deferCopy ) {
	 XCopyArea(display, termPixmap, termWin, termGC, /*srcx*/0, /*srcy*/0,
		   areaWd, areaHt, /*dstx*/0, /*dsty*/0);
      }

   } // End if going off bottom

//
// Update line count if necessary
//
   if ( scrn->curLine == scrn->lineCnt-1 &&
	scrn->lineCnt < scrn->maxLines ) scrn->lineCnt++;

//
// Move to the next line
//
   scrn->curLine++;
   scrn->curCharLine = scrn->charLines[scrn->curLine];
   //cout <<" new curLine, lineCnt: " <<scrn->curLine SP scrn->lineCnt NL;

//
// Update scrollbar
//
   int	max = MAX(rowCnt, scrn->lineCnt);
   //cout <<"ScrollBar max: " <<max <<", val: " <<scrn->topLine NL;
   XtVaSetValues(scrollBar, XmNmaximum, max, XmNvalue, scrn->topLine, NULL);

   return;

} // End TermC DownLine

/*----------------------------------------------------------------------
 * Method to move cursor up 1 line
 */

void
TermC::UpLine()
{
   //cout <<"UpLine" NL;
   //cout <<" topLine, botLine: " <<scrn->topLine SP scrn->botLine NL;
   //cout <<" curLine, lineCnt: " <<scrn->curLine SP scrn->lineCnt NL;

   if ( scrn->curLine <= scrn->topLine ) {

      //cout <<" scrolling" NL;

//
// Do a pixel copy to move the existing lines down
//
      XCopyArea(display, termPixmap, termPixmap, termGC, /*srcx*/0, /*srcy*/0,
		areaWd, areaHt-charHt, /*dstx*/0, /*dsty*/charHt);

//
// Clear the top line
//
      XSetForeground(display, termGC, bgColor);
      XFillRectangle(display, termPixmap, termGC, 0, 0, areaWd, charHt);

//
// Update the top and bottom if necessary
//
      if ( scrn->topLine > 0 ) {
	 scrn->topLine--;
	 scrn->botLine--;
      }

      //cout <<" new topLine, botLine: " <<scrn->topLine SP scrn->botLine NL;

//
// If we're at the top, move all lines down and clear the top line
//
      if ( scrn->curLine == 0 ) {

	 for (int i=scrn->maxLines-1; i>0; i--) {
	    memcpy(scrn->charLines[i], scrn->charLines[i-1],
		   colCnt*sizeof(TermCharT));
	 }
	 FillCharMem(scrn->charLines[0], initChar, colCnt);

	 scrn->curLine++;
      }

// Copy to visible screen

      if ( !deferCopy ) {
	 XCopyArea(display, termPixmap, termWin, termGC, /*srcx*/0, /*srcy*/0,
		   areaWd, areaHt, /*dstx*/0, /*dsty*/0);
      }

   } // End if going off top

//
// Move to the previous line
//
   scrn->curLine--;

//
// Update scrollbar
//
   XtVaSetValues(scrollBar, XmNvalue, scrn->topLine, NULL);

   return;

} // End TermC UpLine

/*----------------------------------------------------------------------
 * Method to add a character to the display
 */

void
TermC::DrawChar(int line, int col, TermCharT tc)
{
   if ( line < scrn->topLine || line > scrn->botLine ) return;
   //cout << "Drawing <" << tc.c << "> in pos " << line SP col NL;

   int	x = marginWd + (col * charWd);
   int	y = marginHt + ((line - scrn->topLine) * (charHt + lineSpacing));
   //cout << "Drawing <" << tc.c << "> at " << x SP y NL;

   XSetForeground(display, termGC, FgColor(tc));
   XFillRectangle(display, termPixmap, termGC, x, y, charWd, charHt);

   int	cy = y + Ascent(tc);
   XSetForeground(display, termGC, BgColor(tc));
   if ( Underlined(tc) ) {
      XDrawLine(display, termPixmap, termGC, x, cy+1, x+charWd, cy+1);
   }

   XSetFont(display, termGC, FontId(tc));
   XDrawString(display, termPixmap, termGC, x, cy, &tc.c, 1);

// Copy to visible screen

   if ( !deferCopy ) {
      XCopyArea(display, termPixmap, termWin, termGC, /*srcx*/x, /*srcy*/y,
		charWd, charHt, /*dstx*/x, /*dsty*/y);
   }

   return;

} // End TermC DrawChar

/*----------------------------------------------------------------------
 * Method to add a character string to the display
 */

void
TermC::DrawString(int line, int col, const StringC& str, TermCharT tc)
{
   if ( line < scrn->topLine || line > scrn->botLine ) return;
   //cout << "Drawing <" << str << "> in pos " << line SP col NL;

   int	x = marginWd + (col * charWd);
   int	y = marginHt + ((line - scrn->topLine) * (charHt + lineSpacing));
   int	sy = y + Ascent(tc);
   int	wd = charWd * str.size();
   //cout << "Drawing <" << str << "> at " << x SP sy NL;

   XSetForeground(display, termGC, FgColor(tc));
   XFillRectangle(display, termPixmap, termGC, x, y, wd, charHt);

   XSetForeground(display, termGC, BgColor(tc));
   if ( Underlined(tc) ) {
      XDrawLine(display, termPixmap, termGC, x, sy+1, x+wd, sy+1);
   }
   XSetFont(display, termGC, FontId(tc));
   XDrawString(display, termPixmap, termGC, x, sy, str, str.size());

// Copy to visible screen

   if ( !deferCopy ) {
      XCopyArea(display, termPixmap, termWin, termGC, /*srcx*/x, /*srcy*/y,
		wd, charHt, /*dstx*/x, /*dsty*/y);
   }

   return;

} // End TermC DrawString

/*----------------------------------------------------------------------
 * Method to draw the given line on the screen
 */

void
TermC::DrawLine(int line, int startCol, int endCol)
{
//
// Point to the data
//
   if ( line < scrn->topLine || line > scrn->botLine || line >= scrn->lineCnt )
      return;

   //cout <<"DrawLine(" <<line <<", " <<startCol <<", " <<endCol <<")" NL;
   //cout <<"   screen @ " <<hex <<(unsigned)scrn <<dec NL;
   //cout <<"   lines  @ " <<hex <<(unsigned)scrn->charLines <<dec NL;

   TermCharT	*charLine = scrn->charLines[line];
   //cout <<"   charLine @ " <<hex <<(unsigned)charLine <<dec NL;

//
// Check range of columns
//
   if ( endCol < 0 || endCol >= colCnt ) endCol = colCnt-1;
   if ( startCol < 0 ) startCol = 0;

//
// Load string with first character and save attributes
//
   StringC	str;
   int		strCol = startCol;
   TermCharT	tc = charLine[startCol];
   TermCharT	lastChar = tc;
   str += tc.c;

   if ( scrn->curLine == line ) HideCursor();

//
// Loop through characters
//
   deferCopy++;
   for (int i=startCol+1; i<=endCol; i++) {

      tc = charLine[i];

      if ( !AttrEqual(tc, lastChar) ) {
	 DrawString(line, strCol, str, lastChar);
	 strCol = i;
	 str = "";
	 lastChar = tc;
      }

      str += tc.c;

   } // End for each character

//
// Draw string if necessary
//
   if ( str.size() ) {
      DrawString(line, strCol, str, lastChar);
   }

   if ( scrn->curLine == line ) ShowCursor();

// Copy to visible screen

   deferCopy--;
   if ( !deferCopy ) {
      int	x = marginWd + (startCol * charWd);
      int	y = marginHt + (line - scrn->topLine) * (charHt + lineSpacing);
      int	wd = (endCol - startCol + 1) * charWd;
      XCopyArea(display, termPixmap, termWin, termGC, /*srcx*/x, /*srcy*/y,
		wd, charHt, /*dstx*/x, /*dsty*/y);
   }

   return;

} // End TermC DrawLine

/*----------------------------------------------------------------------
 * Method to draw the given lines on the screen between the given columns
 */

void
TermC::DrawLines(int startLine, int endLine, int startCol, int endCol)
{
//
// Check for valid lines
//
   if ( startLine > scrn->botLine || endLine < scrn->topLine ) return;

// Clip to visible area

   if ( startLine < scrn->topLine ) startLine = scrn->topLine;
   if ( endLine   > scrn->botLine ) endLine   = scrn->botLine;

   deferCopy++;

// Hide cursor if necessary

   if ( scrn->curLine >= startLine && scrn->curLine <= endLine )
      HideCursor();

// Draw individual lines

   for (int line=startLine; line<=endLine; line++) {
      DrawLine(line, startCol, endCol);
   }

// Show cursor if hidden

   if ( scrn->curLine >= startLine && scrn->curLine <= endLine )
      ShowCursor();

// Copy to visible screen

   deferCopy--;
   if ( !deferCopy ) {
      int	y = marginHt
		  + (startLine - scrn->topLine) * (charHt + lineSpacing);
      int	ht = (endLine - startLine + 1) * (charHt + lineSpacing);
      XCopyArea(display, termPixmap, termWin, termGC, /*srcx*/0, /*srcy*/y,
		areaWd, ht, /*dstx*/0, /*dsty*/y);
   }

   return;

} // End TermC DrawLines

/*----------------------------------------------------------------------
 * Method to look for escape sequences
 */

const char *
TermC::HandleEscape(const char *str)
{
   //cout << "HandleEscape: (" << str << ") (" << escStr << ")" NL;

//
// Loop through characters
//
   while (*str) {

//
// Copy current character to escape buffer
//
      char	c = *str++;
      escStr += c;

//
// See if we've gotten all the required characters yet
//
      switch (escStr[0]) {

	 case '#':			// (ESC # 8) DEC screen alignment test
	 case '(':			// (ESC ( n) Designate G0 charset
	 case ')':			// (ESC ) n) Designate G1 charset
	 case '*':			// (ESC * n) Designate G2 charset
	 case '+':			// (ESC + n) Designate G3 charset
	    if ( escStr.size() < 2 ) continue;
	    Unimplemented(escStr);
	    escStr = "";
	    return str;

	 case '7':			// (ESC 7) Save cursor position
	    saveLine = scrn->curLine;
	    saveCol  = scrn->curCol;
	    escStr = "";
	    return str;

	 case '8':			// (ESC 8) Restore cursor position
	    HideCursor();
	    SetCurrentLine(saveLine);
	    scrn->curCol  = saveCol;
	    ShowCursor();
	    escStr = "";
	    return str;

	 case '=':			// (ESC =) Application keypad
	    flags.appKeypad = True;
	    escStr = "";
	    return str;

	 case '>':			// (ESC >) Normal keypad
	    flags.appKeypad = False;
	    escStr = "";
	    return str;

	 case 'D':			// (ESC D) Index
	    DownLine();
	    escStr = "";
	    return str;

	 case 'E':			// (ESC E) Next Line
	    DownLine();
	    scrn->curCol = 0;
	    escStr = "";
	    return str;

	 case 'H':			// (ESC Tab Set
	    tabs[scrn->curCol] = True;
	    escStr = "";
	    return str;

	 case 'M':			// (ESC M) Reverse index
	    UpLine();
	    escStr = "";
	    return str;

	 case 'N':			// (ESC N) G2 charset for next char
	    Unimplemented(escStr);
	    escStr = "";
	    return str;

	 case 'O':			// (ESC O) G3 charset for next char
	    Unimplemented(escStr);
	    escStr = "";
	    return str;

	 case 'P': {			// (ESC P t ESC \) Dev control string
	    RegexC	patP("P\\([^]*\\)\\\\");
	    if ( !patP.match(escStr) ) continue;
	    // Ignored
	    escStr = "";
	    return str;
	 }

	 case 'Z':			// (ESC Z) Identify terminal
	    write(outputFd, "[?1;2c", 7);
	    escStr = "";
	    return str;

	 case '[': {			// (ESC [ ...)
	 /* A ?, number or list of numbers followed by a single character from
	  *    the following list:
	  */
	    StringC	chars("@ABCDHJKLMPTYcfghlmnrsx");
	    RegexC	patP = "\\[\\([^" + chars + "]*\\)\\([" + chars
			     + "]\\)";
	    //cout << "Looking for <" << patP << "> in <" << escStr << ">" NL;
	    if ( !patP.match(escStr) ) continue;
	    HandleEscapeLeft(escStr(patP[1]), escStr[patP[2].firstIndex()]);
	    escStr = "";
	    return str;
	 }

	 case ']': {			// (ESC ] ...)
	    RegexC	patP("]\\([0-9]+\\);\\([^]*\\)");
	    if ( !patP.match(escStr) ) continue;
	    StringC	numStr = escStr(patP[1]);
	    int	num = atoi(numStr);
	    switch (num) {
	       case (0):		// Change icon name and window title
	       case (1):		// Change icon name
	       case (2):		// Change window title
		  // Ignored
		  break;
	       case (46):		// Change log file
	       case (50):		// Change font
		  Unimplemented(escStr);
		  break;
	       default:
		  Unknown(escStr);
		  break;
	    }
	    escStr = "";
	    return str;
	 }
 
	 case '^': {			// (ESC ^ t ESC \) Privacy Message
	    RegexC	patP("\\^\\([^]*\\)\\\\");
	    if ( !patP.match(escStr) ) continue;
	    // Ignored
	    escStr = "";
	    return str;
	 }

	 case ' ': {			// (ESC   t ESC \) Appl program cmd
	    RegexC	patP(" \\([^]*\\)\\\\");
	    if ( !patP.match(escStr) ) continue;
	    // Ignored
	    escStr = "";
	    return str;
	 }

	 case 'c':			// (ESC c) Full reset
	    ResetScreen();
	    escStr = "";
	    return str;

	 case 'n':			// (ESC n) Select G2 charset
	 case 'o':			// (ESC o) Select G3 charset
	 case '|':			// (ESC |) Invoke G3 charset as GR
	 case '}':			// (ESC }) Invoke G2 charset as GR
	 case '~':			// (ESC ~) Invoke G1 charset as GR
	    Unimplemented(escStr);
	    escStr = "";
	    return str;

	 case '@':			// (ESC @ #) Ignore ATT control
	    if ( escStr.size() < 2 ) continue;
	    escStr = "";
	    return str;

	 default:
	    Unknown(escStr);
	    escStr = "";
	    return str;

      } // End switch current character

   } // End for each character

   return str;

} // End TermC HandleEscape

/*----------------------------------------------------------------------
 * Method to process escape sequences
 */

void
TermC::HandleEscapeLeft(StringC numStr, char type)
{
   int	val;
   int	count;

   //cout << "HandleEscapeLeft: " << numStr << " (" << type << ")" NL;

//
// Look for question mark.  Save this information to be used after numbers
//    are extracted.
//
   Boolean	quest = False;
   if ( numStr[0] == '?' ) {
      quest = True;
      numStr(0,1) = "";		// Remove ? from string
   }

//
// Extract numbers from numStr
//
   IntListC	valList; valList.AllowDuplicates(TRUE);
   StringC	valStr;
   RegexC	patN(";");
   int		index;
   while ( (index = patN.search(numStr)) >= 0 ) {
      valStr = numStr(0,index);		// Length is (index-1) - 0 + 1
      sscanf(valStr, "%d", &val);
      valList.append(val);
      numStr(0,index+1) = "";		// Add 1 to remove ; as well
   }

//
// Extract last number if any
//
   if ( numStr.size() ) {
      sscanf(numStr, "%d", &val);
      valList.append(val);
   }

   int	vsize = valList.size();
   //cout <<" Found " <<vsize <<" numbers: " NL;
   //cout <<valList <<flush;

//
// Process escape type
//
   switch (type) {

      case '@': {			// (ESC [ n @) Insert n blanks

	 count = vsize ? *valList[0] : 1;

//
// Move current characters to the right
//
	 int	dsti = colCnt - 1;
	 int	srci = dsti - count;
	 while ( srci >= scrn->curCol ) {
	    scrn->curCharLine[dsti--] = scrn->curCharLine[srci--];
	 }

//
// Add spaces
//
	 TermCharT	tc = scrn->curCharLine[scrn->curCol];
	 tc.c = ' ';
	 int	i = scrn->curCol;
	 while ( count-- > 0 && i < colCnt) {
	    scrn->curCharLine[i++] = tc;
	 }

//
// Clear and redraw line
//
	 int  	y = marginHt
		  + ((scrn->curLine - scrn->topLine) * (charHt + lineSpacing));
	 HideCursor();
	 XSetForeground(display, termGC, bgColor);
	 XFillRectangle(display, termPixmap, termGC, 0, y, areaWd, charHt);
	 DrawLine(scrn->curLine);
	 ShowCursor();

      } break;

      case 'A':				// (ESC [ n A) Move cursor up n
      case 'B':				// (ESC [ n B) Move cursor down n
      case 'C':				// (ESC [ n C) Move cursor right n
      case 'D': {			// (ESC [ n D) Move cursor left n

         HideCursor();

	 int		newLine = scrn->curLine;
	 Boolean	wasVisible = (newLine >= scrn->topLine &&
				      newLine <= scrn->botLine);
	 count = vsize ? *valList[0] : 1;
	 switch (type) {
	    case 'A': newLine -= count; break;
	    case 'B': newLine += count; break;
	    case 'C': scrn->curCol += count; break;
	    case 'D': scrn->curCol -= count; break;
	 } // End switch type

//
// Keep cursor horizontally on screen
//
	      if (scrn->curCol <  0     ) scrn->curCol = 0;
	 else if (scrn->curCol >= colCnt) scrn->curCol = colCnt - 1;

//
// Keep cursor vertically on screen if it was
//
	 if ( wasVisible ) {

	         if (newLine < scrn->topLine) newLine = scrn->topLine;
	    else if (newLine > scrn->botLine) newLine = scrn->botLine;
         }

         SetCurrentLine(newLine);
	 ShowCursor();

      } break;

      case 'H': {			// (ESC [ n;m H) Move cursor to n,m

         HideCursor();

	 int	newLine = scrn->curLine;

	 if (vsize > 1) scrn->curCol = *valList[1] - 1;
	 else		scrn->curCol = 0;

	 if (vsize > 0) newLine = scrn->topLine + *valList[0] - 1;
	 else		newLine = scrn->topLine;

	      if (scrn->curCol <  0     ) scrn->curCol = 0;
	 else if (scrn->curCol >= colCnt) scrn->curCol = colCnt - 1;

	      if (newLine < scrn->topLine) newLine = scrn->topLine;
	 else if (newLine > scrn->botLine) newLine = scrn->botLine;

	 //cout <<"Moving cursor to: "<<newLine SP scrn->curCol NL;
	 SetCurrentLine(newLine);
	 ShowCursor();

      } break;

      case 'J':
	 val = vsize ? *valList[0] : 0;

	 switch (val) {
	    case 0:			// (ESC [ 0 J) Clear below
	       ClearCols(scrn->curCol, colCnt-1);
	       ClearLines(scrn->curLine+1, scrn->botLine);
	       break;
	    case 1:			// (ESC [ 1 J) Clear above
	       ClearLines(scrn->topLine, scrn->curLine - 1);
	       ClearCols(0, scrn->curCol);
	       break;
	    case 2:			// (ESC [ 2 J) Clear display
	       ClearLines(scrn->topLine, scrn->botLine);
	       break;
	 }
	 break;

      case 'K':
	 val = vsize ? *valList[0] : 0;

	 switch (val) {
	    case 0:			// (ESC [ 0 K) Clear to right
	       ClearCols(scrn->curCol, colCnt-1);
	       break;
	    case 1:			// (ESC [ 1 K) Clear to left
	       ClearCols(0, scrn->curCol);
	       break;
	    case 2:			// (ESC [ 2 K) Clear line
	       ClearLines(scrn->curLine, scrn->curLine);
	       break;
	 }
      break;

      case 'L':				// (ESC [ n L) Insert n lines

	 InsertLines(vsize ? *valList[0] : 1);
	 break;

      case 'M': {			// (ESC [ n M) Delete n lines

	 count = vsize ? *valList[0] : 1;
	 int	lastLine = scrn->curLine + count - 1;
	 if ( lastLine > scrn->lineCnt-1 ) lastLine = scrn->lineCnt - 1;
	 DeleteLines(scrn->curLine, lastLine);
      } break;

      case 'P': {			// (ESC [ n P) Delete n characters

	 count = vsize ? *valList[0] : 1;

//
// Move characters to the left
//
	 int	dsti = scrn->curCol;
	 int	srci = dsti + count;
	 while ( srci < colCnt ) {
	    scrn->curCharLine[dsti++] = scrn->curCharLine[srci++];
	 }

//
// Fill with spaces to end of line
//
	 int	i = colCnt - count;
	 TermCharT	tc = scrn->curCharLine[i];
	 tc.c = ' ';
	 while ( count-- > 0 ) {
	    scrn->curCharLine[i++] = tc;
	 }

//
// Clear and redraw line
//
	 int  	y = marginHt
		  + ((scrn->curLine - scrn->topLine) * (charHt + lineSpacing));
	 HideCursor();
	 XSetForeground(display, termGC, bgColor);
	 XFillRectangle(display, termPixmap, termGC, 0, y, areaWd, charHt);
	 DrawLine(scrn->curLine);
	 ShowCursor();

      } break;

      case 'T':				// (ESC [ f;x;y;s;e T) Mouse tracking 
	 Unimplemented(escStr);
         break;

      case 'Y':				// (ESC [ # Y) Mouse position - ignore
         break;

      case 'c':				// (ESC [ 0 c) Send device attributes
	 Unimplemented(escStr);
         break;

      case 'f':				// (ESC [ r;c f) Horiz and vert pos
	 Unimplemented(escStr);
         break;

      case 'g':				// (ESC [ n g) Tab Clear
	 if ( !vsize ) valList.append(zero), vsize++;

	 switch (*valList[0]) {

	    case 0:			// Clear tab at current column
	       tabs[scrn->curCol] = False;
	       break;

	    case 3:			// Clear all tabs
	       memset(tabs, 0, allocCols*sizeof(Boolean));
	       break;

	    default:
	       Unknown(escStr);
	       break;
	 }
	 break;

      case 'h':
      case 'l':
      case 'r':
      case 's':

	 if ( quest ) {				// (ESC [ ? n h) Set private
	 					// (ESC [ ? n l) Reset private
						// (ESC [ ? n r) Restore private
						// (ESC [ ? n s) Save private
            HandlePrivate(type, valList);

	 } else {				// (ESC [ n h) Set Mode
	 					// (ESC [ n l) Reset Mode
						// (ESC [ t;b r) Set Scroll Reg
	    Unimplemented(escStr);
	 }
	 break;

      case 'm': {			// (ESC [ n m) Character Attributes
	 if ( !vsize ) valList.append(zero), vsize++;

//
// Loop through arguments
//
	 count = vsize;
	 for (int i=0; i<count; i++) {

// Process current argument

	    int	val = *valList[i];
	    switch (val) {

	       case 1:		// Bold	
	       case 5:		// Blink
		  curAttr.flags |= BOLD;
		  break;

	       case 4:		// Underline
		  curAttr.flags |= UNDERLINE;
		  break;

	       case 7:		// Inverse
		  curAttr.flags |= INVERSE;
		  break;

	       case 30:
	       case 31:
	       case 32:
	       case 33:
	       case 34:
	       case 35:
	       case 36:
	       case 37:
		  curAttr.fg = val - 30;
		  break;

	       case 40:
	       case 41:
	       case 42:
	       case 43:
	       case 44:
	       case 45:
	       case 46:
	       case 47:
		  curAttr.bg = val - 40;
		  break;

	       default:		// 0
		  curAttr.flags = DRAWN;
		  curAttr.fg = FG_INDEX;
		  curAttr.bg = BG_INDEX;
		  break;

	    } // End switch current arg
	 } // End for each 'm' arg

      } break;

      case 'n':				// (ESC [ n n) Device Status
	 Unimplemented(escStr);
	 break;

      case 'x':				// (ESC [ n x) Request terminal parms
	 Unimplemented(escStr);
	 break;

      default:
	 Unknown(escStr);
	 break;

   } // End switch type

   return;

} // End TermC HandleEscapeLeft

/*----------------------------------------------------------------------
 * Macro to update mode flag
 */

#define HANDLE_PRIVATE_BOOLEAN(type, flag) { \
   switch (type) { \
      case 'h': flags.flag = True;      break; \
      case 'l': flags.flag = False;     break; \
      case 'r': flags.flag = sflags.flag; break; \
      case 's': sflags.flag = flags.flag; break; \
   } \
}

/*----------------------------------------------------------------------
 * Method to report unsupported escape sequences
 */

void
TermC::HandlePrivate(char type, const IntListC& valList)
{
//
// Loop through arguments
//
   int	count = valList.size();
   for (int i=0; i<count; i++) {

// Process current argument

      switch (*valList[i]) {

	 case 1:		// Application/Normal cursor keys
	    HANDLE_PRIVATE_BOOLEAN(type, appCursor)
	    break;

	 case 47:		// Alternate/Normal screen buffer
	    switch (type) {
	       case 'h': AltScreen(True); break;
	       case 'l': AltScreen(False); break;
	       case 'r': AltScreen(sflags.altScrnOn); break;
	       case 's': sflags.altScrnOn = flags.altScrnOn; break;
	    }
	    break;

	 case 3:		// 132/80 columns
	    switch (type) {
	       case 'h': if (flags.allow132) SetCols(132); break;
	       case 'l': if (flags.allow132) SetCols(80); break;
	       case 'r': if (flags.allow132) SetCols(sflags.colCnt); break;
	       case 's': sflags.colCnt = colCnt; break;
	    }
	    break;

	 case 4:		// Smooth/Jump scroll
	    HANDLE_PRIVATE_BOOLEAN(type, smoothScroll)
	    break;

	 case 5: {		// Reverse/Normal video
	    Boolean	reverse = flags.reverseVideo;
	    HANDLE_PRIVATE_BOOLEAN(type, reverseVideo)
	    if ( flags.reverseVideo != reverse ) {
#if 0
	       Pixel	save = fgColor;
	       fgColor = bgColor;
	       bgColor = save;
#endif
	       Refresh();
	    }
	 } break;

	 case 6:		// Origin/Normal cursor mode
	    HANDLE_PRIVATE_BOOLEAN(type, originCursor)
	    break;

	 case 7:		// Yes/No wraparound mode
	    HANDLE_PRIVATE_BOOLEAN(type, autoWrap)
	    break;

	 case 8:		// Yes/No auto-repeat keys
	    HANDLE_PRIVATE_BOOLEAN(type, autoRepeat)
	    break;

	 case 9:		// Yes/No send mouse xy on button press
	    HANDLE_PRIVATE_BOOLEAN(type, sendXYonPress)
	    break;

	 case 40:		// Yes/No allow 80-132
	    HANDLE_PRIVATE_BOOLEAN(type, allow132)
	    break;

	 case 41:		// Yes/No fix curses(5)
	    HANDLE_PRIVATE_BOOLEAN(type, fixCurses)
	    break;

	 case 44:		// Yes/No margin bell
	    HANDLE_PRIVATE_BOOLEAN(type, marginBell)
	    break;

	 case 45:		// Yes/No reverse wraparound
	    HANDLE_PRIVATE_BOOLEAN(type, reverseWrap)
	    break;

	 case 46:		// Start/Stop logging
	    HANDLE_PRIVATE_BOOLEAN(type, logging)
	    break;

	 case 1000:		// Yes/No mouse xy on button
			       //    press/release
	    HANDLE_PRIVATE_BOOLEAN(type, sendXYonPress)
	    HANDLE_PRIVATE_BOOLEAN(type, sendXYonRelease)
	    break;

	 case 1001:		// Yes/No hilite mouse tracking
	    HANDLE_PRIVATE_BOOLEAN(type, hiliteMouse)
	    break;

	 default: {
	    StringC	str("[?");
	    str += type;
	    Unknown(str);
	 } break;

      } // End switch current arg

   } // End for each 'h', 'l', 'r' or 's' arg

   return;

} // End HandlePrivate

/*----------------------------------------------------------------------
 * Method to report unsupported escape sequences
 */

void
TermC::Unimplemented(const char *str)
{
   cerr << "Escape sequence not implemented: " << str NL;
   return;
}

void
TermC::Unknown(const char *str)
{
   cerr << "Unknown escape sequence: " << str NL;
   return;
}

/*----------------------------------------------------------------------
 * Method to display the cursor
 */

void
TermC::ShowCursor()
{
   if ( hideCnt ) hideCnt--;
   if ( cursorOn || hideCnt || !termWin ) return;

   //cout <<"ShowCursor" NL;
   cursorOn = True;
   DrawCursor();

   return;

} // End ShowCursor

/*----------------------------------------------------------------------
 * Method to hide the cursor
 */

void
TermC::HideCursor()
{
   hideCnt++;
   if ( !cursorOn || !termWin ) return;

   //cout <<"HideCursor" NL;
   cursorOn = False;
   TermCharT	tc = scrn->curCharLine[scrn->curCol];
   DrawChar(scrn->curLine, scrn->curCol, tc);

   return;

} // End HideCursor

/*----------------------------------------------------------------------
 * Method to draw the cursor
 */

void
TermC::DrawCursor()
{
   if ( !cursorOn || scrn->curLine < scrn->topLine ||
		     scrn->curLine > scrn->botLine ) return;

   int	x = marginWd + (scrn->curCol * charWd);
   int	y = marginHt
	  + ((scrn->curLine - scrn->topLine) * (charHt + lineSpacing));

//
// Get character and attributes under cursor
//
   TermCharT	tc = scrn->curCharLine[scrn->curCol];

// Draw solid rectangle with focus, hollow without

   if ( focusHere ) {
      XSetForeground(display, termGC, cursorColor);
      XFillRectangle(display, termPixmap, termGC, x, y, charWd, charHt);
      XSetForeground(display, termGC, FgColor(tc));
   } else {
      XSetForeground(display, termGC, FgColor(tc));
      XFillRectangle(display, termPixmap, termGC, x, y, charWd, charHt);
      XSetForeground(display, termGC, cursorColor);
      XDrawRectangle(display, termPixmap, termGC, x, y, charWd-1, charHt-1);
      XSetForeground(display, termGC, BgColor(tc));
   }

// Draw character

   int	cy = y + Ascent(tc);
   if ( Underlined(tc) ) {
      XDrawLine(display, termPixmap, termGC, x, cy+1, x+charWd, cy+1);
   }
   XSetFont(display, termGC, FontId(tc));
   XDrawString(display, termPixmap, termGC, x, cy, &tc.c, 1);

// Copy to visible screen

   if ( !deferCopy ) {
      XCopyArea(display, termPixmap, termWin, termGC, /*srcx*/x, /*srcy*/y,
		charWd, charHt, /*dstx*/x, /*dsty*/y);
   }

   return;

} // End DrawCursor

/*----------------------------------------------------------------------
 * Method to translate keysym into function key value
 */

int
TermC::FKeyValue(KeySym keysym)
{
   switch (keysym) {
      case XK_F1:	return(11);
      case XK_F2:	return(12);
      case XK_F3:	return(13);
      case XK_F4:	return(14);
      case XK_F5:	return(15);
      case XK_F6:	return(17);
      case XK_F7:	return(18);
      case XK_F8:	return(19);
      case XK_F9:	return(20);
      case XK_F10:	return(21);
      case XK_F11:	return(23);
      case XK_F12:	return(24);
      case XK_F13:	return(25);
      case XK_F14:	return(26);
      case XK_F15:	return(28);
      case XK_Help:	return(28);
      case XK_F16:	return(29);
      case XK_Menu:	return(29);
      case XK_F17:	return(31);
      case XK_F18:	return(32);
      case XK_F19:	return(33);
      case XK_F20:	return(34);

      case XK_Find :	return(1);
      case XK_Insert:	return(2);
      case XK_Delete:	return(3);
# if defined(DXK_Remove)
      case DXK_Remove: return(3);
# endif
      case XK_Select:	return(4);
      case XK_Prior:	return(5);
      case XK_Next:	return(6);
      default:	return(-1);
   }

} // End TermC FKeyValue

/*----------------------------------------------------------------------
 * Method to translate keysym into Sun function key value
 */

int 
TermC::SunFKeyValue(KeySym keysym)
{
   switch (keysym) {
      case XK_F1:	return(224);
      case XK_F2:	return(225);
      case XK_F3:	return(226);
      case XK_F4:	return(227);
      case XK_F5:	return(228);
      case XK_F6:	return(229);
      case XK_F7:	return(230);
      case XK_F8:	return(231);
      case XK_F9:	return(232);
      case XK_F10:	return(233);
      case XK_F11:	return(192);
      case XK_F12:	return(193);
      case XK_F13:	return(194);
      case XK_F14:	return(195);
      case XK_F15:	return(196);
      case XK_Help:	return(196);
      case XK_F16:	return(197);
      case XK_Menu:	return(197);
      case XK_F17:	return(198);
      case XK_F18:	return(199);
      case XK_F19:	return(200);
      case XK_F20:	return(201);

      case XK_R1:	return(208);
      case XK_R2:	return(209);
      case XK_R3:	return(210);
      case XK_R4:	return(211);
      case XK_R5:	return(212);
      case XK_R6:	return(213);
      case XK_R7:	return(214);
      case XK_R8:	return(215);
      case XK_R9:	return(216);
      case XK_R10:	return(217);
      case XK_R11:	return(218);
      case XK_R12:	return(219);
      case XK_R13:	return(220);
      case XK_R14:	return(221);
      case XK_R15:	return(222);

      case XK_Find :	return(1);
      case XK_Insert:	return(2);
      case XK_Delete:	return(3);
# if defined(DXK_Remove)
      case DXK_Remove:	return(3);
# endif
      case XK_Select:	return(4);
      case XK_Prior:	return(5);
      case XK_Next:	return(6);
      default:		return(-1);
   }

} // End TermC SunFkeyValue

/*----------------------------------------------------------------------
 * Method to turn alternate screen on or off
 */

void
TermC::AltScreen(Boolean on)
{
   if ( flags.altScrnOn == on ) return;

   //cout <<"AltScreen(" <<(int)on <<")" NL;
   HideCursor();

//
// Point to desired
//
   scrn = on ? &altScrn : &regScrn;
   flags.altScrnOn = on;

   Refresh();

//
// Update scrollbar
//
   int	max = MAX(rowCnt, scrn->lineCnt);
   XtVaSetValues(scrollBar, XmNmaximum, max, XmNvalue, scrn->topLine, NULL);

   ShowCursor();

   return;

} // End TermC AltScreen

/*----------------------------------------------------------------------
 * Method to refresh screen
 */

void
TermC::Refresh()
{
   if ( !termWin ) return;

   HideCursor();
   ClearScreen();

//
// Draw new lines
//
   int	lastLine = MAX(scrn->botLine, scrn->lineCnt-1);
   DrawLines(scrn->topLine, lastLine);
   ShowCursor();

   return;

} // End TermC Refresh

/*----------------------------------------------------------------------
 * Method to clear screen
 */

void
TermC::ClearScreen()
{
   deferCopy++;

   HideCursor();

//
// Clear the screen
//
   XSetForeground(display, termGC, bgColor);
   XFillRectangle(display, termPixmap, termGC, 0, 0, areaWd, areaHt);

   ShowCursor();

   deferCopy--;
   if ( !deferCopy ) {
      XCopyArea(display, termPixmap, termWin, termGC, /*srcx*/0, /*srcy*/0,
		areaWd, areaHt, /*dstx*/0, /*dsty*/0);
   }

   return;

} // End TermC ClearScreen

/*----------------------------------------------------------------------
 * Method to make the given line current
 */

void
TermC::SetCurrentLine(int line)
{
   //cout <<"SetCurrentLine(" <<line <<")" NL;
//
// Update pointers
//
   scrn->curCharLine = scrn->charLines[line];
   scrn->curLine = line;
   //cout <<" new curLine is " <<scrn->curLine NL;

   return;

} // End TermC SetCurrentLine

/*----------------------------------------------------------------------
 * Method to blank out given lines on screen
 */

void
TermC::ClearLines(int first, int last)
{
//
// Loop through lines
//
   for (int i=first; i<colCnt && i<=last; i++) {
      FillCharMem(scrn->charLines[i], initChar, colCnt);
   }

//
// Clear lines from screen
//
   int	x = marginWd;
   int  y = marginHt + ((first - scrn->topLine) * (charHt + lineSpacing));
   int  ht = ((last - first) * (charHt + lineSpacing)) + charHt;

   deferCopy++;

   HideCursor();
   XSetForeground(display, termGC, bgColor);
   XFillRectangle(display, termPixmap, termGC, x, y, areaWd, ht);
   ShowCursor();

   deferCopy--;
   if ( !deferCopy ) {
      XCopyArea(display, termPixmap, termWin, termGC, /*srcx*/x, /*srcy*/y,
		areaWd, ht, /*dstx*/x, /*dsty*/y);
   }

   return;

} // End TermC ClearLines

/*----------------------------------------------------------------------
 * Method to blank out all characters to the end of the current line
 */

void
TermC::ClearCols(int startCol, int endCol)
{
//
// Put blanks in string
//
   int	count = endCol - startCol + 1;
   FillCharMem(&scrn->curCharLine[startCol], initChar, count);

//
// Clear characters from screen
//
   int	sx = marginWd + (startCol * charWd);
   int	ex = marginWd + (endCol   * charWd);
   int	wd = ex - sx + charWd;
   int  y = marginHt
	  + ((scrn->curLine - scrn->topLine) * (charHt + lineSpacing));

   deferCopy++;

   HideCursor();
   XSetForeground(display, termGC, bgColor);
   XFillRectangle(display, termPixmap, termGC, sx, y, wd, charHt);
   ShowCursor();

   deferCopy--;
   if ( !deferCopy ) {
      XCopyArea(display, termPixmap, termWin, termGC, /*srcx*/sx, /*srcy*/y,
		wd, charHt, /*dstx*/sx, /*dsty*/y);
   }

   return;

} // End TermC ClearCols

/*----------------------------------------------------------------------
 * Method to delete given lines
 */

void
TermC::DeleteLines(int first, int last)
{
   //cout <<"DeleteLines(" <<first <<", " <<last <<")" NL;
//
// Move data up
//
   int	dst = first;
   int	src = last + 1;
   while ( src < scrn->maxLines ) {
      memcpy(scrn->charLines[dst++], scrn->charLines[src++],
	     colCnt*sizeof(TermCharT));
   }

//
// Clear out remaining lines
//
   while ( dst < scrn->maxLines ) {
      FillCharMem(scrn->charLines[dst++], initChar, colCnt);
   }

   scrn->lineCnt -= last - first + 1;
   if ( scrn->lineCnt < rowCnt ) scrn->lineCnt = rowCnt;
   //cout <<" new lineCnt is " <<scrn->lineCnt NL;

//
// Reset current pointers
//
   if ( scrn->curLine >= scrn->lineCnt ) {
      scrn->curLine = scrn->lineCnt - 1;
      //cout <<" new curLine is " <<scrn->curLine NL;
   }
   scrn->curCharLine = scrn->charLines[scrn->curLine];

//
// Redraw lines in question
//
   deferCopy++;

   HideCursor();
   int	fy = marginHt + ((first - scrn->topLine) * (charHt + lineSpacing));
   if ( last < scrn->botLine ) {

//
// Pixel copy as much as possible
//
      int	avail = scrn->botLine - last;

      int	ly = marginHt
		   + ((last+1 - scrn->topLine) * (charHt + lineSpacing));
      int	ht = avail * (charHt + lineSpacing);
      XCopyArea(display, termPixmap, termPixmap, termGC, /*srcx*/0, /*srcy*/ly,
		areaWd, ht, /*dstx*/0, /*dsty*/fy);

      first += avail;
   }

//
// Clear area to be redrawn
//
   int  y = marginHt + ((first - scrn->topLine) * (charHt + lineSpacing));
   XSetForeground(display, termGC, bgColor);
   XFillRectangle(display, termPixmap, termGC, 0, y, areaWd, areaHt);
   
//
// Redraw lines that couldn't be copied
//
   DrawLines(first, scrn->botLine);
   ShowCursor();

   deferCopy--;
   if ( !deferCopy ) {
      XCopyArea(display, termPixmap, termWin, termGC, /*srcx*/0, /*srcy*/fy,
		areaWd, areaHt-fy, /*dstx*/0, /*dsty*/fy);
   }

   return;

} // End TermC DeleteLines

/*----------------------------------------------------------------------
 * Method to insert the given number of lines
 */

void
TermC::InsertLines(int count)
{
   //cout <<"InsertLines(" <<count <<")" NL;

//
// See if we're near the bottom of the array
//
   if ( scrn->curLine + count > scrn->maxLines ) {
      count = scrn->maxLines - scrn->curLine;
   }

//
// Move data down
//
   int	dst = scrn->maxLines - 1;
   int	src = dst - count;
   while ( src >= scrn->curLine ) {
      memcpy(scrn->charLines[dst--], scrn->charLines[src--],
	     colCnt*sizeof(TermCharT));
   }

//
// Clear out new lines
//
   while ( dst >= scrn->curLine ) {
      FillCharMem(scrn->charLines[dst--], initChar, colCnt);
   }

   scrn->lineCnt += count;
   if ( scrn->lineCnt > scrn->maxLines ) scrn->lineCnt = scrn->maxLines;
   //cout <<" new lineCnt is " <<scrn->lineCnt NL;

   deferCopy++;

   HideCursor();

//
// Move current line and lines below down by count
//
   int	y = marginHt
	  + ((scrn->curLine - scrn->topLine) * (charHt + lineSpacing));
   int	ht = count * (charHt + lineSpacing);
   XCopyArea(display, termPixmap, termPixmap, termGC, /*srcx*/0, /*srcy*/y,
	     areaWd, areaHt, /*dstx*/0, /*dsty*/y+ht);

//
// Clear new lines
//
   XSetForeground(display, termGC, bgColor);
   XFillRectangle(display, termPixmap, termGC, 0, y, areaWd, ht);

   ShowCursor();

   deferCopy--;
   if ( !deferCopy ) {
      XCopyArea(display, termPixmap, termWin, termGC, /*srcx*/0, /*srcy*/y,
		areaWd, areaHt-y, /*dstx*/0, /*dsty*/y);
   }

   return;

} // End TermC InsertLines

/*----------------------------------------------------------------------
 * Method to execute the specified command
 */

void
TermC::Exec(const char *cmd)
{
   if ( !cmd ) return;

//
// Save this until window pops up, if necessary
//
   if ( !termWin ) {
      initialCmd = cmd;
      return;
   }

//
// Send command to terminal
//
   int	len = strlen(cmd);
   if ( !len ) return;

   write(outputFd, cmd, len);

//
// Send carriage return if not present
//
   if ( cmd[len-1] != '\n' ) write(outputFd, "\n", 1);

   return;

} // End TermC Exec

/*----------------------------------------------------------------------
 * Method to clear the screen
 */

void
TermC::Clear()
{
   AddString("[2J[H");
   write(outputFd, "\r", 1);
}

/*----------------------------------------------------------------------
 * Method to reset the state of the current screen
 */

void
TermC::ResetScreen()
{
   HideCursor();

//
// Reset tabs
//
   memset(tabs, 0, allocCols*sizeof(Boolean));
   for (int i=tabstop; i<allocCols; i+=tabstop) tabs[i] = True;

//
// Switch to primary screen
//
   AltScreen(False);

//
// Clear screen
//
   ClearLines(scrn->topLine, scrn->botLine);

   scrn->curLine = scrn->topLine;
   scrn->curCol  = 0;

   saveLine =
   saveCol  = 0;
   curAttr.flags = DRAWN;
   escStr = "";

//
// Reset flags
//
   flags = sflags = iflags;

//
// Reset menu toggle buttons
//
   XmToggleButtonSetState(allow132TB,      flags.allow132,      False);
   XmToggleButtonSetState(appCursorTB,     flags.appCursor,     False);
   XmToggleButtonSetState(appKeypadTB,     flags.appKeypad,     False);
   XmToggleButtonSetState(autoWrapTB,      flags.autoWrap,      False);
   XmToggleButtonSetState(cutNewlineTB,    flags.cutNewline,    False);
   XmToggleButtonSetState(cutToLeftTB,     flags.cutToLeft,     False);
   XmToggleButtonSetState(fixCursesTB,     flags.fixCurses,     False);
   XmToggleButtonSetState(jumpScrollTB,   !flags.smoothScroll,  False);
   XmToggleButtonSetState(loggingTB,       flags.logging,       False);
   XmToggleButtonSetState(marginBellTB,    flags.marginBell,    False);
   XmToggleButtonSetState(reverseVideoTB,  flags.reverseVideo,  False);
   XmToggleButtonSetState(reverseWrapTB,   flags.reverseWrap,   False);
   XmToggleButtonSetState(scrollBarTB,     flags.scrollBarOn,   False);
   XmToggleButtonSetState(scrollOnKeyTB,   flags.scrollOnKey,   False);
   XmToggleButtonSetState(scrollOnTtyTB,   flags.scrollOnTty,   False);
   XmToggleButtonSetState(signalInhibitTB, flags.signalInhibit, False);
   XmToggleButtonSetState(visualBellTB,    flags.visualBell,    False);

   XtSetSensitive(sigStopPB, !flags.signalInhibit);
   XtSetSensitive(sigContPB, !flags.signalInhibit);
   XtSetSensitive(sigIntPB,  !flags.signalInhibit);
   XtSetSensitive(sigHupPB,  !flags.signalInhibit);
   XtSetSensitive(sigTermPB, !flags.signalInhibit);
   XtSetSensitive(sigKillPB, !flags.signalInhibit);

   ShowCursor();

   return;

} // End TermC ResetScreen

/*----------------------------------------------------------------------
 * Method to set the number of columns in the terminal
 */

void
TermC::SetCols(int newColCnt)
{
//
// Calculate and update the width of the drawing area.  This should cause a
//    resize event
//
   Dimension	width = (marginWd*2) + (charWd * newColCnt);
   XtVaSetValues(termArea, XmNwidth, width, NULL);

} // End TermC SetCols

/*----------------------------------------------------------------------
 * Action proc to handle new selection
 */

void
TermC::HandleSelectStart(Widget w, XButtonEvent *ev, String*, Cardinal*)
{
   //cout <<"HandleSelectStart" NL;

   TermC	*tp;
   XtVaGetValues(w, XmNuserData, &tp, NULL);

//
// Calculate line and column
//
   int	line, col;
   tp->XYtoLC(ev->x, ev->y, line, col);
   //cout <<" Char pos is: " <<line SP col NL;

//
// Add timer to reset click count
//
   if ( tp->clickTimer ) XtRemoveTimeOut(tp->clickTimer);
   tp->clickTimer = XtAppAddTimeOut(tp->context, tp->multiClickTime,
				    (XtTimerCallbackProc)ClickReset,
				    (caddr_t)tp);

//
// Process number of clicks
//
   tp->clickCount++;
   switch ( tp->clickCount ) {

      case 1:

//
// Make this one active
//
	 XmProcessTraversal(tp->termArea, XmTRAVERSE_CURRENT);

//
// Clear current selection
//
	 tp->ClearSelection(tp->selectStartLine, tp->selectStartCol,
			    tp->selectEndLine,   tp->selectEndCol);

//
// Redraw affected lines
//
	 if ( tp->selectStartLine < tp->selectEndLine )
	    tp->DrawLines(tp->selectStartLine, tp->selectEndLine);
	 else
	    tp->DrawLines(tp->selectEndLine, tp->selectStartLine);

//
// Save start line and column
//
	 tp->selectStartLine = tp->selectEndLine = line;
	 tp->selectStartCol  = tp->selectEndCol  = col;
	 break;

      case 2:

//
// Select all chars with matching class around current position
//
	 if ( tp->flags.cutNewline ||
	      tp->selectStartCol <= tp->LastDrawnColumn(tp->selectStartLine) ) {
	    tp->selectEndLine = tp->selectStartLine;
	    tp->SelectCharClass();
	    tp->SetSelection(tp->selectStartLine, tp->selectStartCol,
			     tp->selectEndLine,   tp->selectEndCol);
	    tp->DrawLine(tp->selectStartLine);
	 }
	 break;

      case 3:

//
// Clear current selection
//
	 tp->ClearSelection(tp->selectStartLine, tp->selectStartCol,
			    tp->selectEndLine,   tp->selectEndCol);

//
// Select all chars in current line
//
	 if (tp->flags.cutToLeft) tp->selectStartCol = 0;
	 else                     tp->selectStartCol = col;

	 if (tp->flags.cutNewline) {
	    tp->selectEndLine = tp->selectStartLine + 1;
	    tp->selectEndCol  = 0;
         } else {
	    tp->selectEndLine = tp->selectStartLine;
	    tp->selectEndCol  = tp->LastDrawnColumn(tp->selectEndLine) + 1;
	 }

	 tp->SetSelection(tp->selectStartLine, tp->selectStartCol,
			  tp->selectEndLine,   tp->selectEndCol);
	 tp->DrawLine(tp->selectStartLine);

	 tp->clickCount = 0;
	 break;

   } // End switch number of clicks

   return;

} // End TermC HandleSelectStart

/*----------------------------------------------------------------------
 * Action proc to handle extension of selection
 */

void
TermC::HandleSelectExtend(Widget w, XMotionEvent *ev, String*, Cardinal*)
{
   //cout <<"HandleSelectExtend" NL;

   TermC	*tp;
   XtVaGetValues(w, XmNuserData, &tp, NULL);

//
// Clear current selection
//
   tp->ClearSelection(tp->selectStartLine, tp->selectStartCol,
		      tp->selectEndLine, tp->selectEndCol);

//
// Calculate new line and column
//
   int	line, col;
   tp->XYtoLC(ev->x, ev->y, line, col);
   //cout <<" Char pos is: " <<line SP col NL;

//
// Calculate range of changed lines
//
   int	minLine, maxLine;
   if ( tp->selectStartLine < tp->selectEndLine ) {
      minLine = tp->selectStartLine;
      maxLine = tp->selectEndLine;
   } else {
      minLine = tp->selectEndLine;
      maxLine = tp->selectStartLine;
   }

   if ( line < minLine ) minLine = line;
   else if ( line > maxLine ) maxLine = line;

//
// Save end line and column
//
   tp->selectEndLine = line;
   tp->selectEndCol = col;

//
// Mark new selection
//
   tp->SetSelection(tp->selectStartLine, tp->selectStartCol,
		    tp->selectEndLine, tp->selectEndCol);

//
// Redraw affected lines
//
   tp->DrawLines(minLine, maxLine);

   return;

} // End TermC HandleSelectExtend

/*----------------------------------------------------------------------
 * Action proc to handle selection of end point
 */

void
TermC::HandleStartExtend(Widget w, XButtonEvent *ev, String*, Cardinal*)
{
   //cout <<"HandleStartExtend" NL;

   TermC	*tp;
   XtVaGetValues(w, XmNuserData, &tp, NULL);

//
// Clear current selection
//
   tp->ClearSelection(tp->selectStartLine, tp->selectStartCol,
		      tp->selectEndLine, tp->selectEndCol);

//
// Calculate new line and column
//
   int	line, col;
   tp->XYtoLC(ev->x, ev->y, line, col);
   //cout <<" Char pos is: " <<line SP col NL;

//
// Calculate range of changed lines
//
   int	minLine, maxLine;
   if ( tp->selectStartLine < tp->selectEndLine ) {
      minLine = tp->selectStartLine;
      maxLine = tp->selectEndLine;
   } else {
      minLine = tp->selectEndLine;
      maxLine = tp->selectStartLine;
   }

   if ( line < minLine ) minLine = line;
   else if ( line > maxLine ) maxLine = line;

//
// See if position is close to start or end
//
   if ( tp->RangeSize(tp->selectStartLine, tp->selectStartCol, line, col) <
	tp->RangeSize(tp->selectEndLine, tp->selectEndCol, line, col) ) {
      tp->selectStartLine = line;
      tp->selectStartCol  = col;
   } else {
      tp->selectEndLine = line;
      tp->selectEndCol  = col;
   }

//
// Mark new selection
//
   tp->SetSelection(tp->selectStartLine, tp->selectStartCol,
		    tp->selectEndLine, tp->selectEndCol);

//
// Redraw affected lines
//
   tp->DrawLines(minLine, maxLine);

   return;

} // End TermC HandleStartExtend

/*----------------------------------------------------------------------
 * Method to clear selection bit in specified locations
 */

void
TermC::ClearSelection(int lineA, int colA, int lineB, int colB)
{
//
// Figure out the order of the start and end positions
//
   OrderPositions(&lineA, &colA, &lineB, &colB);

//
// Clear current selection
//
   register TermCharT	*lp = scrn->charLines[lineA];
   register int		l, c;
   if ( lineA == lineB ) {

// Clear between marks

      lp += colA;
      for (c=colA; c<colB; c++, lp++) lp->flags &= ~SELECTED;

   } else { // Multiple lines

// Clear top line to end

      lp += colA;
      for (c=colA; c<colCnt; c++, lp++) lp->flags &= ~SELECTED;

// Clear middle lines entirely

      for (l=lineA+1; l<lineB; l++) {
	 lp = scrn->charLines[l];
	 for (c=0; c<colCnt; c++, lp++) lp->flags &= ~SELECTED;
      }

// Clear bottom line from beginning

      lp = scrn->charLines[lineB];
      for (c=0; c<colB; c++, lp++) lp->flags &= ~SELECTED;

   } // End if multiple lines selected

   return;

} // End TermC ClearSelection

/*----------------------------------------------------------------------
 * Method to set selection bit in specified locations
 */

void
TermC::SetSelection(int lineA, int colA, int lineB, int colB)
{
//
// Figure out the order of the start and end positions
//
   OrderPositions(&lineA, &colA, &lineB, &colB);

//
// Set current selection
//
   register TermCharT	*lp = scrn->charLines[lineA];
   register int		l, c;
   if ( lineA == lineB ) {

// Set between marks

      lp += colA;
      for (c=colA; c<colB; c++, lp++) lp->flags |= SELECTED;

   } else { // Multiple lines

// Set top line to end

      lp += colA;
      for (c=colA; c<colCnt; c++, lp++) lp->flags |= SELECTED;

// Set middle lines entirely

      for (l=lineA+1; l<lineB; l++) {
	 lp = scrn->charLines[l];
	 for (c=0; c<colCnt; c++, lp++) lp->flags |= SELECTED;
      }

// Set bottom line from beginning

      lp = scrn->charLines[lineB];
      for (c=0; c<colB; c++, lp++) lp->flags |= SELECTED;

   } // End if multiple lines selected

   return;

} // End TermC SetSelection

/*----------------------------------------------------------------------
 * Method to set order of two character positions
 */

void
TermC::OrderPositions(int *lineA, int *colA, int *lineB, int *colB)
{
   register int	tmp;

   if ( *lineA < *lineB ) return;

   if ( *lineA > *lineB ) { // They're backward

// Swap lines

      tmp = *lineA;
      *lineA = *lineB;
      *lineB = tmp;

// Swap columns

      tmp = *colA;
      *colA = *colB;
      *colB = tmp;

   } else { // They're equal, maybe swap columns

      if ( *colA < *colB ) return;

// Swap columns

      tmp = *colA;
      *colA = *colB;
      *colB = tmp;
   }

   return;

} // End TermC OrderPositions

/*----------------------------------------------------------------------
 * Method to calculate the number of characters between the given positions
 */

int
TermC::RangeSize(int lineA, int colA, int lineB, int colB)
{
//
// Figure out the order of the start and end positions
//
   OrderPositions(&lineA, &colA, &lineB, &colB);

//
// Count the number of included columns on each row
//
   int	size;
   if ( lineA == lineB ) {

      size = colB - colA;

   } else {	// Multiple lines

// Get size of first line

      size = colCnt/*-1*/ - colA /*+1*/;

// Get size of middle lines

      for (int l=lineA+1; l<lineB; l++) size += colCnt;

// Get size of last line

      size += colB;

   } // End if multiple lines in range

   return size;

} // End TermC RangeSize

/*----------------------------------------------------------------------
 * Action proc to handle release of selection button
 */

void
TermC::HandleSelectEnd(Widget w, XButtonEvent *ev, String*, Cardinal*)
{
   //cout <<"HandleSelectEnd" NL;

   TermC	*tp;
   XtVaGetValues(w, XmNuserData, &tp, NULL);

   if ( tp->selectStartLine == tp->selectEndLine &&
	tp->selectStartCol  == tp->selectEndCol  ) {
      tp->textSelected = False;
      return;
   }

//
// Claim ownership of the primary selection
//
   if ( !XtOwnSelection(tp->termArea, XA_PRIMARY, ev->time,
			(XtConvertSelectionProc)SendSelection,
			(XtLoseSelectionProc)LoseSelection, NULL) ) {

//
// Clear current selection since we can't own it.
//
      tp->ClearSelection(tp->selectStartLine, tp->selectStartCol,
			 tp->selectEndLine, tp->selectEndCol);
      tp->DrawLines(tp->selectStartLine, tp->selectEndLine);
      tp->textSelected = False;
      return;
   }

   tp->textSelected = True;
   return;

} // End TermC HandleSelectEnd

/*----------------------------------------------------------------------
 * Callback to handle loss of primary selection ownership
 */

void
TermC::LoseSelection(Widget w, Atom*)
{
   //cout <<"LoseSelection" NL;

   TermC	*tp;
   XtVaGetValues(w, XmNuserData, &tp, NULL);

//
// Clear current selection since we don't own it.
//
   tp->ClearSelection(tp->selectStartLine, tp->selectStartCol,
		      tp->selectEndLine, tp->selectEndCol);
   tp->DrawLines(tp->selectStartLine, tp->selectEndLine);
   tp->textSelected = False;

} // End TermC LoseSelection

/*----------------------------------------------------------------------
 * Callback to handle request for primary selection
 */

Boolean
TermC::SendSelection(Widget w, Atom *selection, Atom *target, Atom *type,
		     XtPointer *val, unsigned long *len, int *format)
{
   //cout <<"SendSelection " << *selection << " to target " << *target NL;

   TermC	*tp;
   XtVaGetValues(w, XmNuserData, &tp, NULL);

//
// Handle required atoms
//
   if ( *target == XA_TARGETS(tp->display) ) {

      XSelectionRequestEvent *req = XtGetSelectionRequest(w, *selection, NULL);
      Atom		*std_targets;
      unsigned long	std_len;

      XmuConvertStandardSelection(w, req->time, selection, target, type,
				  (caddr_t*)&std_targets, &std_len, format);

      *len = std_len + 3;
      *val = XtMalloc((Cardinal)(sizeof(Atom) * (*len)));
      Atom	*targetP = *(Atom**)val;
      *targetP++ = XA_STRING;
      *targetP++ = XA_TEXT(tp->display);
      *targetP++ = XA_COMPOUND_TEXT(tp->display);
      memcpy(targetP, std_targets, (size_t)(sizeof(Atom) * std_len));
      XtFree((char *)std_targets);
      *type = XA_ATOM;
      *format = sizeof(Atom) * 8;

      return True;

   } else if ( *target != XA_STRING &&
	       *target != XA_TEXT(tp->display) &&
	       *target != XA_COMPOUND_TEXT(tp->display) ) {
      return XmuConvertStandardSelection(w, CurrentTime, selection, target,
				         type, (caddr_t*)val, len, format);
   }

//
// Now handle the targets we are expecting
//
   if ( !tp->textSelected ) return False;

   if ( *target == XA_COMPOUND_TEXT(tp->display) ) *type = *target;
   else						   *type = XA_STRING;

   *format = sizeof(char) * 8;

//
// Figure out the order of the start and end positions
//
   int	lineA = tp->selectStartLine;
   int	colA  = tp->selectStartCol;
   int	lineB = tp->selectEndLine;
   int	colB  = tp->selectEndCol;
   tp->OrderPositions(&lineA, &colA, &lineB, &colB);

//
// Get the length of the selection
//
   *len = tp->RangeSize(lineA, colA, lineB, colB);

//
// Add space for newline characters
//
   *len += lineB - lineA;

//
// Allocate memory for selection data.  This memory will be freed by the
//    Intrinsics since we didn't register an XtSelectionDoneProc
//
   *val = XtMalloc((Cardinal)*len);

//
// Copy current selection
//
   register char	*dst = (char *)(*val);
   register TermCharT	*src = tp->scrn->charLines[lineA];
   register int		l, c;

   if ( lineA == lineB ) {

// Copy between cols

      src += colA;
      for (c=colA; c<colB; c++, src++) {
	 *dst++ = src->c ? src->c : ' ';
      }

   } else { // Multiple lines

// Copy first line to end

      src += colA;
      for (c=colA; c<tp->colCnt; c++, src++) {
	 *dst++ = src->c ? src->c : ' ';
      }
      *dst++ = '\n';

// Copy middle lines entirely

      for (l=lineA+1; l<lineB; l++) {
	 src = tp->scrn->charLines[l];
	 for (c=0; c<tp->colCnt; c++, src++) {
	    *dst++ = src->c ? src->c : ' ';
	 }
	 *dst++ = '\n';
      }

// Copy last line from beginning

      src = tp->scrn->charLines[lineB];
      for (c=0; c<colB; c++, src++) {
	 *dst++ = src->c ? src->c : ' ';
      }

   } // End if multiple lines selected

   return True;

} // End TermC SendSelection

/*----------------------------------------------------------------------
 * Action proc to handle release of paste selection button
 */

void
TermC::HandleInsertSelection(Widget w, XButtonEvent *ev, String*, Cardinal*)
{
//
// Get the selection data
//
   XtGetSelectionValue(w, XA_PRIMARY, XA_STRING,
		       (XtSelectionCallbackProc)ReceiveSelection, NULL,
		       ev->time);

} // End TermC HandleInsertSelection

/*----------------------------------------------------------------------
 * Callback to handle paste of primary selection
 */

void
TermC::ReceiveSelection(Widget w, XtPointer, Atom *, Atom *type, XtPointer val,
			unsigned long *len, int*)
{
   //cout <<"ReceiveSelection " << *selection << " of type " << *type NL;

   TermC	*tp;
   XtVaGetValues(w, XmNuserData, &tp, NULL);

//
// Check for any data
//
   if ( val == NULL || *len == 0 || *type == XT_CONVERT_FAIL ||
	(*type != XA_STRING && *type != XA_TEXT(tp->display) &&
	 *type != XA_COMPOUND_TEXT(tp->display)) ) {
      tp->Bell();
      return;
   }

//
// Write data to pty
//
   write(tp->outputFd, (char *)val, (unsigned)*len);

} // End TermC ReceiveSelection

/*----------------------------------------------------------------------
 * Action proc to handle backward scroll
 */

void
TermC::HandleScrollBack(Widget w, XButtonEvent*, String *parms,
			Cardinal *nparms)
{
   TermC	*tp;
   XtVaGetValues(w, XmNuserData, &tp, NULL);

   int	incr;
   switch (*nparms) {

      case (1):				// Default to lines
	 incr = atoi(parms[0]);
	 break;

      case (2): {
	 char	*p = parms[1];
	 int	cnt = atoi(parms[0]);
	 if ( tp->CompareNoCase(p, "page") ) {
	    incr = tp->rowCnt * cnt;
	 } else if ( tp->CompareNoCase(p, "halfpage") ) {
	    incr = tp->rowCnt * cnt / 2;
         }  else {	// Default to line
	    incr = cnt;
	 }
      } break;

      default: 			// Default to scrollbar increment
	 XtVaGetValues(tp->scrollBar, XmNincrement, &incr, NULL);
	 break;

   } // End switch parameter count

//
// Update the slider position
//
   tp->ScrollUp(incr);
   XtVaSetValues(tp->scrollBar, XmNvalue, tp->scrn->topLine, NULL);

   return;

} // End TermC HandleScrollBack

/*----------------------------------------------------------------------
 * Action proc to handle forward scroll
 */

void
TermC::HandleScrollForw(Widget w, XButtonEvent*, String *parms,
			Cardinal *nparms)
{
   TermC	*tp;
   XtVaGetValues(w, XmNuserData, &tp, NULL);

   int	incr;
   switch (*nparms) {

      case (1):				// Default to lines
	 incr = atoi(parms[0]);
	 break;

      case (2): {
	 char	*p = parms[1];
	 int	cnt = atoi(parms[0]);
	 if ( tp->CompareNoCase(p, "page") ) {
	    incr = tp->rowCnt * cnt;
	 } else if ( tp->CompareNoCase(p, "halfpage") ) {
	    incr = tp->rowCnt * cnt / 2;
         }  else {	// Default to line
	    incr = cnt;
	 }
      } break;

      default: 			// Default to scrollbar increment
	 XtVaGetValues(tp->scrollBar, XmNincrement, &incr, NULL);
	 break;

   } // End switch parameter count

//
// Update the slider position
//
   tp->ScrollDown(incr);
   XtVaSetValues(tp->scrollBar, XmNvalue, tp->scrn->topLine, NULL);

   return;

} // End TermC HandleScrollForw

/*----------------------------------------------------------------------
 * Compare two strings, ignoring case and plurals
 */

Boolean
TermC::CompareNoCase(const char *a, const char *b)
{
   register char	ca, cb;

   if (!a || !b) return False;

   while (True) {

      ca = *a;
      cb = *b;

      if (isascii(ca) && isupper(ca)) {               /* lowercasify */
#ifdef _tolower
	 ca = _tolower (ca);
#else
         ca = tolower (ca);
#endif
      }
      if (ca != cb || ca == '\0') break;  /* if not eq else both nul */
      a++, b++;
   }
   if (cb == '\0' && (ca == '\0' || (ca == 's' && a[1] == '\0')))
      return True;

   return False;

} // End TermC CompareNoCase

/*----------------------------------------------------------------------
 * Action proc to handle popup menu
 */

void
TermC::HandlePopupMenu(Widget w, XButtonEvent *ev, String *parms,
		       Cardinal *nparms)
{
   if ( *nparms < 1 ) return;

   TermC	*tp;
   XtVaGetValues(w, XmNuserData, &tp, NULL);

   Widget	menu;
   if ( strcmp(parms[0], "mainMenu") == 0 ) menu = tp->mainMenu;
   else					    menu = tp->vtMenu;

   XmMenuPosition(menu, (XButtonPressedEvent *)ev);
   XtManageChild(menu);

   return;

} // End TermC HandlePopupMenu

/*----------------------------------------------------------------------
 * Method to parse character class ranges.  Takes a string of the form:
 * 
 *    low[-high]:val[,low[-high]:val[...]]
 * 
 * and sets the indicated ranges to the specified values.
 *
 */

void
TermC::SetCharClasses(const char *s)
{

   extern char *ProgramName;

   if ( !s || !s[0] ) return;

   int	base = 10;			// in case we ever add octal, hex
   int	low = -1;			// bounds of range [0..127]
   int	high = -1;			// bounds of range [0..127]
   int	acc = 0;			// accumulator
   int	numbers = 0;			// count of numbers per range
   int	digits = 0;			// count of digits in a number
   int	len = strlen(s);

   for (register int i=0; i<len; i++) {
      char	c = s[i];

      if ( isspace(c) ) {
	 continue;

      } else if ( isdigit(c) ) {
	 acc = acc * base + (c - '0');
	 digits++;
	 continue;

      } else if (c == '-') {
	 low = acc;
	 acc = 0;
	 if (digits == 0) {
	    cerr << "Missing number in range string \"" << s
		 << "\" (position " << i << ")" NL;
	    return;
	 }
	 digits = 0;
	 numbers++;
	 continue;

      } else if (c == ':') {
	 if (numbers == 0)      low  = acc;
	 else if (numbers == 1) high = acc;
	 else {
	    cerr << "Too many numbers in range string \"" << s
		 << "\" (position " << i << ")" NL;
	    return;
	 }
	 digits = 0;
	 numbers++;
	 acc = 0;
	 continue;

      } else if (c == ',') {	// now, process it

	 if (high < 0) {
	     high = low;
	     numbers++;
	 }
	 if (numbers != 2) {
	    cerr << "Bad value number in range string \"" << s
		 << "\" (position " << i << ")" NL;
	    return;
	 } else if ( !SetCharClassRange(low, high, acc) ) {
	    cerr << "Bad range in range string \"" << s
		 << "\" (position " << i << ")" NL;
	 }

	 low = high = -1;
	 acc = 0;
	 digits = 0;
	 numbers = 0;
	 continue;

      } else {
	 cerr << "Bad character in range string \"" << s
	      << "\" (position " << i << ")" NL;
	 return;
      }

   } // End for each character

   if (low < 0 && high < 0) return;

/*
 * now, process it
 */

   if (high < 0) high = low;
   if (numbers < 1 || numbers > 2) {
      cerr << "Bad value number in range string \"" << s
	   << "\" (position " << i << ")" NL;
   } else if ( !SetCharClassRange (low, high, acc) ) {
      cerr << "Bad range in range string \"" << s
	   << "\" (position " << i << ")" NL;
   }

   return;

} // End TermC SetCharClasses

/*----------------------------------------------------------------------
 * Method to set character class for specified range
 */

Boolean
TermC::SetCharClassRange(int low, int high, int value)
{
   if (low < 0 || high > 255 || high < low) return False;

   for (; low <= high; low++) charClass[low] = value;
   return True;

} // End TermC SetCharClassRange

/*-----------------------------------------------------------------------
 *  Reset the click count after this timeout
 */

void
TermC::ClickReset(TermC *tp, XtIntervalId*)
{
   tp->clickCount = 0;
   tp->clickTimer = (XtIntervalId)NULL;

} // End TermC ClickReset

/*-----------------------------------------------------------------------
 *  Extend the selection to include all neighboring characters in the same
 *     character class
 */

void
TermC::SelectCharClass()
{
   TermCharT	*charLine = scrn->charLines[selectStartLine];
   TermCharT	*tc = charLine + selectStartCol;
   int		cls = charClass[tc->c];

//
// Look to the left
//
   int		startCol = selectStartCol;
   do {
      tc--;
      startCol--;
   } while ( startCol >= 0 && charClass[tc->c] == cls );
   startCol++;

//
// Look to the right
//
   int		endCol   = selectStartCol;
   tc = charLine + selectStartCol;
   do {
      tc++;
      endCol++;
   } while ( endCol < colCnt && charClass[tc->c] == cls );
   //endCol--;  Need to go one past so this one gets highlighted

   selectEndLine  = selectStartLine;
   selectStartCol = startCol;
   selectEndCol   = endCol;

} // End TermC SelectCharClass

/*-----------------------------------------------------------------------
 *  Ring the bell or flash the display
 */

void
TermC::Bell()
{
//
// Ignore this bell if too soon after last one
//
   if ( bellActive ) return;

//
// Beep if necessary
//
   if ( !flags.visualBell ) {
      XBell(display, 0);
      return;
   }

//
// For the visual bell, draw a rectangle in XOR mode, then erase it
//
   Pixel	color = fgColor ^ bgColor;
   XSetFunction(display, termGC, GXxor);
   XSetForeground(display, termGC, color);
   XFillRectangle(display, termWin, termGC, 0, 0, areaWd, areaHt);
   XFlush(display);
   XFillRectangle(display, termWin, termGC, 0, 0, areaWd, areaHt);
   XSetFunction(display, termGC, GXcopy);

//
// Add a timer to suppress subsequent bells
//
   if ( bellSuppressTime > 0 ) {
      XtAppAddTimeOut(context, bellSuppressTime,
		      (XtTimerCallbackProc)BellReset, (caddr_t)this);
      bellActive = True;
   }

} // End TermC Bell

/*-----------------------------------------------------------------------
 *  Reset the bell after this timeout
 */

void
TermC::BellReset(TermC *tp, XtIntervalId*)
{
   tp->bellActive = False;

} // End TermC BellReset

/*-----------------------------------------------------------------------
 *  Determine the rightmost column with valid text in the specified line
 */

int
TermC::LastDrawnColumn(int line)
{
//
// Loop backwards from the end until we find a drawn character
//
   int		i = colCnt - 1;
   TermCharT	*tc = scrn->charLines[line] + i;
   while ( i>=0 && !Drawn(*tc) ) {
      i--;
      tc--;
   }

   return i;

} // End TermC LastDrawnColumn

/*-----------------------------------------------------------------------
 *  Callback to handle press of allow132 toggle button
 */

void
TermC::Allow132CB(Widget, TermC *tp, XmToggleButtonCallbackStruct *tb)
{
   tp->flags.allow132 = tb->set;
}

/*-----------------------------------------------------------------------
 *  Callback to handle press of appCursor toggle button
 */

void
TermC::AppCursorCB(Widget, TermC *tp, XmToggleButtonCallbackStruct *tb)
{
   tp->flags.appCursor = tb->set;
}

/*-----------------------------------------------------------------------
 *  Callback to handle press of appKeypad toggle button
 */

void
TermC::AppKeypadCB(Widget, TermC *tp, XmToggleButtonCallbackStruct *tb)
{
   tp->flags.appKeypad = tb->set;
}

/*-----------------------------------------------------------------------
 *  Callback to handle press of autoWrap toggle button
 */

void
TermC::AutoWrapCB(Widget, TermC *tp, XmToggleButtonCallbackStruct *tb)
{
   tp->flags.autoWrap = tb->set;
}

/*-----------------------------------------------------------------------
 *  Callback to handle press of cutNewline toggle button
 */

void
TermC::CutNewlineCB(Widget, TermC *tp, XmToggleButtonCallbackStruct *tb)
{
   tp->flags.cutNewline = tb->set;
}

/*-----------------------------------------------------------------------
 *  Callback to handle press of cutToLeft toggle button
 */

void
TermC::CutToLeftCB(Widget, TermC *tp, XmToggleButtonCallbackStruct *tb)
{
   tp->flags.cutToLeft = tb->set;
}

/*-----------------------------------------------------------------------
 *  Callback to handle press of fixCurses toggle button
 */

void
TermC::FixCursesCB(Widget, TermC *tp, XmToggleButtonCallbackStruct *tb)
{
   tp->flags.fixCurses = tb->set;
}

/*-----------------------------------------------------------------------
 *  Callback to handle press of fullReset push button
 */

void
TermC::FullResetCB(Widget, TermC *tp, XtPointer)
{
   tp->ResetScreen();
}

/*-----------------------------------------------------------------------
 *  Callback to handle press of jumpScroll toggle button
 */

void
TermC::JumpScrollCB(Widget, TermC *tp, XmToggleButtonCallbackStruct *tb)
{
   tp->flags.smoothScroll = !tb->set;
}

/*-----------------------------------------------------------------------
 *  Callback to handle press of logging toggle button
 */

void
TermC::LoggingCB(Widget, TermC *tp, XmToggleButtonCallbackStruct *tb)
{
   tp->flags.logging = tb->set;
}

/*-----------------------------------------------------------------------
 *  Callback to handle press of marginBell toggle button
 */

void
TermC::MarginBellCB(Widget, TermC *tp, XmToggleButtonCallbackStruct *tb)
{
   tp->flags.marginBell = tb->set;
}

/*-----------------------------------------------------------------------
 *  Callback to handle press of redraw push button
 */

void
TermC::RedrawCB(Widget, TermC *tp, XtPointer)
{
   tp->Refresh();
}

/*-----------------------------------------------------------------------
 *  Callback to handle press of resetClear push button
 */

void
TermC::ResetClearCB(Widget, TermC *tp, XtPointer)
{
//
// Clear out all lines
//
   FillCharMem(tp->scrn->charMem, tp->initChar, tp->scrn->memSize);

//
// Reset line counts
//
   tp->scrn->curLine = tp->scrn->curCol = 0;
   tp->scrn->topLine = 0;
   tp->scrn->botLine = tp->rowCnt - 1;
   tp->scrn->lineCnt = tp->rowCnt;

   tp->HideCursor();
   tp->ClearScreen();
   tp->ShowCursor();

//
// Reset the scrollbar
//
   XtVaSetValues(tp->scrollBar, XmNminimum, 0, XmNmaximum, tp->rowCnt,
				XmNsliderSize, tp->rowCnt, XmNvalue, 0, NULL);

   tp->ResetScreen();

} // End TermC ResetClear

/*-----------------------------------------------------------------------
 *  Callback to handle press of reverseVideo toggle button
 */

void
TermC::ReverseVideoCB(Widget, TermC *tp, XmToggleButtonCallbackStruct *tb)
{
   tp->flags.reverseVideo = tb->set;

#if 0
//
// Swap foreground and background colors, then redraw
//
   Pixel	save = tp->fgColor;
   tp->fgColor = tp->bgColor;
   tp->bgColor = save;
#endif
   tp->Refresh();
}

/*-----------------------------------------------------------------------
 *  Callback to handle press of reverseWrap toggle button
 */

void
TermC::ReverseWrapCB(Widget, TermC *tp, XmToggleButtonCallbackStruct *tb)
{
   tp->flags.reverseWrap = tb->set;
}

/*-----------------------------------------------------------------------
 *  Callback to handle press of scrollBar toggle button
 */

void
TermC::ScrollBarCB(Widget, TermC *tp, XmToggleButtonCallbackStruct *tb)
{
   tp->flags.scrollBarOn = tb->set;

//
// Manage or unmanage the scrollbar
//
   if ( tb->set ) {
      XtManageChild(tp->scrollBar);
      XtVaSetValues(tp->termFrame, XmNrightAttachment, XmATTACH_WIDGET,
				   XmNrightWidget, tp->scrollBar, NULL);
   } else {
      XtVaSetValues(tp->termFrame, XmNrightAttachment, XmATTACH_FORM, NULL);
      XtUnmanageChild(tp->scrollBar);
   }
}

/*-----------------------------------------------------------------------
 *  Callback to handle press of scrollOnKey toggle button
 */

void
TermC::ScrollOnKeyCB(Widget, TermC *tp, XmToggleButtonCallbackStruct *tb)
{
   tp->flags.scrollOnKey = tb->set;
}

/*-----------------------------------------------------------------------
 *  Callback to handle press of scrollOnTty toggle button
 */

void
TermC::ScrollOnTtyCB(Widget, TermC *tp, XmToggleButtonCallbackStruct *tb)
{
   tp->flags.scrollOnTty = tb->set;
}

/*-----------------------------------------------------------------------
 *  Callback to handle press of sigCont push button
 */

void
TermC::SigContCB(Widget, TermC *tp, XtPointer)
{
   kill(tp->pid, SIGCONT);
}

/*-----------------------------------------------------------------------
 *  Callback to handle press of sigHup push button
 */

void
TermC::SigHupCB(Widget, TermC *tp, XtPointer)
{
   kill(tp->pid, SIGHUP);
}

/*-----------------------------------------------------------------------
 *  Callback to handle press of sigInt push button
 */

void
TermC::SigIntCB(Widget, TermC *tp, XtPointer)
{
   kill(tp->pid, SIGINT);
}

/*-----------------------------------------------------------------------
 *  Callback to handle press of sigKill push button
 */

void
TermC::SigKillCB(Widget, TermC *tp, XtPointer)
{
   kill(tp->pid, SIGKILL);
}

/*-----------------------------------------------------------------------
 *  Callback to handle press of sigStop push button
 */

void
TermC::SigStopCB(Widget, TermC *tp, XtPointer)
{
   kill(tp->pid, SIGTSTP);
}

/*-----------------------------------------------------------------------
 *  Callback to handle press of sigTerm push button
 */

void
TermC::SigTermCB(Widget, TermC *tp, XtPointer)
{
   kill(tp->pid, SIGTERM);
}

/*-----------------------------------------------------------------------
 *  Callback to handle press of signalInhibit toggle button
 */

void
TermC::SignalInhibitCB(Widget, TermC *tp, XmToggleButtonCallbackStruct *tb)
{
   tp->flags.signalInhibit = tb->set;

   XtSetSensitive(tp->sigStopPB, !tb->set);
   XtSetSensitive(tp->sigContPB, !tb->set);
   XtSetSensitive(tp->sigIntPB,  !tb->set);
   XtSetSensitive(tp->sigHupPB,  !tb->set);
   XtSetSensitive(tp->sigTermPB, !tb->set);
   XtSetSensitive(tp->sigKillPB, !tb->set);
}

/*-----------------------------------------------------------------------
 *  Callback to handle press of softReset push button
 */

void
TermC::SoftResetCB(Widget, TermC*, XtPointer)
{
}

/*-----------------------------------------------------------------------
 *  Callback to handle press of visualBell toggle button
 */

void
TermC::VisualBellCB(Widget, TermC *tp, XmToggleButtonCallbackStruct *tb)
{
   tp->flags.visualBell = tb->set;
}

/*----------------------------------------------------------------------
 * Action proc for action "TermC-bell"
 */

void
TermC::HandleBell(Widget w, XButtonEvent*, String *parms, Cardinal *nparms)
{
   int	percent = (*nparms) ? atoi(parms[0]) : 0;
   XBell(XtDisplay(w), percent);
}

/*----------------------------------------------------------------------
 * Action proc for action "TermC-visual-bell"
 */

void
TermC::HandleVisualBell(Widget w, XButtonEvent*, String*, Cardinal*)
{
   TermC	*tp;
   XtVaGetValues(w, XmNuserData, &tp, NULL);

   Boolean	save = tp->flags.visualBell;
   tp->flags.visualBell = True;
   tp->Bell();
   tp->flags.visualBell = save;
}

/*----------------------------------------------------------------------
 * Action proc for action "TermC-redraw"
 */

void
TermC::HandleRedraw(Widget w, XButtonEvent*, String*, Cardinal*)
{
   TermC	*tp;
   XtVaGetValues(w, XmNuserData, &tp, NULL);

   tp->Refresh();
}

/*----------------------------------------------------------------------
 * Action proc for action "TermC-send-signal"
 */

void
TermC::HandleSendSignal(Widget w, XButtonEvent*, String *parms,
			Cardinal *nparms)
{
   if ( *nparms < 1 ) return;

   TermC	*tp;
   XtVaGetValues(w, XmNuserData, &tp, NULL);

   char		*parm = parms[0];
   int		sig = -1;

   switch (parm[0]) {

      case 'a':
      case 'A':
	 if ( XmuCompareISOLatin1(parm, "alrm" ) == 0 ||
	      XmuCompareISOLatin1(parm, "alarm") == 0 ) sig = SIGALRM;
	 break;

      case 'c':
      case 'C':
	 if ( XmuCompareISOLatin1(parm, "cont") == 0) sig = SIGCONT;
	 break;

      case 'i':
      case 'I':
	 if ( XmuCompareISOLatin1(parm, "int") == 0) sig = SIGINT;
	 break;

      case 'h':
      case 'H':
	 if ( XmuCompareISOLatin1(parm, "hup") == 0) sig = SIGHUP;
	 break;

      case 'k':
      case 'K':
	 if ( XmuCompareISOLatin1(parm, "kill") == 0) sig = SIGKILL;
	 break;

      case 'q':
      case 'Q':
	 if ( XmuCompareISOLatin1(parm, "quit") == 0) sig = SIGQUIT;
	 break;

      case 's':
      case 'S':
	 if ( XmuCompareISOLatin1(parm, "suspend") == 0) sig = SIGTSTP;
	 break;

      case 't':
      case 'T':
	 if      ( XmuCompareISOLatin1(parm, "tstp") == 0) sig = SIGTSTP;
	 else if ( XmuCompareISOLatin1(parm, "term") == 0) sig = SIGTERM;
	 break;

      default:
	 tp->Bell();
	 return;

   } // End switch first character of parameter

   if ( sig != -1 ) kill(tp->pid, sig);

} // End HandleSendSignal

/*----------------------------------------------------------------------
 * Action proc for action "TermC-string"
 */

void
TermC::HandleString(Widget w, XButtonEvent*, String *parms, Cardinal *nparms)
{
   if ( *nparms < 1 ) return;

   TermC	*tp;
   XtVaGetValues(w, XmNuserData, &tp, NULL);

   char	*parm = parms[0];
   if ( parm[0] == '0' && parm[1] == 'x' && parm[2] != '\0') {

      char	c, *p, hexval[2];
      hexval[0] = hexval[1] = 0;
      for (p = parm+2; (c = *p); p++) {
         hexval[0] *= 16;
         if (isupper(c)) c = tolower(c);
         if (c >= '0' && c <= '9')      hexval[0] += c - '0';
         else if (c >= 'a' && c <= 'f') hexval[0] += c - 'a' + 10;
         else                           break;
      }

      if (c == '\0') write(tp->outputFd, hexval, 1);

   } else {
      write(tp->outputFd, parm, strlen(parm));
   }

} // End TermC HandleString

/*----------------------------------------------------------------------
 * Action proc for action "TermC-set-allow132"
 */

void
TermC::HandleSetAllow132(Widget w, XButtonEvent*, String *parms,
			 Cardinal *nparms)
{
   TermC	*tp;
   XtVaGetValues(w, XmNuserData, &tp, NULL);

   tp->SetToggle(tp->allow132TB, tp->flags.allow132, *nparms, parms[0]);
}

/*----------------------------------------------------------------------
 * Action proc for action "TermC-set-appcursor"
 */

void
TermC::HandleSetAppCursor(Widget w, XButtonEvent*, String *parms,
			  Cardinal *nparms)
{
   TermC	*tp;
   XtVaGetValues(w, XmNuserData, &tp, NULL);

   tp->SetToggle(tp->appCursorTB, tp->flags.appCursor, *nparms, parms[0]);
}

/*----------------------------------------------------------------------
 * Action proc for action "TermC-set-appkeypad"
 */

void
TermC::HandleSetAppKeypad(Widget w, XButtonEvent*, String *parms,
			  Cardinal *nparms)
{
   TermC	*tp;
   XtVaGetValues(w, XmNuserData, &tp, NULL);

   tp->SetToggle(tp->appKeypadTB, tp->flags.appKeypad, *nparms, parms[0]);
}

/*----------------------------------------------------------------------
 * Action proc for action "TermC-set-autowrap"
 */

void
TermC::HandleSetAutoWrap(Widget w, XButtonEvent*, String *parms,
			 Cardinal *nparms)
{
   TermC	*tp;
   XtVaGetValues(w, XmNuserData, &tp, NULL);

   tp->SetToggle(tp->autoWrapTB, tp->flags.autoWrap, *nparms, parms[0]);
}

/*----------------------------------------------------------------------
 * Action proc for action "TermC-set-jumpscroll"
 */

void
TermC::HandleSetJumpScroll(Widget w, XButtonEvent*, String *parms,
			   Cardinal *nparms)
{
   TermC	*tp;
   XtVaGetValues(w, XmNuserData, &tp, NULL);

   tp->SetToggle(tp->jumpScrollTB, !tp->flags.smoothScroll, *nparms, parms[0]);
}

/*----------------------------------------------------------------------
 * Action proc for action "TermC-set-logging"
 */

void
TermC::HandleSetLogging(Widget w, XButtonEvent*, String *parms,
			Cardinal *nparms)
{
   TermC	*tp;
   XtVaGetValues(w, XmNuserData, &tp, NULL);

   tp->SetToggle(tp->loggingTB, tp->flags.logging, *nparms, parms[0]);
}

/*----------------------------------------------------------------------
 * Action proc for action "TermC-set-margin-bell"
 */

void
TermC::HandleSetMarginBell(Widget w, XButtonEvent*, String *parms,
			   Cardinal *nparms)
{
   TermC	*tp;
   XtVaGetValues(w, XmNuserData, &tp, NULL);

   tp->SetToggle(tp->marginBellTB, tp->flags.marginBell, *nparms, parms[0]);
}

/*----------------------------------------------------------------------
 * Action proc for action "TermC-set-reverse-video"
 */

void
TermC::HandleSetReverseVideo(Widget w, XButtonEvent*, String *parms,
			     Cardinal *nparms)
{
   TermC	*tp;
   XtVaGetValues(w, XmNuserData, &tp, NULL);

   tp->SetToggle(tp->reverseVideoTB, tp->flags.reverseVideo, *nparms, parms[0]);
}

/*----------------------------------------------------------------------
 * Action proc for action "TermC-set-reversewrap"
 */

void
TermC::HandleSetReverseWrap(Widget w, XButtonEvent*, String *parms,
			    Cardinal *nparms)
{
   TermC	*tp;
   XtVaGetValues(w, XmNuserData, &tp, NULL);

   tp->SetToggle(tp->reverseWrapTB, tp->flags.reverseWrap, *nparms, parms[0]);
}

/*----------------------------------------------------------------------
 * Action proc for action "TermC-set-scrollbar"
 */

void
TermC::HandleSetScrollBar(Widget w, XButtonEvent*, String *parms,
			  Cardinal *nparms)
{
   TermC	*tp;
   XtVaGetValues(w, XmNuserData, &tp, NULL);

   tp->SetToggle(tp->scrollBarTB, tp->flags.scrollBarOn, *nparms, parms[0]);
}

/*----------------------------------------------------------------------
 * Action proc for action "TermC-set-scroll-on-key"
 */

void
TermC::HandleSetScrollOnKey(Widget w, XButtonEvent*, String *parms,
			    Cardinal *nparms)
{
   TermC	*tp;
   XtVaGetValues(w, XmNuserData, &tp, NULL);

   tp->SetToggle(tp->scrollOnKeyTB, tp->flags.scrollOnKey, *nparms, parms[0]);
}

/*----------------------------------------------------------------------
 * Action proc for action "TermC-set-scroll-on-tty-output"
 */

void
TermC::HandleSetScrollOnTty(Widget w, XButtonEvent*, String *parms,
			    Cardinal *nparms)
{
   TermC	*tp;
   XtVaGetValues(w, XmNuserData, &tp, NULL);

   tp->SetToggle(tp->scrollOnTtyTB, tp->flags.scrollOnTty, *nparms, parms[0]);
}

/*----------------------------------------------------------------------
 * Action proc for action "TermC-set-visual-bell"
 */

void
TermC::HandleSetVisualBell(Widget w, XButtonEvent*, String *parms,
			   Cardinal *nparms)
{
   TermC	*tp;
   XtVaGetValues(w, XmNuserData, &tp, NULL);

   tp->SetToggle(tp->visualBellTB, tp->flags.visualBell, *nparms, parms[0]);
}

/*----------------------------------------------------------------------
 * Action proc for action "TermC-soft-reset"
 */

void
TermC::HandleSoftReset(Widget, XButtonEvent*, String*, Cardinal*)
{
}

/*----------------------------------------------------------------------
 * Action proc for action "TermC-set-hard-reset"
 */

void
TermC::HandleHardReset(Widget w, XButtonEvent*, String*, Cardinal*)
{
   TermC	*tp;
   XtVaGetValues(w, XmNuserData, &tp, NULL);

   tp->ResetScreen();
}

/*----------------------------------------------------------------------
 * Action proc for action "TermC-clear-saved-lines"
 */

void
TermC::HandleResetClear(Widget w, XButtonEvent*, String*, Cardinal*)
{
   TermC	*tp;
   XtVaGetValues(w, XmNuserData, &tp, NULL);

   ResetClearCB(NULL, tp, NULL);
}

/*----------------------------------------------------------------------
 * Method to set toggle button from action routine
 */

void
TermC::SetToggle(Widget tb, Boolean flag, int nparms, const char *parm)
{
   enum { ON, OFF, TOGGLE } type;

   switch (nparms) {

      case 0:
         type = TOGGLE;
	 break;

      case 1:
         if      ( XmuCompareISOLatin1(parm, "on"     ) == 0) type = ON;
         else if ( XmuCompareISOLatin1(parm, "off"    ) == 0) type = OFF;
         else if ( XmuCompareISOLatin1(parm, "toggle" ) == 0) type = TOGGLE;
	 break;

      default:
         Bell();
	 return;

   } // End switch number of parameters

   switch (type) {

      case (ON):
	 if (!flag) XmToggleButtonSetState(tb, True, True);
	 break;

      case (OFF):
	 if (flag) XmToggleButtonSetState(tb, False, True);
	 break;

      case (TOGGLE):
	 XmToggleButtonSetState(tb, !flag, True);
	 break;

   } // End switch type

} // End TermC SetToggle
