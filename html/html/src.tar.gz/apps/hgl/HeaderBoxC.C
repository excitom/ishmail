/*
 * $Id: HeaderBoxC.C,v 1.1 1998/06/24 01:29:07 lang Exp $
 *
 * Copyright (c) 1992 HAL Computer Systems International, Ltd.
 * 
 *          HAL COMPUTER SYSTEMS INTERNATIONAL, LTD.
 *                  1315 Dell Avenue
 *                  Campbell, CA  95008
 *
 * Author: Greg Hilton
 * Contributors: Tom Lang, Frank Bieser, and others
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * http://www.gnu.org/copyleft/gpl.html
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#ifdef ICL
#include <stddef.h>
#endif
#include "HeaderBoxC.h"
#include "hal.xbm"
#include <Xm/Form.h>
#include <Xm/RowColumn.h>
#include <Xm/ToggleB.h>
#include <Xm/LabelG.h>
#include "WArgList.h"

void
HeaderBoxC::Build(Widget parent, const char *name)
{
    WArgList args;

    /*---------------------------------------------------------------
     *  Create the main form
     */

    args.Reset();
    args.LeftAttachment(XmATTACH_FORM);
    args.RightAttachment(XmATTACH_FORM);
    args.TopAttachment(XmATTACH_FORM);
    headerForm = XmCreateForm(parent, (char *)name, ARGS);
    XtManageChild(headerForm);

    args.Reset();
    args.Packing(XmPACK_COLUMN);
    args.Orientation(XmHORIZONTAL);
    args.EntryAlignment(XmALIGNMENT_CENTER);
    args.LeftAttachment(XmATTACH_FORM);
//    args.RightAttachment(XmATTACH_FORM);
    args.TopAttachment(XmATTACH_FORM);
    args.BottomAttachment(XmATTACH_FORM);
    Widget outerRC = XmCreateRowColumn(headerForm, "outerRC", ARGS);
    XtManageChild(outerRC);
    
    args.Reset();
    args.LeftAttachment(XmATTACH_FORM);
    args.TopAttachment(XmATTACH_FORM);
    args.BottomAttachment(XmATTACH_FORM);
    Widget leftRC = XmCreateRowColumn(outerRC, "leftRC", ARGS);
    XtManageChild(leftRC);

    args.Reset();
    Widget heading = XmCreateForm(leftRC, "heading", ARGS);
    XtManageChild(heading);
    
    Pixel fg, bg;
    Pixmap pixmap;
    XtVaGetValues(heading, XmNforeground, &fg, XmNbackground, &bg, NULL);
    pixmap = XCreatePixmapFromBitmapData(XtDisplay(heading),
					 RootWindowOfScreen(XtScreen(heading)),
					 /* these values are defined in "hal.btm" */
					 (char *)hal_bits, 
					 hal_width, 
					 hal_height,
					 fg, bg, DefaultDepthOfScreen(XtScreen(heading)));
    
    args.Reset();
    args.LeftAttachment(XmATTACH_FORM);
    args.LabelType(XmPIXMAP);
    args.LabelPixmap(pixmap);
    args.Alignment(XmALIGNMENT_END);
    Widget icon = XmCreateLabelGadget(heading, "icon", ARGS);
    XtManageChild(icon);
    
    args.Reset();
    args.RightAttachment(XmATTACH_FORM);
    args.LeftAttachment(XmATTACH_WIDGET, icon);
    args.TopAttachment(XmATTACH_FORM);
    args.BottomAttachment(XmATTACH_FORM);
    Widget titleRC = XmCreateRowColumn(heading, "titleRC", ARGS);
    XtManageChild(titleRC);
    
    Widget headerTitle = XmCreateLabelGadget(titleRC, "headerTitle", 0,0);
    XtManageChild(headerTitle);

}

void
HeaderPinBoxC::Build()
{
    Widget headerForm = HeaderForm();

    WArgList	args;
    args.Reset();
    args.RightAttachment(XmATTACH_FORM);
    args.TopAttachment(XmATTACH_FORM);
    args.BottomAttachment(XmATTACH_FORM);
    Widget pushpinForm = XmCreateForm(headerForm, "pushpinForm", ARGS);
    XtManageChild(pushpinForm);

//
// Create the pushpin toggle button in the upper right hand
// of the Dialog (pushpinForm)
//
   args.Reset();
   args.TopAttachment(XmATTACH_FORM);
   args.RightAttachment(XmATTACH_FORM);
   args.BottomAttachment(XmATTACH_FORM);
   pushpinTB = XmCreateToggleButton(pushpinForm, "pushpinTB", ARGS);

   XtManageChild(pushpinTB);
}

/*-----------------------------------------------------------------------
 *  Check whether this dialog has been pinned
 */
int
HeaderPinBoxC::IsPinned()
{
    return (XmToggleButtonGetState(pushpinTB));

} // End HeaderPinBoxC::IsPinned

void
HeaderPinBoxC::IsPinned(Boolean state)
{
    XmToggleButtonSetState(pushpinTB, state, True);
    return;

} // End HeaderPinBoxC::IsPinned
