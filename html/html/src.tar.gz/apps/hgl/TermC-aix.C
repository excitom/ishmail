/*
 *  $Id: TermC-aix.C,v 1.1 1998/06/24 01:29:07 lang Exp $
 *  
 *  Copyright (c) 1994 HAL Computer Systems International, Ltd.
 * 
 *          HAL COMPUTER SYSTEMS INTERNATIONAL, LTD.
 *                  1315 Dell Avenue
 *                  Campbell, CA  95008
 *
 * Author: Greg Hilton
 * Contributors: Tom Lang, Frank Bieser, and others
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * http://www.gnu.org/copyleft/gpl.html
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
   int	tty;
#if defined SUN_OS || defined LINUX
   int	pgrp = getpid();
#elif defined HPUX
   pid_t	pgrp = getpid();
#elif defined SOLARIS || defined OSF1 || defined SVR4
   pid_t	pgrp = setsid();
#endif

   if ( debuglev > 0 )
      cout <<"Child  closing X: " <<ConnectionNumber(halApp->display) <<endl;
   close(ConnectionNumber(halApp->display));

#if defined SUN_OS || defined HPUX || defined LINUX || defined OSF1 || defined SVR4

   if ( debuglev > 0 ) cout <<"Child closing input: " <<inputFd <<endl;
   close(inputFd);

#if defined SVR4 || defined HPUX
   setpgrp();
#endif

//
// Disconnect from parent tty
//
   tty = open("/dev/tty", O_RDWR);
   if ( tty >= 0 ) {
#ifdef TIOCNOTTY
      ioctl(tty, TIOCNOTTY, 0);
#endif
      if ( debuglev > 0 ) cout <<"Child closing tty: " <<tty <<endl;
      close(tty);
   }

#elif defined SOLARIS

   setpgrp();
   grantpt(inputFd);
   unlockpt(inputFd);

#endif

   tty = open(name, O_RDWR);

#if defined SOLARIS
// 
// Now push two modules onto the slaves stream: "ptem" is the pseudo
//    terminal hardware emulation, and "ldterm" is the standard terminal
//    line discipline.
//
   if ( ioctl(tty, I_PUSH, "ptem"    ) < 0	||
	ioctl(tty, I_PUSH, "ldterm"  ) < 0	||
	ioctl(tty, I_PUSH, "ttcompat") < 0 ) {
      exit(-1);
   }

#endif

//
// Make this user the owner
//
   chown(name, uid, gid);
   chmod(name, 0622);

//
// Close all files
//
   for (int i=0; i<=2; i++) {
      if ( i != tty ) {
	 if ( debuglev > 0 ) cout <<"Child closing file: " <<i <<endl;
	 close(i);
	 dup(tty);
      }
   }

#if defined SUN_OS || defined HPUX || defined LINUX || defined OSF1
   if ( tty > 2 ) {
      if ( debuglev > 0 ) cout <<"Child closing tty: " <<tty <<endl;
      close(tty);
   }

#ifdef TIOCSCTTY
   setsid();
   ioctl(0, TIOCSCTTY, 0);
#endif

#ifdef TIOCSPGRP
   ioctl(0, TIOCSPGRP, (char *)&pgrp);
#endif

#if defined SUN_OS
   setpgrp(0,0);
   close(open(name, O_WRONLY, 0));
   setpgrp(0, pgrp);
#elif defined LINUX || defined OSF1
   setpgrp();
#endif

#endif

//
// Set user and group just to be safe
//
   setuid(uid);
   setgid(gid);

#if defined SUN_OS || defined HPUX || defined LINUX || defined OSF1
//
// Restore the child handler
//
   signal(SIGCHLD, SIG_DFL);
   sigsetmask(omask);
#endif
