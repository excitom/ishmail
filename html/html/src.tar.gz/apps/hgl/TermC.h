/*
 * $Id: TermC.h,v 1.1 1998/06/24 01:29:07 lang Exp $
 *
 * Copyright (c) 1992 HaL Computer Systems, Inc.  All rights reserved.
 * 
 *          HAL COMPUTER SYSTEMS INTERNATIONAL, LTD.
 *                  1315 Dell Avenue
 *                  Campbell, CA  95008
 *
 * Author: Greg Hilton
 * Contributors: Tom Lang, Frank Bieser, and others
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * http://www.gnu.org/copyleft/gpl.html
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#ifndef _TermC_h_
#define _TermC_h_

#include "StringC.h"
#include "CallbackC.h"
#include "SignalRegistry.h"

#include <Xm/Xm.h>

class IntListC;

#define COLOR_COUNT	8	// Standard 8-color screen

//----------------------------------------------------------------------------
// Character value and attributes

typedef struct {

   char		c;			// Text character
   char		flags;			// Attributes
   char		bg;			// Background color index (0-9)
   char 	fg;			// Foreground color index (0-9)

} TermCharT;

//----------------------------------------------------------------------------
// Screen dependent state attributes

typedef struct {

   unsigned	memSize;	// Number of bytes allocated for this screen
   TermCharT	*charMem;	// Character data for screen
   TermCharT	**charLines;	// Pointers to beginning of text lines
   TermCharT	*curCharLine;	// Current text line
   int		allocLines;	// Number of lines allocated
   int		maxLines;	// Limit on list size
   int		lineCnt;	// Current list size
   int		curLine;	// Cursor position
   int		curCol;
   int		topLine;	// First visible line
   int		botLine;	// Last visible line

} ScreenStateT;

//----------------------------------------------------------------------------
// Terminal state flags

typedef struct {

   Boolean		allow132;		// Allow size switching
   Boolean		altScrnOn;		// True if using alternate scrn
   Boolean		appCursor;		// Use application cursor keys
   Boolean		appKeypad;		// Use application keypad
   Boolean		autoRepeat;		//
   Boolean		autoWrap;		// Allow auto-wraparound
   int			colCnt;			// Used in save structure only
   Boolean		cutNewline;		// Include \n in triple click
   Boolean		cutToLeft;		// Include begginning to cursor
						//    in triple click
   Boolean		fixCurses;		// Fix bug in curses(5)
   Boolean		hiliteMouse;		// Start hilite mouse tracking
   Boolean		logging;		// Log to file
   Boolean		marginBell;		// Sound bell at margin
   Boolean		originCursor;		//
   Boolean		reverseVideo;		// Switch fg/bg colors
   Boolean		reverseWrap;		//
   Boolean		sendXYonPress;		// Pass pointer location through
   Boolean		sendXYonRelease;	// Pass pointer location through
   Boolean		smoothScroll;		// Use fast scroll
   Boolean		scrollBarOn;		// Display it?
   Boolean		scrollOnTty;		// Auto scroll on input?
   Boolean		scrollOnKey;		// Auto scroll on keystroke?
   Boolean		signalInhibit;		// Inhibit main menu entries?
   Boolean		visualBell;		// Flash instead of beep?

} TermFlagsT;

//----------------------------------------------------------------------------
// Class definition

class TermC {

   enum {
      INVERSE   = 1<<0,
      BOLD      = 1<<1,
      UNDERLINE = 1<<2,
      SELECTED  = 1<<3,
      DRAWN     = 1<<4
   } AttrFlags;

   Widget		topLevel;
   Widget		form;
   Widget		scrollBar;
   Widget		termFrame;
   Widget		termArea;
   Widget		mainMenu;
   Widget		vtMenu;
   Widget		loggingTB;
   Widget		sigStopPB;
   Widget		sigContPB;
   Widget		sigIntPB;
   Widget		sigHupPB;
   Widget		sigTermPB;
   Widget		sigKillPB;
   Widget		appCursorTB;
   Widget		appKeypadTB;
   Widget		autoWrapTB;
   Widget		allow132TB;
   Widget		cutNewlineTB;
   Widget		cutToLeftTB;
   Widget		fixCursesTB;
   Widget		jumpScrollTB;
   Widget		marginBellTB;
   Widget		reverseVideoTB;
   Widget		reverseWrapTB;
   Widget		scrollBarTB;
   Widget		scrollOnTtyTB;
   Widget		scrollOnKeyTB;
   Widget		signalInhibitTB;
   Widget		visualBellTB;

// Drawing attributes

   Window		termWin;
   GC			termGC;
   Pixmap		termPixmap;
   Pixel		fgColor;
   Pixel		bgColor;
   Pixel		cursorColor;
   Pixel		colors[COLOR_COUNT+2];	// Extra for bg and fg
   XFontStruct		*font;
   XFontStruct		*boldFont;
   Display		*display;
   XtAppContext		context;
   int			charWd;
   int			charHt;
   int			lineSpacing;
   Dimension		marginWd;
   Dimension		marginHt;
   Dimension		areaWd;
   Dimension		areaHt;
   Dimension		pixmapWd;
   Dimension		pixmapHt;
   TermCharT		initChar;		// Screen memory initialization
						// value

// Screen dependent state attributes

   ScreenStateT		regScrn;		// State of primary screen
   ScreenStateT		altScrn;		// State of alternate screen
   ScreenStateT		*scrn;			// Pointer to current screen

// Screen independent State attributes

   int			rowCnt;			// Number of visible rows
   int			colCnt;			// Number of visible columns
   int			allocCols;		// Number of columns allocated
   int			saveLines;		// Number of lines to save
   TermCharT		curAttr;		// Current text attributes
   Boolean		focusHere;		// Window has focus
   Boolean		cursorOn;		// Cursor is displayed
   int			hideCnt;		// Number of times hidden
   int			saveLine;		// Saved Cursor position
   int			saveCol;
   int			deferCopy;		// Don't copy data to screen yet
   Boolean		*tabs;			// Pointer to tab settings
   int			clickCount;		// For selecting text
   XtIntervalId		clickTimer;
   Boolean		inputFromUser;		// True if keypress input

// Terminal modes and flags

   int			tabstop;		// Spacing between tabs
   Boolean		sunFKeys;		// Use Sun function keys
   int			bellSuppressTime;	// Keep bells from stacking up
   StringC		charClassDef;		// Used to specify "words" for
						//    double click
   static int		charClass[256];		// Actual class numbers
   static XtActionsRec	actions[29];
   StringC		logFile;		// Used for command logging
   Boolean		logInhibit;		// Disable logging
   int			multiClickTime;		// Identify multi clicks
   int			marginBellRange;	// When to ring margin bell
   Cursor		termCursor;
   Pixel		pointerFgColor;
   Pixel		pointerBgColor;
   int			resizeGravity;		// Which line to fix for resize
   Boolean		bellActive;		// True if suppressing

// Terminal flags

   TermFlagsT		iflags;			// Initial settings
   TermFlagsT		flags;			// Current settings
   TermFlagsT		sflags;			// Saved settings

// Terminal process information

   pid_t		pid;			// Id of child process
   StringC		name;			// Name of device
   int			outputFd;		// Output to tty
   int			inputFd;		// Input from tty
   XtInputId		inputId;
   XtInputId		errorId;

// Used for building escape sequences

   StringC		escStr;
   StringC		initialCmd;		// Execute on startup

//
// Selection information
//
   int			selectStartLine;
   int			selectStartCol;
   int			selectEndLine;
   int			selectEndCol;
   Boolean		textSelected;

//
// Callbacks
//
   CallbackListC	userInputCalls;
   CallbackListC	shellExitCalls;

//
// Input procs
//
   static void	PtyInput(TermC*, int, int);
   static void	PtyError(TermC*, int, int);

//
// Timeout procs
//
   static void	ChildDone2(TermC*, XtIntervalId*);
   static void	ClickReset(TermC*, XtIntervalId*);
   static void	BellReset (TermC*, XtIntervalId*);

//
// Signal handlers
//
   static void	ChildDone(SignalDataT*, TermC*);

//
// Callbacks
//
   static Boolean	SendSelection(Widget, Atom*, Atom*, Atom*, XtPointer*,
				      unsigned long*, int*);
   static void	HandleExpose (Widget, TermC*, XmDrawingAreaCallbackStruct*);
   static void	HandleInput  (Widget, TermC*, XmDrawingAreaCallbackStruct*);
   static void	HandleResize (Widget, TermC*, XtPointer);
   static void	HandleScroll (Widget, TermC*, XmScrollBarCallbackStruct *);
   static void	LoseSelection(Widget, Atom*);
   static void	ReceiveSelection(Widget, XtPointer, Atom*, Atom*, XtPointer,
				 unsigned long*, int*);

   static void	Allow132CB     (Widget, TermC*, XmToggleButtonCallbackStruct*);
   static void	AppCursorCB    (Widget, TermC*, XmToggleButtonCallbackStruct*);
   static void	AppKeypadCB    (Widget, TermC*, XmToggleButtonCallbackStruct*);
   static void	AutoWrapCB     (Widget, TermC*, XmToggleButtonCallbackStruct*);
   static void	CutNewlineCB   (Widget, TermC*, XmToggleButtonCallbackStruct*);
   static void	CutToLeftCB    (Widget, TermC*, XmToggleButtonCallbackStruct*);
   static void	FixCursesCB    (Widget, TermC*, XmToggleButtonCallbackStruct*);
   static void	FullResetCB    (Widget, TermC*, XtPointer);
   static void	JumpScrollCB   (Widget, TermC*, XmToggleButtonCallbackStruct*);
   static void	LoggingCB      (Widget, TermC*, XmToggleButtonCallbackStruct*);
   static void	MarginBellCB   (Widget, TermC*, XmToggleButtonCallbackStruct*);
   static void	RedrawCB       (Widget, TermC*, XtPointer);
   static void	ResetClearCB   (Widget, TermC*, XtPointer);
   static void	ReverseVideoCB (Widget, TermC*, XmToggleButtonCallbackStruct*);
   static void	ReverseWrapCB  (Widget, TermC*, XmToggleButtonCallbackStruct*);
   static void	ScrollBarCB    (Widget, TermC*, XmToggleButtonCallbackStruct*);
   static void	ScrollOnKeyCB  (Widget, TermC*, XmToggleButtonCallbackStruct*);
   static void	ScrollOnTtyCB  (Widget, TermC*, XmToggleButtonCallbackStruct*);
   static void	SigContCB      (Widget, TermC*, XtPointer);
   static void	SigHupCB       (Widget, TermC*, XtPointer);
   static void	SigIntCB       (Widget, TermC*, XtPointer);
   static void	SigKillCB      (Widget, TermC*, XtPointer);
   static void	SigStopCB      (Widget, TermC*, XtPointer);
   static void	SigTermCB      (Widget, TermC*, XtPointer);
   static void	SignalInhibitCB(Widget, TermC*, XmToggleButtonCallbackStruct*);
   static void	SoftResetCB    (Widget, TermC*, XtPointer);
   static void	VisualBellCB   (Widget, TermC*, XmToggleButtonCallbackStruct*);

//
// Event handlers
//
   static void	HandleFocusChange(Widget, TermC*, XFocusChangeEvent*, Boolean*);

//
// Actions procs
//
   static void	HandleBell           (Widget, XButtonEvent*, String*,Cardinal*);
   static void	HandleHardReset      (Widget, XButtonEvent*, String*,Cardinal*);
   static void	HandleInsertSelection(Widget, XButtonEvent*, String*,Cardinal*);
   static void	HandlePopupMenu      (Widget, XButtonEvent*, String*,Cardinal*);
   static void	HandleRedraw         (Widget, XButtonEvent*, String*,Cardinal*);
   static void	HandleResetClear     (Widget, XButtonEvent*, String*,Cardinal*);
   static void	HandleScrollBack     (Widget, XButtonEvent*, String*,Cardinal*);
   static void	HandleScrollForw     (Widget, XButtonEvent*, String*,Cardinal*);
   static void	HandleSelectEnd      (Widget, XButtonEvent*, String*,Cardinal*);
   static void	HandleSelectExtend   (Widget, XMotionEvent*, String*,Cardinal*);
   static void	HandleSelectStart    (Widget, XButtonEvent*, String*,Cardinal*);
   static void	HandleSendSignal     (Widget, XButtonEvent*, String*,Cardinal*);
   static void	HandleSetAllow132    (Widget, XButtonEvent*, String*,Cardinal*);
   static void	HandleSetAppCursor   (Widget, XButtonEvent*, String*,Cardinal*);
   static void	HandleSetAppKeypad   (Widget, XButtonEvent*, String*,Cardinal*);
   static void	HandleSetAutoWrap    (Widget, XButtonEvent*, String*,Cardinal*);
   static void	HandleSetJumpScroll  (Widget, XButtonEvent*, String*,Cardinal*);
   static void	HandleSetLogging     (Widget, XButtonEvent*, String*,Cardinal*);
   static void	HandleSetMarginBell  (Widget, XButtonEvent*, String*,Cardinal*);
   static void	HandleSetReverseVideo(Widget, XButtonEvent*, String*,Cardinal*);
   static void	HandleSetReverseWrap (Widget, XButtonEvent*, String*,Cardinal*);
   static void	HandleSetScrollBar   (Widget, XButtonEvent*, String*,Cardinal*);
   static void	HandleSetScrollOnKey (Widget, XButtonEvent*, String*,Cardinal*);
   static void	HandleSetScrollOnTty (Widget, XButtonEvent*, String*,Cardinal*);
   static void	HandleSetVisualBell  (Widget, XButtonEvent*, String*,Cardinal*);
   static void	HandleSoftReset      (Widget, XButtonEvent*, String*,Cardinal*);
   static void	HandleStartExtend    (Widget, XButtonEvent*, String*,Cardinal*);
   static void	HandleString         (Widget, XButtonEvent*, String*,Cardinal*);
   static void	HandleVisualBell     (Widget, XButtonEvent*, String*,Cardinal*);

//
// Static Methods
//
   static int		FKeyValue(KeySym);
   static void		FillCharMem(TermCharT*, TermCharT, int);
   static int		SunFKeyValue(KeySym);
   static void		OrderPositions(int*, int*, int*, int*);
   static Boolean	CompareNoCase(const char*, const char*);

//
// Methods to access TermCharT attributes
//
   int		Ascent(TermCharT);
   Pixel	BgColor(TermCharT);
   Boolean	Bold(TermCharT);
   Boolean	Drawn(TermCharT);
   Boolean	AttrEqual(TermCharT, TermCharT);
   Pixel	FgColor(TermCharT);
   Font		FontId(TermCharT);
   Boolean	Inverted(TermCharT);
   Boolean	Selected(TermCharT);
   Boolean	Underlined(TermCharT);

//
// General methods
//
   void		AddChar(char);
   void		AddString(const char *);
   void		AltScreen(Boolean);
   void		Bell();
   void		ClearCols(int, int);
   void		ClearScreen();
   void		ClearSelection(int, int, int, int);
   void		ClearLines(int, int);
   void		CloseTty();
   void		DeleteLines(int, int);
   void		DownLine();
   void		DrawChar(int, int, TermCharT);
   void		DrawCursor();
   void		DrawLine(int, int start=0, int end=-1);
   void		DrawLines(int, int, int startCol=0, int endCol=-1);
   void		DrawString(int, int, const StringC&, TermCharT);
   Boolean	FindPty();
   const char	*HandleEscape(const char *);
   void 	HandleEscapeLeft(StringC, char);
   void 	HandlePrivate(char, const IntListC&);
   void		HideCursor();
   void		Initialize();
   void		InsertLines(int);
   int		LastDrawnColumn(int);
   void		NextLine();
   Boolean	OpenTty();
   int		RangeSize(int, int, int, int);
   void		Refresh();
   void		Resize();
   void		ReallocateScreen(ScreenStateT*, int, int);
   void		ReallocateTabs(int);
   void		ResetScreen();
   void		ScrollDown(int);
   void		ScrollUp(int);
   void		SelectCharClass();
   Boolean	SetCharClassRange(int, int, int);
   void		SetCharClasses(const char*);
   void		SetCols(int);
   void		SetCurrentLine(int);
   void		SetSelection(int, int, int, int);
   void		SetToggle(Widget, Boolean, int, const char*);
   void		ShowCursor();
   void		SpawnChild();		// Create pty process
   void		Unimplemented(const char *);
   void		Unknown(const char *);
   void		UpLine();
   void		XYtoLC(int, int, int&, int&);

public:

// Methods

   inline Widget	Form()			{ return form; }
   inline Widget	ScrollBar()		{ return scrollBar; }
   inline Widget	TermFrame()		{ return termFrame; }
   inline Widget	TermArea()		{ return termArea; }

// Widget Constructors
   TermC(Widget parent, const char *name);
   ~TermC();

//
// Execute a command
//
   void		Exec(const char *);

//
// Restart shell process
//
   void		Restart();

//
// Clear screen
//
   void		Clear();

//
// Add user input callbacks
//
   inline void	AddUserInputCallback(CallbackFn *fn, void *data) {
      AddCallback(userInputCalls, fn, data);
   }
   inline void	AddShellExitCallback(CallbackFn *fn, void *data) {
      AddCallback(shellExitCalls, fn, data);
   }

};

#ifdef SYSV
  // signal handlers
  void trap_sigchild(void);
  void child_handler(int);

  // pty defines
  extern "C" {
	int grantpt(int);
  	int unlockpt(int);
  	char *ptsname(int);
	}
#endif


#endif // _TermC_h_
