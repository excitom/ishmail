/*
 * $Id: TreeC.h,v 1.1 1998/06/24 01:29:07 lang Exp $
 *
 * Copyright (c) 1992 HAL Computer Systems International, Ltd.
 * 
 *          HAL COMPUTER SYSTEMS INTERNATIONAL, LTD.
 *                  1315 Dell Avenue
 *                  Campbell, CA  95008
 *
 * Author: Greg Hilton
 * Contributors: Tom Lang, Frank Bieser, and others
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * http://www.gnu.org/copyleft/gpl.html
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

# ifndef _TreeC_h_
# define _TreeC_h_

# include <Xm/Xm.h>
# include "TreeOutline.h"

class TreeC;
class TreeItemListC;
class TreeItemC;

typedef enum {
    TREE_DISPLAY_MANUAL,
    TREE_DISPLAY_ONE_LEVEL
} TreeDisplayMode;

class TreeItemListC {

    public:
	TreeItemListC ();
	TreeItemListC (const TreeItemListC &);
	~TreeItemListC ();

    public:
	TreeItemListC &		operator = (const TreeItemListC &);
	TreeItemC *		operator [] (const int) const;

    public:
	void			add (const TreeItemC *);
	void			remove (const TreeItemC *);
	void			removeAll ();
	unsigned int		size () const;
	Boolean			inList (const TreeItemC *) const;
	TreeItemC *		lookup (Widget) const;

    private:
	unsigned int		_listSize;
	unsigned int		_nItems;
	TreeItemC **		_items;
	static const int	allocSize;
};

class TreeItemC {
    friend class TreeC;
    protected:
	TreeItemC (TreeC &parent, TreeItemC *treeParent = 0);
    public:
	virtual ~TreeItemC ();

    public:
	void			initialize ();
	unsigned int		depth ();
	TreeItemC *		parent ();
	TreeItemListC		children ();
	TreeItemListC		siblings ();
	void			hide (Boolean layout = True);
	void			hideChildren (Boolean layout = True);
	void			hideSiblings (Boolean layout = True);
	void			hideParent (Boolean layout = True);
	void			show (Boolean layout = True);
	void			showChildren (Boolean layout = True);
	void			showSiblings (Boolean layout = True);
	void			showSubtree (Boolean layout = True);
	void			showParent (Boolean layout = True);
	void			showDescendants (Boolean layout = True);
	void			removeChildren ();
	Boolean			visible ();
	TreeC &			tree ();
	virtual void		selected () {}
	virtual void		unselected () {}
	virtual void		hidden () {}
	virtual void		shown () {}
	virtual void		destroyed () {}

    protected:

    public:
				operator Widget ();
        Widget                  GetWidget() {return (_widget); };

    protected:
	Widget			_widget;
	TreeC &			_tree;
	TreeItemC *		_treeParent;

    protected:
	void			recursiveShow ();
	Boolean			anyChildrenShown ();

    private:
	static void		hideSubtreeCB (Widget, TreeItemC *, XtPointer);
	static void		hideChildrenCB (Widget, TreeItemC *, XtPointer);
	static void		hideSiblingsCB (Widget, TreeItemC *, XtPointer);
	static void		showDescendantsCB (Widget, TreeItemC *, XtPointer);
	static void		showChildrenCB (Widget, TreeItemC *, XtPointer);
	static void		showSiblingsCB (Widget, TreeItemC *, XtPointer);
	static void		widgetDestroyedCB (Widget, TreeItemC *, XtPointer);
	static void		mapNotify (Widget, TreeItemC *, XEvent *, Boolean *);
};

class TreeC {
    public:
	TreeC (Widget parent, char *name, TreeDisplayMode mode = TREE_DISPLAY_MANUAL);
	~TreeC ();

    public:
	TreeItemListC		roots ();
	TreeItemListC &		items ();
	void			layout ();
	void			erase ();
	void                    Defer (Boolean);
	void			MakeEast ();
	void			MakeWest ();
	void			MakeSouth ();
	void			MakeNorth ();
	void			MakeTree ();
	void			MakeOutline ();
	void			displayMode (TreeDisplayMode);
	TreeDisplayMode		displayMode ();
	Widget			scrolledWindow ();

    public:
	operator Widget ();
        Widget                  GetTree() {return (_tree); };

    private:
	Widget			_sw;
	Widget			_tree;
	TreeItemListC		_list;
	TreeDisplayMode		_displayMode;
	unsigned 		_deferCount;
	Boolean 		_deferred;
};

# endif
