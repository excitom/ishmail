/*
 * $Id: Db.C,v 1.1 1998/06/24 01:29:07 lang Exp $
 *
 * Copyright (c) 1992 HAL Computer Systems International, Ltd.
 * 
 *          HAL COMPUTER SYSTEMS INTERNATIONAL, LTD.
 *                  1315 Dell Avenue
 *                  Campbell, CA  95008
 *
 * Author: Greg Hilton
 * Contributors: Tom Lang, Frank Bieser, and others
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * http://www.gnu.org/copyleft/gpl.html
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#include <stdio.h>
#include <iostream.h>
#include <unistd.h>
#include <sys/param.h>

#include <X11/Intrinsic.h>

#include "Db.h"

Db::Db()
{
  _numHelpcards = -1;
  strcpy( _version, "Bogus Version Info" );
}

Db::~Db()
{
  closeFile();
  if( _numHelpcards != -1 ) {
    for( int i = 0; i < _numHelpcards; i++ ) {
      delete _titles[ i ];
      delete _titlesCards[ i ];
      delete _cards[ i ];
      delete _locators[ i ];
    }
    delete []_titles;
    delete []_titlesCards;
    delete []_cards;
    delete []_offsets;
    delete []_locators;
    delete []_lengths;
  }
//  cout << "deleting Db object " << endl;
}

int
Db::openFile(const char *filename, const char * /*appName*/, Display *display)
{
   char	fullFilename[MAXPATHLEN];
   char	*path = NULL;

//
// Try using the HELPCARD_PATH variable
//
   const char *helpcard_path = getenv( "HELPCARD_PATH" );
   if ( helpcard_path ) {
      path = XtResolvePathname(display, "help", filename, NULL, helpcard_path,
			       NULL, 0, NULL);
   }

//
// If we don't have a path, try the default search path
//
   if ( !path ) {
      path = XtResolvePathname(display, "help", filename, NULL, NULL, NULL, 0,
			       NULL);
   }

//
// If we still didn't find it, see if we can just access it directly
//
   if ( !path && access(filename, F_OK) == 0 )
      path = (char*)filename;

//
// If we still didn't find it, punt
//
   if ( !path ) {
#if 0
      cerr << "Could not locate helpcard database file: " << filename << endl;
      cerr << "Help will not be available." << endl;
#endif
      return(0);
   }

   strcpy( fullFilename, path );
   if ( path != filename ) XtFree(path);

   _f.open(fullFilename, ios::in);
   if (!_f) {
#if 0
      cerr << "Error opening helpcard database file: " << fullFilename << endl;
      cerr << "Help will not be available." << endl;
#endif
      return(0);
   }

  long pos = 0;
  char c = '\0';
  while( 1 ) {
    _f.seekg( --pos, ios::end );
    _f.get( c );
#ifdef HELP_DB_DEBUG
    cout << "Char at pos: '" << _f.tellg() << "' is: '" << c << "'" << endl;
#endif
    if( ( c == '\n' ) || ( c == ' ' ) ) {
#ifdef HELP_DB_DEBUG
      cout << "Helpcard DB warning: Useless whitespace at end of file."
	   << endl;
#endif
      continue;
    } else
      break;
  }

  while( 1 ) {
    _f.seekg( --pos, ios::end );
    _f.get( c );
#ifdef HELP_DB_DEBUG
    cout << "Char at pos: '" << _f.tellg() << "' is: '" << c << "'" << endl;
#endif
    if( c == '\n' )
      break;
  }
  
  char tmp[ 81 ];
  long globalOffset = 0;
  
  _f.getline( tmp, 80, ':' );
#ifdef HELP_DB_DEBUG
  cout << "Line = '" << tmp << "'" << endl;
#endif
  if( strcmp( tmp, "[TABLE-OFFSET]" ) ) {
    cerr << "Bogus helpcard data file." << endl
	 << "Looks like the 'table offset' value is invalid." << endl
	 << "Likely cause is:" << endl
	 << "Missing '[TABLE-OFFSET]' tag." << endl;
    return( 0 );
  } else {
    _f >> globalOffset;
#ifdef HELP_DB_DEBUG
    cout << "Global offset = '" << globalOffset << "'" << endl;
#endif
      if( globalOffset <= 0 ) {
	cerr << "Table offset must be greater than 0." << endl
	     << "Current 'table offset' value = '" << globalOffset
	     << "'" << endl;
	return( 0 );
      }
  }

  _f.seekg( globalOffset, ios::beg );

  _f.getline( tmp, 80, ':' );
#ifdef HELP_DB_DEBUG
  cout << "Line = '" << tmp << "'" << endl;
#endif
  if( strcmp( tmp, "[VERSION]" ) ) {
    cerr << "Bogus helpcard data file." << endl
	 << "Looks like the 'version' entry is invalid." << endl
	 << "Likely causes are:" << endl
	 << "Missing '[VERSION]' tag, or wrong 'table offset' value." << endl;
    return( 0 );
  } else {
    _f.getline( _version, 80 );
#ifdef HELP_DB_DEBUG
  cout << "Version = '" << _version << "'" << endl;
#endif
  }

  _f.getline( tmp, 80, ':' );
#ifdef HELP_DB_DEBUG
  cout << "Line = '" << tmp << "'" << endl;
#endif
  if( strcmp( tmp, "[NUM-HELPCARDS]" ) ) {
    cerr << "Bogus helpcard data file." << endl
	 << "Looks like the 'num helpcards' value is invalid." << endl
	 << "Likely cause is:" << endl
	 << "Missing '[NUM-HELPCARDS]' tag." << endl;
    return( 0 );
  } else {
    _f >> _numHelpcards;
#ifdef HELP_DB_DEBUG
    cout << "Num helpcards = '" << _numHelpcards << "'" << endl;
#endif
  }

  _f.seekg( 1, ios::cur );  // Move past newline not skipped by previous read.
  _f.getline( tmp, 80 );
#ifdef HELP_DB_DEBUG
  cout << "Line = '" << tmp << "'" << endl;
#endif
  if( strcmp( tmp, "[BEGIN-TABLE]" ) ) {
    cerr << "Bogus helpcard data file." << endl
	 << "Missing '[BEGIN-TABLE]' tag." << endl;
    return( 0 );
  }

  _cards = ( char ** )XtMalloc( _numHelpcards * sizeof( char * ) );
  _offsets = ( int * )XtMalloc( _numHelpcards * sizeof( int ) );
  _locators = ( char ** )XtMalloc( _numHelpcards * sizeof( char * ) );
  _lengths = ( int * )XtMalloc( _numHelpcards * sizeof( int ) );
  for( int i = 0; i < _numHelpcards; i++ ) {
    _f.getline( tmp, 80, ':' );
#ifdef HELP_DB_DEBUG
      cout << "Card name = '" << tmp << "'" << endl;
#endif
    _cards[ i ] = ( char * )XtMalloc( strlen( tmp ) + 1 );
    strcpy( _cards[ i ], tmp );
    _f.getline( tmp, 80, ':' );
#ifdef HELP_DB_DEBUG
      cout << "Offset = '" << tmp << "'" << endl;
#endif
    _offsets[ i ] = atoi( tmp );
    _f.getline( tmp, 80, ':' );
#ifdef HELP_DB_DEBUG
      cout << "Locator = '" << tmp << "'" << endl;
#endif
    _locators[ i ] = ( char * )XtMalloc( strlen( tmp ) + 1 );
    strcpy( _locators[ i ], tmp );
    _f.getline( tmp, 80 );
#ifdef HELP_DB_DEBUG
      cout << "Length = '" << tmp << "'" << endl;
#endif
    _lengths[ i ] = atoi( tmp );
  }

  _f.getline( tmp, 80 );
#ifdef HELP_DB_DEBUG
  cout << "Line = '" << tmp << "'" << endl;
#endif
  if( strcmp( tmp, "[END-TABLE]" ) ) {
    cerr << "Bogus helpcard data file." << endl
	 << "Missing '[END-TABLE]' tag." << endl
	 << "Likely cause is:" << endl
	 << "Wrong number of helpcards." << endl;
    return( 0 );
  }

  _f.getline( tmp, 80 );
#ifdef HELP_DB_DEBUG
  cout << "Line = '" << tmp << "'" << endl;
#endif
  if( strcmp( tmp, "[BEGIN-INDEX]" ) ) {
    cerr << "Bogus helpcard data file." << endl
	 << "Missing '[BEGIN-INDEX]' tag." << endl;
    return( 0 );
  }

  _titles = ( char ** )XtMalloc( _numHelpcards * sizeof( char * ) );
  _titlesCards = ( char ** )XtMalloc( _numHelpcards * sizeof( char * ) );
  for( i = 0; i < _numHelpcards; i++ ) {
    _f.getline( tmp, 80, ':' );
#ifdef HELP_DB_DEBUG
      cout << "Title = '" << tmp << "'" << endl;
#endif
    _titles[ i ] = ( char * )XtMalloc( strlen( tmp ) + 1 );
    strcpy( _titles[ i ], tmp );
    _f.getline( tmp, 80 );
#ifdef HELP_DB_DEBUG
      cout << "Title -> card name = '" << tmp << "'" << endl;
#endif
    _titlesCards[ i ] = ( char * )XtMalloc( strlen( tmp ) + 1 );
    strcpy( _titlesCards[ i ], tmp );
  }

  _f.getline( tmp, 80 );
#ifdef HELP_DB_DEBUG
  cout << "Line = '" << tmp << "'" << endl;
#endif
  if( strcmp( tmp, "[END-INDEX]" ) ) {
    cerr << "Bogus helpcard data file." << endl
	 << "Missing '[END-INDEX]' tag." << endl
	 << "Likely cause is:" << endl
	 << "Wrong number of helpcards." << endl;
    return( 0 );
  }

  return( 1 );  // Successful. 
}

int Db::getCard( const char *cardName, char **locator, char *title,
		char **helpText )
{
  int i = 0;
  Boolean match = False;

  // Return if this Db object isn't being used.
  // See Help::init for why this could happen. 
  if( ! _f ) {
    return( 0 );
  }

//  cout << cardName << endl;
  for( i = 0; i < _numHelpcards; i++ ) {
//    cout << _cards[ i ] << endl;
    if ( ! strcmp( _cards[ i ], cardName ) ) {
//      cout << cardName << " == " << _cards[ i ] << endl;
      match = True;
      break;
    }
  }
  // If no match found... 
  if ( ! match ) {
    *helpText = NULL;
    return( 0 );
  }

  *locator = _locators[ i ];
#ifdef HELP_DB_DEBUG
  cout << "Locator = '" << *locator << "'" << endl;
#endif

  int length = _lengths[ i ];
#ifdef HELP_DB_DEBUG
  cout << "Length = '" << length << "'" << endl;
#endif

  _f.seekg( 0, ios::beg );
  _f.seekg( _offsets[ i ], ios::beg );

  char tmp[ 81 ];
  _f.getline( tmp, 80, ':' );
  if( strcmp( tmp, "[TITLE]" ) ) {
    cerr << "Bogus helpcard data file." << endl
	 << "Missing '[TITLE]' tag." << endl
	 << "Error occurred trying to retrieve helpcard: '" << cardName << "'"
	 << endl;
    return( 0 );
  } else {
    _f.getline( tmp, 80 );
    strcpy( title, tmp );
#ifdef HELP_DB_DEBUG
    cout << "Title = '" << title << "'" << endl;
#endif
  }

  _f.getline( tmp, 80 );
  if( strcmp( tmp, "[BEGIN-TEXT]" ) ) {
    cerr << "Bogus helpcard data file." << endl
	 << "Missing '[BEGIN-TEXT]' tag." << endl
	 << "Error occurred trying to retrieve helpcard: '" << cardName << "'"
	 << endl;
    return( 0 );
  }

  *helpText = ( char * )XtMalloc( length + 1 );
  _f.read( *helpText, length );
  (*helpText)[ length ] = '\0';

  _f.getline( tmp, 80 );
#ifdef HELP_DB_DEBUG
  cout << "Line = '" << tmp << "'" << endl;
#endif
  if( strcmp( tmp, "[END-TEXT]" ) ) {
    cerr << "Bogus helpcard data file." << endl
	 << "Seem to be missing the '[END-TEXT]' tag." << endl
	 << "Likely cause is:" << endl
	 << "Helpcard 'length' value is wrong." << endl
	 << "Error occurred trying to retrieve helpcard: '" << cardName << "'"
	 << endl;
  }

  return( 1 );
}

void Db::closeFile()
{
  if( _f )
    _f.close();
}
