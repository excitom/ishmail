/*
 * $Id: PieChartModC.C,v 1.1 1998/06/24 01:29:07 lang Exp $
 *
 * Copyright (c) 1992 HAL Computer Systems International, Ltd.
 * 
 *          HAL COMPUTER SYSTEMS INTERNATIONAL, LTD.
 *                  1315 Dell Avenue
 *                  Campbell, CA  95008
 *
 * Author: Greg Hilton
 * Contributors: Tom Lang, Frank Bieser, and others
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * http://www.gnu.org/copyleft/gpl.html
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#ifdef ICL
#include <stddef.h>
#endif

#include "PieChartModC.h"

#include "FormatModC.h"
#include "ShadowModC.h"
#include "OrientModC.h"
#include "ColorModC.h"
#include "StringC.h"
#include "WArgList.h"
#include "rsrc.h"

#include <Xm/Form.h>
#include <Xm/Frame.h>
#include <Xm/Label.h>
#include <Xm/LabelG.h>
#include <Xm/TextF.h>
#include <Xm/RowColumn.h>
#include <Xm/ToggleB.h>
#include <Xm/ScrolledW.h>
#include <Xm/List.h>

#define Eprintf(a) printf a
#define Dprintf(a)


// ---------------------------------------------------------------------
//
// Create the paramForm hierarchy
//
//
// paramFrame
//   paramForm
//      title               valueTotal       
//      declination         rotation       
//      pieThickness        lineWidth       
//      showLegend          valueType                   
//      value Type       
//      slice list.
//
// ---------------------------------------------------------------------
PieChartModC::PieChartModC(Widget parent, const char *name, ArgList argv,
		           Cardinal argc)
{
   WArgList	args;
   StringC	wname;

   pieChart   = 0;
   init.slice   = 0;

//
// Create the main form for the whole enchilada.
//
   topForm = XmCreateForm(parent, (char *)name, argv, argc);

   wname = "paramFrame";
   args.Reset();
   args.TopAttachment(XmATTACH_FORM);
   args.LeftAttachment(XmATTACH_FORM);
   args.RightAttachment(XmATTACH_FORM);
   paramFrame = XmCreateFrame(topForm, wname, ARGS);

   wname = "colorFrame";
   args.Reset();
   args.TopAttachment(XmATTACH_WIDGET, paramFrame);
   args.LeftAttachment(XmATTACH_FORM);
   args.RightAttachment(XmATTACH_FORM);
   args.BottomAttachment(XmATTACH_NONE);
   colorFrame = XmCreateFrame(topForm, wname, ARGS);

   wname = "sliceFrame";
   args.Reset();
   args.TopAttachment(XmATTACH_WIDGET, colorFrame);
   args.LeftAttachment(XmATTACH_FORM);
   args.RightAttachment(XmATTACH_FORM);
   args.BottomAttachment(XmATTACH_NONE);
   sliceFrame = XmCreateFrame(topForm, wname, ARGS);

   wname = "paramFrameLabel";
   args.Reset();
   args.ChildType(XmFRAME_TITLE_CHILD);
   args.ChildHorizontalAlignment(XmALIGNMENT_BEGINNING);
   paramFrameLabel = XmCreateLabel(paramFrame, wname, ARGS);

   wname = "paramForm";
   paramForm = XmCreateForm(paramFrame, wname, 0,0);

   wname = "colorFrameLabel";
   args.Reset();
   args.ChildType(XmFRAME_TITLE_CHILD);
   args.ChildHorizontalAlignment(XmALIGNMENT_BEGINNING);
   colorFrameLabel = XmCreateLabel(colorFrame, wname, ARGS);

   wname = "colorForm";
   colorForm = XmCreateForm(colorFrame, wname, 0,0);

   wname = "sliceFrameLabel";
   args.Reset();
   args.ChildType(XmFRAME_TITLE_CHILD);
   args.ChildHorizontalAlignment(XmALIGNMENT_BEGINNING);
   sliceFrameLabel = XmCreateLabel(sliceFrame, wname, ARGS);

   wname = "sliceForm";
   sliceForm = XmCreateForm(sliceFrame, wname, 0, 0);


   int	ltOffset = get_int("PieChartModC", paramForm, "labelTextOffset");

   wname = "title";
   Widget titleForm = LabeledTextField(paramForm, wname,
					     &titleLabel,
					     &titleTF);
   Dprintf(("  titleTF: %d\n", titleTF));
   Dprintf(("  titleTF name: %s\n", XtName(titleTF)));

   wname = "thickness";
   Widget thicknessForm	= LabeledTextField(paramForm, wname,
					   &thicknessLabel,
					   &thicknessTF);

   wname = "declination";
   Widget declinationForm = LabeledTextField(paramForm, wname,
						   &declinationLabel,
						   &declinationTF);

   wname = "lineWidth";
   Widget lineWidthForm = LabeledTextField(paramForm, wname,
						 &lineWidthLabel,
						 &lineWidthTF);

   wname = "rotation";
   Widget rotationForm = LabeledTextField(paramForm, wname,
						&rotationLabel,
						&rotationTF);

   args.Reset();
   args.TopAttachment(XmATTACH_FORM);
   args.LeftAttachment(XmATTACH_WIDGET, titleForm);
   Widget totalForm = XmCreateForm(paramForm, "totalForm", ARGS);

   args.Reset();
   args.LeftAttachment(XmATTACH_FORM);
   args.TopAttachment(XmATTACH_FORM);
   args.BottomAttachment(XmATTACH_FORM);
   args.RightAttachment(XmATTACH_NONE);
   Widget totalLabel = XmCreateLabel(totalForm, "totalLabel", ARGS);

   args.Reset();
   args.LeftAttachment(XmATTACH_FORM);
   args.TopAttachment(XmATTACH_FORM);
   args.BottomAttachment(XmATTACH_FORM);
   args.RightAttachment(XmATTACH_NONE);
   totalNF = new NumericFieldC(totalForm, "totalNF", ARGS);

   XtManageChild(totalLabel);
   XtManageChild(*totalNF);
   XtManageChild(totalForm);

//
// Common Size the labels in column 1.
//
   Dimension	wd, max_wd = 0;
   args.Reset();
   args.Add(XmNwidth, &wd);
   XtGetValues(titleLabel,    ARGS); if (wd>max_wd) max_wd = wd;
   XtGetValues(thicknessLabel,    ARGS); if (wd>max_wd) max_wd = wd;
   XtGetValues(declinationLabel,  ARGS); if (wd>max_wd) max_wd = wd;

   args.Reset();
   args.Width(max_wd);
   args.Alignment(XmALIGNMENT_END);
   XtSetValues(titleLabel, ARGS);
   XtSetValues(thicknessLabel, ARGS);
   XtSetValues(declinationLabel, ARGS);

// Column 2.
   args.Reset();
   args.Add(XmNwidth, &wd);
   XtGetValues(lineWidthLabel, ARGS); if (wd>max_wd) max_wd = wd;
   XtGetValues(rotationLabel,  ARGS); if (wd>max_wd) max_wd = wd;
   XtGetValues(totalLabel,     ARGS); if (wd>max_wd) max_wd = wd;

   args.Reset();
   args.Width(max_wd);
   args.Alignment(XmALIGNMENT_END);
   XtSetValues(lineWidthLabel, ARGS);
   XtSetValues(rotationLabel, ARGS);
   XtSetValues(totalLabel, ARGS);

//
// Attach everything...
//
   args.Reset();
   args.TopAttachment(XmATTACH_WIDGET, titleForm);
   XtSetValues(thicknessForm, ARGS);

   args.Reset();
   args.TopAttachment(XmATTACH_WIDGET, thicknessForm);
   args.LeftAttachment(XmATTACH_FORM);
   XtSetValues(declinationForm, ARGS);

   args.Reset();
   args.TopAttachment(XmATTACH_WIDGET, titleForm);
   args.LeftAttachment(XmATTACH_WIDGET, thicknessForm);
   XtSetValues(lineWidthForm, ARGS);

   args.Reset();
   args.TopAttachment(XmATTACH_WIDGET, thicknessForm);
   args.LeftAttachment(XmATTACH_WIDGET, declinationForm);
   XtSetValues(rotationForm, ARGS);

//
// A box with the visibility toggles.
//
   args.Reset();
   args.TopAttachment(XmATTACH_WIDGET, declinationForm);
   args.LeftAttachment(XmATTACH_FORM );
   Widget visForm = XmCreateForm(paramForm,"visForm", ARGS);

   args.Reset();
   args.TopAttachment(XmATTACH_FORM);
   args.LeftAttachment(XmATTACH_FORM);
   args.BottomAttachment(XmATTACH_FORM);
   args.RightAttachment(XmATTACH_NONE);
   Widget visLabel = XmCreateLabel(visForm,"visLabel", ARGS);
   XtManageChild(visLabel);

   args.Reset();
   args.TopAttachment(XmATTACH_FORM);
   args.LeftAttachment(XmATTACH_WIDGET, visLabel);
   args.BottomAttachment(XmATTACH_FORM);
   Widget visFrame = XmCreateFrame(visForm,"visFrame", ARGS);

   args.Reset();
   args.Packing(XmPACK_TIGHT);
   args.Orientation(XmHORIZONTAL);
   Widget visRC = XmCreateRowColumn(visFrame,"visRC", ARGS);

   args.Reset();
   legendVisTB = XmCreateToggleButton(visRC,"legendVisTB", ARGS);
   XtManageChild(legendVisTB);

   legendTextShadowTB = XmCreateToggleButton(visRC,"legendTextShadowTB", ARGS);
   XtManageChild(legendTextShadowTB);

   titleTextShadowTB = XmCreateToggleButton(visRC,"titleTextShadowTB", ARGS);
   XtManageChild(titleTextShadowTB);

   labelTextShadowTB = XmCreateToggleButton(visRC,"labelTextShadowTB", ARGS);
   XtManageChild(labelTextShadowTB);

   XtManageChild(visRC);
   XtManageChild(visFrame);
   XtManageChild(visForm);

//
// Add the format modifier.
//
   legendValueTypeMod = new ValueTypeModC(paramForm, "legendValueTypeMod");
   labelValueTypeMod  = new ValueTypeModC(paramForm, "labelValueTypeMod");
   max_wd = 0;
   args.Reset();
   args.Add(XmNwidth, &wd);
   // XtGetValues(visLabel, ARGS); if (wd>max_wd) max_wd = wd;
   XtGetValues(legendValueTypeMod->Label(), ARGS); if (wd>max_wd) max_wd = wd;
   XtGetValues(labelValueTypeMod->Label(), ARGS);  if (wd>max_wd) max_wd = wd;
   args.Reset();
   args.Width(max_wd);
   args.Alignment(XmALIGNMENT_END);
   // XtSetValues(visLabel, ARGS);
   XtSetValues(legendValueTypeMod->Label(), ARGS);
   XtSetValues(labelValueTypeMod->Label(), ARGS);

//
// Position the type modifiers.
//
   args.Reset();
   args.LeftAttachment(XmATTACH_FORM);
   args.TopAttachment(XmATTACH_WIDGET, legendVisTB);
   XtSetValues(*legendValueTypeMod, ARGS);

   args.Reset();
   args.LeftAttachment(XmATTACH_FORM);
   args.TopAttachment(XmATTACH_WIDGET, *legendValueTypeMod);
   XtSetValues(*labelValueTypeMod, ARGS);

//
// Provide color editors for the colors of the pie chart excluding slices.
//
// backgroundColorMod  lineColorMod
// titleTextColorMod   titleShadowColorMod
// labelTextColorMod   labelShadowColorMod
// legendTextColorMod  legendShadowColorMod
//
   wname = "backgroundColorMod";
   args.Reset();
   args.LeftAttachment(XmATTACH_FORM);
   args.TopAttachment(XmATTACH_FORM);
   backgroundColorMod = new ColorModC(colorForm, wname, ARGS);

   wname = "lineColorMod";
   args.Reset();
   args.LeftAttachment(XmATTACH_WIDGET, *backgroundColorMod);
   args.TopAttachment(XmATTACH_FORM);
   lineColorMod = new ColorModC(colorForm, wname, ARGS);

   wname = "titleTextColorMod";
   args.Reset();
   args.LeftAttachment(XmATTACH_FORM);
   args.TopAttachment(XmATTACH_WIDGET, *backgroundColorMod);
   titleTextColorMod = new ColorModC(colorForm, wname, ARGS);

   wname = "titleShadowColorMod";
   args.Reset();
   args.LeftAttachment(XmATTACH_WIDGET, *titleTextColorMod);
   args.TopAttachment(XmATTACH_WIDGET, *lineColorMod);
   titleShadowColorMod = new ColorModC(colorForm, wname, ARGS);

   wname = "labelTextColorMod";
   args.Reset();
   args.TopAttachment(XmATTACH_WIDGET, *titleTextColorMod);
   args.LeftAttachment(XmATTACH_FORM);
   labelTextColorMod = new ColorModC(colorForm, wname, ARGS);

   wname = "labelShadowColorMod";
   args.Reset();
   args.TopAttachment(XmATTACH_WIDGET, *titleTextColorMod);
   args.LeftAttachment(XmATTACH_WIDGET, *labelTextColorMod);
   labelShadowColorMod = new ColorModC(colorForm, wname, ARGS);

   wname = "legendTextColorMod";
   args.Reset();
   args.LeftAttachment(XmATTACH_FORM);
   args.TopAttachment(XmATTACH_WIDGET, *labelShadowColorMod);
   legendTextColorMod = new ColorModC(colorForm, wname, ARGS);

   wname = "legendShadowColorMod";
   args.Reset();
   args.LeftAttachment(XmATTACH_WIDGET, *legendTextColorMod);
   args.TopAttachment(XmATTACH_WIDGET, *labelShadowColorMod);
   legendShadowColorMod = new ColorModC(colorForm, wname, ARGS);

//
// Resize the labels of the color modifiers.
//
   max_wd = 0;
   args.Reset();
   args.Add(XmNwidth, &wd);
   XtGetValues(backgroundColorMod->Label(), ARGS); if (wd>max_wd) max_wd = wd;
   XtGetValues(titleTextColorMod->Label(),  ARGS); if (wd>max_wd) max_wd = wd;
   XtGetValues(labelTextColorMod->Label(),  ARGS); if (wd>max_wd) max_wd = wd;
   XtGetValues(legendTextColorMod->Label(), ARGS); if (wd>max_wd) max_wd = wd;

   args.Reset();
   args.Width(max_wd);
   args.Alignment(XmALIGNMENT_END);
   XtSetValues(backgroundColorMod->Label(), ARGS);
   XtSetValues(titleTextColorMod->Label(),  ARGS);
   XtSetValues(labelTextColorMod->Label(),  ARGS);
   XtSetValues(legendTextColorMod->Label(), ARGS);

//
// Resize the labels of the color modifiers.
//
   max_wd = 0;
   args.Reset();
   args.Add(XmNwidth, &wd);
   XtGetValues(lineColorMod->Label(),         ARGS); if (wd>max_wd) max_wd = wd;
   XtGetValues(titleShadowColorMod->Label(),  ARGS); if (wd>max_wd) max_wd = wd;
   XtGetValues(labelShadowColorMod->Label(),  ARGS); if (wd>max_wd) max_wd = wd;
   XtGetValues(legendShadowColorMod->Label(), ARGS); if (wd>max_wd) max_wd = wd;

   args.Reset();
   args.Width(max_wd);
   args.Alignment(XmALIGNMENT_END);
   XtSetValues(lineColorMod->Label(),         ARGS);
   XtSetValues(titleShadowColorMod->Label(),  ARGS);
   XtSetValues(labelShadowColorMod->Label(),  ARGS);
   XtSetValues(legendShadowColorMod->Label(), ARGS);

//
// Slice values...
//
//    Slice list...
//    label     topColor
//    value     innerEdgeColor
//    offset    outerEdgeColor
//    lineWidth
//    *lineColor
//
// * maybe later...
//
   wname = "sliceListLabel";
   args.Reset();
   args.LeftAttachment(XmATTACH_FORM);
   args.TopAttachment(XmATTACH_FORM);
   args.BottomAttachment(XmATTACH_NONE);
   args.RightAttachment(XmATTACH_NONE);
   Widget sliceListLabel = XmCreateLabel(sliceForm, wname, ARGS);
   XtManageChild(sliceListLabel);

   wname = "sliceListSW";
   args.Reset();
   // args.LeftAttachment(XmATTACH_FORM);
   // args.TopAttachment(XmATTACH_WIDGET, sliceListLabel);
   args.LeftAttachment(XmATTACH_WIDGET, sliceListLabel);
   args.TopAttachment(XmATTACH_FORM);
   args.BottomAttachment(XmATTACH_FORM);
   args.RightAttachment(XmATTACH_NONE);
   sliceListSW = XmCreateScrolledWindow(sliceForm,wname,ARGS);

   wname = "sliceList";
   args.Reset();
   args.SelectionPolicy(XmSINGLE_SELECT);
   sliceList = XmCreateList(sliceListSW,wname,ARGS);
   XtManageChild(sliceList);
   Dprintf(("  sliceList widget: %d\n", sliceList));

   XtAddCallback(sliceList,XmNsingleSelectionCallback,
		 (XtCallbackProc)DoSelectSlice, (XtPointer)this);

   wname = "sliceLabel";
   sliceLabelForm = LabeledTextField(sliceForm, wname,
					  &sliceLabelLabel,
					  &sliceLabelTF);

   wname = "sliceValue";
   sliceValueForm = LabeledTextField(sliceForm, wname,
					   &sliceValueLabel,
					   &sliceValueTF);

   wname = "sliceOffset";
   sliceOffsetForm = LabeledTextField(sliceForm, wname,
					    &sliceOffsetLabel,
					    &sliceOffsetTF);



   args.Reset();
   args.TopAttachment(XmATTACH_WIDGET, sliceOffsetForm);
   args.LeftAttachment(XmATTACH_WIDGET, sliceListSW);
   args.TopAttachment(XmATTACH_NONE);
   args.BottomAttachment(XmATTACH_NONE);
   Widget sliceLineWidthForm = XmCreateForm(sliceForm, "sliceLineWidthForm", ARGS);

   args.Reset();
   args.TopAttachment(XmATTACH_FORM);
   args.LeftAttachment(XmATTACH_FORM);
   args.RightAttachment(XmATTACH_NONE);
   args.BottomAttachment(XmATTACH_FORM);
   Widget sliceLineWidthLabel = XmCreateLabel(sliceLineWidthForm, "sliceLineWidthLabel", ARGS);

   args.Reset();
   args.TopAttachment(XmATTACH_FORM);
   args.LeftAttachment(XmATTACH_WIDGET, sliceLineWidthLabel);
   args.RightAttachment(XmATTACH_NONE);
   args.BottomAttachment(XmATTACH_FORM);
   sliceLineWidthNF = new NumericFieldC(sliceLineWidthForm, "sliceLineWidthNF", ARGS);
   sliceLineWidthNF->SetPrecision(0);

   XtManageChild(sliceLineWidthLabel);
   XtManageChild(*sliceLineWidthNF);
   XtManageChild(sliceLineWidthForm);

   wname = "sliceTopColorMod";
   args.Reset();
   args.LeftAttachment(XmATTACH_WIDGET,sliceLabelTF);
   args.TopAttachment(XmATTACH_FORM);
   sliceTopColorMod = new ColorModC(sliceForm, wname, ARGS);

   wname = "sliceInnerColorMod";
   args.Reset();
   args.LeftAttachment(XmATTACH_WIDGET,sliceLabelTF);
   args.TopAttachment(XmATTACH_WIDGET, *sliceTopColorMod);
   sliceInnerColorMod = new ColorModC(sliceForm, wname, ARGS);

   wname = "sliceOuterColorMod";
   args.Reset();
   args.LeftAttachment(XmATTACH_WIDGET,sliceLabelTF);
   args.TopAttachment(XmATTACH_WIDGET, *sliceInnerColorMod);
   sliceOuterColorMod = new ColorModC(sliceForm, wname, ARGS);

//
// Resize the pie chart modifier slice information label widgets.
//
   max_wd = 0;
   args.Reset();
   args.Add(XmNwidth, &wd);
   XtGetValues(sliceLabelLabel,     ARGS); if (wd>max_wd) max_wd = wd;
   XtGetValues(sliceValueLabel,     ARGS); if (wd>max_wd) max_wd = wd;
   XtGetValues(sliceOffsetLabel,    ARGS); if (wd>max_wd) max_wd = wd;
   XtGetValues(sliceLineWidthLabel, ARGS); if (wd>max_wd) max_wd = wd;

   args.Reset();
   args.Width(max_wd);
   args.Alignment(XmALIGNMENT_END);
   XtSetValues(sliceLabelLabel,     ARGS);
   XtSetValues(sliceValueLabel,     ARGS);
   XtSetValues(sliceOffsetLabel,    ARGS);
   XtSetValues(sliceLineWidthLabel, ARGS);

   max_wd = 0;
   args.Reset();
   args.Add(XmNwidth, &wd);
   XtGetValues(sliceTopColorMod->Label(),   ARGS); if (wd>max_wd) max_wd = wd;
   XtGetValues(sliceInnerColorMod->Label(), ARGS); if (wd>max_wd) max_wd = wd;
   XtGetValues(sliceOuterColorMod->Label(), ARGS); if (wd>max_wd) max_wd = wd;

   args.Reset();
   args.Width(max_wd);
   args.Alignment(XmALIGNMENT_END);
   XtSetValues(sliceTopColorMod->Label(),   ARGS);
   XtSetValues(sliceInnerColorMod->Label(), ARGS);
   XtSetValues(sliceOuterColorMod->Label(), ARGS);

//
// Attach some widgets...
//
   args.Reset();
   args.TopAttachment(XmATTACH_FORM);
   args.LeftAttachment(XmATTACH_WIDGET, sliceListSW);
   XtSetValues(sliceLabelForm, ARGS);

   args.Reset();
   args.TopAttachment(XmATTACH_WIDGET, sliceLabelForm);
   args.LeftAttachment(XmATTACH_WIDGET, sliceListSW);
   XtSetValues(sliceValueForm, ARGS);

   args.Reset();
   args.TopAttachment(XmATTACH_WIDGET, sliceValueForm);
   args.LeftAttachment(XmATTACH_WIDGET, sliceListSW);
   XtSetValues(sliceOffsetForm, ARGS);

//
// Manage the widgets in reverse order for sizing.
//
   XtManageChild(titleForm);
   XtManageChild(thicknessForm);
   XtManageChild(lineWidthForm);
   XtManageChild(declinationForm);
   XtManageChild(rotationForm);
   XtManageChild(legendVisTB);
   XtManageChild(*labelValueTypeMod);
   XtManageChild(*legendValueTypeMod);

   XtManageChild(*backgroundColorMod);
   XtManageChild(*lineColorMod);
   XtManageChild(*titleTextColorMod);
   XtManageChild(*titleShadowColorMod);
   XtManageChild(*labelTextColorMod);
   XtManageChild(*labelShadowColorMod);
   XtManageChild(*legendTextColorMod);
   XtManageChild(*legendShadowColorMod);

   XtManageChild(sliceListSW);
   XtManageChild(sliceLabelForm);
   XtManageChild(sliceValueForm);
   XtManageChild(sliceOffsetForm);
   XtManageChild(sliceLineWidthForm);
   XtManageChild(*sliceTopColorMod);
   XtManageChild(*sliceInnerColorMod);
   XtManageChild(*sliceOuterColorMod);

   XtManageChild(sliceFrame);
   XtManageChild(sliceFrameLabel);
   XtManageChild(sliceForm);

   XtManageChild(paramFrame);
   XtManageChild(paramFrameLabel);
   XtManageChild(paramForm);

   XtManageChild(colorFrame);
   XtManageChild(colorFrameLabel);
   XtManageChild(colorForm);

   XtManageChild(topForm);

} // End PieChartModC PieChartModC


// =====================================================================
//  Destructor
// =====================================================================
PieChartModC::~PieChartModC()
{
   delete backgroundColorMod;
   delete legendTextColorMod;
   delete legendShadowColorMod;
   delete lineColorMod;
   delete titleTextColorMod;
   delete titleShadowColorMod;
   delete labelTextColorMod;
   delete labelShadowColorMod;
   delete sliceTopColorMod;
   delete sliceInnerColorMod;
   delete sliceOuterColorMod;
   delete sliceLineWidthNF;
   delete totalNF;
}


// =====================================================================
// Method to apply pie changes
// =====================================================================
void
PieChartModC::Apply(PieChartC& pie)
{
   Dprintf(("***************\n"));
   Dprintf(("Entering Apply\n"));

   pie.Defer(True);

   char *str;
   str = XmTextFieldGetString(titleTF);
   pie.Title(str);
   XtFree(str);

   str = XmTextFieldGetString(declinationTF);
   pie.Declination(atoi(str));
   XtFree(str);

   str = XmTextFieldGetString(rotationTF);
   // pie.Rotation(atoi(str));
   pie.StartAngle(atoi(str));
   XtFree(str);

   str = XmTextFieldGetString(thicknessTF);
   pie.Thickness(atoi(str));
   XtFree(str);

   str = XmTextFieldGetString(lineWidthTF);
   pie.LineWidth(atoi(str));
   XtFree(str);

   pie.ShowLegend(XmToggleButtonGetState(legendVisTB));
   pie.LegendTextShadow(XmToggleButtonGetState(legendTextShadowTB));
   pie.TitleTextShadow(XmToggleButtonGetState(titleTextShadowTB));
   pie.LabelTextShadow(XmToggleButtonGetState(labelTextShadowTB));

//
// Apply the colors.
//
/*
   for (int i=0; i<PieChartC::COLOR_ATTR_COUNT; i++) {
      ColorModC	*cm = colorForm[i];
      if ( cm->Changed() ) {
	 pie.SetColor((PieChartC::PieChartColorAttr)i, cm->Value());
      }
   }
*/
   pie.BackgroundColor(backgroundColorMod->Value());
   pie.TitleTextColor(titleTextColorMod->Value());
   pie.TitleTextShadowColor(titleShadowColorMod->Value());
   pie.LegendTextColor(legendTextColorMod->Value());
   pie.LegendTextShadowColor(legendShadowColorMod->Value());
   pie.LabelTextColor(labelTextColorMod->Value());
   pie.LabelTextShadowColor(labelShadowColorMod->Value());
   pie.LineColor(lineColorMod->Value());

//
// Apply the Format identifiers.
//
   pie.LegendValueType(legendValueTypeMod->Type(),
		       legendValueTypeMod->Precision());
   pie.LabelValueType(labelValueTypeMod->Type(),
                      labelValueTypeMod->Precision());

//
// Apply the slice values.
//
   if ( init.slice )
   {
      str = XmTextFieldGetString(sliceLabelTF);
      init.slice->Label(str);
      XtFree(str);

      str = XmTextFieldGetString(sliceValueTF);
      init.slice->Value(atof(str));
      XtFree(str);

      str = XmTextFieldGetString(sliceOffsetTF);
      init.slice->Offset(atoi(str));
      XtFree(str);

      init.sliceLineWidth = (int)*sliceLineWidthNF;
      init.slice->LineWidth(init.sliceLineWidth);

      init.slice->TopColor(sliceTopColorMod->Value());
      init.slice->InnerEdgeColor(sliceInnerColorMod->Value());
      init.slice->OuterEdgeColor(sliceOuterColorMod->Value());
      init.slice->LineWidth((int)*sliceLineWidthNF);
   }

//
// Set the total last because it will change the slice values.
//
#ifdef DO_TOTAL
   if ( pie.Total() != totalNF->GetValue() )
   {
      Dprintf(("  total old: %f new: %f\n", pie.Total(),totalNF->GetValue()));
      pie.Total( totalNF->Value() );
   }
#endif

   // pie.RecomputeSize();
   pie.Defer(False);
   pie.Draw();

   Dprintf(("Leaving Apply\n"));
   Dprintf(("***************\n"));
}


// =====================================================================
// Method to initialize the settings based on the given pie
// =====================================================================
void
PieChartModC::Init(const PieChartC& pie)
{
   char tmpstr[128];

   Dprintf(("*************\n"));
   Dprintf(("Entering Init\n"));

   pieChart = (PieChartC*)&pie;

//
// Initialize the fields
//
//      title (char)        valueTotal (int)
//      declination (int)   rotation (int)
//      pieThickness (int)  lineWidth (int)
//      showLegend (t|f)    valueType (int|hex|float)
//      value Type Form
//      slice list.

   Dprintf(("  title: %s\n", pie.Title())); fflush(stdout);
   init.title = pie.Title();
   XmTextFieldSetString(titleTF, (char*)pie.Title());

   init.declination = pie.Declination();
   sprintf(tmpstr,"%d", pie.Declination());
   XmTextFieldSetString(declinationTF, tmpstr);

   init.rotation = pie.Rotation();
   sprintf(tmpstr,"%d", pie.Rotation());
   XmTextFieldSetString(rotationTF, tmpstr);

   init.thickness = pie.Thickness();
   sprintf(tmpstr,"%d", pie.Thickness());
   XmTextFieldSetString(thicknessTF, tmpstr);

   init.lineWidth = pie.LineWidth();
   sprintf(tmpstr,"%d", pie.LineWidth());
   XmTextFieldSetString(lineWidthTF, (char *)tmpstr);

   init.total = pie.Total();
   totalNF->SetValue(pie.Total());

   init.showLegend = pie.ShowLegend();
   XmToggleButtonSetState(legendVisTB, pie.ShowLegend(), False);

   init.legendTextShadow = pie.LegendTextShadow();
   XmToggleButtonSetState(legendTextShadowTB, pie.LegendTextShadow(), False);

   init.titleTextShadow = pie.TitleTextShadow();
   XmToggleButtonSetState(titleTextShadowTB, pie.TitleTextShadow(), False);

   init.labelTextShadow = pie.LabelTextShadow();
   XmToggleButtonSetState(labelTextShadowTB, pie.LabelTextShadow(), False);

//
// Initialize the colors.
//
   // for (int i=0; i<PieChartC::COLOR_ATTR_COUNT; i++)
      // colorForm[i]->Init(pie.GetColor((PieChartC::PieChartColorAttr)i));
   Dprintf(("  Colors\n"));
   backgroundColorMod->Init(pie.BackgroundColor());
   lineColorMod->Init(pie.LineColor());
   legendTextColorMod->Init(pie.LegendTextColor());
   legendShadowColorMod->Init(pie.LegendTextShadowColor());
   titleTextColorMod->Init(pie.TitleTextColor());
   titleShadowColorMod->Init(pie.TitleTextShadowColor());
   labelTextColorMod->Init(pie.LabelTextColor());
   labelShadowColorMod->Init(pie.LabelTextShadowColor());

//
// Store all the slices in the slice list and select the first one.
//
   init.slice = 0;
   XmListDeleteAllItems(sliceList);
   const PieSliceListC &list = *(pie.SliceList());
   for (int i=0; i<list.size(); i++ )
   {
      Dprintf(("  #%d pie slice: %s\n", i, list[i]->Name()));
      XmString xmstr;
      xmstr =  XmStringCreateLtoR(list[i]->Name(), XmSTRING_DEFAULT_CHARSET);
      XmListAddItem(sliceList, xmstr, 0 );
      XmStringFree(xmstr);
   }

   // legendFormatMod->Init(pie.OutputFormat(), pie.Precision());

//
// Set the data type formats.
//
   init.labelValueType = pie.LabelValueType();
   init.labelPrecision = pie.LabelPrecision();
   labelValueTypeMod->Type(init.labelValueType, init.labelPrecision);

   init.legendValueType = pie.LegendValueType();
   init.legendPrecision = pie.LegendPrecision();
   legendValueTypeMod->Type(init.legendValueType, init.legendPrecision);

   XmListSelectPos(sliceList, 1, True);

   Dprintf(("Leaving Init\n"));
   Dprintf(("*************\n"));
}


// =====================================================================
// Method to reset the fields to their initial values
// =====================================================================
void
PieChartModC::Reset()
{
   Dprintf(("**************\n"));
   Dprintf(("Entering Reset\n"));

   XmTextFieldSetString(titleTF, init.title);

   char tmpstr[128];
   sprintf(tmpstr,"%d", init.declination);
   XmTextFieldSetString(declinationTF, tmpstr);

   sprintf(tmpstr,"%d", init.rotation);
   XmTextFieldSetString(rotationTF, tmpstr);

   sprintf(tmpstr,"%d", init.thickness);
   XmTextFieldSetString(thicknessTF, tmpstr);

   sprintf(tmpstr,"%d", init.lineWidth);
   XmTextFieldSetString(lineWidthTF, tmpstr);

   totalNF->SetValue(pieChart->Total());

   XmToggleButtonSetState(legendVisTB, init.showLegend, False);
   XmToggleButtonSetState(legendTextShadowTB, init.legendTextShadow, False);
   XmToggleButtonSetState(titleTextShadowTB, init.titleTextShadow, False);
   XmToggleButtonSetState(labelTextShadowTB, init.labelTextShadow, False);

//
// Reset the colors.
//
   // for (int i=0; i<PieChartC::COLOR_ATTR_COUNT; i++) colorForm[i]->Reset();
   backgroundColorMod->Reset();
   titleTextColorMod->Reset();
   titleShadowColorMod->Reset();
   labelTextColorMod->Reset();
   labelShadowColorMod->Reset();
   legendTextColorMod->Reset();
   legendShadowColorMod->Reset();
   lineColorMod->Reset();

//
// Reset the Format identifiers.
//
   labelValueTypeMod->Type(init.labelValueType, init.labelPrecision);
   legendValueTypeMod->Type(init.legendValueType, init.legendPrecision);

//
// Reset the slice values which was edited (if any).
//
   Boolean found = False;
   Dprintf(("  init.slice: %d\n", init.slice));
   const PieSliceListC &list = *(pieChart->SliceList());
   if ( init.slice )
   {
      for ( int i=0; i<list.size(); i++)
      {
         PieSliceC* slice = list[i];
	 Dprintf(("  slice: %d\n", slice));
	 if ( slice == init.slice )
	 {
	    Dprintf(("  found the slice at %d\n", i));
	    if ( !XmListPosSelected(sliceList, i+1) )
	       XmListSelectPos(sliceList, i+1, False);

            Dprintf(("  reset slice label <%s>\n", (char*)init.sliceLabel));
	    XmTextFieldSetString(sliceLabelTF,init.sliceLabel);

	    char str[512];
	    sprintf(str,"%.*f", init.labelPrecision, init.sliceValue);
	    Dprintf(("  reset value string: %s\n", str));
	    XmTextFieldSetString(sliceValueTF, str);

	    sprintf(str,"%d", init.sliceOffset);
	    XmTextFieldSetString(sliceOffsetTF, str);

            sliceLineWidthNF->SetValue(init.sliceLineWidth);

            sliceTopColorMod->Reset();
            sliceInnerColorMod->Reset();
            sliceOuterColorMod->Reset();
	    found = True;
	    break;
	 }
      }
   }

   if ( !found )
   {
      Dprintf(("  slice not found...clearing text\n"));
      if ( list.size() > 0 )
         XmListSelectPos(sliceList, 1, True);
      else
      {
         XmTextFieldSetString(sliceLabelTF,"");
         XmTextFieldSetString(sliceValueTF,"");
         XmTextFieldSetString(sliceOffsetTF,"");
      }
   }

   Dprintf(("Leaving Reset\n"));
   Dprintf(("**************\n"));
} // End PieChartModC Reset


// =====================================================================
// =====================================================================
void
PieChartModC::DoSelectSlice(Widget w, PieChartModC* pcm, XmListCallbackStruct*)
{
   Dprintf(("************************\n"));
   Dprintf(("Entering DoSelectSlice\n"));
   Dprintf(("  list widget: %d\n", w));
//   
// Get the selected slice.
//   
   int *position_list;
   int  position_count;
   XmListGetSelectedPos(w, &position_list, &position_count);
   Dprintf(("  num_selected: %d\n", position_count));

   if ( position_count != 1 )
   {
      pcm->init.slice = 0; 
      return;
   }

   int index = position_list[0] - 1;
   Dprintf(("  index: %d\n", index));

   const PieSliceListC &list = *(pcm->pieChart->SliceList());
   pcm->init.slice = list[index];

   Dprintf(("  label: %s\n", pcm->init.slice->Label()));
   XmTextFieldSetString(pcm->sliceLabelTF,pcm->init.slice->Label());
   pcm->init.sliceLabel = pcm->init.slice->Label();

   char str[512];
   sprintf(str, "%.*f", pcm->init.labelPrecision, pcm->init.slice->Value() );
   XmTextFieldSetString(pcm->sliceValueTF,str);
   pcm->init.sliceValue = pcm->init.slice->Value();

   sprintf(str, "%d", pcm->init.slice->Offset() );
   XmTextFieldSetString(pcm->sliceOffsetTF,str);
   pcm->init.sliceOffset = pcm->init.slice->Offset();

   pcm->sliceLineWidthNF->SetValue(pcm->init.slice->LineWidth());
   pcm->sliceTopColorMod->Init(pcm->init.slice->TopColor());
   pcm->sliceInnerColorMod->Init(pcm->init.slice->InnerEdgeColor());
   pcm->sliceOuterColorMod->Init(pcm->init.slice->OuterEdgeColor());

   Dprintf(("Leaving DoSelectSlice\n"));
   Dprintf(("**********************\n"));
}


// =====================================================================
// =====================================================================
Widget
PieChartModC::LabeledTextField(Widget parent, char* name, Widget *label, Widget *field)
{
   WArgList	args;

   StringC form_name(name);
   form_name += "Form";
   Widget form   = XmCreateForm(parent, form_name, 0,0);

   StringC label_name(name);
   label_name += "Label";
   args.Reset();
   args.LeftAttachment(XmATTACH_FORM);
   args.TopAttachment(XmATTACH_FORM);
   args.BottomAttachment(XmATTACH_FORM);
   *label = XmCreateLabelGadget(form, label_name, ARGS);
   XtManageChild(*label);    

   StringC field_name(name);
   field_name += "TF";
   args.Reset();
   args.LeftAttachment(XmATTACH_WIDGET, *label);
   args.TopAttachment(XmATTACH_FORM);
   args.RightAttachment(XmATTACH_FORM);
   args.BottomAttachment(XmATTACH_FORM);
   *field = XmCreateTextField(form, field_name, ARGS);
   XtManageChild(*field);

   return (form);
}


// =====================================================================
// =====================================================================
ValueTypeModC::ValueTypeModC(Widget parent, char* name)
{
   StringC wname;
   WArgList args;

// Create a selection box for determining the type value
// to display in the slice.
//
   wname = name;
   args.Reset();
   form = XmCreateForm(parent, wname, ARGS);

   wname = "label";
   args.Reset();
   args.LeftAttachment(XmATTACH_FORM);
   args.TopAttachment(XmATTACH_FORM);
   args.BottomAttachment(XmATTACH_FORM);
   label = XmCreateLabel(form, wname, ARGS);
   XtManageChild(label);

   wname = "frame";
   args.Reset();
   args.LeftAttachment(XmATTACH_WIDGET,label);
   frame = XmCreateFrame(form, wname, ARGS);
   XtManageChild(frame);

   wname = "radioBox";
   args.Packing(XmPACK_TIGHT);
   args.Orientation(XmHORIZONTAL);
   radioBox = XmCreateRadioBox(frame, wname, ARGS);
   XtManageChild(radioBox);

   wname = "noneTB";
   args.Reset();
   noneTB = XmCreateToggleButton(radioBox, wname, ARGS);
   XtManageChild(noneTB);
   XtAddCallback(noneTB, XmNarmCallback, (XtCallbackProc)DoSelectTB, (XtPointer)this);

   wname = "percentTB";
   percentTB = XmCreateToggleButton(radioBox, wname, ARGS);
   XtManageChild(percentTB);
   XtAddCallback(percentTB, XmNarmCallback, (XtCallbackProc)DoSelectTB, (XtPointer)this);

   wname = "intTB";
   intTB = XmCreateToggleButton(radioBox, wname, ARGS);
   XtManageChild(intTB);
   XtAddCallback(intTB, XmNarmCallback, (XtCallbackProc)DoSelectTB, (XtPointer)this);

   wname = "hexTB";
   hexTB = XmCreateToggleButton(radioBox, wname, ARGS);
   XtManageChild(hexTB);
   XtAddCallback(hexTB, XmNarmCallback, (XtCallbackProc)DoSelectTB, (XtPointer)this);

   wname = "floatTB";
   floatTB = XmCreateToggleButton(radioBox, wname, ARGS);
   XtManageChild(floatTB);
   XtAddCallback(floatTB, XmNarmCallback, (XtCallbackProc)DoSelectTB, (XtPointer)this);

   wname = "precisionLabel";
   args.Reset();
   args.LeftAttachment(XmATTACH_WIDGET,frame);
   args.TopAttachment(XmATTACH_FORM);
   args.BottomAttachment(XmATTACH_FORM);
   precisionLabel = XmCreateLabel(form, wname, ARGS);
   XtManageChild(precisionLabel);

   wname = "precisionTF";
   args.Reset();
   args.LeftAttachment(XmATTACH_WIDGET,precisionLabel);
   args.TopAttachment(XmATTACH_NONE);
   args.BottomAttachment(XmATTACH_FORM);
   precisionTF = XmCreateTextField(form, wname, ARGS);
   XtManageChild(precisionTF);
   XtAddCallback(precisionTF, XmNvalueChangedCallback,
		 (XtCallbackProc)DoChangePrecision, (XtPointer)this);
}


// =====================================================================
// =====================================================================
void
ValueTypeModC::Type(PieSliceC::ValueType new_type, int prec)
{
   valueType = new_type;
   precision = prec;

   switch ( valueType )
   {
      case PieSliceC::NONE:
	 XmToggleButtonSetState(noneTB,True,False);
	 XmToggleButtonSetState(hexTB,False,False);
	 XmToggleButtonSetState(intTB,False,False);
	 XmToggleButtonSetState(percentTB,False,False);
	 XmToggleButtonSetState(floatTB,False,False);
	 XtSetSensitive(precisionLabel,False);
	 XtSetSensitive(precisionTF,False);
	 break;

      case PieSliceC::HEX:
	 XmToggleButtonSetState(noneTB,False,False);
	 XmToggleButtonSetState(hexTB,True,False);
	 XmToggleButtonSetState(intTB,False,False);
	 XmToggleButtonSetState(percentTB,False,False);
	 XmToggleButtonSetState(floatTB,False,False);
	 XtSetSensitive(precisionLabel,False);
	 XtSetSensitive(precisionTF,False);
	 break;

      case PieSliceC::INT:
	 XmToggleButtonSetState(noneTB,False,False);
	 XmToggleButtonSetState(hexTB,False,False);
	 XmToggleButtonSetState(intTB,True,False);
	 XmToggleButtonSetState(percentTB,False,False);
	 XmToggleButtonSetState(floatTB,False,False);
	 XtSetSensitive(precisionLabel,False);
	 XtSetSensitive(precisionTF,False);
	 break;

      case PieSliceC::PERCENTAGE:
	 XmToggleButtonSetState(noneTB,False,False);
	 XmToggleButtonSetState(hexTB,False,False);
	 XmToggleButtonSetState(intTB,False,False);
	 XmToggleButtonSetState(percentTB,True,False);
	 XmToggleButtonSetState(floatTB,False,False);
	 XtSetSensitive(precisionLabel,True);
	 XtSetSensitive(precisionTF,True);
	 break;

      case PieSliceC::FLOAT:
      default:
	 XmToggleButtonSetState(noneTB,False,False);
	 XmToggleButtonSetState(hexTB,False,False);
	 XmToggleButtonSetState(intTB,False,False);
	 XmToggleButtonSetState(percentTB,False,False);
	 XmToggleButtonSetState(floatTB,True,False);
	 XtSetSensitive(precisionLabel,True);
	 XtSetSensitive(precisionTF,True);
	 break;
   }

   char str[64];
   sprintf(str,"%d", precision);
   XmTextFieldSetString(precisionTF,str);
}


// =====================================================================
// =====================================================================
void
ValueTypeModC::DoSelectTB(Widget w, ValueTypeModC* vm, XtPointer)
{
   Boolean sensitive = False;
   if ( w == vm->noneTB )
      vm->valueType = PieSliceC::NONE;
   else if ( w == vm->hexTB )
      vm->valueType = PieSliceC::HEX;
   else if ( w == vm->intTB )
      vm->valueType = PieSliceC::INT;
   else if ( w == vm->percentTB )
   {
      vm->valueType = PieSliceC::PERCENTAGE;
      sensitive = True;
   }
   else if ( w == vm->floatTB )
   {
      vm->valueType = PieSliceC::FLOAT;
      sensitive = True;
   }

   XtSetSensitive(vm->precisionLabel,sensitive);
   XtSetSensitive(vm->precisionTF,sensitive);
}


// =====================================================================
// =====================================================================
void
ValueTypeModC::DoChangePrecision(Widget w, ValueTypeModC* vm, XtPointer)
{
   char* str = XmTextFieldGetString(w);
   vm->precision = atoi(str);
}
