/*
 * $Id: StripChartC.h,v 1.1 1998/06/24 01:29:07 lang Exp $
 *
 * Copyright (c) 1992 HAL Computer Systems International, Ltd.
 * 
 *          HAL COMPUTER SYSTEMS INTERNATIONAL, LTD.
 *                  1315 Dell Avenue
 *                  Campbell, CA  95008
 *
 * Author: Greg Hilton
 * Contributors: Tom Lang, Frank Bieser, and others
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * http://www.gnu.org/copyleft/gpl.html
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#ifndef _StripChartC_h_
#define _StripChartC_h_

#include "GraphC.h"
#include "ValueC.h"
#include "StringC.h"
#include "FloatListC.h"
#include "StringListC.h"

#include <Xm/Xm.h>

class IntListC;
class WorkingBoxC;

//----------------------------------------------------------------------------
// Class definition

class StripChartC : public GraphC {

public:

   enum StripChartColorAttr {
      BACKGROUND = 0,
      CHART_COLOR,
      LINE_COLOR,
      AXIS_COLOR,
      LABEL_COLOR,
      TICK_COLOR,
      GRID_COLOR,
      MARK_COLOR,
      TOP_SHADOW,
      BOTTOM_SHADOW,
      COLOR_ATTR_COUNT
   };

protected:

   Widget		form;
   Widget		scrollBar;

//
// Drawing attributes
//
   Pixel		colors[COLOR_ATTR_COUNT];
   StringC		colorNames[COLOR_ATTR_COUNT];
   XFontStruct		*font;
   unsigned char	shadowType;
   Dimension		shadowThickness;
   int			labelOffset;
   int			majorTickLen;
   int			minorTickLen;
   int			majorXTickSpacing;	// In samples
   int			minorXTickSpacing;
   float		majorYTickSpacing;	// In value units
   float		minorYTickSpacing;
   Boolean		majorXGridVis;
   Boolean		minorXGridVis;
   Boolean		majorYGridVis;
   Boolean		minorYGridVis;
   float		minValue;		// On y axis
   float		maxValue;
   float		valRangeInv;
   ValueC		formatVal;
   FloatListC		valueList;		// y values
   StringListC		labelList;		// x labels
   FloatListC		markList;		// y values
   unsigned		visCount;		// # of values displayed
   unsigned		maxCount;		// Maximum # of values stored
   int			minIndex;		// visible range
   int			maxIndex;

//
// Callbacks and event handlers
//
   static void		ScrollCB(Widget, StripChartC*,
				 XmScrollBarCallbackStruct*);

//
// Private methods
//
   Widget		BuildWidgets(Widget, const char*, ArgList, Cardinal);
   float		NormalizeValue(float);
   void			UpdateVisibleRange();

public:

//
// Cast to widget
//
   inline operator	Widget() const		{ return form;		}

//
// Constructor and destructor
//
   StripChartC(Widget parent, const char *name, ArgList argv=NULL,
	       Cardinal argc=0);
   virtual	~StripChartC();

//
// Assignment from another strip chart
//
   StripChartC&		operator=(const StripChartC&);

//
// Read from and write to a file
//
   int			Read(FILE*, WorkingBoxC *wb=NULL);
   void			Write(FILE*, const char *prefix="");

//
// Methods to modify the strip chart
//
   void			AddMark(const ValueC);
   void			AddValue(const ValueC, const char*);
   void			Draw();
   void			SetColor(StripChartC::StripChartColorAttr, Pixel);
   void			SetColor(StripChartC::StripChartColorAttr, const char *);
   void			SetLabelOffset(int);
   void			SetMargins(Dimension, Dimension);
   void			SetMarks(const IntListC&);
   void			SetMarks(const FloatListC&);
   void			SetMaximumValueCount(unsigned);
   void			SetOutputFormat(ValueC::ValueFormat);
   void			SetPrecision(int);
   void			SetRange(const ValueC, const ValueC);
   void			SetShadowThickness(Dimension);
   void			SetShadowType(unsigned char);
   void			SetTickLength(int, int);
   void			SetXGridVis(Boolean, Boolean);
   void			SetXTickSpacing(int, int);
   void			SetYGridVis(Boolean, Boolean);
   void			SetYTickSpacing(const ValueC, const ValueC);
   void			SetValues(const IntListC&, const StringListC&);
   void			SetValues(const FloatListC&, const StringListC&);
   void			SetVisibleValueCount(unsigned);

//
// Methods to query the strip chart
//
   MEMBER_QUERY(Widget,	       Form,		  form);
   MEMBER_QUERY(Widget,	       ScrollBar,         scrollBar)
   MEMBER_QUERY(int,           LabelOffset,       labelOffset)
   MEMBER_QUERY(unsigned,      MaximumValueCount, maxCount)
   MEMBER_QUERY(int,           Precision,         formatVal.Precision())
   MEMBER_QUERY(Dimension,     ShadowThickness,   shadowThickness)
   MEMBER_QUERY(unsigned char, ShadowType,        shadowType)
      PTR_QUERY(FloatListC&,   ValueList,	  valueList)
   MEMBER_QUERY(unsigned,      VisibleValueCount, visCount)
   MEMBER_QUERY(ValueC::ValueFormat,    OutputFormat, formatVal.Format())

   Pixel		GetColor    (StripChartC::StripChartColorAttr) const;
   StringC		GetColorName(StripChartC::StripChartColorAttr) const;
   void			GetMargins(Dimension*, Dimension*) const;
   void			GetRange(int*, int*) const;
   void			GetRange(long*, long*) const;
   void			GetRange(float*, float*) const;
   void			GetRange(ValueC*, ValueC*) const;
   void			GetRange(StringC*, StringC*) const;
   void			GetTickLength(int*, int*) const;
   void			GetXGridVis(Boolean*, Boolean*) const;
   void			GetXTickSpacing(int*, int*) const;
   void			GetXTickSpacing(StringC*, StringC*) const;
   void			GetYGridVis(Boolean*, Boolean*) const;
   void			GetYTickSpacing(int*, int*) const;
   void			GetYTickSpacing(long*, long*) const;
   void			GetYTickSpacing(float*, float*) const;
   void			GetYTickSpacing(ValueC*, ValueC*) const;
   void			GetYTickSpacing(StringC*, StringC*) const;
   inline GraphType	Type() const { return STRIP_CHART; }
};

#endif // _StripChartC_h_
