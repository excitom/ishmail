/*
 * $Id: PostCardC.C,v 1.1 1998/06/24 01:29:07 lang Exp $
 *
 * Copyright (c) 1992 HAL Computer Systems International, Ltd.
 * 
 *          HAL COMPUTER SYSTEMS INTERNATIONAL, LTD.
 *                  1315 Dell Avenue
 *                  Campbell, CA  95008
 *
 * Author: Greg Hilton
 * Contributors: Tom Lang, Frank Bieser, and others
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * http://www.gnu.org/copyleft/gpl.html
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#include "HalAppC.h"
#include "PostCardC.h"
#include "rsrc.h"

#include <Xm/PanedW.h>
#include <Xm/RowColumn.h>
#include <Xm/List.h>
#include <Xm/Frame.h>
#include <Xm/Label.h>
#include <Xm/LabelG.h>
#include <Xm/PushB.h>
#include <Xm/MessageB.h>
#include <Xm/Separator.h>
#include <Xm/ToggleB.h>
#include <Xm/Form.h>
#include <Xm/Text.h>
#include <Xm/TextF.h>
#include "WArgList.h"

#include "HeaderBoxC.h"
#include "ListBoxC.h"

/*************************************************************/
/*************************************************************/
/* WE REALLY NEED TO DEFINE AN ENVIRONMENT VARIABLE FOR THIS */
/*************************************************************/
/*************************************************************/
/* The MAIL var is used for storage of mailbox info          */
/* But MAILTOOL might be obvious                             */
/*************************************************************/
/*************************************************************/

#define MAIL_CMD "Mail"

void
PostCardC::DoHider(Widget, PostCardC *pc, XtPointer)
{
  XmTextSetString(pc->text_w, "");
  XmTextSetString(pc->abstract_w, "");
  pc->answer = FALSE;
  pc->ready = 1;
  pc->Hide();
}

void
PostCardC::DoHelp(Widget w, PostCardC*, XtPointer)
{
    halApp->DoHelp(w, "helpcard", NULL);
} // End PostCardC DoHelp

/*---------------------------------------------------------------
 *  PostCard window destructor
 */

PostCardC::~PostCardC()
{
}

/*---------------------------------------------------------------
 *  PostCard window constructor
 */

PostCardC::PostCardC(Widget parent)
: HalDialogC(POSTCARD_NAME, parent)
{
    WArgList	args;
    Build();
}

PostCardC::PostCardC(Widget parent, StringListC& recipients)
: HalDialogC(POSTCARD_NAME, parent)
{
    WArgList	args;
    recipientList = recipients;
    Build();
}

PostCardC::PostCardC(Widget parent, StringListC& recipients, StringC& subject)
: HalDialogC(POSTCARD_NAME, parent)
{
    subjectTitle = subject;
    recipientList = recipients;
    Build();
}

void
PostCardC::Build()
{
    WArgList	args;
    ready = 0;
/*---------------------------------------------------------------
 *  Create a Paned Window with a top and bottom form
 */

   args.Reset();
   args.LeftAttachment(XmATTACH_FORM);
   args.RightAttachment(XmATTACH_FORM);
   args.TopAttachment(XmATTACH_FORM);
   args.BottomAttachment(XmATTACH_FORM);
   Widget panedWin = XmCreatePanedWindow(appForm, "panedWin", args.Args(),
				  args.NumArgs());
   XtManageChild(panedWin);

/*---------------------------------------------------------------
 *  Create two forms
 */
   args.Reset();
   args.LeftAttachment(XmATTACH_FORM);
   args.RightAttachment(XmATTACH_FORM);
   args.TopAttachment(XmATTACH_FORM);
   args.BottomAttachment(XmATTACH_FORM);
   Widget topForm   = XmCreateForm(panedWin, "topForm", args.Args(), args.NumArgs());
   XtManageChild(topForm);

   args.Reset();
   args.LeftAttachment(XmATTACH_FORM);
   args.RightAttachment(XmATTACH_FORM);
   args.TopAttachment(XmATTACH_FORM);
   args.BottomAttachment(XmATTACH_FORM);
   Widget midForm   = XmCreateForm(panedWin, "midForm", args.Args(), args.NumArgs());
   XtManageChild(midForm);

   args.Reset();
   args.LeftAttachment(XmATTACH_FORM);
   args.RightAttachment(XmATTACH_FORM);
   args.TopAttachment(XmATTACH_FORM);
   args.BottomAttachment(XmATTACH_FORM);
   Widget bottomForm   = XmCreateForm(panedWin, "bottomForm", args.Args(), args.NumArgs());
   XtManageChild(bottomForm);

   /*---------------------------------------------------------------
    *  Below the header are two RowColums
    */
   args.Reset();
   args.LeftAttachment(XmATTACH_FORM);
   args.RightAttachment(XmATTACH_POSITION, 50);
   args.TopAttachment(XmATTACH_FORM);
   args.BottomAttachment(XmATTACH_FORM);
//   args.Packing(XmPACK_COLUMN);
   args.Orientation(XmVERTICAL);
//   args.EntryAlignment(XmALIGNMENT_CENTER);
   addrRC = XmCreateRowColumn(topForm, "addrRC", args.Args(), args.NumArgs());
   XtManageChild(addrRC);

   args.Reset();
   args.RightAttachment(XmATTACH_FORM);
   args.LeftAttachment(XmATTACH_POSITION, 50);
   args.TopAttachment(XmATTACH_FORM);
   args.BottomAttachment(XmATTACH_FORM);
//   args.Packing(XmPACK_COLUMN);
   args.Orientation(XmHORIZONTAL);
//   args.EntryAlignment(XmALIGNMENT_CENTER);
   statusRC = XmCreateRowColumn(topForm, "statusRC", args.Args(), args.NumArgs());
   XtManageChild(statusRC);
   args.Reset();
   Widget catForm   = XmCreateForm(statusRC, "catForm", args.Args(), args.NumArgs());
   XtManageChild(catForm);

   args.Reset();
   Widget sevForm   = XmCreateForm(statusRC, "sevForm", args.Args(), args.NumArgs());
   XtManageChild(sevForm);


   /*---------------------------------------------------------------
    *  In the left RowColumn is the Subject and Address of recipients
    */

   args.Reset();
   Widget subjForm   = XmCreateForm(addrRC, "subjForm", args.Args(), args.NumArgs());
   XtManageChild(subjForm);

    args.Reset();
    args.TopAttachment(XmATTACH_FORM);
    args.LeftAttachment(XmATTACH_FORM);
    Widget subjTitle = XmCreateLabelGadget(subjForm, "subjTitle", args.Args(), args.NumArgs());
    XtManageChild(subjTitle);

    args.Reset();
    args.LeftAttachment(XmATTACH_WIDGET, subjTitle);
    args.RightAttachment(XmATTACH_FORM);
    args.TopAttachment(XmATTACH_FORM);
    if(subjectTitle.size() > 0) {
	XmString str = XmStringCreateSimple((char*)subjectTitle);
	args.LabelString(str);
    }
    subjLabel = XmCreateLabelGadget(subjForm, "subjLabel", args.Args(), args.NumArgs());
    XtManageChild(subjLabel);


   /*---------------------------------------------------------------
    *  Provide a To: prompt
    */
    args.Reset();
    args.TopAttachment(XmATTACH_WIDGET, subjTitle);
    args.LeftAttachment(XmATTACH_FORM);
    args.RightAttachment(XmATTACH_FORM);
    Widget toTitle = XmCreateLabelGadget(addrRC, "toTitle", args.Args(), args.NumArgs());
    XtManageChild(toTitle);

    args.Reset();
    args.LeftAttachment(XmATTACH_FORM);
    args.RightAttachment(XmATTACH_FORM);
    args.TopAttachment(XmATTACH_WIDGET, toTitle);
    args.BottomAttachment(XmATTACH_FORM);
    toBox = new ListBoxC(addrRC, (StringC)"toBox", ARGS);
    XtManageChild(*toBox);
    toBox->AllowDuplicates(False);

   args.Reset();
   args.VisibleItemCount(4);
   Widget boxList = toBox->ItemList();
   XtSetValues(boxList, ARGS);


   /*---------------------------------------------------------------
    *  Any command line args are receipients
    */

    if (recipientList.size() > 0)
      toBox->SetItems(recipientList);

   /*---------------------------------------------------------------
    * Now for two radio boxes in the statusRC
    */
    args.Reset();
    args.TopAttachment(XmATTACH_FORM);
    args.LeftAttachment(XmATTACH_FORM);
    Widget catLabel = XmCreateLabelGadget(catForm, "catLabel", args.Args(), args.NumArgs());
    XtManageChild(catLabel);
    args.Reset();
    args.TopAttachment(XmATTACH_WIDGET, catLabel);
//    args.LeftAttachment(XmATTACH_FORM);
    args.RightAttachment(XmATTACH_FORM);
    args.BottomAttachment(XmATTACH_FORM);
    Widget catRadioBox = XmCreateRadioBox(catForm, "catRadioBox", args.Args(), args.NumArgs());
    XtManageChild(catRadioBox);
    args.Reset();
    bugTB = XmCreateToggleButton(catRadioBox, "bugTB", args.Args(), args.NumArgs());
    XtManageChild(bugTB);
    XtAddCallback(bugTB, XmNvalueChangedCallback, 
		  (XtCallbackProc)PostCardC::DoCategory, (XtPointer)this);
    args.Reset();
    perfTB = XmCreateToggleButton(catRadioBox, "perfTB", args.Args(), args.NumArgs());
    XtManageChild(perfTB);
    XtAddCallback(perfTB, XmNvalueChangedCallback, 
		  (XtCallbackProc)PostCardC::DoCategory, (XtPointer)this);
    args.Reset();
    commentTB = XmCreateToggleButton(catRadioBox, "commentTB", args.Args(), args.NumArgs());
    XtManageChild(commentTB);
    XtAddCallback(commentTB, XmNvalueChangedCallback, 
		  (XtCallbackProc)PostCardC::DoCategory, (XtPointer)this);

//    Widget radioSeparator = XmCreateSeparator(statusRC, "radioSeparator", 0,0);
//    XtManageChild(radioSeparator);

    args.Reset();
    args.TopAttachment(XmATTACH_FORM);
    args.LeftAttachment(XmATTACH_FORM);
    Widget sevLabel = XmCreateLabelGadget(sevForm, "sevLabel", args.Args(), args.NumArgs());
    XtManageChild(sevLabel);

    args.Reset();
    args.TopAttachment(XmATTACH_WIDGET, sevLabel);
//    args.LeftAttachment(XmATTACH_FORM);
    args.RightAttachment(XmATTACH_FORM);
    args.BottomAttachment(XmATTACH_FORM);
    Widget sevRadioBox = XmCreateRadioBox(sevForm, "sevRadioBox", args.Args(), args.NumArgs());
    XtManageChild(sevRadioBox);
    args.Reset();
    crucialTB = XmCreateToggleButton(sevRadioBox, "crucialTB", args.Args(), args.NumArgs());
    XtManageChild(crucialTB);
    XtAddCallback(crucialTB, XmNvalueChangedCallback, 
		  (XtCallbackProc)PostCardC::DoSeverity, (XtPointer)this);
    args.Reset();
    majorTB = XmCreateToggleButton(sevRadioBox, "majorTB", args.Args(), args.NumArgs());
    XtManageChild(majorTB);
    XtAddCallback(majorTB, XmNvalueChangedCallback, 
		  (XtCallbackProc)PostCardC::DoSeverity, (XtPointer)this);
    args.Reset();
    mediumTB = XmCreateToggleButton(sevRadioBox, "mediumTB", args.Args(), args.NumArgs());
    XtManageChild(mediumTB);
    XtAddCallback(mediumTB, XmNvalueChangedCallback, 
		  (XtCallbackProc)PostCardC::DoSeverity, (XtPointer)this);
    args.Reset();
    minorTB = XmCreateToggleButton(sevRadioBox, "minorTB", args.Args(), args.NumArgs());
    XtManageChild(minorTB);
    XtAddCallback(minorTB, XmNvalueChangedCallback, 
		  (XtCallbackProc)PostCardC::DoSeverity, (XtPointer)this);

   /*---------------------------------------------------------------
    * the middle form has the abstract 
    */
   abstract_w = CreateLabeledTextForm(midForm, "abstractLabel", "abstractText");
   
   /*---------------------------------------------------------------
    * the bottom is a scrolled text region for letter input
    */
   Widget textTitle = XmCreateLabelGadget(bottomForm, "textTitle", 0,0);
   XtManageChild(textTitle);

   args.Reset();
   args.EditMode(XmMULTI_LINE_EDIT);
   args.ScrollVertical(True);
   args.ScrollHorizontal(True);
   args.Rows(12);
   args.LeftAttachment(XmATTACH_FORM);
   args.RightAttachment(XmATTACH_FORM);
   args.TopAttachment(XmATTACH_WIDGET, textTitle);
   args.BottomAttachment(XmATTACH_FORM);
   text_w = XmCreateScrolledText(bottomForm, "msg-text", args.Args(), args.NumArgs());
    XtManageChild(text_w);

   /* Ctrl-D in text_w casuses activate() which call send_it() */
   XtAddCallback(text_w, XmNactivateCallback, (XtCallbackProc)send_it, (caddr_t) this);

   /*---------------------------------------------------------------
    * Add tab groups in the order we'd like tabbing to follow
    */
   XmAddTabGroup(toBox->ItemText());
   XmAddTabGroup(abstract_w);
   XmAddTabGroup(text_w);

   XtAddCallback(shell, XmNpopupCallback, (XtCallbackProc)PostCardC::DoPopup,
		 (XtPointer)this);

    AddButtonBox();

    args.Reset();
    args.ShowAsDefault(True);
    args.DefaultButtonShadowThickness(1);
    applyPB = XmCreatePushButton(buttonRC, "applyPB", ARGS);
    XtManageChild(applyPB);
    XtAddCallback(applyPB,XmNactivateCallback,
		  (XtCallbackProc)PostCardC::send_it, (caddr_t)this);
    
    args.Reset();
    args.ShowAsDefault(False);
    args.DefaultButtonShadowThickness(1);
    Widget cancelPB = XmCreatePushButton(buttonRC, "cancelPB", ARGS);
    XtManageChild(cancelPB);
    XtAddCallback(cancelPB,XmNactivateCallback,(XtCallbackProc)PostCardC::DoHider, 
		  (caddr_t)this);

    args.Reset();
    args.ShowAsDefault(False);
    args.DefaultButtonShadowThickness(1);
    Widget helpPB = XmCreatePushButton(buttonRC, "helpPB", ARGS);
    XtManageChild(helpPB);
    XtAddCallback(helpPB,XmNactivateCallback,(XtCallbackProc)PostCardC::DoHelp, 
		  (caddr_t)this);

    HandleHelp();
}


/* user clicked on Send -- build a command line, use popen() to 
 * open pipe to mail command, send text data to it, then exit.
 */
int
PostCardC::PrepareMessage(Widget w, XmAnyCallbackStruct *cbs)
{
  int   err = 0;
  char *text;
  char *subj;
  char *p;

  if (w == text_w) {
    XtCallActionProc(send_w, "ArmAndActivate", cbs->event, NULL, 0);
    return(1);
  }

  /* if something is in the Abstract: field, grab it */
  text = XmTextGetString(abstract_w);
  if (text != 0 && *text != 0) {
    //
  } else {
    XmProcessTraversal(abstract_w, XmTRAVERSE_CURRENT);
    PopupMessage("You must include a short abstract describing the condition.");
    return (-1);
  }

  /* Get the list of users entered */
  StringListC list;
  list = toBox->GetItems(list);
  if (!(list.size())) {
    XmProcessTraversal(toBox->ItemList(), XmTRAVERSE_CURRENT);
    PopupMessage("You must send to at least one address.");
    return(-1);
  }

  /* get the subject (may be empty) */
  XmString tmpString;
  XtVaGetValues(subjLabel, XmNlabelString, &tmpString, NULL);
  XmStringGetLtoR(tmpString, XmSTRING_DEFAULT_CHARSET, &subj);

  /* build command line */
  if (!(p = getenv("MAIL_CMD")))
    mailCmd = (char*)MAIL_CMD;
  else
    mailCmd = (char*)p;

  if (subj && *subj) {
    mailCmd += " -s \"";
    mailCmd += (char*)subj;
    mailCmd += "\" ";
  }

  /* Add each user in the List to the command line */
  for (int i=0; i<list.size(); i++) {
    mailCmd += *list[i];
    if (i < list.size()-1) /* more to come yet... */
      mailCmd += ", ";
  }

  /* give it the text user typed (may be empty) */

  XmTextInsert(text_w, 0, "\nDesc/Comments: \n");
  XmTextInsert(text_w, 0, text);
  XmTextInsert(text_w, 0, "Abstract: ");
  switch(sev_mode) {
  case PC_CRUCIAL:
    XmTextInsert(text_w, 0, "Crucial \n");
    break;
  case PC_MAJOR:
    XmTextInsert(text_w, 0, "Major \n");
    break;
  case PC_MEDIUM:
    XmTextInsert(text_w, 0, "Medium \n");
    break;
  case PC_MINOR:
    XmTextInsert(text_w, 0, "Minor \n");
    break;
  }
  XmTextInsert(text_w, 0, "Severity: ");
  switch(cat_mode) {
  case PC_BUG:
    XmTextInsert(text_w, 0, "Bug \n");
    break;
  case PC_PERF:
    XmTextInsert(text_w, 0, "Performance \n");
    break;
  case PC_COMMENT:
    XmTextInsert(text_w, 0, "Enhancement \n");
    break;
  }
  XmTextInsert(text_w, 0, "\nCategory: ");
  XmTextInsert(text_w, 0, (char*)versionTitle);
  XmTextInsert(text_w, 0, "\nVersion: ");
  XmTextInsert(text_w, 0, (char*)componentTitle);
  XmTextInsert(text_w, 0, "\nComponent: ");
  XmTextInsert(text_w, 0, (char*)productTitle);
  XmTextInsert(text_w, 0, "Product: ");

  XtFree(text);
  XtFree(subj);
  return(err);
}

int
PostCardC::SendMessage()
{
  FILE *pp;

  /* open pipe to mail command */
  if (!(pp = popen((char*)mailCmd, "w"))){
    PopupMessage("Can't execute");
    return (-1);
  }

  char *text = XmTextGetString(text_w);
  fputs(text, pp);
  fputc('\n', pp); /* make sure there's a terminating newline */
  int status = pclose(pp); /* close mail program */


  XmTextSetString(text_w, "");
  XmTextSetString(abstract_w, "");
  XtFree(text);
  return(status);
}

void
PostCardC::send_it(Widget w, PostCardC *pc, XmAnyCallbackStruct *cbs)
{
  int err = pc->PrepareMessage(w, cbs);
  if(err == 1 || err == -1) return;
  err = pc->SendMessage();
  if(err == 1 || err == -1) return;

  pc->answer = TRUE;
  pc->ready = 1;
  pc->Hide();
}

/*---------------------------------------------------------------
 *  Method to make a textfield invalid
 */

void
PostCardC::InvalidText(Widget w)
{
   set_invalid(w, True);

// Add a restore callback
   XtAddCallback(w, XmNvalueChangedCallback,
                 (XtCallbackProc)PostCardC::RestoreText, NULL);
}

/*---------------------------------------------------------------
 *  Callback routine to handle entry of text in an invalid field
 */

void
PostCardC::RestoreText(Widget w, XtPointer, XtPointer)
{
   set_invalid(w, False);

// Remove this callback
   XtRemoveCallback(w, XmNvalueChangedCallback,
                    (XtCallbackProc)PostCardC::RestoreText, NULL);
}


/* Create a Form Widget that has a label on the left and a Text 
 * widget to the right. Attach perimeter edges to form.
 * We use it twice in the program, so make a function out of it.
 */

Widget
PostCardC::CreateLabeledTextForm(Widget parent, char *label_name, char *text_name)
{
    WArgList	args;

    args.Reset();
    args.LeftAttachment(XmATTACH_FORM);
    args.RightAttachment(XmATTACH_FORM);
    args.TopAttachment(XmATTACH_FORM);
    args.BottomAttachment(XmATTACH_FORM);
    Widget form   = XmCreateForm(parent, "form", args.Args(), args.NumArgs());
    XtManageChild(form);

    args.Reset();
    args.LeftAttachment(XmATTACH_FORM);
    args.TopAttachment(XmATTACH_FORM);
    args.BottomAttachment(XmATTACH_FORM);
    Widget label = XmCreateLabelGadget(form, label_name, args.Args(), args.NumArgs());
    XtManageChild(label);    

    args.Reset();
    args.LeftAttachment(XmATTACH_WIDGET, label);
    args.TopAttachment(XmATTACH_FORM);
    args.RightAttachment(XmATTACH_FORM);
    args.BottomAttachment(XmATTACH_FORM);
    Widget ret = XmCreateTextField(form, text_name, args.Args(), args.NumArgs());
    XtManageChild(ret);

    return (ret);

}
/*---------------------------------------------------------------
 *  Callback routine to handle initial display of dialog
 */

void
PostCardC::DoCategory(Widget widget, PostCardC* pc, XmToggleButtonCallbackStruct* state)
{ 
    if (state->set) {
	if(widget == pc->bugTB) {
	    pc->cat_mode = PC_BUG;
	} else if (widget == pc->perfTB) {
	    pc->cat_mode = PC_PERF;
	} else {
	    pc->cat_mode = PC_COMMENT;
	}
    }
}

void
PostCardC::DoSeverity(Widget widget, PostCardC* pc, XmToggleButtonCallbackStruct* state)
{ 
    if (state->set) {
	if(widget == pc->crucialTB) {
	    pc->sev_mode = PC_CRUCIAL;
	} else if (widget == pc->majorTB) {
	    pc->sev_mode = PC_MAJOR;
	} else if (widget == pc->mediumTB) {
	    pc->sev_mode = PC_MEDIUM;
	} else {
	    pc->sev_mode = PC_MINOR;
	}
    }
}

void
PostCardC::DoPopup(Widget w, PostCardC *pc, XtPointer)
{ 
   Dimension	ht;

//
// Fix the size of the button form pane
//

   XtVaGetValues(pc->statusRC, XmNheight, &ht, NULL);
   XtVaSetValues(pc->statusRC, XmNpaneMinimum, ht,
		             XmNpaneMaximum, ht, NULL);

   XtVaGetValues(pc->addrRC, XmNheight, &ht, NULL);
   XtVaSetValues(pc->addrRC, XmNpaneMinimum, ht,
		             XmNpaneMaximum, ht, NULL);

   XmProcessTraversal(w, XmTRAVERSE_HOME);
}

void
PostCardC::SetVersion(const StringC& product, const StringC& component, const StringC& version)
{ 
    productTitle   = product;
    componentTitle = component;
    versionTitle   = version;

    XmTextSetString(abstract_w , "");
    XmTextSetString(text_w , "");
}

void
PostCardC::SetVersion(const StringC& product, const StringC& component, 
		      const StringC& version, const StringC& key)
{ 
    productTitle   = product;
    componentTitle = component;
    versionTitle   = version;
    keyTitle       = key;
}

void
PostCardC::SetCategory(category_mode cat)
{ 
    cat_mode = cat;
    if(cat == PC_BUG) {
	XmToggleButtonSetState(bugTB, True, True);
    } else if (cat == PC_PERF){
	XmToggleButtonSetState(perfTB, True, True);
    } else {
	XmToggleButtonSetState(commentTB, True, True);
    }
}


void
PostCardC::SetSeverity(severity_mode sev)
{ 
    sev_mode = sev;
    if(sev == PC_CRUCIAL)
      XmToggleButtonSetState(crucialTB, True, True);
    else if (sev == PC_MAJOR)
      XmToggleButtonSetState(majorTB, True, True);
    else if (sev == PC_MEDIUM)
      XmToggleButtonSetState(mediumTB, True, True);
    else 
      XmToggleButtonSetState(minorTB, True, True);
}


void
PostCardC::SetRecipients(StringListC& recipients)
{ 
    recipientList = recipients;
    if (recipientList.size() > 0)
      toBox->SetItems(recipientList);
}


void
PostCardC::SetSubject(StringC& subject)
{ 
    subjectTitle = subject;
    XmString str = XmStringCreateSimple((char*)subject);
    XtVaSetValues(subjLabel, XmNlabelString, str, NULL);
}
