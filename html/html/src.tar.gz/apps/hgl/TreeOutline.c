/*
 * $Id: TreeOutline.c,v 1.1 1998/06/24 01:29:07 lang Exp $
 *
 * Copyright (c) 1991 HaL Computer Systems, Inc.  All rights reserved.
 * 
 *          HAL COMPUTER SYSTEMS INTERNATIONAL, LTD.
 *                  1315 Dell Avenue
 *                  Campbell, CA  95008
 *
 * Author: Greg Hilton
 * Contributors: Tom Lang, Frank Bieser, and others
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * http://www.gnu.org/copyleft/gpl.html
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

/*
 * $XConsortium: Tree.c,v 1.42 91/02/20 20:06:07 converse Exp $
 *
 * Copyright 1990 Massachusetts Institute of Technology
 * Copyright 1989 Prentice Hall
 *
 * Permission to use, copy, modify, and distribute this software for any
 * purpose and without fee is hereby granted, provided that the above
 * copyright notice appear in all copies and that both the copyright notice
 * and this permission notice appear in supporting documentation.
 * 
 * M.I.T., Prentice Hall and the authors disclaim all warranties with regard
 * to this software, including all implied warranties of merchantability and
 * fitness.  In no event shall M.I.T., Prentice Hall or the authors be liable
 * for any special, indirect or cosequential damages or any damages whatsoever
 * resulting from loss of use, data or profits, whether in an action of
 * contract, negligence or other tortious action, arising out of or in
 * connection with the use or performance of this software.
 * 
 * Authors:  Jim Fulton, MIT X Consortium,
 *           based on a version by Douglas Young, Prentice Hall
 * 
 * This widget is based on the Tree widget described on pages 397-419 of
 * Douglas Young's book "The X Window System, Programming and Applications 
 * with Xt OSF/Motif Edition."  The layout code has been rewritten to use
 * additional blank space to make the structure of the graph easier to see
 * as well as to support vertical trees.
 */

# include <stdio.h>

#include <X11/Intrinsic.h>
#include <X11/IntrinsicP.h>
#include <X11/StringDefs.h>
#include <X11/CoreP.h>
#include <X11/CompositeP.h>
#include <X11/ConstrainP.h>
#include <X11/Xaw/XawInit.h>
#include <X11/Xaw/Cardinals.h>
#include "TreeOutlineP.h"

#define IsHorizontal(tw) ((tw)->treeOutline.gravity == WestGravity || \
			  (tw)->treeOutline.gravity == EastGravity)


					/* widget class method */
static void             ClassInitialize();
static void             Initialize();
static void             ConstraintInitialize();
static void             ConstraintDestroy();
static Boolean          ConstraintSetValues();
static void             Destroy();
static Boolean          SetValues();
static XtGeometryResult GeometryManager();
static void             ChangeManaged();
static void             Redisplay();
static XtGeometryResult	QueryGeometry();

					/* utility routines */
static void             insert_node();
static void             delete_node();
static void             layout_treeOutline();


/*
 * resources of the treeOutline itself
 */
static XtResource resources[] = {
    { XtNtreeOutline, XtCTreeOutline, XtRTreeOutlineType, sizeof (XtTreeOutlineType),
	XtOffsetOf(TreeOutlineRec, treeOutline.tree_outline), XtRImmediate,
	(XtPointer) XtTREE },
    { XtNautoReconfigure, XtCAutoReconfigure, XtRBoolean, sizeof (Boolean),
	XtOffsetOf(TreeOutlineRec, treeOutline.auto_reconfigure), XtRImmediate,
	(XtPointer) FALSE },
    { XtNhSpace, XtCHSpace, XtRDimension, sizeof (Dimension),
	XtOffsetOf(TreeOutlineRec, treeOutline.hpad), XtRImmediate, (XtPointer) 0 },
    { XtNvSpace, XtCVSpace, XtRDimension, sizeof (Dimension),
	XtOffsetOf(TreeOutlineRec, treeOutline.vpad), XtRImmediate, (XtPointer) 0 },
    { XtNforeground, XtCForeground, XtRPixel, sizeof (Pixel),
	XtOffsetOf(TreeOutlineRec, treeOutline.foreground), XtRString,
	XtDefaultForeground},
    { XtNlineWidth, XtCLineWidth, XtRDimension, sizeof (Dimension),
	XtOffsetOf(TreeOutlineRec, treeOutline.line_width), XtRImmediate, (XtPointer) 0 },
    { XtNgravity, XtCGravity, XtRGravity, sizeof (XtGravity),
	XtOffsetOf(TreeOutlineRec, treeOutline.gravity), XtRImmediate,
	(XtPointer) WestGravity },
};


/*
 * resources that are attached to all children of the treeOutline
 */
static XtResource treeOutlineConstraintResources[] = {
    { XtNtreeOutlineParent, XtCTreeOutlineParent, XtRWidget, sizeof (Widget),
	XtOffsetOf(TreeOutlineConstraintsRec, treeOutline.parent), XtRImmediate, NULL },
    { XtNtreeOutlineGC, XtCTreeOutlineGC, XtRGC, sizeof(GC),
	XtOffsetOf(TreeOutlineConstraintsRec, treeOutline.gc), XtRImmediate, NULL },
};


TreeOutlineClassRec treeOutlineClassRec = {
  {
					/* core_class fields  */
    (WidgetClass) &constraintClassRec,	/* superclass         */
    "TreeOutline",				/* class_name         */
    sizeof(TreeOutlineRec),			/* widget_size        */
    ClassInitialize,			/* class_init         */
    NULL,				/* class_part_init    */
    FALSE,				/* class_inited       */	
    Initialize,				/* initialize         */
    NULL,				/* initialize_hook    */	
    XtInheritRealize,			/* realize            */
    NULL,				/* actions            */
    0,					/* num_actions        */	
    resources,				/* resources          */
    XtNumber(resources),		/* num_resources      */
    NULLQUARK,				/* xrm_class          */
    TRUE,				/* compress_motion    */	
    TRUE,				/* compress_exposure  */	
    TRUE,				/* compress_enterleave*/	
    TRUE,				/* visible_interest   */
    Destroy,				/* destroy            */
    NULL,				/* resize             */
    Redisplay,				/* expose             */
    SetValues,				/* set_values         */
    NULL,				/* set_values_hook    */	
    XtInheritSetValuesAlmost,		/* set_values_almost  */
    NULL,				/* get_values_hook    */	
    NULL,				/* accept_focus       */
    XtVersion,				/* version            */	
    NULL,				/* callback_private   */
    NULL,				/* tm_table           */
    QueryGeometry,			/* query_geometry     */	
    NULL,				/* display_accelerator*/
    NULL,				/* extension          */
  },
  {
					/* composite_class fields */
    GeometryManager,			/* geometry_manager    */
    ChangeManaged,			/* change_managed      */
    XtInheritInsertChild,		/* insert_child        */	
    XtInheritDeleteChild,		/* delete_child        */	
    NULL,				/* extension           */
  },
  { 
					/* constraint_class fields */
   treeOutlineConstraintResources,		/* subresources        */
   XtNumber(treeOutlineConstraintResources),	/* subresource_count   */
   sizeof(TreeOutlineConstraintsRec),		/* constraint_size     */
   ConstraintInitialize,		/* initialize          */
   ConstraintDestroy,			/* destroy             */
   ConstraintSetValues,			/* set_values          */
   NULL,				/* extension           */
   },
  {
					/* TreeOutline class fields */
    0,					/* ignore              */	
  }
};

WidgetClass treeOutlineWidgetClass = (WidgetClass) &treeOutlineClassRec;


/*****************************************************************************
 *                                                                           *
 *			     treeOutline utility routines                           *
 *                                                                           *
 *****************************************************************************/

static void initialize_dimensions (listp, sizep, n)
    Dimension **listp;
    int *sizep;
    int n;
{
    register int i;
    register Dimension *l;

    if (!*listp) {
	*listp = (Dimension *) XtCalloc ((unsigned int) n,
					 (unsigned int) sizeof(Dimension));
	*sizep = ((*listp) ? n : 0);
	return;
    }
    if (n > *sizep) {
	*listp = (Dimension *) XtRealloc((char *) *listp,
					 (unsigned int) (n*sizeof(Dimension)));
	if (!*listp) {
	    *sizep = 0;
	    return;
	}
	for (i = *sizep, l = (*listp) + i; i < n; i++, l++) *l = 0;
	*sizep = n;
    }
    return;
}

static GC get_treeOutline_gc (w)
    TreeOutlineWidget w;
{
    XtGCMask valuemask = GCBackground | GCForeground;
    XGCValues values;

    values.background = w->core.background_pixel;
    values.foreground = w->treeOutline.foreground;
    if (w->treeOutline.line_width != 0) {
	valuemask |= GCLineWidth;
	values.line_width = w->treeOutline.line_width;
    }

    return XtGetGC ((Widget) w, valuemask, &values);
}

static void insert_node (parent, node)
     Widget parent, node;
{
    TreeOutlineConstraints pc;
    TreeOutlineConstraints nc = TREEOUTLINE_CONSTRAINT(node);
    int nindex;
  
    nc->treeOutline.parent = parent;

    if (parent == NULL) return;

    /*
     * If there isn't more room in the children array, 
     * allocate additional space.
     */  
    pc = TREEOUTLINE_CONSTRAINT(parent);
    nindex = pc->treeOutline.n_children;
  
    if (pc->treeOutline.n_children == pc->treeOutline.max_children) {
	pc->treeOutline.max_children += (pc->treeOutline.max_children / 2) + 2;
	pc->treeOutline.children = (WidgetList) XtRealloc ((char *)pc->treeOutline.children, 
						    (unsigned int)
						    ((pc->treeOutline.max_children) *
						    sizeof(Widget)));
    } 

    /*
     * Add the sub_node in the next available slot and 
     * increment the counter.
     */
    pc->treeOutline.children[nindex] = node;
    pc->treeOutline.n_children++;
}

static void delete_node (parent, node)
    Widget parent, node;
{
    TreeOutlineConstraints pc;
    int pos, i;

    /*
     * Make sure the parent exists.
     */
    if (!parent) return;  
  
    pc = TREEOUTLINE_CONSTRAINT(parent);

    /*
     * Find the sub_node on its parent's list.
     */
    for (pos = 0; pos < pc->treeOutline.n_children; pos++)
      if (pc->treeOutline.children[pos] == node) break;

    if (pos == pc->treeOutline.n_children) return;

    /*
     * Decrement the number of children
     */  
    pc->treeOutline.n_children--;

    /*
     * Fill in the gap left by the sub_node.
     * Zero the last slot for good luck.
     */
    for (i = pos; i < pc->treeOutline.n_children; i++) 
      pc->treeOutline.children[i] = pc->treeOutline.children[i+1];

    pc->treeOutline.children[pc->treeOutline.n_children]=0;
}

static void check_gravity (tw, grav)
    TreeOutlineWidget tw;
    XtGravity grav;
{
    switch (tw->treeOutline.gravity) {
      case WestGravity: case NorthGravity: case EastGravity: case SouthGravity:
	break;
      default:
	tw->treeOutline.gravity = grav;
	break;
    }
}

static void check_treetype (tw, type)
    TreeOutlineWidget tw;
    XtTreeOutlineType type;
{
    switch (tw->treeOutline.tree_outline) {
      case XtTREE: case XtOUTLINE:
	break;
      default:
	tw->treeOutline.tree_outline = type;
	break;
    }
}


/*****************************************************************************
 *                                                                           *
 * 			      treeOutline class methods                             *
 *                                                                           *
 *****************************************************************************/

static void ClassInitialize ()
{
    XawInitializeWidgetSet();
    XtAddConverter (XtRString, XtRGravity, XmuCvtStringToGravity,
		    (XtConvertArgList) NULL, (Cardinal) 0);
}


static void Initialize (grequest, gnew)
    Widget grequest, gnew;
{
    TreeOutlineWidget request = (TreeOutlineWidget) grequest, new = (TreeOutlineWidget) gnew;
    Arg args[2];

    /*
     * Make sure the widget's width and height are 
     * greater than zero.
     */
    if (request->core.width <= 0) new->core.width = 5;
    if (request->core.height <= 0) new->core.height = 5;

    /*
     * Set the padding according to the orientation
     */
    if (request->treeOutline.hpad == 0 && request->treeOutline.vpad == 0) {
	if (IsHorizontal (request)) {
	    new->treeOutline.hpad = TREEOUTLINE_HORIZONTAL_DEFAULT_SPACING;
	    new->treeOutline.vpad = TREEOUTLINE_VERTICAL_DEFAULT_SPACING;
	} else {
	    new->treeOutline.hpad = TREEOUTLINE_VERTICAL_DEFAULT_SPACING;
	    new->treeOutline.vpad = TREEOUTLINE_HORIZONTAL_DEFAULT_SPACING;
	}
    }

    /*
     * Create a graphics context for the connecting lines.
     */
    new->treeOutline.gc = get_treeOutline_gc (new);

    /*
     * Create the hidden root widget.
     */
    new->treeOutline.treeOutline_root = (Widget) NULL;
    XtSetArg(args[0], XtNwidth, 1);
    XtSetArg(args[1], XtNheight, 1);
    new->treeOutline.treeOutline_root = XtCreateWidget ("root", widgetClass, gnew, args,TWO);

    /*
     * Allocate the array used to hold the widest values per depth
     */
    new->treeOutline.largest = NULL;
    new->treeOutline.n_largest = 0;
    initialize_dimensions (&new->treeOutline.largest, &new->treeOutline.n_largest, 
			   TREEOUTLINE_INITIAL_DEPTH);

    /*
     * make sure that our gravity is one of the acceptable values
     */
    check_gravity (new, WestGravity);

    /*
     * make sure that our tree type is one of the acceptable values
     */
    check_treetype (new, XtTREE);

    new->treeOutline.in_change_managed = 0;
    new->treeOutline.internal_rm_count = 0;
} 


/* ARGSUSED */
static void ConstraintInitialize (request, new)
     Widget request, new;
{
    TreeOutlineConstraints tc = TREEOUTLINE_CONSTRAINT(new);
    TreeOutlineWidget tw = (TreeOutlineWidget) new->core.parent;

    /*
     * Initialize the widget to have no sub-nodes.
     */
    tc->treeOutline.n_children = 0;
    tc->treeOutline.max_children = 0;
    tc->treeOutline.children = (Widget *) NULL;
    tc->treeOutline.x = tc->treeOutline.y = 0; 
    tc->treeOutline.bbsubwidth = 0;
    tc->treeOutline.bbsubheight = 0;
    tc->treeOutline.internal_rm = 0;


    /*
     * If this widget has a super-node, add it to that 
     * widget' sub-nodes list. Otherwise make it a sub-node of 
     * the treeOutline_root widget.
     */
    if (tc->treeOutline.parent)
      insert_node (tc->treeOutline.parent, new);
    else if (tw->treeOutline.treeOutline_root)
      insert_node (tw->treeOutline.treeOutline_root, new);
} 


/* ARGSUSED */
static Boolean SetValues (gcurrent, grequest, gnew)
    Widget gcurrent, grequest, gnew;
{
    TreeOutlineWidget current = (TreeOutlineWidget) gcurrent, new = (TreeOutlineWidget) gnew;
    Boolean redraw = FALSE;

    /*
     * If the foreground color has changed, redo the GC's
     * and indicate a redraw.
     */
    if (new->treeOutline.foreground != current->treeOutline.foreground ||
	new->core.background_pixel != current->core.background_pixel ||
	new->treeOutline.line_width != current->treeOutline.line_width) {
	XtReleaseGC (gnew, new->treeOutline.gc);
	new->treeOutline.gc = get_treeOutline_gc (new);
	redraw = TRUE;     
    }

    /*
     * If the minimum spacing has changed, recalculate the
     * treeOutline layout. layout_treeOutline() does a redraw, so we don't
     * need SetValues to do another one.
     */
    if (new->treeOutline.gravity != current->treeOutline.gravity) {
	check_gravity (new, current->treeOutline.gravity);
    }
    if (new->treeOutline.tree_outline != current->treeOutline.tree_outline) {
	check_treetype (new, current->treeOutline.tree_outline);
    }

    if (IsHorizontal(new) != IsHorizontal(current)) {
	if (new->treeOutline.vpad == current->treeOutline.vpad &&
	    new->treeOutline.hpad == current->treeOutline.hpad) {
	    new->treeOutline.vpad = current->treeOutline.hpad;
	    new->treeOutline.hpad = current->treeOutline.vpad;
	}
    }

    if ((new->treeOutline.vpad != current->treeOutline.vpad ||
	new->treeOutline.hpad != current->treeOutline.hpad ||
	new->treeOutline.gravity != current->treeOutline.gravity) &&
	new->treeOutline.auto_reconfigure) {
	layout_treeOutline (new, TRUE);
	redraw = FALSE;
    }
    return redraw;
}


/* ARGSUSED */
static Boolean ConstraintSetValues (current, request, new, args, num_args)
    Widget current, request, new;
    ArgList args;
    Cardinal *num_args;
{
    TreeOutlineConstraints newc = TREEOUTLINE_CONSTRAINT(new);
    TreeOutlineConstraints curc = TREEOUTLINE_CONSTRAINT(current);
    TreeOutlineWidget tw = (TreeOutlineWidget) new->core.parent;

    /*
     * If the parent field has changed, remove the widget
     * from the old widget's children list and add it to the
     * new one.
     */
    if (curc->treeOutline.parent != newc->treeOutline.parent){
	if (curc->treeOutline.parent)
	  delete_node (curc->treeOutline.parent, new);
	if (newc->treeOutline.parent) {
	  insert_node(newc->treeOutline.parent, new);
	} else {
	    insert_node (tw->treeOutline.treeOutline_root, new);
	}

	/*
	 * If the TreeOutline widget has been realized, 
	 * compute new layout.
	 */
	if (XtIsRealized((Widget)tw) && tw->treeOutline.auto_reconfigure)
	  layout_treeOutline (tw, FALSE);
    }
    return False;
}

static void DestroySubtree (tw, w)
TreeOutlineWidget tw;
Widget w;
{
    TreeOutlineConstraints tc = TREEOUTLINE_CONSTRAINT(w);
    int i;

    for (i = 0; i < tc->treeOutline.n_children; i ++)
	DestroySubtree (tw, tc->treeOutline.children[i]);
    if (!w->core.being_destroyed) {
	tc->treeOutline.internal_rm = 1;
	tw->treeOutline.internal_rm_count ++;
	XtDestroyWidget (w);
    }
}

static void ConstraintDestroy (w) 
    Widget w;
{ 
    TreeOutlineConstraints tc = TREEOUTLINE_CONSTRAINT(w);
    TreeOutlineWidget tw = (TreeOutlineWidget) XtParent(w);
    int i;

    /* 
     * Remove the widget from its parent's sub-nodes list and
     * make all this widget's sub-nodes sub-nodes of the parent.
     */
  
    if (tw->treeOutline.treeOutline_root == w) {
	if (tc->treeOutline.n_children > 0)
	  tw->treeOutline.treeOutline_root = tc->treeOutline.children[0];
	else
	  tw->treeOutline.treeOutline_root = NULL;
    }

    if (tc->treeOutline.internal_rm) {
	tw->treeOutline.internal_rm_count --;
	delete_node (tc->treeOutline.parent, (Widget) w);
    }
    if (tw->treeOutline.internal_rm_count == 0) {
	layout_treeOutline ((TreeOutlineWidget) (w->core.parent), FALSE);
    }
}

/* ARGSUSED */
static XtGeometryResult GeometryManager (w, request, reply)
    Widget w;
    XtWidgetGeometry *request;
    XtWidgetGeometry *reply;
{

    TreeOutlineWidget tw = (TreeOutlineWidget) w->core.parent;

    /*
     * No position changes allowed!.
     */
    if ((request->request_mode & CWX && request->x!=w->core.x)
	||(request->request_mode & CWY && request->y!=w->core.y))
      return (XtGeometryNo);

    /*
     * Allow all resize requests.
     */

    if (request->request_mode & CWWidth)
      w->core.width = request->width;
    if (request->request_mode & CWHeight)
      w->core.height = request->height;
    if (request->request_mode & CWBorderWidth)
      w->core.border_width = request->border_width;

    if (tw->treeOutline.auto_reconfigure) layout_treeOutline (tw, FALSE);
    return (XtGeometryYes);
}

static int UnmanageChildrenManually (w, list, count, unmanage)
Widget w;
WidgetList list;
int count;
int unmanage;
{
    TreeOutlineConstraints tc = TREEOUTLINE_CONSTRAINT (w);
    int i;
    
    if (unmanage && w->core.managed) {
	list[count ++] = w;
    } else if (!unmanage && !w->core.managed) {
	unmanage = 1;
    }
    for (i = 0; i < tc->treeOutline.n_children; i ++) {
	count = UnmanageChildrenManually (tc->treeOutline.children[i], list, count, unmanage);
    }
    return count;
}

static void ChangeManaged (gw)
    Widget gw;
{
    /*
     *	Need to walk the tree, checking for unmanaged tree nodes that have managed
     *  tree children. We need to unmanage those children (and their children...)
     *  However, we don't want to layout the tree everytime, so we'll only make
     *  the call to layout_tree when our recursive search for children that we
     *  need to unmanage returns nothing.
     */
     WidgetList kidsToUnmanage;
     int kidCount, i;
     TreeOutlineWidget tw = (TreeOutlineWidget) gw;
     Widget root = tw->treeOutline.treeOutline_root;
     TreeOutlineConstraints tc = TREEOUTLINE_CONSTRAINT (root);

     if (tw->treeOutline.in_change_managed)
	return;
     tw->treeOutline.in_change_managed = 1;

     XtVaGetValues (gw, XtNnumChildren, &kidCount, NULL);
     kidsToUnmanage = (WidgetList) XtCalloc (kidCount, sizeof (Widget));
     kidCount = 0;
     for (i = 0; i < tc->treeOutline.n_children; i ++) {
	kidCount = UnmanageChildrenManually (tc->treeOutline.children[i], kidsToUnmanage, kidCount, 0);
     }
     if (kidCount) {
	XtUnmanageChildren (kidsToUnmanage, kidCount);
     }
     XtFree ((char*)kidsToUnmanage);
     if (tw->treeOutline.auto_reconfigure) {
	 layout_treeOutline ((TreeOutlineWidget) gw, FALSE);
     }
     tw->treeOutline.in_change_managed = 0;
}

static void Destroy (gw)
    Widget gw;
{
    TreeOutlineWidget w = (TreeOutlineWidget) gw;

    XtReleaseGC (gw, w->treeOutline.gc);
    if (w->treeOutline.largest) XtFree ((char *) w->treeOutline.largest);
}

static void redisplay_tree (tw, event, region)
     TreeOutlineWidget tw;
     XEvent *event;
     Region region;
{
    int count;
    int i, j, c;
    Display *dpy = XtDisplay (tw);
    Window w = XtWindow (tw);
    
    for (i = 0; i < tw->composite.num_children; i++) {
	register Widget child = tw->composite.children[i];
	TreeOutlineConstraints tc = TREEOUTLINE_CONSTRAINT(child);
	
	if (!child->core.managed)
	  continue;

	/*
	 * Don't draw lines from the fake treeOutline_root.
	 */
	count = 0;
	for (c = 0; c < tc->treeOutline.n_children; c ++) {
	    if (tc->treeOutline.children[c]->core.managed)
	      count ++;
	}
	if (child != tw->treeOutline.treeOutline_root && count) {
	    int srcx = child->core.x + child->core.border_width;
	    int srcy = child->core.y + child->core.border_width;
	    
	    switch (tw->treeOutline.gravity) {
	    case WestGravity:
		srcx += child->core.width + child->core.border_width;
		/* fall through */
	    case EastGravity:
		srcy += child->core.height / 2;
		break;
		
	    case NorthGravity:
		srcy += child->core.height + child->core.border_width;
		/* fall through */
	    case SouthGravity:
		srcx += child->core.width / 2;
		break;
	    }
	    
	    for (j = 0; j < tc->treeOutline.n_children; j++) {
		register Widget k = tc->treeOutline.children[j];
		GC gc = (tc->treeOutline.gc ? tc->treeOutline.gc : tw->treeOutline.gc);
		
		if (!k->core.managed)
		  continue;

		switch (tw->treeOutline.gravity) {
		case WestGravity:
		    /*
		     * right center to left center
		     */
		    XDrawLine (dpy, w, gc, srcx, srcy,
			       (int) k->core.x,
			       (k->core.y + ((int) k->core.border_width) +
				((int) k->core.height) / 2));
		    break;
		    
		case NorthGravity:
		    /*
		     * bottom center to top center
		     */
		    XDrawLine (dpy, w, gc, srcx, srcy,
			       (k->core.x + ((int) k->core.border_width) +
				((int) k->core.width) / 2),
			       (int) k->core.y);
		    break;
		    
		case EastGravity:
		    /*
		     * left center to right center
		     */
		    XDrawLine (dpy, w, gc, srcx, srcy,
			       (k->core.x +
				(((int) k->core.border_width) << 1) +
				(int) k->core.width),
			       (k->core.y + ((int) k->core.border_width) +
				((int) k->core.height) / 2));
		    break;
		    
		case SouthGravity:
		    /*
		     * top center to bottom center
		     */
		    XDrawLine (dpy, w, gc, srcx, srcy,
			       (k->core.x + ((int) k->core.border_width) +
				((int) k->core.width) / 2),
			       (k->core.y +
				(((int) k->core.border_width) << 1) +
				(int) k->core.height));
		    break;
		}
	    }
	}
    }
}

static void redisplay_outline (tw, event, region)
     TreeOutlineWidget tw;
     XEvent *event;
     Region region;
{

}


/* ARGSUSED */
static void Redisplay (tw, event, region)
     TreeOutlineWidget tw;
     XEvent *event;
     Region region;
{
    /*
     * If the TreeOutline widget is visible, visit each managed child.
     */
    if (tw->core.visible) {
	switch (tw->treeOutline.tree_outline) {
	case XtTREE:
	    redisplay_tree (tw, event, region);
	    break;
	case XtOUTLINE:
	    redisplay_outline (tw, event, region);
	    break;	    
	}
    }
}

static XtGeometryResult QueryGeometry (w, intended, preferred)
    Widget w;
    XtWidgetGeometry *intended, *preferred;
{
    register TreeOutlineWidget tw = (TreeOutlineWidget) w;

    preferred->request_mode = (CWWidth | CWHeight);
    preferred->width = tw->treeOutline.maxwidth;
    preferred->height = tw->treeOutline.maxheight;

    if (((intended->request_mode & (CWWidth | CWHeight)) ==
	 (CWWidth | CWHeight)) &&
	intended->width == preferred->width &&
	intended->height == preferred->height)
      return XtGeometryYes;
    else if (preferred->width == w->core.width &&
             preferred->height == w->core.height)
      return XtGeometryNo;
    else
      return XtGeometryAlmost;
}


/*****************************************************************************
 *                                                                           *
 *			     treeOutline layout algorithm                           *
 *                                                                           *
 * Each node in the treeOutline is "shrink-wrapped" with a minimal bounding         *
 * rectangle, laid next to its siblings (with a small about of padding in    *
 * between) and then wrapped with their parent.  Parents are centered about  *
 * their children (or vice versa if the parent is larger than the children). *
 *                                                                           *
 *****************************************************************************/

static void compute_bounding_box_subtree (treeOutline, w, depth)
    TreeOutlineWidget treeOutline;
    Widget w;
    int depth;
{
    TreeOutlineConstraints tc = TREEOUTLINE_CONSTRAINT(w);  /* info attached to all kids */
    register int i;
    Bool horiz = IsHorizontal (treeOutline);
    Dimension newwidth, newheight;
    Dimension bw2 = w->core.border_width * 2;

    /*
     * Set the max-size per level.
     */
    if (depth >= treeOutline->treeOutline.n_largest) {
	initialize_dimensions (&treeOutline->treeOutline.largest,
			       &treeOutline->treeOutline.n_largest, depth + 1);
    }
    newwidth = ((horiz ? w->core.width : w->core.height) + bw2);
    if (treeOutline->treeOutline.largest[depth] < newwidth)
      treeOutline->treeOutline.largest[depth] = newwidth;


    /*
     * initialize
     */
    tc->treeOutline.bbwidth = w->core.width + bw2;
    tc->treeOutline.bbheight = w->core.height + bw2;

    {
	int count = 0;
	for (i = 0; i < tc->treeOutline.n_children; i ++) {
	    Widget child = tc->treeOutline.children[i];
	    if (child->core.managed)
		count ++;
	}
	if (count == 0)
	    return;
    }

    /*
     * Figure the size of the opposite dimension (vertical if treeOutline is 
     * horizontal, else vice versa).  The other dimension will be set 
     * in the second pass once we know the maximum dimensions.
     */
    newwidth = 0;
    newheight = 0;
    for (i = 0; i < tc->treeOutline.n_children; i++) {
	Widget child = tc->treeOutline.children[i];
	TreeOutlineConstraints cc = TREEOUTLINE_CONSTRAINT(child);
	    
	if (!child->core.managed)
	    continue;

	compute_bounding_box_subtree (treeOutline, child, depth + 1);

	if (horiz) {
	    if (newwidth < cc->treeOutline.bbwidth) newwidth = cc->treeOutline.bbwidth;
	    newheight += treeOutline->treeOutline.vpad + cc->treeOutline.bbheight;
	} else {
	    if (newheight < cc->treeOutline.bbheight) newheight = cc->treeOutline.bbheight;
	    newwidth += treeOutline->treeOutline.hpad + cc->treeOutline.bbwidth;
	}
    }


    tc->treeOutline.bbsubwidth = newwidth;
    tc->treeOutline.bbsubheight = newheight;

    /*
     * Now fit parent onto side (or top) of bounding box and correct for
     * extra padding.  Be careful of unsigned arithmetic.
     */
    if (horiz) {
	tc->treeOutline.bbwidth += treeOutline->treeOutline.hpad + newwidth;
	newheight -= treeOutline->treeOutline.vpad;
	if (newheight > tc->treeOutline.bbheight) tc->treeOutline.bbheight = newheight;
    } else {
	tc->treeOutline.bbheight += treeOutline->treeOutline.vpad + newheight;
	newwidth -= treeOutline->treeOutline.hpad;
	if (newwidth > tc->treeOutline.bbwidth) tc->treeOutline.bbwidth = newwidth;
    }
}

static void compute_bounding_box_suboutline (treeOutline, w, depth)
    TreeOutlineWidget treeOutline;
    Widget w;
    int depth;
{
    TreeOutlineConstraints tc = TREEOUTLINE_CONSTRAINT(w);  /* info attached to all kids */
    register int i;
    Bool horiz = IsHorizontal (treeOutline);
    Dimension newwidth, newheight;
    Dimension bw2 = w->core.border_width * 2;

    /*
     * Set the max-size per level.
     */
    if (depth >= treeOutline->treeOutline.n_largest) {
	initialize_dimensions (&treeOutline->treeOutline.largest,
			       &treeOutline->treeOutline.n_largest, depth + 1);
    }
    newwidth = ((horiz ? w->core.width : w->core.height) + bw2);
    if (treeOutline->treeOutline.largest[depth] < newwidth)
      treeOutline->treeOutline.largest[depth] = newwidth;


    /*
     * initialize
     */
    tc->treeOutline.bbwidth = w->core.width + bw2;
    tc->treeOutline.bbheight = w->core.height + bw2;

    {
	int count = 0;
	for (i = 0; i < tc->treeOutline.n_children; i ++) {
	    Widget child = tc->treeOutline.children[i];
	    if (child->core.managed)
		count ++;
	}
	if (count == 0)
	    return;
    }

    /*
     * Figure the size of the opposite dimension (vertical if treeOutline is 
     * horizontal, else vice versa).  The other dimension will be set 
     * in the second pass once we know the maximum dimensions.
     */
    newwidth = 0;
    newheight = 0;
    for (i = 0; i < tc->treeOutline.n_children; i++) {
	Widget child = tc->treeOutline.children[i];
	TreeOutlineConstraints cc = TREEOUTLINE_CONSTRAINT(child);
	    
	if (!child->core.managed)
	    continue;

	compute_bounding_box_suboutline (treeOutline, child, depth + 1);

	if (newwidth < cc->treeOutline.bbwidth) newwidth = cc->treeOutline.bbwidth;
	newheight += treeOutline->treeOutline.vpad + cc->treeOutline.bbheight;
    }


    tc->treeOutline.bbsubwidth = newwidth;
    tc->treeOutline.bbsubheight = newheight;

    /*
     * Now fit parent onto side (or top) of bounding box and correct for
     * extra padding.  Be careful of unsigned arithmetic.
     */

    tc->treeOutline.bbheight += treeOutline->treeOutline.vpad + newheight;
    newwidth -= treeOutline->treeOutline.hpad;
    if (newwidth > tc->treeOutline.bbwidth) tc->treeOutline.bbwidth = newwidth;
}


static void set_positions (tw, w, level)
     TreeOutlineWidget tw;
     Widget w;
     int level;
{
    int i;
  
    if (w) {
	TreeOutlineConstraints tc = TREEOUTLINE_CONSTRAINT(w);

	if (level > 0) {
	    /*
	     * mirror if necessary
	     */
	    switch (tw->treeOutline.gravity) {
	      case EastGravity:
		tc->treeOutline.x = (((Position) tw->treeOutline.maxwidth) -
			      ((Position) w->core.width) - tc->treeOutline.x);
		break;

	      case SouthGravity:
		tc->treeOutline.y = (((Position) tw->treeOutline.maxheight) -
			      ((Position) w->core.height) - tc->treeOutline.y);
		break;
	    }

	    /*
	     * Move the widget into position.
	     */
	    XtMoveWidget (w, tc->treeOutline.x, tc->treeOutline.y);
	}

	/*
	 * Set the positions of all children.
	 */
	for (i = 0; i < tc->treeOutline.n_children; i++)
	  if (tc->treeOutline.children[i]->core.managed)
	    set_positions (tw, tc->treeOutline.children[i], level + 1);
    }
}


static void arrange_subtree (treeOutline, w, depth, x, y)
    TreeOutlineWidget treeOutline;
    Widget w;
    int depth;
    Position x, y;
{
    TreeOutlineConstraints tc = TREEOUTLINE_CONSTRAINT(w);  /* info attached to all kids */
    TreeOutlineConstraints firstcc, lastcc;
    register int i;
    int newx, newy;
    Bool horiz = IsHorizontal (treeOutline);
    Widget child = NULL;
    Dimension tmp;
    Dimension bw2 = w->core.border_width * 2;
    Bool relayout = True;


    /*
     * If no children, then just lay out where requested.
     */
    tc->treeOutline.x = x;
    tc->treeOutline.y = y;

    if (horiz) {
	int myh = (w->core.height + bw2);

	if (myh > (int)tc->treeOutline.bbsubheight) {
	    y += (myh - (int)tc->treeOutline.bbsubheight) / 2;
	    relayout = False;
	}
    } else {
	int myw = (w->core.width + bw2);

	if (myw > (int)tc->treeOutline.bbsubwidth) {
	    x += (myw - (int)tc->treeOutline.bbsubwidth) / 2;
	    relayout = False;
	}
    }

    if ((tmp = ((Dimension) x) + tc->treeOutline.bbwidth) > treeOutline->treeOutline.maxwidth)
      treeOutline->treeOutline.maxwidth = tmp;
    if ((tmp = ((Dimension) y) + tc->treeOutline.bbheight) > treeOutline->treeOutline.maxheight)
      treeOutline->treeOutline.maxheight = tmp;

    {
	int count = 0;
	for (i = 0; i < tc->treeOutline.n_children; i ++)
	    if (tc->treeOutline.children[i]->core.managed)
		count ++;
	if (count == 0)
	    return;
    }

    /*
     * Have children, so walk down treeOutline laying out children, then laying
     * out parents.
     */
    if (horiz) {
	newx = x + treeOutline->treeOutline.largest[depth];
	if (depth > 0) newx += treeOutline->treeOutline.hpad;
	newy = y;
    } else {
	newx = x;
	newy = y + treeOutline->treeOutline.largest[depth];
	if (depth > 0) newy += treeOutline->treeOutline.vpad;
    }

    for (i = 0; i < tc->treeOutline.n_children; i++) {
	TreeOutlineConstraints cc;

	child = tc->treeOutline.children[i];	/* last value is used outside loop */
	if (!child->core.managed)
	    continue;
	cc = TREEOUTLINE_CONSTRAINT(child);

	arrange_subtree (treeOutline, child, depth + 1, newx, newy);
	if (horiz) {
	    newy += treeOutline->treeOutline.vpad + cc->treeOutline.bbheight;
	} else {
	    newx += treeOutline->treeOutline.hpad + cc->treeOutline.bbwidth;
	}
    }

    /*
     * now layout parent between first and last children
     */
    if (relayout) {
	Position adjusted;
    {
	int j;
	for (j = 0; j < tc->treeOutline.n_children; j ++) {
	    if (tc->treeOutline.children[j]->core.managed) {
		firstcc = TREEOUTLINE_CONSTRAINT (tc->treeOutline.children[j]);
		break;
	    }
	}
	for (j = tc->treeOutline.n_children - 1; j >= 0; j --) {
	    if (tc->treeOutline.children[j]->core.managed) {
		lastcc = TREEOUTLINE_CONSTRAINT (tc->treeOutline.children[j]);
		break;
	    }
	}
    }

	/* Adjustments are disallowed if they result in a position above
         * or to the left of the originally requested position, because
	 * this could collide with the position of the previous sibling.
	 */
	if (horiz) {
	    tc->treeOutline.x = x;
	    adjusted = firstcc->treeOutline.y +
	      ((lastcc->treeOutline.y + (Position) child->core.height + 
		(Position) child->core.border_width * 2 -
		firstcc->treeOutline.y - (Position) w->core.height - 
		(Position) w->core.border_width * 2 + 1) / 2);
	    if (adjusted > tc->treeOutline.y) tc->treeOutline.y = adjusted;
	} else {
	    adjusted = firstcc->treeOutline.x +
	      ((lastcc->treeOutline.x + (Position) child->core.width +
		(Position) child->core.border_width * 2 -
		firstcc->treeOutline.x - (Position) w->core.width -
		(Position) w->core.border_width * 2 + 1) / 2);
	    if (adjusted > tc->treeOutline.x) tc->treeOutline.x = adjusted;
	    tc->treeOutline.y = y;
	}
    }
}

static void arrange_suboutline (treeOutline, w, depth, x, y)
    TreeOutlineWidget treeOutline;
    Widget w;
    int depth;
    Position x, y;
{
    TreeOutlineConstraints tc = TREEOUTLINE_CONSTRAINT(w);  /* info attached to all kids */
    TreeOutlineConstraints firstcc, lastcc;
    register int i;
    int newx, newy;
    Bool horiz = IsHorizontal (treeOutline);
    Widget child = NULL;
    Dimension tmp;
    Dimension bw2 = w->core.border_width * 2;
    Bool relayout = True;
    int myh;

    /*
     * If no children, then just lay out where requested.
     */
    tc->treeOutline.x = x;
    tc->treeOutline.y = y;

    myh = (w->core.height + bw2);
/*** THIS DOESN'T WORK -SWM
    if (myh > (int)tc->treeOutline.bbsubheight) {
	y += (myh - (int)tc->treeOutline.bbsubheight) / 2;
	relayout = False;
    }
***/

    if ((tmp = ((Dimension) x) + tc->treeOutline.bbwidth) > treeOutline->treeOutline.maxwidth)
      treeOutline->treeOutline.maxwidth = tmp;
    if ((tmp = ((Dimension) y) + tc->treeOutline.bbheight) > treeOutline->treeOutline.maxheight) {
      treeOutline->treeOutline.maxheight = tmp;
    }

    {
	int count = 0;
	for (i = 0; i < tc->treeOutline.n_children; i ++)
	    if (tc->treeOutline.children[i]->core.managed)
		count ++;
	if (count == 0)
	    return;
    }

    /*
     * Have children, so walk down treeOutline laying out children, then laying
     * out parents.
     */

    /**********************************************************/
    /*	newx = x + treeOutline->treeOutline.largest[depth];   */
    /*	if (depth > 0) newx += treeOutline->treeOutline.hpad; */
    /**********************************************************/

    newx = x + treeOutline->treeOutline.hpad;
    newy = y + treeOutline->treeOutline.vpad;

    for (i = 0; i < tc->treeOutline.n_children; i++) {
	TreeOutlineConstraints cc;

	child = tc->treeOutline.children[i];	/* last value is used outside loop */
	if (!child->core.managed)
	    continue;
	cc = TREEOUTLINE_CONSTRAINT(child);

	if(i==0 && depth > 0) {
	    newy += treeOutline->treeOutline.vpad + myh;
	    relayout = False;
	}

	arrange_suboutline (treeOutline, child, depth + 1, newx, newy);

	newy += treeOutline->treeOutline.vpad + cc->treeOutline.bbheight;
    }

    /*
     * now layout parent between first and last children
     */
    if (relayout) {
	Position adjusted;
    {
	int j;
	for (j = 0; j < tc->treeOutline.n_children; j ++) {
	    if (tc->treeOutline.children[j]->core.managed) {
		firstcc = TREEOUTLINE_CONSTRAINT (tc->treeOutline.children[j]);
		break;
	    }
	}
	for (j = tc->treeOutline.n_children - 1; j >= 0; j --) {
	    if (tc->treeOutline.children[j]->core.managed) {
		lastcc = TREEOUTLINE_CONSTRAINT (tc->treeOutline.children[j]);
		break;
	    }
	}
    }

	/* Adjustments are disallowed if they result in a position above
         * or to the left of the originally requested position, because
	 * this could collide with the position of the previous sibling.
	 */
	if (horiz) {
	    tc->treeOutline.x = x;
	    adjusted = firstcc->treeOutline.y +
	      ((lastcc->treeOutline.y + (Position) child->core.height + 
		(Position) child->core.border_width * 2 -
		firstcc->treeOutline.y - (Position) w->core.height - 
		(Position) w->core.border_width * 2 + 1) / 2);
	    if (adjusted > tc->treeOutline.y) tc->treeOutline.y = adjusted;
	} else {
	    adjusted = firstcc->treeOutline.x +
	      ((lastcc->treeOutline.x + (Position) child->core.width +
		(Position) child->core.border_width * 2 -
		firstcc->treeOutline.x - (Position) w->core.width -
		(Position) w->core.border_width * 2 + 1) / 2);
	    if (adjusted > tc->treeOutline.x) tc->treeOutline.x = adjusted;
	    tc->treeOutline.y = y;
	}
    }
}

static void set_treeOutline_size (tw, insetvalues, width, height)
    TreeOutlineWidget tw;
    Boolean insetvalues;
    Dimension width, height;
{
    if (insetvalues) {
	tw->core.width = width;
	tw->core.height = height;
    } else {
	Dimension replyWidth = 0, replyHeight = 0;
	XtGeometryResult result = XtMakeResizeRequest ((Widget) tw,
						       width, height,
						       &replyWidth,
						       &replyHeight);
	/*
	 * Accept any compromise.
	 */
	if (result == XtGeometryAlmost)
	  XtMakeResizeRequest ((Widget) tw, replyWidth, replyHeight,
			       (Dimension *) NULL, (Dimension *) NULL);
    }
    return;
}

static void layout_tree (tw, insetvalues)
    TreeOutlineWidget tw;
    Boolean insetvalues;
{
    int i;
    Dimension *dp;

    tw->treeOutline.maxwidth = tw->treeOutline.maxheight = 0;
    for (i = 0, dp = tw->treeOutline.largest; i < tw->treeOutline.n_largest; i++, dp++)
      *dp = 0;
    initialize_dimensions (&tw->treeOutline.largest, &tw->treeOutline.n_largest, 
			   tw->treeOutline.n_largest);
    compute_bounding_box_subtree (tw, tw->treeOutline.treeOutline_root, 0);

   /*
    * Second pass to do final layout.  Each child's bounding box is stacked
    * on top of (if horizontal, else next to) on top of its siblings.  The
    * parent is centered between the first and last children.
    */
    arrange_subtree (tw, tw->treeOutline.treeOutline_root, 0, 0, 0);

    /*
     * Move each widget into place.
     */
    set_treeOutline_size (tw, insetvalues, tw->treeOutline.maxwidth, tw->treeOutline.maxheight);
    set_positions (tw, tw->treeOutline.treeOutline_root, 0);

}

static void layout_outline (tw, insetvalues)
    TreeOutlineWidget tw;
    Boolean insetvalues;
{
    int i;
    Dimension *dp;

    tw->treeOutline.maxwidth = tw->treeOutline.maxheight = 0;
    for (i = 0, dp = tw->treeOutline.largest; i < tw->treeOutline.n_largest; i++, dp++)
      *dp = 0;
    initialize_dimensions (&tw->treeOutline.largest, &tw->treeOutline.n_largest, 
			   tw->treeOutline.n_largest);
    compute_bounding_box_suboutline (tw, tw->treeOutline.treeOutline_root, 0);

   /*
    * Second pass to do final layout.  Each child's bounding box is stacked
    * on top of (if horizontal, else next to) on top of its siblings.  The
    * parent is centered between the first and last children.
    */
    arrange_suboutline (tw, tw->treeOutline.treeOutline_root, 0, 0, 0);

    /*
     * Move each widget into place.
     */
    set_treeOutline_size (tw, insetvalues, tw->treeOutline.maxwidth + tw->treeOutline.hpad, tw->treeOutline.maxheight);
    set_positions (tw, tw->treeOutline.treeOutline_root, 0);

}

static void layout_treeOutline (tw, insetvalues)
    TreeOutlineWidget tw;
    Boolean insetvalues;
{
    int i;
    Dimension *dp;

    /*
     * Do a depth-first search computing the width and height of the bounding
     * box for the treeOutline at that position (and below).  Then, walk again using
     * this information to layout the children at each level.
     */

    if (tw->treeOutline.treeOutline_root == NULL)
	return;

    switch (tw->treeOutline.tree_outline) {
    case XtTREE: 
	layout_tree(tw, insetvalues);
	break;
    case XtOUTLINE:
	layout_outline(tw, insetvalues);
	break;
    }

    /*
     * And redisplay.
     */
    if (XtIsRealized ((Widget) tw)) {
	XClearArea (XtDisplay(tw), XtWindow((Widget)tw), 0, 0, 0, 0, True);
    }
}




/*****************************************************************************
 *                                                                           *
 * 				Public Routines                              *
 *                                                                           *
 *****************************************************************************/

void
#if NeedFunctionPrototypes
XawTreeOutlineForceLayout (Widget treeOutline)
#else
XawTreeOutlineForceLayout (treeOutline)
    Widget treeOutline;
#endif
{
    layout_treeOutline ((TreeOutlineWidget) treeOutline, FALSE);
}

void
#if NeedFunctionPrototypes
XawTreeOutlineDestroySubtree (Widget treeChild)
#else
XawTreeOutlineDestroySubtree (treeChild)
Widget treeChild;
#endif
{
    TreeOutlineWidget tw = (TreeOutlineWidget) XtParent(treeChild);
    DestroySubtree (tw, treeChild);
}

void
#if NeedFunctionPrototypes
XawTreeOutlineDestroyChildren (Widget treeChild)
#else
XawTreeOutlineDestroyChildren (treeChild)
Widget treeChild;
#endif
{
    TreeOutlineConstraints tc = TREEOUTLINE_CONSTRAINT (treeChild);
    TreeOutlineWidget tw = (TreeOutlineWidget) XtParent(treeChild);
    int i;

    for (i = 0; i < tc->treeOutline.n_children; i ++)
	DestroySubtree (tw, tc->treeOutline.children[i]);
}
