/*
 * $Id: HistogramModC.C,v 1.1 1998/06/24 01:29:07 lang Exp $
 *
 * Copyright (c) 1992 HAL Computer Systems International, Ltd.
 * 
 *          HAL COMPUTER SYSTEMS INTERNATIONAL, LTD.
 *                  1315 Dell Avenue
 *                  Campbell, CA  95008
 *
 * Author: Greg Hilton
 * Contributors: Tom Lang, Frank Bieser, and others
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * http://www.gnu.org/copyleft/gpl.html
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#include "HistogramModC.h"
#include "FormatModC.h"
#include "ShadowModC.h"
#include "OrientModC.h"
#include "ColorModC.h"
#include "WArgList.h"
#include "rsrc.h"

#include <Xm/Form.h>
#include <Xm/Frame.h>
#include <Xm/Label.h>
#include <Xm/TextF.h>
#include <Xm/ToggleB.h>
#include <Xm/RowColumn.h>

HistogramModC::HistogramModC(Widget parent, const char *name, ArgList argv,
			     Cardinal argc)
   : ModFormC(parent, name, argv, argc)
{
   WArgList	args;
   StringC	wname;
   int	ltOffset = get_int("HistogramModC", paramForm, "labelTextOffset");

   histogram = NULL;

//
// Create the paramForm hierarchy
//
//   paramForm
//      ShadowModC	shadowForm
//      ShadowModC	barShadowForm
//      Label		tick1LenLabel
//      TextField	tick1LenTF
//      Label		tick2LenLabel
//      TextField	tick2LenTF
//      Label		margWdLabel
//      TextField	margWdTF
//      Label		margHtLabel
//      TextField	margHtTF
//      OrientModC	orientForm
//	Label		maxCountLabel
//	TextField	maxCountTF
//      Frame		valFrame
//      Frame		cntFrame
//
   wname = "shadowMod";
   args.Reset();
   args.LeftAttachment(XmATTACH_FORM);
   args.TopAttachment(XmATTACH_FORM);
   shadowForm = new ShadowModC(paramForm, wname, ARGS);

   wname = "barShadowMod";
   args.Reset();
   args.TopAttachment(XmATTACH_WIDGET, *shadowForm);
   args.LeftAttachment(XmATTACH_FORM);
   barShadowForm = new ShadowModC(paramForm, wname, ARGS);

   wname = "majorTickLengthLabel";
   tick1LenLabel = XmCreateLabel(paramForm, wname, 0,0);

   wname = "majorTickLengthTF";
   args.Reset();
   args.TopAttachment(XmATTACH_WIDGET, *barShadowForm);
   args.LeftAttachment(XmATTACH_FORM);
   tick1LenTF = XmCreateTextField(paramForm, wname, ARGS);

   wname = "marginWidthLabel";
   margWdLabel = XmCreateLabel(paramForm, wname, 0,0);

   wname = "marginWidthTF";
   args.Reset();
   args.TopAttachment(XmATTACH_WIDGET, tick1LenTF);
   args.LeftAttachment(XmATTACH_FORM);
   margWdTF = XmCreateTextField(paramForm, wname, ARGS);

   wname = "orientationMod";
   args.Reset();
   args.TopAttachment(XmATTACH_WIDGET, margWdTF);
   args.LeftAttachment(XmATTACH_FORM);
   orientForm = new OrientModC(paramForm, wname, ARGS);

//
// Get maximum label width
//
   Dimension	wd, max_wd;
   args.Reset();
   args.Add(XmNwidth, &wd);
   XtGetValues(shadowForm->TypeLabel(),    ARGS); max_wd = wd;
   XtGetValues(barShadowForm->TypeLabel(), ARGS); if (wd>max_wd) max_wd = wd;
   XtGetValues(tick1LenLabel,              ARGS); if (wd>max_wd) max_wd = wd;
   XtGetValues(margWdLabel,                ARGS); if (wd>max_wd) max_wd = wd;
   XtGetValues(orientForm->Label(),        ARGS); if (wd>max_wd) max_wd = wd;

   args.Reset();
   args.LeftAttachment(XmATTACH_FORM, max_wd + ltOffset);
   XtSetValues(shadowForm->TypeFrame(),    ARGS);
   XtSetValues(barShadowForm->TypeFrame(), ARGS);
   XtSetValues(tick1LenTF,                 ARGS);
   XtSetValues(margWdTF,                   ARGS);
   XtSetValues(orientForm->Frame(),        ARGS);

//
// Attach labels
//
   args.Reset();
   args.TopAttachment(XmATTACH_OPPOSITE_WIDGET,    tick1LenTF);
   args.BottomAttachment(XmATTACH_OPPOSITE_WIDGET, tick1LenTF);
   args.RightAttachment(XmATTACH_WIDGET,           tick1LenTF);
   XtSetValues(tick1LenLabel, ARGS);

   args.TopWidget(margWdTF);
   args.BottomWidget(margWdTF);
   args.RightWidget(margWdTF);
   XtSetValues(margWdLabel, ARGS);

//
// Create the second column of labels and fields
//
   wname = "minorTickLengthLabel";
   tick2LenLabel = XmCreateLabel(paramForm, wname, 0,0);

   wname = "minorTickLengthTF";
   args.Reset();
   args.TopAttachment(XmATTACH_OPPOSITE_WIDGET, tick1LenTF);
   args.LeftAttachment(XmATTACH_WIDGET, tick1LenTF);
   tick2LenTF = XmCreateTextField(paramForm, wname, ARGS);

   wname = "marginHeightLabel";
   margHtLabel = XmCreateLabel(paramForm, wname, 0,0);

   wname = "marginHeightTF";
   args.Reset();
   args.TopAttachment(XmATTACH_OPPOSITE_WIDGET, margWdTF);
   args.LeftAttachment(XmATTACH_WIDGET, margWdTF);
   margHtTF = XmCreateTextField(paramForm, wname, ARGS);

   wname = "maximumValueCountLabel";
   maxCountLabel = XmCreateLabel(paramForm, wname, ARGS);
   XtVaGetValues(maxCountLabel, XmNwidth, &wd, NULL);

   wname = "maximumValueCountTF";
   args.Reset();
   args.TopAttachment(XmATTACH_OPPOSITE_WIDGET, *orientForm);
   args.LeftAttachment(XmATTACH_WIDGET, *orientForm, wd + ltOffset);
   maxCountTF = XmCreateTextField(paramForm, wname, ARGS);

//
// Position 2nd column labels and text
//
   max_wd = 0;
   args.Reset();
   args.Add(XmNwidth, &wd);
   XtGetValues(tick2LenLabel, ARGS); if (wd>max_wd) max_wd = wd;
   XtGetValues(margHtLabel,   ARGS); if (wd>max_wd) max_wd = wd;

   args.Reset();
   args.LeftAttachment(XmATTACH_WIDGET, tick1LenTF, max_wd + ltOffset);
   XtSetValues(tick2LenTF, ARGS);

   args.LeftWidget(margWdTF);
   XtSetValues(margHtTF, ARGS);

   args.LeftWidget(*orientForm);
   XtSetValues(maxCountTF, ARGS);

   args.Reset();
   args.LeftAttachment  (XmATTACH_NONE);
   args.RightAttachment (XmATTACH_WIDGET,          tick2LenTF);
   args.TopAttachment   (XmATTACH_OPPOSITE_WIDGET, tick2LenTF);
   args.BottomAttachment(XmATTACH_OPPOSITE_WIDGET, tick2LenTF);
   XtSetValues(tick2LenLabel, ARGS);

   args.RightWidget (margHtTF);
   args.TopWidget   (margHtTF);
   args.BottomWidget(margHtTF);
   XtSetValues(margHtLabel, ARGS);

   args.RightWidget (maxCountTF);
   args.TopWidget   (maxCountTF);
   args.BottomWidget(maxCountTF);
   XtSetValues(maxCountLabel, ARGS);

//
// Create axis frames
//
   wname = "valueAxisFrame";
   args.Reset();
   args.TopAttachment(XmATTACH_WIDGET, *orientForm);
   args.LeftAttachment(XmATTACH_FORM);
   args.RightAttachment(XmATTACH_FORM);
   valFrame = XmCreateFrame(paramForm, wname, ARGS);

   wname = "countAxisFrame";
   args.Reset();
   args.TopAttachment(XmATTACH_WIDGET, valFrame);
   args.LeftAttachment(XmATTACH_FORM);
   args.RightAttachment(XmATTACH_FORM);
   cntFrame = XmCreateFrame(paramForm, wname, ARGS);

//
// Create the valFrame hierarchy
//
//   valFrame
//      Label	valTitle
//      Form	valForm
//
   wname = "valueAxisTitle";
   args.Reset();
   args.ChildType(XmFRAME_TITLE_CHILD);
   args.ChildHorizontalAlignment(XmALIGNMENT_BEGINNING);
   valTitle = XmCreateLabel(valFrame, wname, ARGS);

   wname = "valueAxisForm";
   valForm = XmCreateForm(valFrame, wname, 0,0);

//
// Create the valForm hierarchy
//
//   valForm
//      FormatModC	formatForm
//      Label		bucketWdLabel
//      TextField	bucketWdTF
//	Label		visCountLabel
//	TextField	visCountTF
//      Label		valTick1SpaceLabel
//      TextField	valTick1SpaceTF
//      Label		valTick2SpaceLabel
//      TextField	valTick2SpaceTF
//
   wname = "formatMod";
   args.Reset();
   args.TopAttachment(XmATTACH_FORM);
   args.LeftAttachment(XmATTACH_FORM);
   formatForm = new FormatModC(valForm, wname, ARGS);

   wname = "bucketWidthLabel";
   bucketWdLabel = XmCreateLabel(valForm, wname, 0,0);

   wname = "majorValueTickSpacingLabel";
   valTick1SpaceLabel = XmCreateLabel(valForm, wname, 0,0);

   args.Reset();
   args.Add(XmNwidth, &wd);
   XtGetValues(formatForm->Label(), ARGS); max_wd = wd;
   XtGetValues(bucketWdLabel,       ARGS); if (wd>max_wd) max_wd = wd;
   XtGetValues(valTick1SpaceLabel,  ARGS); if (wd>max_wd) max_wd = wd;

   args.Reset();
   args.LeftAttachment(XmATTACH_FORM, max_wd + ltOffset);
   XtSetValues(formatForm->Frame(), ARGS);

   wname = "bucketWidthTF";
   args.TopAttachment(XmATTACH_WIDGET, *formatForm);
   bucketWdTF = XmCreateTextField(valForm, wname, ARGS);

   wname = "majorValueTickSpacingTF";
   args.TopWidget(bucketWdTF);
   valTick1SpaceTF = XmCreateTextField(valForm, wname, ARGS);

   args.Reset();
   args.TopAttachment(XmATTACH_OPPOSITE_WIDGET,    bucketWdTF);
   args.BottomAttachment(XmATTACH_OPPOSITE_WIDGET, bucketWdTF);
   args.RightAttachment(XmATTACH_WIDGET,           bucketWdTF);
   XtSetValues(bucketWdLabel, ARGS);

   args.TopWidget(valTick1SpaceTF);
   args.BottomWidget(valTick1SpaceTF);
   args.RightWidget(valTick1SpaceTF);
   XtSetValues(valTick1SpaceLabel, ARGS);

//
// Line up 2nd column fields
//
   wname = "visibleBucketCountLabel";
   visCountLabel = XmCreateLabel(valForm, wname, 0,0);

   wname = "minorValueTickSpacingLabel";
   valTick2SpaceLabel = XmCreateLabel(valForm, wname, 0,0);

   args.Reset();
   args.Add(XmNwidth, &wd);
   XtGetValues(visCountLabel,      ARGS); max_wd = wd;
   XtGetValues(valTick2SpaceLabel, ARGS); if (wd>max_wd) max_wd = wd;

   wname = "visibleBucketTF";
   args.Reset();
   args.TopAttachment(XmATTACH_OPPOSITE_WIDGET, bucketWdTF);
   args.LeftAttachment(XmATTACH_WIDGET, bucketWdTF, max_wd + ltOffset);
   visCountTF = XmCreateTextField(valForm, wname, ARGS);

   wname = "minorValueTickSpacingTF";
   args.Reset();
   args.TopAttachment(XmATTACH_OPPOSITE_WIDGET, valTick1SpaceTF);
   args.LeftAttachment(XmATTACH_WIDGET, valTick1SpaceTF, max_wd + ltOffset);
   valTick2SpaceTF = XmCreateTextField(valForm, wname, ARGS);

   args.Reset();
   args.TopAttachment(XmATTACH_OPPOSITE_WIDGET,    visCountTF);
   args.BottomAttachment(XmATTACH_OPPOSITE_WIDGET, visCountTF);
   args.RightAttachment(XmATTACH_WIDGET,           visCountTF);
   XtSetValues(visCountLabel, ARGS);

   args.TopWidget(valTick2SpaceTF);
   args.BottomWidget(valTick2SpaceTF);
   args.RightWidget(valTick2SpaceTF);
   XtSetValues(valTick2SpaceLabel, ARGS);

//
// Create the cntFrame hierarchy
//
//   cntFrame
//      Label	cntTitle
//      Form	cntForm
//
   wname = "countAxisTitle";
   args.Reset();
   args.ChildType(XmFRAME_TITLE_CHILD);
   args.ChildHorizontalAlignment(XmALIGNMENT_BEGINNING);
   cntTitle = XmCreateLabel(cntFrame, wname, ARGS);

   wname = "countAxisForm";
   cntForm = XmCreateForm(cntFrame, wname, 0,0);

//
// Create the cntForm hierarchy
//
//   cntForm
//      Frame		compressFrame
//         RowColumn	   compressRC
//            ToggleButton    showZeroTB
//            ToggleButton    compressTB
//      Label		cntTick1SpaceLabel
//      TextField	cntTick1SpaceTF
//      ToggleButton	grid1TB
//      Label		cntTick2SpaceLabel
//      TextField	cntTick2SpaceTF
//      ToggleButton	grid2TB
//
   wname = "countCompressFrame";
   args.Reset();
   args.TopAttachment(XmATTACH_FORM);
   args.LeftAttachment(XmATTACH_FORM);
   compressFrame = XmCreateFrame(cntForm, wname, ARGS);

   wname = "countCompressRadioBox";
   args.Reset();
   args.RadioBehavior(True);
   args.Orientation(XmHORIZONTAL);
   compressRC = XmCreateRowColumn(compressFrame, wname, ARGS);

   wname = "countShowZeroTB";
   showZeroTB = XmCreateToggleButton(compressRC, wname, 0,0);

   wname = "countCompressTB";
   compressTB = XmCreateToggleButton(compressRC, wname, 0,0);

   wname = "majorCountTickSpacingLabel";
   cntTick1SpaceLabel = XmCreateLabel(cntForm, wname, 0,0);

   wname = "minorCountTickSpacingLabel";
   cntTick2SpaceLabel = XmCreateLabel(cntForm, wname, 0,0);

//
// Get maximum label width
//
   max_wd = 0;
   args.Reset();
   args.Add(XmNwidth, &wd);
   XtGetValues(cntTick1SpaceLabel, ARGS); if (wd>max_wd) max_wd = wd;
   XtGetValues(cntTick2SpaceLabel, ARGS); if (wd>max_wd) max_wd = wd;

//
// Create text fields
//
   wname = "majorCountTickSpacingTF";
   args.Reset();
   args.TopAttachment(XmATTACH_WIDGET, compressFrame);
   args.LeftAttachment(XmATTACH_FORM, max_wd + ltOffset);
   cntTick1SpaceTF = XmCreateTextField(cntForm, wname, ARGS);

   wname = "minorCountTickSpacingTF";
   args.TopWidget(cntTick1SpaceTF);
   cntTick2SpaceTF = XmCreateTextField(cntForm, wname, ARGS);

//
// Attach labels
//
   args.Reset();
   args.TopAttachment(XmATTACH_OPPOSITE_WIDGET,    cntTick1SpaceTF);
   args.BottomAttachment(XmATTACH_OPPOSITE_WIDGET, cntTick1SpaceTF);
   args.RightAttachment(XmATTACH_WIDGET,           cntTick1SpaceTF);
   XtSetValues(cntTick1SpaceLabel, ARGS);

   args.TopWidget(cntTick2SpaceTF);
   args.BottomWidget(cntTick2SpaceTF);
   args.RightWidget(cntTick2SpaceTF);
   XtSetValues(cntTick2SpaceLabel, ARGS);

//
// Create the grid toggle buttons
//
   wname = "majorGridTB";
   args.Reset();
   args.TopAttachment(XmATTACH_OPPOSITE_WIDGET,    cntTick1SpaceTF);
   args.BottomAttachment(XmATTACH_OPPOSITE_WIDGET, cntTick1SpaceTF);
   args.LeftAttachment(XmATTACH_WIDGET,            cntTick1SpaceTF);
   grid1TB = XmCreateToggleButton(cntForm, wname, ARGS);

   wname = "minorGridTB";
   args.Reset();
   args.TopAttachment(XmATTACH_OPPOSITE_WIDGET,    cntTick2SpaceTF);
   args.BottomAttachment(XmATTACH_OPPOSITE_WIDGET, cntTick2SpaceTF);
   args.LeftAttachment(XmATTACH_WIDGET,            cntTick2SpaceTF);
   grid2TB = XmCreateToggleButton(cntForm, wname, ARGS);

//
// Create the colorRC hierarchy
//
//   colorRC
//      ColorModC	backgroundForm
//      ColorModC	digitBackgroundForm
//      ColorModC	digitForegroundForm
//      ColorModC	topShadowForm
//      ColorModC	bottomShadowForm
//
   wname = "backgroundMod";
   colorForm[HistogramC::BACKGROUND]    = new ColorModC(colorRC, wname, 0,0);
   wname = "chartColorMod";
   colorForm[HistogramC::CHART_COLOR]   = new ColorModC(colorRC, wname, 0,0);
   wname = "barColorMod";
   colorForm[HistogramC::BAR_COLOR]     = new ColorModC(colorRC, wname, 0,0);
   wname = "barBorderColorMod";
   colorForm[HistogramC::BAR_BORDER_COLOR] = new ColorModC(colorRC, wname, 0,0);
   wname = "axisColorMod";
   colorForm[HistogramC::AXIS_COLOR]    = new ColorModC(colorRC, wname, 0,0);
   wname = "labelColorMod";
   colorForm[HistogramC::LABEL_COLOR]   = new ColorModC(colorRC, wname, 0,0);
   wname = "tickColorMod";
   colorForm[HistogramC::TICK_COLOR]    = new ColorModC(colorRC, wname, 0,0);
   wname = "gridColorMod";
   colorForm[HistogramC::GRID_COLOR]    = new ColorModC(colorRC, wname, 0,0);
   wname = "markColorMod";
   colorForm[HistogramC::MARK_COLOR]    = new ColorModC(colorRC, wname, 0,0);
   wname = "topShadowColorMod";
   colorForm[HistogramC::TOP_SHADOW]    = new ColorModC(colorRC, wname, 0,0);
   wname = "bottomShadowColorMod";
   colorForm[HistogramC::BOTTOM_SHADOW] = new ColorModC(colorRC, wname, 0,0);
   wname = "barTopShadowColorMod";
   colorForm[HistogramC::BAR_TOP_SHADOW]    = new ColorModC(colorRC, wname,0,0);
   wname = "barBottomShadowColorMod";
   colorForm[HistogramC::BAR_BOTTOM_SHADOW] = new ColorModC(colorRC, wname,0,0);

//
// Manage children
//
   Widget	list[15];

   list[ 0] = *colorForm[HistogramC::BACKGROUND];
   list[ 1] = *colorForm[HistogramC::CHART_COLOR];
   list[ 2] = *colorForm[HistogramC::BAR_COLOR];
   list[ 3] = *colorForm[HistogramC::BAR_BORDER_COLOR];
   list[ 4] = *colorForm[HistogramC::AXIS_COLOR];
   list[ 5] = *colorForm[HistogramC::LABEL_COLOR];
   list[ 6] = *colorForm[HistogramC::TICK_COLOR];
   list[ 7] = *colorForm[HistogramC::GRID_COLOR];
   list[ 8] = *colorForm[HistogramC::MARK_COLOR];
   list[ 9] = *colorForm[HistogramC::TOP_SHADOW];
   list[10] = *colorForm[HistogramC::BOTTOM_SHADOW];
   list[11] = *colorForm[HistogramC::BAR_TOP_SHADOW];
   list[12] = *colorForm[HistogramC::BAR_BOTTOM_SHADOW];
   XtManageChildren(list, 13);	// colorRC children

   list[0] = showZeroTB;
   list[1] = compressTB;
   XtManageChildren(list, 2);	// compressRC children

   list[0] = compressRC;
   XtManageChildren(list, 1);	// compressFrame children

   list[ 0] = compressFrame;
   list[ 1] = cntTick1SpaceLabel;
   list[ 2] = cntTick1SpaceTF;
   list[ 3] = grid1TB;
   list[ 4] = cntTick2SpaceLabel;
   list[ 5] = cntTick2SpaceTF;
   list[ 6] = grid2TB;
   XtManageChildren(list, 7);	// cntForm children

   list[0] = cntTitle;
   list[1] = cntForm;
   XtManageChildren(list, 2);	// cntFrame children

   list[0] = *formatForm;
   list[1] = bucketWdLabel;
   list[2] = bucketWdTF;
   list[3] = visCountLabel;
   list[4] = visCountTF;
   list[5] = valTick1SpaceLabel;
   list[6] = valTick1SpaceTF;
   list[7] = valTick2SpaceLabel;
   list[8] = valTick2SpaceTF;
   XtManageChildren(list, 9);	// valForm children

   list[0] = valTitle;
   list[1] = valForm;
   XtManageChildren(list, 2);	// valFrame children

   list[ 0] = *shadowForm;
   list[ 1] = *barShadowForm;
   list[ 2] = tick1LenLabel;
   list[ 3] = tick1LenTF;
   list[ 4] = tick2LenLabel;
   list[ 5] = tick2LenTF;
   list[ 6] = margWdLabel;
   list[ 7] = margWdTF;
   list[ 8] = margHtLabel;
   list[ 9] = margHtTF;
   list[10] = *orientForm;
   list[11] = maxCountLabel;
   list[12] = maxCountTF;
   list[13] = valFrame;
   list[14] = cntFrame;
   XtManageChildren(list, 15);	// paramForm children

} // End HistogramModC HistogramModC

/*---------------------------------------------------------------
 *  Destructor
 */

HistogramModC::~HistogramModC()
{
   delete shadowForm;
   delete barShadowForm;
   delete formatForm;
   delete orientForm;
   for (int i=0; i<HistogramC::COLOR_ATTR_COUNT; i++) delete colorForm[i];
}

/*---------------------------------------------------------------
 *  Method to apply histogram changes
 */

void
HistogramModC::Apply(HistogramC& hist)
{
   hist.Defer(True);

//
// Apply the shadows
//
   hist.SetShadowType(shadowForm->Type());
   hist.SetShadowThickness(shadowForm->Thickness());
   hist.SetBarShadowType(barShadowForm->Type());
   hist.SetBarShadowThickness(barShadowForm->Thickness());

//
// Apply the tick lengths
//
   char *cs = XmTextFieldGetString(tick1LenTF);
   int	tick1Len = atoi(cs);
   XtFree(cs);
   cs = XmTextFieldGetString(tick2LenTF);
   int	tick2Len = atoi(cs);
   XtFree(cs);
   hist.SetTickLength(tick1Len, tick2Len);

//
// Apply the margins
//
   cs = XmTextFieldGetString(margWdTF);
   int	marginWd = atoi(cs);
   XtFree(cs);
   cs = XmTextFieldGetString(margHtTF);
   int	marginHt = atoi(cs);
   XtFree(cs);
   hist.SetMargins(marginWd, marginHt);

//
// Apply the orientation
//
   hist.SetOrientation(orientForm->Type());

//
// Apply the maximum value count
//
   cs = XmTextFieldGetString(maxCountTF);
   int	maxCount = atoi(cs);
   XtFree(cs);
   hist.SetMaximumValueCount(maxCount);

//
// Apply the value format
//
   ValueC	format;
   formatForm->Apply(format);

   hist.SetValueFormat(format.Format());
   hist.SetValuePrecision(format.Precision());

//
// Apply the bucket width
//
   cs = XmTextFieldGetString(bucketWdTF);
   float	bucketWd = atof(cs);
   XtFree(cs);
   hist.SetBucketWidth(bucketWd);

//
// Apply the visible bucket count
//
   cs = XmTextFieldGetString(visCountTF);
   int	visCount = atoi(cs);
   XtFree(cs);
   hist.SetVisibleBucketCount(visCount);

//
// Apply the value tick spacings
//
   cs = XmTextFieldGetString(valTick1SpaceTF);
   float	valTick1Space = atof(cs);
   XtFree(cs);
   cs = XmTextFieldGetString(valTick2SpaceTF);
   float	valTick2Space = atof(cs);
   XtFree(cs);
   hist.SetValueTickSpacing(valTick1Space, valTick2Space);

//
// Apply the count compresssion
//
   hist.SetCountCompress(XmToggleButtonGetState(compressTB));

//
// Apply the count tick spacings
//
   cs = XmTextFieldGetString(cntTick1SpaceTF);
   int	cntTick1Space = atoi(cs);
   XtFree(cs);
   cs = XmTextFieldGetString(cntTick2SpaceTF);
   int	cntTick2Space = atoi(cs);
   XtFree(cs);
   hist.SetCountTickSpacing(cntTick1Space, cntTick2Space);

//
// Set the count grid visibilities
//
   Boolean	grid1 = XmToggleButtonGetState(grid1TB);
   Boolean	grid2 = XmToggleButtonGetState(grid2TB);
   hist.SetGridVis(grid1, grid2);

//
// Set the colors
//
   for (int i=0; i<HistogramC::COLOR_ATTR_COUNT; i++) {
      ColorModC	*cm = colorForm[i];
      if ( cm->Changed() ) {
	 hist.SetColor((HistogramC::HistogramColorAttr)i, cm->Value());
      }
   }

   hist.Defer(False);
   hist.Draw();

   return;

} // End HistogramModC Apply

/*---------------------------------------------------------------
 *  Method to initialize the settings based on the given histogram
 */

void
HistogramModC::Init(HistogramC& hist)
{
//
// Initialize shadows
//
   shadowForm->Init(hist.ShadowType(), hist.ShadowThickness());
   barShadowForm->Init(hist.BarShadowType(), hist.BarShadowThickness());

//
// Initialize tick length
//
   hist.GetTickLength(&init.tick1Len, &init.tick2Len);
   StringC	str;
   str += init.tick1Len;
   XmTextFieldSetString(tick1LenTF, str);
   str = "";
   str += init.tick2Len;
   XmTextFieldSetString(tick2LenTF, str);

//
// Initialize margins
//
   hist.GetMargins(&init.marginWd, &init.marginHt);
   str = "";
   str += (int)init.marginWd;
   XmTextFieldSetString(margWdTF, str);
   str = "";
   str += (int)init.marginHt;
   XmTextFieldSetString(margHtTF, str);

//
// Initialize orientation
//
   orientForm->Init(hist.Orientation());

//
// Initialize the maximum value count
//
   init.maxCount = hist.MaximumValueCount();
   str = "";
   str += init.maxCount;
   XmTextFieldSetString(maxCountTF, str);

//
// Initialize value format
//
   ValueC	format;
   format.SetFormat(hist.ValFormat(), hist.ValuePrecision());
   formatForm->Init(format.Format(), format.Precision());

//
// Initialize bucket width
//
   init.bucketWd = hist.BucketWidth();
   init.bucketWd.SetFormat(format.Format());
   init.bucketWd.SetPrecision(format.Precision());
   XmTextFieldSetString(bucketWdTF, (char *)(StringC)init.bucketWd);

//
// Initialize the visible bucket count
//
   init.visCount = hist.VisibleBucketCount();
   str = "";
   str += init.visCount;
   XmTextFieldSetString(visCountTF, str);

//
// Initialize value axis ticks
//
   hist.GetValueTickSpacing(&init.valTick1Space, &init.valTick2Space);
   init.valTick1Space.SetFormat(format.Format());
   init.valTick1Space.SetPrecision(format.Precision());
   init.valTick2Space.SetFormat(format.Format());
   init.valTick2Space.SetPrecision(format.Precision());
   XmTextFieldSetString(valTick1SpaceTF, (char *)(StringC)init.valTick1Space);
   XmTextFieldSetString(valTick2SpaceTF, (char *)(StringC)init.valTick2Space);

//
// Initialize count compresssion
//
   init.compress = hist.CountCompress();
   if ( init.compress ) XmToggleButtonSetState(compressTB, True, False);
   else			XmToggleButtonSetState(showZeroTB, True, False);

//
// Initialize count axis ticks
//
   hist.GetCountTickSpacing(&init.cntTick1Space, &init.cntTick2Space);
   str = "";
   str += init.cntTick1Space;
   XmTextFieldSetString(cntTick1SpaceTF, str);
   str = "";
   str += init.cntTick2Space;
   XmTextFieldSetString(cntTick2SpaceTF, str);

//
// Initialize count axis grid visibility
//
   hist.GetGridVis(&init.grid1, &init.grid2);
   XmToggleButtonSetState(grid1TB, init.grid1, False);
   XmToggleButtonSetState(grid2TB, init.grid2, False);

//
// Initialize the colors
//
   for (int i=0; i<HistogramC::COLOR_ATTR_COUNT; i++) {
      colorForm[i]->Init(hist.GetColor((HistogramC::HistogramColorAttr)i));
   }

   histogram = &hist;

} // End HistogramModC Init

/*---------------------------------------------------------------
 *  Method to reset the fields to their initial values
 */

void
HistogramModC::Reset()
{
//
// Reset shadows
//
   shadowForm->Reset();
   barShadowForm->Reset();

//
// Reset tick length
//
   StringC	str;
   str += init.tick1Len;
   XmTextFieldSetString(tick1LenTF, str);
   str = "";
   str += init.tick2Len;
   XmTextFieldSetString(tick2LenTF, str);

//
// Reset margins
//
   str = "";
   str += (int)init.marginWd;
   XmTextFieldSetString(margWdTF, str);
   str = "";
   str += (int)init.marginHt;
   XmTextFieldSetString(margHtTF, str);

//
// Reset orientation and format
//
   orientForm->Reset();
   formatForm->Reset();

//
// Reset the maximum value count
//
   str = "";
   str += init.maxCount;
   XmTextFieldSetString(maxCountTF, str);

//
// Reset bucket width
//
   XmTextFieldSetString(bucketWdTF, (char *)(StringC)init.bucketWd);

//
// Reset the visible bucket count
//
   str = "";
   str += init.visCount;
   XmTextFieldSetString(visCountTF, str);

//
// Reset value axis ticks
//
   XmTextFieldSetString(valTick1SpaceTF, (char *)(StringC)init.valTick1Space);
   XmTextFieldSetString(valTick2SpaceTF, (char *)(StringC)init.valTick2Space);

//
// Reset count compresssion
//
   if ( init.compress ) XmToggleButtonSetState(compressTB, True, False);
   else		        XmToggleButtonSetState(showZeroTB, True, False);

//
// Reset count axis ticks
//
   str = "";
   str += init.cntTick1Space;
   XmTextFieldSetString(cntTick1SpaceTF, str);
   str = "";
   str += init.cntTick2Space;
   XmTextFieldSetString(cntTick2SpaceTF, str);

//
// Reset count axis grid visibility
//
   XmToggleButtonSetState(grid1TB, init.grid1, False);
   XmToggleButtonSetState(grid2TB, init.grid2, False);

//
// Reset the colors
//
   for (int i=0; i<HistogramC::COLOR_ATTR_COUNT; i++) colorForm[i]->Reset();

   if ( autoApply ) {
      histogram->Defer(True);
      histogram->SetShadowType(shadowForm->Type());
      histogram->SetShadowThickness(shadowForm->Thickness());
      histogram->SetBarShadowType(barShadowForm->Type());
      histogram->SetBarShadowThickness(barShadowForm->Thickness());
      histogram->SetTickLength(init.tick1Len, init.tick2Len);
      histogram->SetMargins(init.marginWd, init.marginHt);
      histogram->SetOrientation(orientForm->Type());
      histogram->SetMaximumValueCount(init.maxCount);
      histogram->SetValueFormat(formatForm->Format());
      histogram->SetValuePrecision(formatForm->Precision());
      histogram->SetBucketWidth(init.bucketWd);
      histogram->SetVisibleBucketCount(init.visCount);
      histogram->SetValueTickSpacing(init.valTick1Space, init.valTick2Space);
      histogram->SetCountCompress(XmToggleButtonGetState(compressTB));
      histogram->SetCountTickSpacing(init.cntTick1Space, init.cntTick2Space);
      histogram->SetGridVis(XmToggleButtonGetState(grid1TB),
			    XmToggleButtonGetState(grid2TB));
      for (int i=0; i<HistogramC::COLOR_ATTR_COUNT; i++)
	 histogram->SetColor( (HistogramC::HistogramColorAttr)i,
			       colorForm[i]->Value() );
      histogram->Defer(False);
      histogram->Draw();
   }

} // End HistogramModC Reset

/*---------------------------------------------------------------
 *  Method to add the callbacks needed to support auto update
 */

void
HistogramModC::EnableAutoApply()
{
   if ( autoApply ) return;

#define AddValueChanged(W,C) \
   XtAddCallback(W, XmNvalueChangedCallback, \
	         (XtCallbackProc)(C), (XtPointer)this)

#define AddActivate(W,C) \
   XtAddCallback(W, XmNactivateCallback, \
	         (XtCallbackProc)(C), (XtPointer)this)

#define AddColorActivate(COL,C) \
   AddActivate(colorForm[HistogramC::COL]->TextField(), C)

//
// Add auto-update callbacks
//
   AddValueChanged (shadowForm->InTB(),         ChangeShadow);
   AddValueChanged (shadowForm->OutTB(),        ChangeShadow);
   AddValueChanged (shadowForm->EtchInTB(),     ChangeShadow);
   AddValueChanged (shadowForm->EtchOutTB(),    ChangeShadow);
   AddActivate     (shadowForm->ThickTF(),      ChangeShadowThick);
   AddValueChanged (barShadowForm->InTB(),      ChangeBarShadow);
   AddValueChanged (barShadowForm->OutTB(),     ChangeBarShadow);
   AddValueChanged (barShadowForm->EtchInTB(),  ChangeBarShadow);
   AddValueChanged (barShadowForm->EtchOutTB(), ChangeBarShadow);
   AddActivate     (barShadowForm->ThickTF(),   ChangeBarShadowThick);
   AddActivate     (tick1LenTF,                 ChangeTickLength);
   AddActivate     (tick2LenTF,                 ChangeTickLength);
   AddActivate     (margWdTF,                   ChangeMargin);
   AddActivate     (margHtTF,                   ChangeMargin);
   AddValueChanged (orientForm->VerticalTB(),	ChangeOrient);
   AddValueChanged (orientForm->HorizontalTB(),	ChangeOrient);
   AddActivate     (maxCountTF,                 ChangeMaxCount);
   AddValueChanged (formatForm->IntTB(),        ChangeFormat);
   AddValueChanged (formatForm->HexTB(),        ChangeFormat);
   AddValueChanged (formatForm->FloatTB(),      ChangeFormat);
   AddActivate     (formatForm->PrecisTF(),     ChangeFormatPrecis);
   AddActivate     (bucketWdTF,                 ChangeBucketWidth);
   AddActivate     (visCountTF,                 ChangeVisCount);
   AddActivate     (valTick1SpaceTF,            ChangeValTickSpace);
   AddActivate     (valTick2SpaceTF,            ChangeValTickSpace);
   AddValueChanged (showZeroTB,                 ChangeCompress);
   AddValueChanged (compressTB,                 ChangeCompress);
   AddActivate     (cntTick1SpaceTF,            ChangeCntTickSpace);
   AddActivate     (cntTick2SpaceTF,            ChangeCntTickSpace);
   AddValueChanged (grid1TB,                    ChangeGrid);
   AddValueChanged (grid2TB,                    ChangeGrid);
   AddColorActivate(BACKGROUND,                 ChangeBackground);
   AddColorActivate(CHART_COLOR,                ChangeChartColor);
   AddColorActivate(BAR_COLOR,                  ChangeBarColor);
   AddColorActivate(BAR_BORDER_COLOR,           ChangeBarBorderColor);
   AddColorActivate(AXIS_COLOR,                 ChangeAxisColor);
   AddColorActivate(LABEL_COLOR,                ChangeLabelColor);
   AddColorActivate(TICK_COLOR,                 ChangeTickColor);
   AddColorActivate(GRID_COLOR,                 ChangeGridColor);
   AddColorActivate(MARK_COLOR,                 ChangeMarkColor);
   AddColorActivate(TOP_SHADOW,                 ChangeTopShadow);
   AddColorActivate(BOTTOM_SHADOW,              ChangeBottomShadow);
   AddColorActivate(BAR_TOP_SHADOW,             ChangeBarTopShadow);
   AddColorActivate(BAR_BOTTOM_SHADOW,          ChangeBarBottomShadow);

} // End HistogramModC EnableAutoApply

/*---------------------------------------------------------------
 *  Method to remove the callbacks needed to support auto update
 */

void
HistogramModC::DisableAutoApply()
{
   if ( !autoApply ) return;

#define RemoveValueChanged(W,C) \
   XtRemoveCallback(W, XmNvalueChangedCallback, \
	            (XtCallbackProc)(C), (XtPointer)this)

#define RemoveActivate(W,C) \
   XtRemoveCallback(W, XmNactivateCallback, \
	            (XtCallbackProc)(C), (XtPointer)this)

#define RemoveColorActivate(COL,C) \
   RemoveActivate(colorForm[HistogramC::COL]->TextField(), C)

//
// Remove auto-update callbacks
//
   RemoveValueChanged (shadowForm->InTB(),         ChangeShadow);
   RemoveValueChanged (shadowForm->OutTB(),        ChangeShadow);
   RemoveValueChanged (shadowForm->EtchInTB(),     ChangeShadow);
   RemoveValueChanged (shadowForm->EtchOutTB(),    ChangeShadow);
   RemoveActivate     (shadowForm->ThickTF(),      ChangeShadowThick);
   RemoveValueChanged (barShadowForm->InTB(),      ChangeBarShadow);
   RemoveValueChanged (barShadowForm->OutTB(),     ChangeBarShadow);
   RemoveValueChanged (barShadowForm->EtchInTB(),  ChangeBarShadow);
   RemoveValueChanged (barShadowForm->EtchOutTB(), ChangeBarShadow);
   RemoveActivate     (barShadowForm->ThickTF(),   ChangeBarShadowThick);
   RemoveActivate     (tick1LenTF,                 ChangeTickLength);
   RemoveActivate     (tick2LenTF,                 ChangeTickLength);
   RemoveActivate     (margWdTF,                   ChangeMargin);
   RemoveActivate     (margHtTF,                   ChangeMargin);
   RemoveValueChanged (orientForm->VerticalTB(),   ChangeOrient);
   RemoveValueChanged (orientForm->HorizontalTB(), ChangeOrient);
   RemoveActivate     (maxCountTF,                 ChangeMaxCount);
   RemoveValueChanged (formatForm->IntTB(),        ChangeFormat);
   RemoveValueChanged (formatForm->HexTB(),        ChangeFormat);
   RemoveValueChanged (formatForm->FloatTB(),      ChangeFormat);
   RemoveActivate     (formatForm->PrecisTF(),     ChangeFormatPrecis);
   RemoveActivate     (bucketWdTF,                 ChangeBucketWidth);
   RemoveActivate     (visCountTF,                 ChangeVisCount);
   RemoveActivate     (valTick1SpaceTF,            ChangeValTickSpace);
   RemoveActivate     (valTick2SpaceTF,            ChangeValTickSpace);
   RemoveValueChanged (showZeroTB,                 ChangeCompress);
   RemoveValueChanged (compressTB,                 ChangeCompress);
   RemoveActivate     (cntTick1SpaceTF,            ChangeCntTickSpace);
   RemoveActivate     (cntTick2SpaceTF,            ChangeCntTickSpace);
   RemoveValueChanged (grid1TB,                    ChangeGrid);
   RemoveValueChanged (grid2TB,                    ChangeGrid);
   RemoveColorActivate(BACKGROUND,                 ChangeBackground);
   RemoveColorActivate(CHART_COLOR,                ChangeChartColor);
   RemoveColorActivate(BAR_COLOR,                  ChangeBarColor);
   RemoveColorActivate(BAR_BORDER_COLOR,           ChangeBarBorderColor);
   RemoveColorActivate(AXIS_COLOR,                 ChangeAxisColor);
   RemoveColorActivate(LABEL_COLOR,                ChangeLabelColor);
   RemoveColorActivate(TICK_COLOR,                 ChangeTickColor);
   RemoveColorActivate(GRID_COLOR,                 ChangeGridColor);
   RemoveColorActivate(MARK_COLOR,                 ChangeMarkColor);
   RemoveColorActivate(TOP_SHADOW,                 ChangeTopShadow);
   RemoveColorActivate(BOTTOM_SHADOW,              ChangeBottomShadow);
   RemoveColorActivate(BAR_TOP_SHADOW,             ChangeBarTopShadow);
   RemoveColorActivate(BAR_BOTTOM_SHADOW,          ChangeBarBottomShadow);

} // End HistogramModC DisableAutoApply

void
HistogramModC::ChangeShadow(Widget, HistogramModC *hm,
			    XmToggleButtonCallbackStruct *tb)
{
   if ( tb->set )
      hm->histogram->SetShadowType(hm->shadowForm->Type());
}

void
HistogramModC::ChangeShadowThick(Widget, HistogramModC *hm, XtPointer)
{
   hm->histogram->SetShadowThickness(hm->shadowForm->Thickness());
}

void
HistogramModC::ChangeBarShadow(Widget, HistogramModC *hm,
			       XmToggleButtonCallbackStruct *tb)
{
   if ( tb->set )
      hm->histogram->SetBarShadowType(hm->barShadowForm->Type());
}

void
HistogramModC::ChangeBarShadowThick(Widget, HistogramModC *hm, XtPointer)
{
   hm->histogram->SetBarShadowThickness(hm->barShadowForm->Thickness());
}

void
HistogramModC::ChangeTickLength(Widget, HistogramModC *hm, XtPointer)
{
   if ( XmTextFieldGetLastPosition(hm->tick1LenTF) == 0 ||
	XmTextFieldGetLastPosition(hm->tick2LenTF) == 0 ) return;

   char *cs = XmTextFieldGetString(hm->tick1LenTF);
   int	tick1 = atoi(cs);
   XtFree(cs);

   cs = XmTextFieldGetString(hm->tick2LenTF);
   int	tick2 = atoi(cs);
   XtFree(cs);

   hm->histogram->SetTickLength(tick1, tick2);
}

void
HistogramModC::ChangeMargin(Widget, HistogramModC *hm, XtPointer)
{
   if ( XmTextFieldGetLastPosition(hm->margWdTF) == 0 ||
	XmTextFieldGetLastPosition(hm->margHtTF) == 0 ) return;

   char *cs = XmTextFieldGetString(hm->margWdTF);
   int	wd = atoi(cs);
   XtFree(cs);

   cs = XmTextFieldGetString(hm->margHtTF);
   int	ht = atoi(cs);
   XtFree(cs);

   hm->histogram->SetMargins(wd, ht);
}

void
HistogramModC::ChangeOrient(Widget, HistogramModC *hm, XtPointer)
{
   hm->histogram->SetOrientation(hm->orientForm->Type());
}

void
HistogramModC::ChangeMaxCount(Widget, HistogramModC *hm, XtPointer)
{
   if ( XmTextFieldGetLastPosition(hm->maxCountTF) == 0 ) return;

   char *cs = XmTextFieldGetString(hm->maxCountTF);
   int	count = atoi(cs);
   XtFree(cs);

   hm->histogram->SetMaximumValueCount(count);
}

void
HistogramModC::ChangeFormat(Widget, HistogramModC *hm,
			    XmToggleButtonCallbackStruct *tb)
{
   if ( tb->set )
      hm->histogram->SetValueFormat(hm->formatForm->Format());
}

void
HistogramModC::ChangeFormatPrecis(Widget, HistogramModC *hm, XtPointer)
{
   hm->histogram->SetValuePrecision(hm->formatForm->Precision());
}

void
HistogramModC::ChangeBucketWidth(Widget, HistogramModC *hm, XtPointer)
{
   if ( XmTextFieldGetLastPosition(hm->bucketWdTF) == 0 ) return;

   char *cs = XmTextFieldGetString(hm->bucketWdTF);
   float	wd = atof(cs);
   XtFree(cs);

   hm->histogram->SetBucketWidth(wd);
}

void
HistogramModC::ChangeVisCount(Widget, HistogramModC *hm, XtPointer)
{
   if ( XmTextFieldGetLastPosition(hm->visCountTF) == 0 ) return;

   char *cs = XmTextFieldGetString(hm->visCountTF);
   int	count = atoi(cs);
   XtFree(cs);

   hm->histogram->SetVisibleBucketCount(count);
}

void
HistogramModC::ChangeValTickSpace(Widget, HistogramModC *hm, XtPointer)
{
   if ( XmTextFieldGetLastPosition(hm->valTick1SpaceTF) == 0 ||
	XmTextFieldGetLastPosition(hm->valTick2SpaceTF) == 0 ) return;

   char *cs = XmTextFieldGetString(hm->valTick1SpaceTF);
   int	tick1 = atoi(cs);
   XtFree(cs);

   cs = XmTextFieldGetString(hm->valTick2SpaceTF);
   int	tick2 = atoi(cs);
   XtFree(cs);

   hm->histogram->SetValueTickSpacing(tick1, tick2);
}

void
HistogramModC::ChangeCompress(Widget w, HistogramModC *hm,
			      XmToggleButtonCallbackStruct *tb)
{
   if ( w == hm->compressTB ) {
      if ( tb->set ) hm->histogram->SetCountCompress(True);
   } else {
      if ( tb->set ) hm->histogram->SetCountCompress(False);
   }
}

void
HistogramModC::ChangeCntTickSpace(Widget, HistogramModC *hm, XtPointer)
{
   if ( XmTextFieldGetLastPosition(hm->cntTick1SpaceTF) == 0 ||
	XmTextFieldGetLastPosition(hm->cntTick2SpaceTF) == 0 ) return;

   char *cs = XmTextFieldGetString(hm->cntTick1SpaceTF);
   int	tick1 = atoi(cs);
   XtFree(cs);

   cs = XmTextFieldGetString(hm->cntTick2SpaceTF);
   int	tick2 = atoi(cs);
   XtFree(cs);

   hm->histogram->SetCountTickSpacing(tick1, tick2);
}

void
HistogramModC::ChangeGrid(Widget w, HistogramModC *hm,
			  XmToggleButtonCallbackStruct *tb)
{
   Boolean grid1 = (w == hm->grid1TB) ? tb->set
				      : XmToggleButtonGetState(hm->grid1TB);
   Boolean grid2 = (w == hm->grid2TB) ? tb->set
				      : XmToggleButtonGetState(hm->grid2TB);
   hm->histogram->SetGridVis(grid1, grid2);
}

void
HistogramModC::ChangeBackground(Widget, HistogramModC *hm, XtPointer)
{
   hm->ChangeColor(HistogramC::BACKGROUND);
}

void
HistogramModC::ChangeChartColor(Widget, HistogramModC *hm, XtPointer)
{
   hm->ChangeColor(HistogramC::CHART_COLOR);
}

void
HistogramModC::ChangeBarColor(Widget, HistogramModC *hm, XtPointer)
{
   hm->ChangeColor(HistogramC::BAR_COLOR);
}

void
HistogramModC::ChangeBarBorderColor(Widget, HistogramModC *hm, XtPointer)
{
   hm->ChangeColor(HistogramC::BAR_BORDER_COLOR);
}

void
HistogramModC::ChangeAxisColor(Widget, HistogramModC *hm, XtPointer)
{
   hm->ChangeColor(HistogramC::AXIS_COLOR);
}

void
HistogramModC::ChangeLabelColor(Widget, HistogramModC *hm, XtPointer)
{
   hm->ChangeColor(HistogramC::LABEL_COLOR);
}

void
HistogramModC::ChangeTickColor(Widget, HistogramModC *hm, XtPointer)
{
   hm->ChangeColor(HistogramC::TICK_COLOR);
}

void
HistogramModC::ChangeGridColor(Widget, HistogramModC *hm, XtPointer)
{
   hm->ChangeColor(HistogramC::GRID_COLOR);
}

void
HistogramModC::ChangeMarkColor(Widget, HistogramModC *hm, XtPointer)
{
   hm->ChangeColor(HistogramC::MARK_COLOR);
}

void
HistogramModC::ChangeTopShadow(Widget, HistogramModC *hm, XtPointer)
{
   hm->ChangeColor(HistogramC::TOP_SHADOW);
}

void
HistogramModC::ChangeBottomShadow(Widget, HistogramModC *hm, XtPointer)
{
   hm->ChangeColor(HistogramC::BOTTOM_SHADOW);
}

void
HistogramModC::ChangeBarTopShadow(Widget, HistogramModC *hm, XtPointer)
{
   hm->ChangeColor(HistogramC::BAR_TOP_SHADOW);
}

void
HistogramModC::ChangeBarBottomShadow(Widget, HistogramModC *hm, XtPointer)
{
   hm->ChangeColor(HistogramC::BAR_BOTTOM_SHADOW);
}

void
HistogramModC::ChangeColor(HistogramC::HistogramColorAttr color)
{
   ColorModC		*cm = colorForm[color];

   if ( cm->Changed() ) histogram->SetColor(color, cm->Value());
}
