/*
 * $Id: BarChartC.h,v 1.1 1998/06/24 01:29:07 lang Exp $
 *
 * Copyright (c) 1992 HAL Computer Systems International, Ltd.
 * 
 *          HAL COMPUTER SYSTEMS INTERNATIONAL, LTD.
 *                  1315 Dell Avenue
 *                  Campbell, CA  95008
 *
 * Author: Greg Hilton
 * Contributors: Tom Lang, Frank Bieser, and others
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * http://www.gnu.org/copyleft/gpl.html
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */


#ifndef _BarChartC_h_
#define _BarChartC_h_

#include "ValueC.h"
#include "IntListC.h"
#include "FloatListC.h"
#include "StringListC.h"

#ifdef TICK
#undef TICK
#endif

#include <Xm/Xm.h>

//----------------------------------------------------------------------------
// Class definition
//
//   The bar chart consists of 2 axes: the count axis and the value/bucket axis
//   When the orientation is vertical, the count axis will be drawn as X and
//      the value/bucket axis will be drawn as Y.
//   When the orientation is horzontal, the count axis will be drawn as Y and
//      the value/bucket axis will be drawn as X.
//

class BarChartC {

public:

   enum BarChartColorAttr {
      BACKGROUND = 0,
      CHART,
      BAR,
      BAR_HIGHLIGHT,
      BAR_VALUE,
      BAR_BORDER,
      AXIS,
      LABEL,
      TICK,
      GRID,
      MARK,
      TOP_SHADOW,
      BOTTOM_SHADOW,
      BAR_TOP_SHADOW,
      BAR_BOTTOM_SHADOW,
      COLOR_ATTR_COUNT
   };

protected:

   Widget		form;
   Widget		da;		// Drawing area
   Widget		scrollBar;
   Widget		thresholdScale;

//
// Drawing attributes
//
   Display		*display;
   XtAppContext		context;
   Window		win;
   GC			gc;
   static Pixmap	pixmap;
   static int		pixmapRefCnt;
   static Dimension	pixmapWd;
   static Dimension	pixmapHt;
   Dimension		daWd;
   Dimension		daHt;
   Dimension		marginWd;
   Dimension		marginHt;
   Pixel		colors[COLOR_ATTR_COUNT];
   XFontStruct		*font;
   unsigned char	shadowType;
   Dimension		shadowThickness;
   unsigned char	barShadowType;
   Dimension		barShadowThickness;
   Boolean		compress;		// Show 0 on count axis or not
   Boolean		drawScaleValues;
   int			labelOffset;
   int			majorTickLen;
   int			minorTickLen;
   float		majorTickSpace;
   float		minorTickSpace;
   Boolean		majorGridVis;
   Boolean		minorGridVis;
   unsigned char	orientation;		// Xm_VERTICAL or Xm_HORIZONTAL
   unsigned		visCount;		// Number of bars displayed

   FloatListC		valueMarkList;		// Marks on value axis

   int			minIndex;		// First visible bar
   int			maxIndex;		// Last visible bar
   float		minDisp;		// Min Display value
   float		maxDisp;		// Max Display value
   float		minValue;		// Min Range value
   float		maxValue;		// Max Range value
   float		minRange;		// Min Range value
   float		maxRange;		// Max Range value
   Boolean		autoRanging;		// Automatic Ranging flag
   float		countRangeInv;
   FloatListC		valueList;		// List of bar values
   StringListC		labelList;		// Labels for each bar
						
   ValueC		valueFormat;
   Boolean		obscured;		// Hidden by another window
   Boolean		deferred;
   int			deferCount;
   Dimension		scrollBarSpan;		// Width or Height

   float		thresholdValue;

//
// Callbacks and event handlers
//
   static void		ExposeCB(Widget, BarChartC*,
				 XmDrawingAreaCallbackStruct*);
   static void		ResizeCB(Widget, BarChartC*, XtPointer);
   static void		ScrollCB(Widget, BarChartC*,
				 XmScrollBarCallbackStruct*);
   static void		HandleVisChange(Widget, BarChartC*, XVisibilityEvent*,
					Boolean*);

//
// Private methods
//
   void			DrawHorizontal();
   void			DrawVertical();
   float		NormalizeValue(float);
   StringC		ValueString(float);

public:

//
// Cast to widget
//
   inline operator	Widget() const		{ return form;	}
   MEMBER_QUERY(Widget, Form,        form);
   MEMBER_QUERY(Widget, DrawingArea, da);
   MEMBER_QUERY(Widget, ScrollBar,   scrollBar);

//
// Constructor and destructor
//
   BarChartC(Widget parent, const char *name, ArgList argv=NULL,
	      Cardinal argc=0);
   virtual	~BarChartC();

//
// Methods to modify the strip chart
//
   void			AddValueMark(const ValueC);
   void			Defer(Boolean);
   void			Draw();
   void			SetBarShadowThickness(Dimension);
   void			SetBarShadowType(unsigned char);
   void			SetBarValues(const FloatListC&, const StringListC&);
   void			SetBarValues(const IntListC&, const StringListC&);
   void			SetColor(BarChartC::BarChartColorAttr, Pixel);
   void			SetColor(BarChartC::BarChartColorAttr, const char *);
   void			SetValueCompress(Boolean);
   void			SetValueFormat(ValueC::ValueFormat);
   void			SetValueMarks(const FloatListC&);
   void			SetValueMarks(const IntListC&);
   void			SetTickSpacing(const ValueC, const ValueC);
   void			SetGridVis(Boolean, Boolean);
   void			SetLabelOffset(int);
   void			SetMargins(Dimension, Dimension);
   void			SetOrientation(unsigned char);
   void			SetShadowThickness(Dimension);
   void			SetShadowType(unsigned char);
   void			SetTickLength(int, int);
   void			SetValuePrecision(int);
   void			SetVisibleBarCount(unsigned);
   void			SetThreshold(float);
   void			SetRangeValues(float,float);
   void			SetAutoRanging(Boolean);
   void			SetDrawScaleValues(Boolean);

//
// Methods to query the strip chart
//
   MEMBER_QUERY(Dimension,	BarShadowThickness,	barShadowThickness)
   MEMBER_QUERY(unsigned char,	BarShadowType,		barShadowType)
   MEMBER_QUERY(Boolean,	ValueCompress,		compress)
   MEMBER_QUERY(int,		LabelOffset,		labelOffset)
   MEMBER_QUERY(unsigned char,	Orientation,		orientation)
   MEMBER_QUERY(Dimension,	ShadowThickness,	shadowThickness)
   MEMBER_QUERY(unsigned char,	ShadowType,		shadowType)
   MEMBER_QUERY(int,		ValuePrecision,		valueFormat.Precision())
   MEMBER_QUERY(unsigned,	VisibleBucketCount,	visCount)
   MEMBER_QUERY(ValueC::ValueFormat,  ValFormat,        valueFormat.Format())

   Pixel		GetColor    (BarChartC::BarChartColorAttr) const;
   StringC		GetColorName(BarChartC::BarChartColorAttr) const;
   void			GetTickSpacing(StringC*, StringC*) const;
   void			GetTickSpacing(ValueC*, ValueC*) const;
   void			GetTickSpacing(int*, int*) const;
   void			GetGridVis(Boolean*, Boolean*) const;
   void			GetMargins(Dimension*, Dimension*) const;
   void			GetTickLength(int*, int*) const;
};

#endif // _BarChartC_h_
