/*
 * $Id: ShadowModC.C,v 1.1 1998/06/24 01:29:07 lang Exp $
 *
 * Copyright (c) 1992 HAL Computer Systems International, Ltd.
 * 
 *          HAL COMPUTER SYSTEMS INTERNATIONAL, LTD.
 *                  1315 Dell Avenue
 *                  Campbell, CA  95008
 *
 * Author: Greg Hilton
 * Contributors: Tom Lang, Frank Bieser, and others
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * http://www.gnu.org/copyleft/gpl.html
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#include "ShadowModC.h"
#include "WArgList.h"
#include "rsrc.h"
#include "StringC.h"

#include <Xm/Form.h>
#include <Xm/Frame.h>
#include <Xm/Label.h>
#include <Xm/RowColumn.h>
#include <Xm/TextF.h>
#include <Xm/ToggleB.h>

/*----------------------------------------------------------------------
 * Method to build the shadow form
 */

ShadowModC::ShadowModC(Widget parent, const char *name, ArgList argv,
		       Cardinal argc)
{
   WArgList	args;

//
// Create widget hierarchy
//
//   form
//	Label		typeLabel
//	Frame		typeFrame
//	Label		thickLabel
//	TextField	thickTF
//	Label		pixelLabel
//
   form = XmCreateForm(parent, (char *)name, argv, argc);

   int	ltOffset = get_int("ShadowModC", form, "labelTextOffset", 0);

   StringC	wname = "shadowModTypeLabel";
   typeLabel = XmCreateLabel(form, wname, 0,0);

   Dimension	wd;
   XtVaGetValues(typeLabel, XmNwidth, &wd, NULL);

   wname = "shadowModTypeFrame";
   args.Reset();
   args.LeftAttachment(XmATTACH_FORM, wd + ltOffset);
   typeFrame = XmCreateFrame(form, wname, ARGS);

   args.Reset();
   args.TopAttachment(XmATTACH_OPPOSITE_WIDGET, typeFrame);
   args.BottomAttachment(XmATTACH_OPPOSITE_WIDGET, typeFrame);
   args.RightAttachment(XmATTACH_WIDGET, typeFrame, ltOffset);
   XtSetValues(typeLabel, ARGS);

   wname = "shadowModThickLabel";
   args.Reset();
   args.LeftAttachment(XmATTACH_WIDGET, typeFrame);
   thickLabel = XmCreateLabel(form, wname, ARGS);
   XtVaGetValues(thickLabel, XmNwidth, &wd, NULL);

   wname = "shadowModThickTF";
   args.Reset();
   args.LeftAttachment(XmATTACH_WIDGET, typeFrame, wd + ltOffset);
   thickTF = XmCreateTextField(form, wname, ARGS);

   args.Reset();
   args.TopAttachment(XmATTACH_OPPOSITE_WIDGET, thickTF);
   args.BottomAttachment(XmATTACH_OPPOSITE_WIDGET, thickTF);
   args.RightAttachment(XmATTACH_WIDGET, thickTF);
   args.LeftAttachment(XmATTACH_NONE);
   XtSetValues(thickLabel, ARGS);

   wname = "shadowModPixelLabel";
   args.Reset();
   args.TopAttachment(XmATTACH_OPPOSITE_WIDGET, thickTF);
   args.BottomAttachment(XmATTACH_OPPOSITE_WIDGET, thickTF);
   args.LeftAttachment(XmATTACH_WIDGET, thickTF);
   Widget	pixelLabel = XmCreateLabel(form, wname, ARGS);

//
// Create typeFrame hierarchy
//
//   typeFrame
//	RowColumn	typeRadioBox
//
   wname = "shadowModTypeRadioBox";
   args.Reset();
   args.Orientation(XmHORIZONTAL);
   args.RadioBehavior(True);
   typeRadioBox = XmCreateRowColumn(typeFrame, wname, ARGS);

//
// Create typeRadioBox hierarchy
//
//   typeRadioBox
//	ToggleButton	inTB
//	ToggleButton	outTB
//	ToggleButton	etchInTB
//	ToggleButton	etchOutTB
//
   wname = "shadowModInTB";
   inTB	  = XmCreateToggleButton(typeRadioBox, wname, 0,0);

   wname = "shadowModOutTB";
   outTB  = XmCreateToggleButton(typeRadioBox, wname, 0,0);

   wname = "shadowModEtchInTB";
   etchInTB = XmCreateToggleButton(typeRadioBox, wname, 0,0);

   wname = "shadowModEtchOutTB";
   etchOutTB = XmCreateToggleButton(typeRadioBox, wname, 0,0);

   XtAddCallback(inTB, XmNvalueChangedCallback, (XtCallbackProc)SetType,
		 (XtPointer)this);
   XtAddCallback(outTB, XmNvalueChangedCallback, (XtCallbackProc)SetType,
		 (XtPointer)this);
   XtAddCallback(etchInTB, XmNvalueChangedCallback, (XtCallbackProc)SetType,
		 (XtPointer)this);
   XtAddCallback(etchOutTB, XmNvalueChangedCallback, (XtCallbackProc)SetType,
		 (XtPointer)this);

//
// Manage widgets
//
   Widget	list[5];
   list[0] = inTB;
   list[1] = outTB;
   list[2] = etchInTB;
   list[3] = etchOutTB;
   XtManageChildren(list, 4);	// typeRadioBox children

   XtManageChild(typeRadioBox);	// typeFrame child

   list[0] = typeLabel;
   list[1] = typeFrame;
   list[2] = thickLabel;
   list[3] = thickTF;
   list[4] = pixelLabel;
   XtManageChildren(list, 5);	// form children

//
// Initialize
//
   XmToggleButtonSetState(inTB, True, True);

} // End ShadowModC ShadowModC

/*---------------------------------------------------------------
 *  Callback routine to handle press of toggle button
 */

void
ShadowModC::SetType(Widget w, ShadowModC *sm, XmToggleButtonCallbackStruct *tb)
{
   if ( !tb->set ) return;

   if      ( w == sm->outTB     ) sm->type = XmSHADOW_OUT;
   else if ( w == sm->etchInTB  ) sm->type = XmSHADOW_ETCHED_IN;
   else if ( w == sm->etchOutTB ) sm->type = XmSHADOW_ETCHED_OUT;
   else				  sm->type = XmSHADOW_IN;
}

/*---------------------------------------------------------------
 *  Method to return the thickness
 */

Dimension
ShadowModC::Thickness()
{
   char	*cs = XmTextFieldGetString(thickTF);
   int	thickness = atoi(cs);
   XtFree(cs);

   return thickness;
}

/*---------------------------------------------------------------
 *  Method to initialize the settings based on the given parameters
 */

void
ShadowModC::Init(unsigned char newType, Dimension thick)
{
   init.thick = thick;
   StringC	str;
   str += (int)init.thick;
   XmTextFieldSetString(thickTF, str);

   init.type = type = newType;
   Widget	tb;
   switch (type) {
      case (XmSHADOW_IN):		tb = inTB;	break;
      case (XmSHADOW_OUT):		tb = outTB;	break;
      case (XmSHADOW_ETCHED_IN):	tb = etchInTB;	break;
      case (XmSHADOW_ETCHED_OUT):	tb = etchOutTB;	break;
   }
   XmToggleButtonSetState(tb, True, True);

} // End ShadowModC Init

/*---------------------------------------------------------------
 *  Method to reset the settings to the initial state
 */

void
ShadowModC::Reset()
{
   StringC	str;
   str += (int)init.thick;
   XmTextFieldSetString(thickTF, str);

   type = init.type;
   Widget	tb;
   switch (type) {
      case (XmSHADOW_IN):		tb = inTB;	break;
      case (XmSHADOW_OUT):		tb = outTB;	break;
      case (XmSHADOW_ETCHED_IN):	tb = etchInTB;	break;
      case (XmSHADOW_ETCHED_OUT):	tb = etchOutTB;	break;
   }
   XmToggleButtonSetState(tb, True, True);

} // End ShadowModC Reset
