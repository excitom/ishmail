/*
 * $Id: StripChartModC.C,v 1.1 1998/06/24 01:29:07 lang Exp $
 *
 * Copyright (c) 1992 HAL Computer Systems International, Ltd.
 * 
 *          HAL COMPUTER SYSTEMS INTERNATIONAL, LTD.
 *                  1315 Dell Avenue
 *                  Campbell, CA  95008
 *
 * Author: Greg Hilton
 * Contributors: Tom Lang, Frank Bieser, and others
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * http://www.gnu.org/copyleft/gpl.html
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#include "StripChartModC.h"
#include "FormatModC.h"
#include "ShadowModC.h"
#include "ColorModC.h"
#include "WArgList.h"
#include "rsrc.h"

#include <Xm/Form.h>
#include <Xm/Frame.h>
#include <Xm/Label.h>
#include <Xm/TextF.h>
#include <Xm/ToggleB.h>
#include <Xm/RowColumn.h>

StripChartModC::StripChartModC(Widget parent, const char *name, ArgList argv,
			       Cardinal argc)
   : ModFormC(parent, name, argv, argc)
{
   WArgList	args;
   StringC	wname;
   int	ltOffset = get_int("StripChartModC", paramForm, "labelTextOffset");

   chart = NULL;

//
// Create the paramForm hierarchy
//
//   paramForm
//      ShadowModC	shadowForm
//      Label		tick1LenLabel
//      TextField	tick1LenTF
//      Label		tick2LenLabel
//      TextField	tick2LenTF
//      Label		margWdLabel
//      TextField	margWdTF
//      Label		margHtLabel
//      TextField	margHtTF
//      Frame		xFrame
//      Frame		yFrame
//
   wname = "shadowMod";
   args.Reset();
   args.LeftAttachment(XmATTACH_FORM);
   args.TopAttachment(XmATTACH_FORM);
   shadowForm = new ShadowModC(paramForm, wname, ARGS);

   wname = "majorTickLengthLabel";
   tick1LenLabel = XmCreateLabel(paramForm, wname, 0,0);

   wname = "majorTickLengthTF";
   args.Reset();
   args.TopAttachment(XmATTACH_WIDGET, *shadowForm);
   args.LeftAttachment(XmATTACH_FORM);
   tick1LenTF = XmCreateTextField(paramForm, wname, ARGS);

   wname = "marginWidthLabel";
   margWdLabel = XmCreateLabel(paramForm, wname, 0,0);

   wname = "marginWidthTF";
   args.Reset();
   args.TopAttachment(XmATTACH_WIDGET, tick1LenTF);
   args.LeftAttachment(XmATTACH_FORM);
   margWdTF = XmCreateTextField(paramForm, wname, ARGS);

//
// Get maximum label width
//
   Dimension	wd, max_wd;
   args.Reset();
   args.Add(XmNwidth, &wd);
   XtGetValues(shadowForm->TypeLabel(), ARGS); max_wd = wd;
   XtGetValues(tick1LenLabel,           ARGS); if (wd>max_wd) max_wd = wd;
   XtGetValues(margWdLabel,             ARGS); if (wd>max_wd) max_wd = wd;

   args.Reset();
   args.LeftAttachment(XmATTACH_FORM, max_wd + ltOffset);
   XtSetValues(shadowForm->TypeFrame(), ARGS);
   XtSetValues(tick1LenTF,              ARGS);
   XtSetValues(margWdTF,                ARGS);

//
// Attach labels
//
   args.Reset();
   args.TopAttachment(XmATTACH_OPPOSITE_WIDGET,    tick1LenTF);
   args.BottomAttachment(XmATTACH_OPPOSITE_WIDGET, tick1LenTF);
   args.RightAttachment(XmATTACH_WIDGET,           tick1LenTF);
   XtSetValues(tick1LenLabel, ARGS);

   args.TopWidget(margWdTF);
   args.BottomWidget(margWdTF);
   args.RightWidget(margWdTF);
   XtSetValues(margWdLabel, ARGS);

//
// Create the second column of labels and fields
//
   wname = "minorTickLengthLabel";
   tick2LenLabel = XmCreateLabel(paramForm, wname, 0,0);

   wname = "minorTickLengthTF";
   args.Reset();
   args.TopAttachment(XmATTACH_OPPOSITE_WIDGET, tick1LenTF);
   args.LeftAttachment(XmATTACH_WIDGET, tick1LenTF);
   tick2LenTF = XmCreateTextField(paramForm, wname, ARGS);

   wname = "marginHeightLabel";
   margHtLabel = XmCreateLabel(paramForm, wname, 0,0);

   wname = "marginHeightTF";
   args.Reset();
   args.TopAttachment(XmATTACH_OPPOSITE_WIDGET, margWdTF);
   args.LeftAttachment(XmATTACH_WIDGET, margWdTF);
   margHtTF = XmCreateTextField(paramForm, wname, ARGS);

//
// Position 2nd column labels and text
//
   max_wd = 0;
   args.Reset();
   args.Add(XmNwidth, &wd);
   XtGetValues(tick2LenLabel, ARGS); if (wd>max_wd) max_wd = wd;
   XtGetValues(margHtLabel,   ARGS); if (wd>max_wd) max_wd = wd;

   args.Reset();
   args.LeftAttachment(XmATTACH_WIDGET, tick1LenTF, max_wd + ltOffset);
   XtSetValues(tick2LenTF, ARGS);

   args.LeftWidget(margWdTF);
   XtSetValues(margHtTF, ARGS);

   args.Reset();
   args.LeftAttachment  (XmATTACH_NONE);
   args.RightAttachment (XmATTACH_WIDGET,          tick2LenTF);
   args.TopAttachment   (XmATTACH_OPPOSITE_WIDGET, tick2LenTF);
   args.BottomAttachment(XmATTACH_OPPOSITE_WIDGET, tick2LenTF);
   XtSetValues(tick2LenLabel, ARGS);

   args.RightWidget (margHtTF);
   args.TopWidget   (margHtTF);
   args.BottomWidget(margHtTF);
   XtSetValues(margHtLabel, ARGS);

   wname = "xAxisFrame";
   args.Reset();
   args.TopAttachment(XmATTACH_WIDGET, margWdTF);
   args.LeftAttachment(XmATTACH_FORM);
   args.RightAttachment(XmATTACH_FORM);
   xFrame = XmCreateFrame(paramForm, wname, ARGS);

   wname = "yAxisFrame";
   args.Reset();
   args.TopAttachment(XmATTACH_WIDGET, xFrame);
   args.LeftAttachment(XmATTACH_FORM);
   args.RightAttachment(XmATTACH_FORM);
   yFrame = XmCreateFrame(paramForm, wname, ARGS);

//
// Create the xFrame hierarchy
//
//   xFrame
//      Label	xTitle
//      Form	xForm
//
   wname = "xAxisTitle";
   args.Reset();
   args.ChildType(XmFRAME_TITLE_CHILD);
   args.ChildHorizontalAlignment(XmALIGNMENT_BEGINNING);
   xTitle = XmCreateLabel(xFrame, wname, ARGS);

   wname = "xAxisForm";
   xForm = XmCreateForm(xFrame, wname, 0,0);

//
// Create the xForm hierarchy
//
//   xForm
//      Label		xTick1SpaceLabel
//      TextField	xTick1SpaceTF
//      ToggleButton	xGrid1TB
//      Label		xTick2SpaceLabel
//      TextField	xTick2SpaceTF
//      ToggleButton	xGrid2TB
//	Label		visCountLabel
//	TextField	visCountTF
//	Label		maxCountLabel
//	TextField	maxCountTF
//
   wname = "majorXTickSpacingLabel";
   xTick1SpaceLabel = XmCreateLabel(xForm, wname, 0,0);

   wname = "minorXTickSpacingLabel";
   xTick2SpaceLabel = XmCreateLabel(xForm, wname, 0,0);

   wname = "visibleValueCountLabel";
   visCountLabel = XmCreateLabel(xForm, wname, 0,0);

   max_wd = 0;
   args.Reset();
   args.Add(XmNwidth, &wd);
   XtGetValues(xTick1SpaceLabel, ARGS); if (wd>max_wd) max_wd = wd;
   XtGetValues(xTick2SpaceLabel, ARGS); if (wd>max_wd) max_wd = wd;
   XtGetValues(visCountLabel,    ARGS); if (wd>max_wd) max_wd = wd;

   wname = "majorXTickSpacingTF";
   args.Reset();
   args.TopAttachment(XmATTACH_FORM);
   args.LeftAttachment(XmATTACH_FORM, max_wd + ltOffset);
   xTick1SpaceTF = XmCreateTextField(xForm, wname, ARGS);

   wname = "minorXTickSpacingTF";
   args.Reset();
   args.TopAttachment(XmATTACH_WIDGET, xTick1SpaceTF);
   args.LeftAttachment(XmATTACH_FORM, max_wd + ltOffset);
   xTick2SpaceTF = XmCreateTextField(xForm, wname, ARGS);

   wname = "visibleValueCountTF";
   args.Reset();
   args.TopAttachment(XmATTACH_WIDGET, xTick2SpaceTF);
   args.LeftAttachment(XmATTACH_FORM, max_wd + ltOffset);
   visCountTF = XmCreateTextField(xForm, wname, ARGS);

   args.Reset();
   args.TopAttachment(XmATTACH_OPPOSITE_WIDGET,    xTick1SpaceTF);
   args.BottomAttachment(XmATTACH_OPPOSITE_WIDGET, xTick1SpaceTF);
   args.RightAttachment(XmATTACH_WIDGET,           xTick1SpaceTF);
   XtSetValues(xTick1SpaceLabel, ARGS);

   args.TopWidget(xTick2SpaceTF);
   args.BottomWidget(xTick2SpaceTF);
   args.RightWidget(xTick2SpaceTF);
   XtSetValues(xTick2SpaceLabel, ARGS);

   args.TopWidget(visCountTF);
   args.BottomWidget(visCountTF);
   args.RightWidget(visCountTF);
   XtSetValues(visCountLabel, ARGS);

   wname = "majorXGridTB";
   args.Reset();
   args.TopAttachment(XmATTACH_OPPOSITE_WIDGET,    xTick1SpaceTF);
   args.BottomAttachment(XmATTACH_OPPOSITE_WIDGET, xTick1SpaceTF);
   args.LeftAttachment(XmATTACH_WIDGET,            xTick1SpaceTF);
   xGrid1TB = XmCreateToggleButton(xForm, wname, ARGS);

   wname = "minorXGridTB";
   args.Reset();
   args.TopAttachment(XmATTACH_OPPOSITE_WIDGET,    xTick2SpaceTF);
   args.BottomAttachment(XmATTACH_OPPOSITE_WIDGET, xTick2SpaceTF);
   args.LeftAttachment(XmATTACH_WIDGET,            xTick2SpaceTF);
   xGrid2TB = XmCreateToggleButton(xForm, wname, ARGS);

   wname = "maximumValueCountLabel";
   args.LeftAttachment(XmATTACH_WIDGET,            visCountTF);
   args.TopAttachment(XmATTACH_OPPOSITE_WIDGET,    visCountTF);
   args.BottomAttachment(XmATTACH_OPPOSITE_WIDGET, visCountTF);
   maxCountLabel = XmCreateLabel(xForm, wname, ARGS);

   wname = "maximumValueCountTF";
   args.LeftAttachment(XmATTACH_WIDGET,            maxCountLabel);
   args.TopAttachment(XmATTACH_OPPOSITE_WIDGET,    visCountTF);
   args.BottomAttachment(XmATTACH_OPPOSITE_WIDGET, visCountTF);
   maxCountTF = XmCreateTextField(xForm, wname, ARGS);

//
// Create the yFrame hierarchy
//
//   yFrame
//      Label	yTitle
//      Form	yForm
//
   wname = "yAxisTitle";
   args.Reset();
   args.ChildType(XmFRAME_TITLE_CHILD);
   args.ChildHorizontalAlignment(XmALIGNMENT_BEGINNING);
   yTitle = XmCreateLabel(yFrame, wname, ARGS);

   wname = "yAxisForm";
   yForm = XmCreateForm(yFrame, wname, 0,0);

//
// Create the yForm hierarchy
//
//   yForm
//      Label		minLabel
//      TextField	minTF
//      Label		maxLabel
//      TextField	maxTF
//      Label		yTick1SpaceLabel
//      TextField	yTick1SpaceTF
//      ToggleButton	yGrid1TB
//      Label		yTick2SpaceLabel
//      TextField	yTick2SpaceTF
//      ToggleButton	yGrid2TB
//      FormatModC	formatForm
//
   wname = "minLabel";
   minLabel = XmCreateLabel(yForm, wname, 0,0);

   wname = "minTF";
   args.Reset();
   args.TopAttachment(XmATTACH_FORM);
   args.LeftAttachment(XmATTACH_FORM);
   minTF = XmCreateTextField(yForm, wname, ARGS);

   wname = "majorYTickSpacingLabel";
   yTick1SpaceLabel = XmCreateLabel(yForm, wname, 0,0);

   wname = "majorYTickSpacingTF";
   args.Reset();
   args.TopAttachment(XmATTACH_WIDGET, minTF);
   args.LeftAttachment(XmATTACH_FORM);
   yTick1SpaceTF = XmCreateTextField(yForm, wname, ARGS);

   wname = "minorYTickSpacingLabel";
   yTick2SpaceLabel = XmCreateLabel(yForm, wname, 0,0);

   wname = "minorYTickSpacingTF";
   args.Reset();
   args.TopAttachment(XmATTACH_WIDGET, yTick1SpaceTF);
   args.LeftAttachment(XmATTACH_FORM);
   yTick2SpaceTF = XmCreateTextField(yForm, wname, ARGS);

   wname = "formatMod";
   args.Reset();
   args.TopAttachment(XmATTACH_WIDGET, yTick2SpaceTF);
   formatForm = new FormatModC(yForm, wname, ARGS);

//
// Get maximum label width
//
   max_wd = 0;
   args.Reset();
   args.Add(XmNwidth, &wd);
   XtGetValues(minLabel,            ARGS); if (wd>max_wd) max_wd = wd;
   XtGetValues(yTick1SpaceLabel,    ARGS); if (wd>max_wd) max_wd = wd;
   XtGetValues(yTick2SpaceLabel,    ARGS); if (wd>max_wd) max_wd = wd;
   XtGetValues(formatForm->Label(), ARGS); if (wd>max_wd) max_wd = wd;

   args.Reset();
   args.LeftAttachment(XmATTACH_FORM, max_wd + ltOffset);
   XtSetValues(minTF,               ARGS);
   XtSetValues(yTick1SpaceTF,       ARGS);
   XtSetValues(yTick2SpaceTF,       ARGS);
   XtSetValues(formatForm->Frame(), ARGS);

//
// Attach labels
//
   args.Reset();
   args.TopAttachment(XmATTACH_OPPOSITE_WIDGET,    minTF);
   args.BottomAttachment(XmATTACH_OPPOSITE_WIDGET, minTF);
   args.RightAttachment(XmATTACH_WIDGET,           minTF);
   XtSetValues(minLabel, ARGS);

   args.TopWidget(yTick1SpaceTF);
   args.BottomWidget(yTick1SpaceTF);
   args.RightWidget(yTick1SpaceTF);
   XtSetValues(yTick1SpaceLabel, ARGS);

   args.TopWidget(yTick2SpaceTF);
   args.BottomWidget(yTick2SpaceTF);
   args.RightWidget(yTick2SpaceTF);
   XtSetValues(yTick2SpaceLabel, ARGS);

//
// Create the second column of labels and fields
//
   wname = "maxLabel";
   maxLabel = XmCreateLabel(yForm, wname, 0,0);

   args.Reset();
   args.Add(XmNwidth, &wd);
   XtGetValues(maxLabel, ARGS);

   wname = "maxTF";
   args.Reset();
   args.TopAttachment(XmATTACH_OPPOSITE_WIDGET, minTF);
   args.LeftAttachment(XmATTACH_WIDGET, minTF, wd + ltOffset);
   maxTF = XmCreateTextField(yForm, wname, ARGS);

   args.Reset();
   args.TopAttachment(XmATTACH_OPPOSITE_WIDGET,    maxTF);
   args.BottomAttachment(XmATTACH_OPPOSITE_WIDGET, maxTF);
   args.RightAttachment(XmATTACH_WIDGET,           maxTF);
   XtSetValues(maxLabel, ARGS);

   wname = "majorYGridTB";
   args.Reset();
   args.TopAttachment(XmATTACH_OPPOSITE_WIDGET,    yTick1SpaceTF);
   args.BottomAttachment(XmATTACH_OPPOSITE_WIDGET, yTick1SpaceTF);
   args.LeftAttachment(XmATTACH_WIDGET,            yTick1SpaceTF);
   yGrid1TB = XmCreateToggleButton(yForm, wname, ARGS);

   wname = "minorYGridTB";
   args.Reset();
   args.TopAttachment(XmATTACH_OPPOSITE_WIDGET,    yTick2SpaceTF);
   args.BottomAttachment(XmATTACH_OPPOSITE_WIDGET, yTick2SpaceTF);
   args.LeftAttachment(XmATTACH_WIDGET,            yTick2SpaceTF);
   yGrid2TB = XmCreateToggleButton(yForm, wname, ARGS);

//
// Create the colorRC hierarchy
//
//   colorRC
//      ColorModC	backgroundForm
//      ColorModC	digitBackgroundForm
//      ColorModC	digitForegroundForm
//      ColorModC	topShadowForm
//      ColorModC	bottomShadowForm
//
   wname = "backgroundMod";
   colorForm[StripChartC::BACKGROUND]    = new ColorModC(colorRC, wname, 0,0);
   wname = "chartColorMod";
   colorForm[StripChartC::CHART_COLOR]   = new ColorModC(colorRC, wname, 0,0);
   wname = "lineColorMod";
   colorForm[StripChartC::LINE_COLOR]    = new ColorModC(colorRC, wname, 0,0);
   wname = "axisColorMod";
   colorForm[StripChartC::AXIS_COLOR]    = new ColorModC(colorRC, wname, 0,0);
   wname = "labelColorMod";
   colorForm[StripChartC::LABEL_COLOR]   = new ColorModC(colorRC, wname, 0,0);
   wname = "tickColorMod";
   colorForm[StripChartC::TICK_COLOR]    = new ColorModC(colorRC, wname, 0,0);
   wname = "gridColorMod";
   colorForm[StripChartC::GRID_COLOR]    = new ColorModC(colorRC, wname, 0,0);
   wname = "markColorMod";
   colorForm[StripChartC::MARK_COLOR]    = new ColorModC(colorRC, wname, 0,0);
   wname = "topShadowColorMod";
   colorForm[StripChartC::TOP_SHADOW]    = new ColorModC(colorRC, wname, 0,0);
   wname = "bottomShadowColorMod";
   colorForm[StripChartC::BOTTOM_SHADOW] = new ColorModC(colorRC, wname, 0,0);

//
// Manage children
//
   Widget	list[11];
   list[0] = *colorForm[StripChartC::BACKGROUND];
   list[1] = *colorForm[StripChartC::CHART_COLOR];
   list[2] = *colorForm[StripChartC::LINE_COLOR];
   list[3] = *colorForm[StripChartC::AXIS_COLOR];
   list[4] = *colorForm[StripChartC::LABEL_COLOR];
   list[5] = *colorForm[StripChartC::TICK_COLOR];
   list[6] = *colorForm[StripChartC::GRID_COLOR];
   list[7] = *colorForm[StripChartC::MARK_COLOR];
   list[8] = *colorForm[StripChartC::TOP_SHADOW];
   list[9] = *colorForm[StripChartC::BOTTOM_SHADOW];
   XtManageChildren(list, 10);	// colorRC children

   list[ 0] = minLabel;
   list[ 1] = minTF;
   list[ 2] = maxLabel;
   list[ 3] = maxTF;
   list[ 4] = yTick1SpaceLabel;
   list[ 5] = yTick1SpaceTF;
   list[ 6] = yGrid1TB;
   list[ 7] = yTick2SpaceLabel;
   list[ 8] = yTick2SpaceTF;
   list[ 9] = yGrid2TB;
   list[10] = *formatForm;
   XtManageChildren(list, 11);	// yForm children

   list[0] = yTitle;
   list[1] = yForm;
   XtManageChildren(list, 2);	// yFrame children

   list[0] = xTick1SpaceLabel;
   list[1] = xTick1SpaceTF;
   list[2] = xGrid1TB;
   list[3] = xTick2SpaceLabel;
   list[4] = xTick2SpaceTF;
   list[5] = xGrid2TB;
   list[6] = visCountLabel;
   list[7] = visCountTF;
   list[8] = maxCountLabel;
   list[9] = maxCountTF;
   XtManageChildren(list, 10);	// xForm children

   list[0] = xTitle;
   list[1] = xForm;
   XtManageChildren(list, 2);	// xFrame children

   list[ 0] = *shadowForm;
   list[ 1] = tick1LenLabel;
   list[ 2] = tick1LenTF;
   list[ 3] = tick2LenLabel;
   list[ 4] = tick2LenTF;
   list[ 5] = margWdLabel;
   list[ 6] = margWdTF;
   list[ 7] = margHtLabel;
   list[ 8] = margHtTF;
   list[ 9] = xFrame;
   list[10] = yFrame;
   XtManageChildren(list, 11);	// paramForm children

} // End StripChartModC StripChartModC

/*---------------------------------------------------------------
 *  Destructor
 */

StripChartModC::~StripChartModC()
{
   delete shadowForm;
   delete formatForm;
   for (int i=0; i<StripChartC::COLOR_ATTR_COUNT; i++) delete colorForm[i];
}

/*---------------------------------------------------------------
 *  Method to apply strip chart changes
 */

void
StripChartModC::Apply(StripChartC& strip)
{
   strip.Defer(True);

//
// Set the shadow attributes
//
   strip.SetShadowType(shadowForm->Type());
   strip.SetShadowThickness(shadowForm->Thickness());

//
// Set the tick lengths
//
   char *cs = XmTextFieldGetString(tick1LenTF);
   int	tick1Len = atoi(cs);
   XtFree(cs);

   cs = XmTextFieldGetString(tick2LenTF);
   int	tick2Len = atoi(cs);
   XtFree(cs);

   strip.SetTickLength(tick1Len, tick2Len);

//
// Set the margins
//
   cs = XmTextFieldGetString(margWdTF);
   int	marginWd = atoi(cs);
   XtFree(cs);

   cs = XmTextFieldGetString(margHtTF);
   int	marginHt = atoi(cs);
   XtFree(cs);

   strip.SetMargins(marginWd, marginHt);

//
// Set the x tick spacings
//
   cs = XmTextFieldGetString(xTick1SpaceTF);
   int	xTick1Space = atoi(cs);
   XtFree(cs);

   cs = XmTextFieldGetString(xTick2SpaceTF);
   int	xTick2Space = atoi(cs);
   XtFree(cs);

   strip.SetXTickSpacing(xTick1Space, xTick2Space);

//
// Set the x grid visibilities
//
   Boolean	xGrid1 = XmToggleButtonGetState(xGrid1TB);
   Boolean	xGrid2 = XmToggleButtonGetState(xGrid2TB);
   strip.SetXGridVis(xGrid1, xGrid2);

//
// Set the visible and maximum value counts
//
   cs = XmTextFieldGetString(visCountTF);
   unsigned	visCount = atoi(cs);
   XtFree(cs);
   strip.SetVisibleValueCount(visCount);

   cs = XmTextFieldGetString(maxCountTF);
   unsigned	maxCount = atoi(cs);
   XtFree(cs);
   strip.SetMaximumValueCount(maxCount);

//
// Set the y range
//
   cs = XmTextFieldGetString(minTF);
   float	minVal = atof(cs);
   XtFree(cs);

   cs = XmTextFieldGetString(maxTF);
   float	maxVal = atof(cs);
   XtFree(cs);

   strip.SetRange(minVal, maxVal);

//
// Set the y tick spacings
//
   cs = XmTextFieldGetString(yTick1SpaceTF);
   float	yTick1Space = atof(cs);
   XtFree(cs);

   cs = XmTextFieldGetString(yTick2SpaceTF);
   float	yTick2Space = atof(cs);
   XtFree(cs);

   strip.SetYTickSpacing(yTick1Space, yTick2Space);

//
// Set the y grid visibilities
//
   Boolean	yGrid1 = XmToggleButtonGetState(yGrid1TB);
   Boolean	yGrid2 = XmToggleButtonGetState(yGrid2TB);
   strip.SetYGridVis(yGrid1, yGrid2);

//
// Set the numeric format
//
   ValueC	formVal;
   formatForm->Apply(formVal);

   strip.SetOutputFormat(formVal.Format());
   strip.SetPrecision(formVal.Precision());

//
// Set the colors
//
   for (int i=0; i<StripChartC::COLOR_ATTR_COUNT; i++) {
      ColorModC	*cm = colorForm[i];
      if ( cm->Changed() ) {
	 strip.SetColor((StripChartC::StripChartColorAttr)i, cm->Value());
      }
   }

   strip.Defer(False);
   strip.Draw();

   return;

} // End StripChartModC Apply

/*---------------------------------------------------------------
 *  Method to initialize the settings based on the given strip chart
 */

void
StripChartModC::Init(StripChartC& strip)
{
//
// Initialize shadows
//
   shadowForm->Init(strip.ShadowType(), strip.ShadowThickness());

//
// Initialize tick length
//
   strip.GetTickLength(&init.tick1Len, &init.tick2Len);
   StringC	str;
   str += init.tick1Len;
   XmTextFieldSetString(tick1LenTF, str);
   str = "";
   str += init.tick2Len;
   XmTextFieldSetString(tick2LenTF, str);

//
// Initialize margins
//
   strip.GetMargins(&init.marginWd, &init.marginHt);
   str = "";
   str += (int)init.marginWd;
   XmTextFieldSetString(margWdTF, str);
   str = "";
   str += (int)init.marginHt;
   XmTextFieldSetString(margHtTF, str);

//
// Initialize x axis ticks
//
   strip.GetXTickSpacing(&init.xTick1Space, &init.xTick2Space);
   str = "";
   str += init.xTick1Space;
   XmTextFieldSetString(xTick1SpaceTF, str);
   str = "";
   str += init.xTick2Space;
   XmTextFieldSetString(xTick2SpaceTF, str);

//
// Initialize x axis grid visibility
//
   strip.GetXGridVis(&init.xGrid1, &init.xGrid2);
   XmToggleButtonSetState(xGrid1TB, init.xGrid1, False);
   XmToggleButtonSetState(xGrid2TB, init.xGrid2, False);

//
// Initialize the visible and maximum value counts
//
   init.visCount = strip.VisibleValueCount();
   str = "";
   str += init.visCount;
   XmTextFieldSetString(visCountTF, str);

   init.maxCount = strip.MaximumValueCount();
   str = "";
   str += init.maxCount;
   XmTextFieldSetString(maxCountTF, str);

//
// Initialize the y range
//
   strip.GetRange((float *)&init.minVal, (float *)&init.maxVal);
   XmTextFieldSetString(minTF, (char *)(StringC)init.minVal);
   XmTextFieldSetString(maxTF, (char *)(StringC)init.maxVal);

//
// Initialize y axis ticks
//
   strip.GetYTickSpacing((float *)&init.yTick1Space, (float *)&init.yTick2Space);
   XmTextFieldSetString(yTick1SpaceTF, (char *)(StringC)init.yTick1Space);
   XmTextFieldSetString(yTick2SpaceTF, (char *)(StringC)init.yTick2Space);

//
// Initialize y axis grid visibility
//
   strip.GetYGridVis(&init.yGrid1, &init.yGrid2);
   XmToggleButtonSetState(yGrid1TB, init.yGrid1, False);
   XmToggleButtonSetState(yGrid2TB, init.yGrid2, False);

//
// Initialize value format
//
   formatForm->Init(strip.OutputFormat(), strip.Precision());

//
// Initialize the colors
//
   for (int i=0; i<StripChartC::COLOR_ATTR_COUNT; i++) {
      colorForm[i]->Init(
		     strip.GetColor((StripChartC::StripChartColorAttr)i));
   }

   chart = &strip;

} // End StripChartModC Init

/*---------------------------------------------------------------
 *  Method to reset the fields to their initial values
 */

void
StripChartModC::Reset()
{
//
// Reset shadows
//
   shadowForm->Reset();

//
// Reset tick length
//
   StringC	str;
   str += init.tick1Len;
   XmTextFieldSetString(tick1LenTF, str);
   str = "";
   str += init.tick2Len;
   XmTextFieldSetString(tick2LenTF, str);

//
// Reset margins
//
   str = "";
   str += (int)init.marginWd;
   XmTextFieldSetString(margWdTF, str);
   str = "";
   str += (int)init.marginHt;
   XmTextFieldSetString(margHtTF, str);

//
// Reset x axis ticks
//
   str = "";
   str += init.xTick1Space;
   XmTextFieldSetString(xTick1SpaceTF, str);
   str = "";
   str += init.xTick2Space;
   XmTextFieldSetString(xTick2SpaceTF, str);

//
// Reset x axis grid visibility
//
   XmToggleButtonSetState(xGrid1TB, init.xGrid1, False);
   XmToggleButtonSetState(xGrid2TB, init.xGrid2, False);

//
// Reset the visible and maximum value counts
//
   str = "";
   str += init.visCount;
   XmTextFieldSetString(visCountTF, str);

   str = "";
   str += init.maxCount;
   XmTextFieldSetString(maxCountTF, str);

//
// Reset the y range
//
   XmTextFieldSetString(minTF, (char *)(StringC)init.minVal);
   XmTextFieldSetString(maxTF, (char *)(StringC)init.maxVal);

//
// Reset y axis ticks
//
   XmTextFieldSetString(yTick1SpaceTF, (char *)(StringC)init.yTick1Space);
   XmTextFieldSetString(yTick2SpaceTF, (char *)(StringC)init.yTick2Space);

//
// Reset y axis grid visibility
//
   XmToggleButtonSetState(yGrid1TB, init.yGrid1, False);
   XmToggleButtonSetState(yGrid2TB, init.yGrid2, False);

//
// Reset value format
//
   formatForm->Reset();

//
// Reset the colors
//
   for (int i=0; i<StripChartC::COLOR_ATTR_COUNT; i++) colorForm[i]->Reset();

   if ( autoApply ) {
      chart->Defer(True);
      chart->SetShadowType(shadowForm->Type());
      chart->SetShadowThickness(shadowForm->Thickness());
      chart->SetTickLength(init.tick1Len, init.tick2Len);
      chart->SetMargins(init.marginWd, init.marginHt);
      chart->SetXTickSpacing(init.xTick1Space, init.xTick2Space);
      chart->SetXGridVis(init.xGrid1, init.xGrid2);
      chart->SetVisibleValueCount(init.visCount);
      chart->SetMaximumValueCount(init.maxCount);
      chart->SetRange(init.minVal, init.maxVal);
      chart->SetYTickSpacing(init.yTick1Space, init.yTick2Space);
      chart->SetYGridVis(init.yGrid1, init.yGrid2);
      chart->SetOutputFormat(formatForm->Format());
      chart->SetPrecision(formatForm->Precision());
      for (int i=0; i<StripChartC::COLOR_ATTR_COUNT; i++)
	 chart->SetColor((StripChartC::StripChartColorAttr)i,
			 colorForm[i]->Value());
      chart->Defer(False);
      chart->Draw();
   }

} // End StripChartModC Reset

/*---------------------------------------------------------------
 *  Method to add the callbacks needed to support auto update
 */

void
StripChartModC::EnableAutoApply()
{
   if ( autoApply ) return;

#define AddValueChanged(W,C) \
   XtAddCallback(W, XmNvalueChangedCallback, \
	         (XtCallbackProc)(C), (XtPointer)this)

#define AddActivate(W,C) \
   XtAddCallback(W, XmNactivateCallback, \
	         (XtCallbackProc)(C), (XtPointer)this)

#define AddColorActivate(COL,C) \
   AddActivate(colorForm[StripChartC::COL]->TextField(), C)

//
// Add auto-update callbacks
//
   AddValueChanged (shadowForm->InTB(),      ChangeShadow);
   AddValueChanged (shadowForm->OutTB(),     ChangeShadow);
   AddValueChanged (shadowForm->EtchInTB(),  ChangeShadow);
   AddValueChanged (shadowForm->EtchOutTB(), ChangeShadow);
   AddActivate     (shadowForm->ThickTF(),   ChangeShadowThick);
   AddActivate     (tick1LenTF,              ChangeTickLength);
   AddActivate     (tick2LenTF,              ChangeTickLength);
   AddActivate     (margWdTF,                ChangeMargin);
   AddActivate     (margHtTF,                ChangeMargin);
   AddActivate     (xTick1SpaceTF,           ChangeXTickSpace);
   AddActivate     (xTick2SpaceTF,           ChangeXTickSpace);
   AddValueChanged (xGrid1TB,                ChangeXGrid);
   AddValueChanged (xGrid2TB,                ChangeXGrid);
   AddActivate     (visCountTF,              ChangeVisCount);
   AddActivate     (maxCountTF,              ChangeMaxCount);
   AddActivate     (minTF,                   ChangeRange);
   AddActivate     (maxTF,                   ChangeRange);
   AddActivate     (yTick1SpaceTF,           ChangeYTickSpace);
   AddActivate     (yTick2SpaceTF,           ChangeYTickSpace);
   AddValueChanged (yGrid1TB,                ChangeYGrid);
   AddValueChanged (yGrid2TB,                ChangeYGrid);
   AddValueChanged (formatForm->IntTB(),     ChangeFormat);
   AddValueChanged (formatForm->HexTB(),     ChangeFormat);
   AddValueChanged (formatForm->FloatTB(),   ChangeFormat);
   AddActivate     (formatForm->PrecisTF(),  ChangeFormatPrecis);
   AddColorActivate(BACKGROUND,              ChangeBackground);
   AddColorActivate(CHART_COLOR,             ChangeChartColor);
   AddColorActivate(LINE_COLOR,              ChangeLineColor);
   AddColorActivate(AXIS_COLOR,              ChangeAxisColor);
   AddColorActivate(LABEL_COLOR,             ChangeLabelColor);
   AddColorActivate(TICK_COLOR,              ChangeTickColor);
   AddColorActivate(GRID_COLOR,              ChangeGridColor);
   AddColorActivate(MARK_COLOR,              ChangeMarkColor);
   AddColorActivate(TOP_SHADOW,              ChangeTopShadow);
   AddColorActivate(BOTTOM_SHADOW,           ChangeBottomShadow);

} // End StripChartModC EnableAutoApply

/*---------------------------------------------------------------
 *  Method to remove the callbacks needed to support auto update
 */

void
StripChartModC::DisableAutoApply()
{
   if ( !autoApply ) return;

#define RemoveValueChanged(W,C) \
   XtRemoveCallback(W, XmNvalueChangedCallback, \
	            (XtCallbackProc)(C), (XtPointer)this)

#define RemoveActivate(W,C) \
   XtRemoveCallback(W, XmNactivateCallback, \
	            (XtCallbackProc)(C), (XtPointer)this)

#define RemoveColorActivate(COL,C) \
   RemoveActivate(colorForm[StripChartC::COL]->TextField(), C)

//
// Remove auto-update callbacks
//
   RemoveValueChanged (shadowForm->InTB(),      ChangeShadow);
   RemoveValueChanged (shadowForm->OutTB(),     ChangeShadow);
   RemoveValueChanged (shadowForm->EtchInTB(),  ChangeShadow);
   RemoveValueChanged (shadowForm->EtchOutTB(), ChangeShadow);
   RemoveActivate     (shadowForm->ThickTF(),   ChangeShadowThick);
   RemoveActivate     (tick1LenTF,              ChangeTickLength);
   RemoveActivate     (tick2LenTF,              ChangeTickLength);
   RemoveActivate     (margWdTF,                ChangeMargin);
   RemoveActivate     (margHtTF,                ChangeMargin);
   RemoveActivate     (xTick1SpaceTF,           ChangeXTickSpace);
   RemoveActivate     (xTick2SpaceTF,           ChangeXTickSpace);
   RemoveValueChanged (xGrid1TB,                ChangeXGrid);
   RemoveValueChanged (xGrid2TB,                ChangeXGrid);
   RemoveActivate     (visCountTF,              ChangeVisCount);
   RemoveActivate     (maxCountTF,              ChangeMaxCount);
   RemoveActivate     (minTF,                   ChangeRange);
   RemoveActivate     (maxTF,                   ChangeRange);
   RemoveActivate     (yTick1SpaceTF,           ChangeYTickSpace);
   RemoveActivate     (yTick2SpaceTF,           ChangeYTickSpace);
   RemoveValueChanged (yGrid1TB,                ChangeYGrid);
   RemoveValueChanged (yGrid2TB,                ChangeYGrid);
   RemoveValueChanged (formatForm->IntTB(),     ChangeFormat);
   RemoveValueChanged (formatForm->HexTB(),     ChangeFormat);
   RemoveValueChanged (formatForm->FloatTB(),   ChangeFormat);
   RemoveActivate     (formatForm->PrecisTF(),  ChangeFormatPrecis);
   RemoveColorActivate(BACKGROUND,              ChangeBackground);
   RemoveColorActivate(CHART_COLOR,             ChangeChartColor);
   RemoveColorActivate(LINE_COLOR,              ChangeLineColor);
   RemoveColorActivate(AXIS_COLOR,              ChangeAxisColor);
   RemoveColorActivate(LABEL_COLOR,             ChangeLabelColor);
   RemoveColorActivate(TICK_COLOR,              ChangeTickColor);
   RemoveColorActivate(GRID_COLOR,              ChangeGridColor);
   RemoveColorActivate(MARK_COLOR,              ChangeMarkColor);
   RemoveColorActivate(TOP_SHADOW,              ChangeTopShadow);
   RemoveColorActivate(BOTTOM_SHADOW,           ChangeBottomShadow);

} // End StripChartModC DisableAutoApply

void
StripChartModC::ChangeShadow(Widget, StripChartModC *sm,
			     XmToggleButtonCallbackStruct *tb)
{
   if ( tb->set )
      sm->chart->SetShadowType(sm->shadowForm->Type());
}

void
StripChartModC::ChangeShadowThick(Widget, StripChartModC *sm, XtPointer)
{
   sm->chart->SetShadowThickness(sm->shadowForm->Thickness());
}

void
StripChartModC::ChangeTickLength(Widget, StripChartModC *sm, XtPointer)
{
   if ( XmTextFieldGetLastPosition(sm->tick1LenTF) == 0 ||
	XmTextFieldGetLastPosition(sm->tick2LenTF) == 0 ) return;

   char *cs = XmTextFieldGetString(sm->tick1LenTF);
   int	tick1 = atoi(cs);
   XtFree(cs);

   cs = XmTextFieldGetString(sm->tick2LenTF);
   int	tick2 = atoi(cs);
   XtFree(cs);

   sm->chart->SetTickLength(tick1, tick2);
}

void
StripChartModC::ChangeMargin(Widget, StripChartModC *sm, XtPointer)
{
   if ( XmTextFieldGetLastPosition(sm->margWdTF) == 0 ||
	XmTextFieldGetLastPosition(sm->margHtTF) == 0 ) return;

   char *cs = XmTextFieldGetString(sm->margWdTF);
   int	wd = atoi(cs);
   XtFree(cs);

   cs = XmTextFieldGetString(sm->margHtTF);
   int	ht = atoi(cs);
   XtFree(cs);

   sm->chart->SetMargins(wd, ht);
}

void
StripChartModC::ChangeXTickSpace(Widget, StripChartModC *sm, XtPointer)
{
   if ( XmTextFieldGetLastPosition(sm->xTick1SpaceTF) == 0 ||
	XmTextFieldGetLastPosition(sm->xTick2SpaceTF) == 0 ) return;

   char *cs = XmTextFieldGetString(sm->xTick1SpaceTF);
   int	tick1 = atoi(cs);
   XtFree(cs);

   cs = XmTextFieldGetString(sm->xTick2SpaceTF);
   int	tick2 = atoi(cs);
   XtFree(cs);

   sm->chart->SetXTickSpacing(tick1, tick2);
}

void
StripChartModC::ChangeXGrid(Widget w, StripChartModC *sm,
			    XmToggleButtonCallbackStruct *tb)
{
   Boolean grid1 = (w == sm->xGrid1TB) ? tb->set
				       : XmToggleButtonGetState(sm->xGrid1TB);
   Boolean grid2 = (w == sm->xGrid2TB) ? tb->set
				       : XmToggleButtonGetState(sm->xGrid2TB);
   sm->chart->SetXGridVis(grid1, grid2);
}

void
StripChartModC::ChangeVisCount(Widget, StripChartModC *sm, XtPointer)
{
   if ( XmTextFieldGetLastPosition(sm->visCountTF) == 0 ) return;

   char *cs = XmTextFieldGetString(sm->visCountTF);
   int	count = atoi(cs);
   XtFree(cs);

   sm->chart->SetVisibleValueCount(count);
}

void
StripChartModC::ChangeMaxCount(Widget, StripChartModC *sm, XtPointer)
{
   if ( XmTextFieldGetLastPosition(sm->maxCountTF) == 0 ) return;

   char *cs = XmTextFieldGetString(sm->maxCountTF);
   int	count = atoi(cs);
   XtFree(cs);

   sm->chart->SetMaximumValueCount(count);
}

void
StripChartModC::ChangeRange(Widget, StripChartModC *sm, XtPointer)
{
   if ( XmTextFieldGetLastPosition(sm->minTF) == 0 ||
        XmTextFieldGetLastPosition(sm->maxTF) == 0 ) return;

   char *cs = XmTextFieldGetString(sm->minTF);
   float	min = atof(cs);
   XtFree(cs);

   cs = XmTextFieldGetString(sm->maxTF);
   float	max = atof(cs);
   XtFree(cs);

   if ( min >= max ) return;

   sm->chart->SetRange(min, max);
}

void
StripChartModC::ChangeYTickSpace(Widget, StripChartModC *sm, XtPointer)
{
   if ( XmTextFieldGetLastPosition(sm->yTick1SpaceTF) == 0 ||
	XmTextFieldGetLastPosition(sm->yTick2SpaceTF) == 0 ) return;

   char *cs = XmTextFieldGetString(sm->yTick1SpaceTF);
   float	tick1 = atof(cs);
   XtFree(cs);

   cs = XmTextFieldGetString(sm->yTick2SpaceTF);
   float	tick2 = atof(cs);
   XtFree(cs);

   sm->chart->SetYTickSpacing(tick1, tick2);
}

void
StripChartModC::ChangeYGrid(Widget w, StripChartModC *sm,
			    XmToggleButtonCallbackStruct *tb)
{
   Boolean grid1 = (w == sm->yGrid1TB) ? tb->set
				       : XmToggleButtonGetState(sm->yGrid1TB);
   Boolean grid2 = (w == sm->yGrid2TB) ? tb->set
				       : XmToggleButtonGetState(sm->yGrid2TB);
   sm->chart->SetYGridVis(grid1, grid2);
}

void
StripChartModC::ChangeFormat(Widget, StripChartModC *sm, XmToggleButtonCallbackStruct *tb)
{
   if ( tb->set )
      sm->chart->SetOutputFormat(sm->formatForm->Format());
}

void
StripChartModC::ChangeFormatPrecis(Widget, StripChartModC *sm, XtPointer)
{
   sm->chart->SetPrecision(sm->formatForm->Precision());
}

void
StripChartModC::ChangeBackground(Widget, StripChartModC *sm, XtPointer)
{
   sm->ChangeColor(StripChartC::BACKGROUND);
}

void
StripChartModC::ChangeChartColor(Widget, StripChartModC *sm, XtPointer)
{
   sm->ChangeColor(StripChartC::CHART_COLOR);
}

void
StripChartModC::ChangeLineColor(Widget, StripChartModC *sm, XtPointer)
{
   sm->ChangeColor(StripChartC::LINE_COLOR);
}

void
StripChartModC::ChangeAxisColor(Widget, StripChartModC *sm, XtPointer)
{
   sm->ChangeColor(StripChartC::AXIS_COLOR);
}

void
StripChartModC::ChangeLabelColor(Widget, StripChartModC *sm, XtPointer)
{
   sm->ChangeColor(StripChartC::LABEL_COLOR);
}

void
StripChartModC::ChangeTickColor(Widget, StripChartModC *sm, XtPointer)
{
   sm->ChangeColor(StripChartC::TICK_COLOR);
}

void
StripChartModC::ChangeGridColor(Widget, StripChartModC *sm, XtPointer)
{
   sm->ChangeColor(StripChartC::GRID_COLOR);
}

void
StripChartModC::ChangeMarkColor(Widget, StripChartModC *sm, XtPointer)
{
   sm->ChangeColor(StripChartC::MARK_COLOR);
}

void
StripChartModC::ChangeTopShadow(Widget, StripChartModC *sm, XtPointer)
{
   sm->ChangeColor(StripChartC::TOP_SHADOW);
}

void
StripChartModC::ChangeBottomShadow(Widget, StripChartModC *sm, XtPointer)
{
   sm->ChangeColor(StripChartC::BOTTOM_SHADOW);
}

void
StripChartModC::ChangeColor(StripChartC::StripChartColorAttr color)
{
   ColorModC		*cm = colorForm[color];

   if ( cm->Changed() ) chart->SetColor(color, cm->Value());
}
