/*
 * $Id: TreeOutline.h,v 1.1 1998/06/24 01:29:07 lang Exp $
 *
 * Copyright (c) 1991 HaL Computer Systems, Inc.  All rights reserved.
 * 
 *          HAL COMPUTER SYSTEMS INTERNATIONAL, LTD.
 *                  1315 Dell Avenue
 *                  Campbell, CA  95008
 *
 * Author: Greg Hilton
 * Contributors: Tom Lang, Frank Bieser, and others
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * http://www.gnu.org/copyleft/gpl.html
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
/*
 * $XConsortium: Tree.h,v 1.11 91/05/04 18:59:13 rws Exp $
 *
 * Copyright 1990 Massachusetts Institute of Technology
 * Copyright 1989 Prentice Hall
 *
 * Permission to use, copy, modify, and distribute this software for any
 * purpose and without fee is hereby granted, provided that the above
 * copyright notice appear in all copies and that both the copyright notice
 * and this permission notice appear in supporting documentation.
 * 
 * M.I.T., Prentice Hall and the authors disclaim all warranties with regard
 * to this software, including all implied warranties of merchantability and
 * fitness.  In no event shall M.I.T., Prentice Hall or the authors be liable
 * for any special, indirect or cosequential damages or any damages whatsoever
 * resulting from loss of use, data or profits, whether in an action of
 * contract, negligence or other tortious action, arising out of or in
 * connection with the use or performance of this software.
 * 
 * Authors:  Jim Fulton, MIT X Consortium,
 *           based on a version by Douglas Young, Prentice Hall
 * 
 * This widget is based on the Tree widget described on pages 397-419 of
 * Douglas Young's book "The X Window System, Programming and Applications 
 * with Xt OSF/Motif Edition."  The layout code has been rewritten to use
 * additional blank space to make the structure of the graph easier to see
 * as well as to support vertical trees.
 */


#ifndef _XawTreeOutline_h
#define _XawTreeOutline_h

#include <X11/Xmu/Converters.h>
#include <X11/Xfuncproto.h>

/******************************************************************************
 * 
 * TreeOutline Widget (subclass of ConstraintClass)
 * 
 ******************************************************************************
 * 
 * Parameters:
 * 
 *  Name                Class              Type            Default
 *  ----                -----              ----            -------
 * 
 *  autoReconfigure     AutoReconfigure    Boolean         FALSE
 *  background          Background         Pixel           XtDefaultBackground
 *  foreground          Foreground         Pixel           XtDefaultForeground
 *  gravity             Gravity            XtGravity       West
 *  hSpace              HSpace             Dimension       20
 *  lineWidth           LineWidth          Dimension       0
 *  vSpace              VSpace             Dimension       6
 * 
 * 
 * Constraint Resources attached to children:
 * 
 *  treeOutlineGC              TreeOutlineGC             GC              NULL
 *  treeOutlineParent          TreeOutlineParent         Widget          NULL
 * 
 * 
 *****************************************************************************/

                                        /* new instance field names */
#ifndef _XtStringDefs_h_
#define XtNhSpace "hSpace"
#define XtNvSpace "vSpace"
#define XtCHSpace "HSpace"
#define XtCVSpace "VSpace"
#endif

#define XtNautoReconfigure "autoReconfigure"
#define XtNlineWidth "lineWidth"
#define XtNtreeOutlineGC "treeOutlineGC"
#define XtNtreeOutlineParent "treeOutlineParent"
#define XtNgravity "gravity"


#define XtCTreeOutline "TreeOutline"
#define XtCAutoReconfigure "AutoReconfigure"
#define XtCLineWidth "LineWidth"
#define XtCTreeOutlineGC "TreeOutlineGC"
#define XtCTreeOutlineParent "TreeOutlineParent"
#define XtCGravity "Gravity"

#define XtRGC "GC"

/***************************************
 *         XmTreeOutlineTypes
 ***************************************/
typedef unsigned char XtTreeOutlineType;
#define XtRTreeOutlineType "XtTreeOutlineType"
#define XtNtreeOutline     "treeOutline"
enum { XtTREE,
       XtOUTLINE
     };
                                        /* external declarations */
extern WidgetClass treeOutlineWidgetClass;

typedef struct _TreeOutlineClassRec *TreeOutlineWidgetClass;
typedef struct _TreeOutlineRec      *TreeOutlineWidget;

_XFUNCPROTOBEGIN

extern void XawTreeOutlineForceLayout (
#if NeedFunctionPrototypes
    Widget /* treeOutline */
#endif
);

extern void XawTreeOutlineDestroySubtree (
#if NeedFunctionPrototypes
    Widget /* tree child */
#endif
);

extern void XawTreeOutlineDestroyChildren (
#if NeedFunctionPrototypes
    Widget /* tree child */
#endif
);

_XFUNCPROTOEND

#endif /* _XawTreeOutline_h */
