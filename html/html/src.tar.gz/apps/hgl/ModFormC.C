/*
 * $Id: ModFormC.C,v 1.1 1998/06/24 01:29:07 lang Exp $
 *
 * Copyright (c) 1992 HAL Computer Systems International, Ltd.
 * 
 *          HAL COMPUTER SYSTEMS INTERNATIONAL, LTD.
 *                  1315 Dell Avenue
 *                  Campbell, CA  95008
 *
 * Author: Greg Hilton
 * Contributors: Tom Lang, Frank Bieser, and others
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * http://www.gnu.org/copyleft/gpl.html
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#include "ModFormC.h"
#include "WArgList.h"
#include "StringC.h"

#include <Xm/RowColumn.h>
#include <Xm/Form.h>
#include <Xm/ToggleB.h>
#include <Xm/Frame.h>
#include <Xm/Label.h>

ModFormC::ModFormC(Widget parent, const char *name, ArgList argv, Cardinal argc)
{
   WArgList	args;

   autoApply = False;

   modRC = XmCreateRowColumn(parent, (char *)name, argv, argc);

   args.Reset();
   args.Orientation(XmVERTICAL);
   args.Packing(XmPACK_TIGHT);
   XtSetValues(modRC, ARGS);

//
// Create the modRC hierarchy
//
//   modRC
//      Frame		paramFrame
//      Frame		colorFrame
//
   paramFrame = XmCreateFrame(modRC, "modFormParamFrame", 0,0);
   colorFrame = XmCreateFrame(modRC, "modFormColorFrame", 0,0);

//
// Create the paramFrame hierarchy
//
//   paramFrame
//      Label		paramTitle
//      Form		paramForm
//
   args.Reset();
   args.ChildType(XmFRAME_TITLE_CHILD);
   args.ChildHorizontalAlignment(XmALIGNMENT_BEGINNING);
   paramTitle = XmCreateLabel(paramFrame, "modFormParamTitle", ARGS);

   paramForm = XmCreateForm(paramFrame, "modFormParamForm", 0,0);

//
// Create the colorFrame hierarchy
//
//   colorFrame
//      Label		colorTitle
//      RowColumn	colorRC
//
   args.Reset();
   args.ChildType(XmFRAME_TITLE_CHILD);
   args.ChildHorizontalAlignment(XmALIGNMENT_BEGINNING);
   colorTitle = XmCreateLabel(colorFrame, "modFormColorTitle", ARGS);

   args.Reset();
   args.Packing(XmPACK_COLUMN);
   colorRC = XmCreateRowColumn(colorFrame, "modFormColorRC", ARGS);

//
// Manage children
//
   Widget	list[2];
   list[0] = colorTitle;
   list[1] = colorRC;
   XtManageChildren(list, 2);	// colorFrame children

   list[0] = paramTitle;
   list[1] = paramForm;
   XtManageChildren(list, 2);	// paramFrame children

   list[0] = paramFrame;
   list[1] = colorFrame;
   XtManageChildren(list, 2);	// topForm children

} // End ModFormC ModFormC

ModFormC::~ModFormC()
{
}

/*-------------------------------------------------------------------------
 * Callback to mark text field as changed
 */

void
ModFormC::TextChanged(Widget, Boolean *flag, XtPointer)
{
   *flag = True;
}

/*-------------------------------------------------------------------------
 * Callback to mark text field as changed
 */

void
ModFormC::AutoApply(Boolean val)
{
   if ( autoApply == val ) return;

   if ( val ) EnableAutoApply();
   else       DisableAutoApply();

   autoApply = val;
}

/*-------------------------------------------------------------------------
 * These are implemented by the derived class if they're needed
 */

void ModFormC::EnableAutoApply()  {}
void ModFormC::DisableAutoApply() {}
