/*
 * $Id: ScaleC.C,v 1.1 1998/06/24 01:29:07 lang Exp $
 *
 * Copyright (c) 1992 HAL Computer Systems International, Ltd.
 * 
 *          HAL COMPUTER SYSTEMS INTERNATIONAL, LTD.
 *                  1315 Dell Avenue
 *                  Campbell, CA  95008
 *
 * Author: Greg Hilton
 * Contributors: Tom Lang, Frank Bieser, and others
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * http://www.gnu.org/copyleft/gpl.html
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#include "HalAppC.h"
#include "ScaleC.h"
#include "WArgList.h"
#include "Shadow.h"
#include "rsrc.h"
#include "IntListC.h"
#include "RegexC.h"
#include "StringListC.h"
#include "WorkingBoxC.h"

#include <Xm/DrawingA.h>
#include <X11/Xmu/Converters.h>

#define DEFAULT_BG_COLOR	WhitePixel(halApp->display, \
					   DefaultScreen(halApp->display))
#define DEFAULT_FG_COLOR	BlackPixel(halApp->display,  \
					   DefaultScreen(halApp->display))

/*----------------------------------------------------------------------
 * Method to build the widget hierarchy
 */

ScaleC::ScaleC(Widget parent, const char *name, ArgList argv, Cardinal argc)
: GraphC(parent, name, argv, argc)
{
   markList.AllowDuplicates(TRUE);

//
// Read attributes
//
   char	*cl = "ScaleC";
   labelOffset	    = get_int   (cl, da, "labelOffset", 2);
   orientation      = get_orient(cl, da, "orientation", XmHORIZONTAL);
   prefSize         = get_int   (cl, da, "troughSize", 0);
   barShadowType    = get_shadow_type(cl, da, "barShadowType",    XmSHADOW_OUT);
   troughShadowType = get_shadow_type(cl, da, "troughShadowType", XmSHADOW_IN);
   barShadowThickness    = get_int(cl, da, "barShadowThickness",    2);
   troughShadowThickness = get_int(cl, da, "troughShadowThickness", 2);

   value       = get_float(cl, da, "value", 0.0);
   minValue    = get_float(cl, da, "minValue", value - 1.0);
   maxValue    = get_float(cl, da, "maxValue", minValue + 2.0);
   valRangeInv = 1.0 / (maxValue - minValue);
   int precis  = get_int  (cl, da, "decimalPlaces", 2);
   formatVal.SetPrecision(precis);

   colors[BACKGROUND]   = get_color(cl, da, "background",  DEFAULT_BG_COLOR);
   colors[BAR_COLOR]    = get_color(cl, da, "barColor",    DEFAULT_BG_COLOR);
   colors[TROUGH_COLOR] = get_color(cl, da, "troughColor", DEFAULT_BG_COLOR);
   colors[VALUE_COLOR]  = get_color(cl, da, "valueColor",  DEFAULT_FG_COLOR);
   colors[LABEL_COLOR]  = get_color(cl, da, "labelColor",  DEFAULT_FG_COLOR);
   colors[MARK_COLOR]   = get_color(cl, da, "markColor",   DEFAULT_FG_COLOR);
   colors[BAR_TOP_SHADOW]
      = get_color(cl, da, "barTopShadowColor",    DEFAULT_BG_COLOR);
   colors[BAR_BOTTOM_SHADOW]
      = get_color(cl, da, "barBottomShadowColor", DEFAULT_FG_COLOR);
   colors[TROUGH_TOP_SHADOW]
      = get_color(cl, da, "troughTopShadowColor",    DEFAULT_BG_COLOR);
   colors[TROUGH_BOTTOM_SHADOW]
      = get_color(cl, da, "troughBottomShadowColor", DEFAULT_FG_COLOR);

//
// Get color names
//
   colorNames[BACKGROUND]          = ColorName(da, colors[BACKGROUND]);
   colorNames[BAR_COLOR]           = ColorName(da, colors[BAR_COLOR]);
   colorNames[TROUGH_COLOR]        = ColorName(da, colors[TROUGH_COLOR]);
   colorNames[VALUE_COLOR]         = ColorName(da, colors[VALUE_COLOR]);
   colorNames[LABEL_COLOR]         = ColorName(da, colors[LABEL_COLOR]);
   colorNames[MARK_COLOR]          = ColorName(da, colors[MARK_COLOR]);
   colorNames[BAR_TOP_SHADOW]      = ColorName(da, colors[BAR_TOP_SHADOW]);
   colorNames[BAR_BOTTOM_SHADOW]   = ColorName(da, colors[BAR_BOTTOM_SHADOW]);
   colorNames[TROUGH_TOP_SHADOW]   = ColorName(da, colors[TROUGH_TOP_SHADOW]);
   colorNames[TROUGH_BOTTOM_SHADOW]= ColorName(da,colors[TROUGH_BOTTOM_SHADOW]);

//
// Load font
//
   StringC	str = get_string(cl, da, "font", "fixed");
   font = XLoadQueryFont(halApp->display, str);
   if ( !font ) font = halApp->font;

   return;

} // End ScaleC ScaleC

/*----------------------------------------------------------------------
 * Destructor
 */

ScaleC::~ScaleC()
{
   if ( halApp->xRunning )  
      XFreeFont(halApp->display, font);
}

/*----------------------------------------------------------------------
 * Method to draw scale
 */

void
ScaleC::Draw()
{
   if ( !gc || obscured ) return;

   XSetForeground(halApp->display, gc, colors[BACKGROUND]);
   XFillRectangle(halApp->display, pixmap, gc, 0, 0, daWd, daHt);

   if ( orientation == XmHORIZONTAL ) DrawHorizontal();
   else				      DrawVertical();

   XCopyArea(halApp->display, pixmap, win, gc, 0, 0, daWd, daHt, 0, 0);
}

/*----------------------------------------------------------------------
 * Method to draw horizontal scale
 */

void
ScaleC::DrawHorizontal()
{
//
// Get size of label strings
//
   formatVal = minValue;
   StringC	minStr = formatVal;
   formatVal = maxValue;
   StringC	maxStr = formatVal;

   int		dir, asc, dsc;
   XCharStruct	minSize, maxSize;
   XTextExtents(font, minStr, minStr.size(), &dir, &asc, &dsc, &minSize);
   XTextExtents(font, maxStr, maxStr.size(), &dir, &asc, &dsc, &maxSize);
   int	maxLabelWd = minSize.width;
   if ( maxSize.width > maxLabelWd ) maxLabelWd = maxSize.width;

   int	botMargin = marginHt + font->ascent + font->descent + labelOffset;
   int	topMargin = marginHt;

//
// Add space for marks if necessary
//
   if ( markList.size() > 0 ) topMargin = botMargin + labelOffset;

//
// Calculate size of trough
//
   int	troughWd = daWd - marginWd*2 - maxLabelWd;
   if ( troughWd < 1 ) troughWd = 1;

//
// Should be no larger than preferred height
//
   int	troughHt;
   if ( prefSize > 0 ) {

      troughHt = prefSize;
      while ( (troughHt + topMargin + botMargin) > (int)daHt ) troughHt--;

   } else {

      troughHt = daHt - topMargin - botMargin;
   }

//
// Center it in graph
//
   if ( troughHt < 1 ) troughHt = 1;
   int	troughX = (int)(daWd - troughWd) / (int)2;
   int	troughY = (int)(daHt - troughHt - topMargin - botMargin) / (int)2;
   troughY += topMargin;

//
// Draw trough background
//
   XSetForeground(halApp->display, gc, colors[TROUGH_COLOR]);
   XFillRectangle(halApp->display, pixmap, gc, troughX, troughY, troughWd,
		  troughHt);

//
// Draw trough shadow
//
   if ( troughShadowThickness > 0 )
      DrawShadow(halApp->display, pixmap, gc, colors[TROUGH_TOP_SHADOW],
		 colors[TROUGH_BOTTOM_SHADOW], troughX, troughY, troughWd,
		 troughHt, troughShadowThickness, troughShadowType);

//
// Draw slider bar
//
   int	barX  = troughX + troughShadowThickness;
   int	barY  = troughY + troughShadowThickness + 1;
   int	barWd = troughWd - troughShadowThickness*2;
   int	valWd = (int)(barWd * NormalizeValue(value));
   if ( valWd < barWd ) barWd = valWd;
   int	barHt = troughHt - troughShadowThickness*2 - 2;
   if ( barWd < 1 ) barWd = 1;
   if ( barHt < 1 ) barHt = 1;
   XSetForeground(halApp->display, gc, colors[BAR_COLOR]);
   XFillRectangle(halApp->display, pixmap, gc, barX, barY, barWd, barHt);

//
// Draw slider bar shadow
//
   if ( barShadowThickness > 0 )
      DrawShadow(halApp->display, pixmap, gc, colors[BAR_TOP_SHADOW],
		 colors[BAR_BOTTOM_SHADOW], barX, barY, barWd, barHt,
		 barShadowThickness, barShadowType);

//
// Draw label strings
//
   int	x = troughX + troughShadowThickness - minSize.width/2;
   int	y = troughY + troughHt + labelOffset + font->ascent;
   XSetForeground(halApp->display, gc, colors[LABEL_COLOR]);
   XDrawString(halApp->display, pixmap, gc, x, y, minStr, minStr.size());

   x = troughX + troughWd - troughShadowThickness - maxSize.width/2;
   XDrawString(halApp->display, pixmap, gc, x, y, maxStr, maxStr.size());

//
// Draw scale value
//
   StringC	valStr = ValueString();
   XCharStruct	size;
   XTextExtents(font, valStr, valStr.size(), &dir, &asc, &dsc, &size);
   y = barY + ((barHt - (size.ascent + size.descent)) / 2) + size.ascent;
   x = (barX + barWd) - barShadowThickness - labelOffset - size.width;
   if ( (int)x < (int)0 ||
	(int)x < (int)(barX + barShadowThickness + labelOffset) )
      x = (barX + barWd) + labelOffset;
   XSetForeground(halApp->display, gc, colors[VALUE_COLOR]);
   XDrawString(halApp->display, pixmap, gc, x, y, valStr, valStr.size());

//
// Draw marks
//
   int		spaceWd = troughWd - troughShadowThickness*2;
   unsigned	count = markList.size();
   for (int i=0; i<count; i++) {
      formatVal = *markList[i];
      valStr = (StringC)formatVal;
      x = barX + (int)(spaceWd * NormalizeValue(formatVal));
      XSetForeground(halApp->display, gc, colors[MARK_COLOR]);
      XDrawLine(halApp->display, pixmap, gc, x, troughY-labelOffset, x,
		troughY+troughHt+labelOffset);
      XTextExtents(font, valStr, valStr.size(), &dir, &asc, &dsc, &size);
      x -= (size.width / 2);
      y = troughY - labelOffset - font->descent;
      XDrawString(halApp->display, pixmap, gc, x, y, valStr, valStr.size());
   }

} // End ScaleC DrawHorizontal

/*----------------------------------------------------------------------
 * Method to draw vertical scale
 */

void
ScaleC::DrawVertical()
{
//
// Get size of label strings
//
   formatVal = minValue;
   StringC	minStr = formatVal;
   formatVal = maxValue;
   StringC	maxStr = formatVal;

   int		dir, asc, dsc;
   XCharStruct	minSize, maxSize;
   XTextExtents(font, minStr, minStr.size(), &dir, &asc, &dsc, &minSize);
   XTextExtents(font, maxStr, maxStr.size(), &dir, &asc, &dsc, &maxSize);
   int	maxLabelWd = minSize.width;
   if ( maxSize.width > maxLabelWd ) maxLabelWd = maxSize.width;

   int	leftMargin  = marginWd + maxLabelWd + labelOffset;
   int	rightMargin = marginWd;

//
// Add space for marks if necessary
//
   if ( markList.size() > 0 ) rightMargin = leftMargin + labelOffset;

   int	fontHt = font->ascent + font->descent;
   int	troughHt = daHt - marginHt*2 - fontHt;
   if ( troughHt < 1 ) troughHt = 1;

//
// Should be no larger than preferred width
//
   int	troughWd;
   if ( prefSize > 0 ) {

      troughWd = prefSize;
      while ( (troughWd + leftMargin + rightMargin) > (int)daWd )
	 troughWd--;

   } else {

      troughWd = daWd - leftMargin - rightMargin;
   }

//
// Center it in graph
//
   if ( troughWd < (int)1 ) troughWd = 1;
   int	troughY = (int)(daHt - troughHt) / (int)2;
   int	troughX = (int)(daWd - troughWd - leftMargin - rightMargin) / (int)2;
   troughX += leftMargin;

//
// Draw trough background
//
   XSetForeground(halApp->display, gc, colors[TROUGH_COLOR]);
   XFillRectangle(halApp->display, pixmap, gc, troughX, troughY, troughWd,
		  troughHt);

//
// Draw trough shadow
//
   if ( troughShadowThickness > 0 )
      DrawShadow(halApp->display, pixmap, gc, colors[TROUGH_TOP_SHADOW],
		 colors[TROUGH_BOTTOM_SHADOW], troughX, troughY, troughWd,
		 troughHt, troughShadowThickness, troughShadowType);

//
// Draw slider bar
//
   int	barWd = troughWd - troughShadowThickness*2;
   int	barHt = troughHt - troughShadowThickness*2 - 2;
   int	valHt = (int)(barHt * NormalizeValue(value));
   if ( valHt < barHt ) barHt = valHt;
   if ( barWd < 1 ) barWd = 1;
   if ( barHt < 1 ) barHt = 1;
   int	barX  = troughX + troughShadowThickness;
   int	barY  = troughY + troughHt - troughShadowThickness - 1 - barHt;
   XSetForeground(halApp->display, gc, colors[BAR_COLOR]);
   XFillRectangle(halApp->display, pixmap, gc, barX, barY, barWd, barHt);

//
// Draw slider bar shadow
//
   if ( barShadowThickness > 0 )
      DrawShadow(halApp->display, pixmap, gc, colors[BAR_TOP_SHADOW],
		 colors[BAR_BOTTOM_SHADOW], barX, barY, barWd, barHt,
		 barShadowThickness, barShadowType);

//
// Draw label strings
//
   int	fontHt2 = fontHt / 2;
   int	x = troughX - minSize.width - labelOffset;
   int	y = troughY + troughHt + font->ascent - fontHt2;
   XSetForeground(halApp->display, gc, colors[LABEL_COLOR]);
   XDrawString(halApp->display, pixmap, gc, x, y, minStr, minStr.size());

   x = troughX - maxSize.width - labelOffset;
   y = troughY + font->ascent - fontHt2;
   XDrawString(halApp->display, pixmap, gc, x, y, maxStr, maxStr.size());

//
// Draw scale value
//
   StringC	valStr = ValueString();
   XCharStruct	size;
   XTextExtents(font, valStr, valStr.size(), &dir, &asc, &dsc, &size);
   x = barX + (barWd - size.width)/(int)2;
   y = barY + barShadowThickness + labelOffset + size.ascent;
   if ( (int)(y + size.descent) > (int)(barY + barHt - barShadowThickness) )
      y = barY - labelOffset - size.descent;
   XSetForeground(halApp->display, gc, colors[VALUE_COLOR]);
   XDrawString(halApp->display, pixmap, gc, x, y, valStr, valStr.size());

//
// Draw marks
//
   int		spaceHt = troughHt - troughShadowThickness*2;
   unsigned	count = markList.size();
   for (int i=0; i<count; i++) {
      formatVal = *markList[i];
      valStr = (StringC)formatVal;
      y = barY + barHt - (int)(spaceHt * NormalizeValue(formatVal));
      x = troughX + troughWd + labelOffset;
      XSetForeground(halApp->display, gc, colors[MARK_COLOR]);
      XDrawLine(halApp->display, pixmap, gc, troughX-labelOffset, y, x, y);
      XTextExtents(font, valStr, valStr.size(), &dir, &asc, &dsc, &size);
      x += labelOffset;
      y += font->ascent - fontHt2;
      XDrawString(halApp->display, pixmap, gc, x, y, valStr, valStr.size());
   }

} // End ScaleC DrawVertical

/*----------------------------------------------------------------------
 * Method to convert value into range 0.0 to 1.0
  */

float
ScaleC::NormalizeValue(float val)
{
   return ((val - minValue) * valRangeInv);
}

/*----------------------------------------------------------------------
 * Method to add a mark
 */

void
ScaleC::AddMark(const ValueC val)
{
   float	fval = val;
   markList.append(fval);
   if ( !deferred ) Draw();
}

/*----------------------------------------------------------------------
 * Methods to set the shadow thickness
 */

void
ScaleC::SetBarShadowThickness(Dimension thick)
{
   if ( thick != barShadowThickness ) {
      barShadowThickness = thick;
      if ( !deferred ) Draw();
   }
}

void
ScaleC::SetTroughShadowThickness(Dimension thick)
{
   if ( thick != troughShadowThickness ) {
      troughShadowThickness = thick;
      if ( !deferred ) Draw();
   }
}

/*----------------------------------------------------------------------
 * Methods to set the shadow type
 */

void
ScaleC::SetBarShadowType(unsigned char type)
{
   if ( type != barShadowType ) {
      barShadowType = type;
      if ( !deferred ) Draw();
   }
}

void
ScaleC::SetTroughShadowType(unsigned char type)
{
   if ( type != troughShadowType ) {
      troughShadowType = type;
      if ( !deferred ) Draw();
   }
}

/*----------------------------------------------------------------------
 * Method to set the size of the trough
 */

void
ScaleC::SetTroughSize(int size)
{
   if ( size != prefSize ) {
      prefSize = size;
      if ( !deferred ) Draw();
   }
}

/*----------------------------------------------------------------------
 * Method to set the spacing between labels and the scale
 */

void
ScaleC::SetLabelOffset(int offset)
{
   if ( offset != labelOffset ) {
      labelOffset = offset;
      if ( !deferred ) Draw();
   }
}

/*----------------------------------------------------------------------
 * Methods to set mark values
 */

void
ScaleC::SetMarks(const IntListC& list)
{
   markList.removeAll();

   unsigned	count = list.size();
   for (int i=0; i<count; i++) {
      float	fval = *list[i];
      markList.append(fval);
   }

   if ( !deferred ) Draw();
}

void
ScaleC::SetMarks(const FloatListC& list)
{
   markList = list;
   if ( !deferred ) Draw();
}

/*----------------------------------------------------------------------
 * Method to set the scale orientation
 */

void
ScaleC::SetOrientation(unsigned char orient)
{
   if ( orient != orientation ) {
      orientation = orient;
      if ( !deferred ) Draw();
   }
}

/*----------------------------------------------------------------------
 * Method to set the numeric output format to INT, HEX or FLOAT
 */

void
ScaleC::SetOutputFormat(ValueC::ValueFormat newFormat)
{
   if ( newFormat != formatVal.Format() ) {
      formatVal.SetFormat(newFormat);
      if ( !deferred ) Draw();
   }
}

/*----------------------------------------------------------------------
 * Methods to set the number of decimal places for float output
 */

void
ScaleC::SetPrecision(int places)
{
   if ( places != formatVal.Precision() ) {
      formatVal.SetPrecision(places);
      if ( !deferred && formatVal.Format() == ValueC::FLOAT ) Draw();
   }
}

/*----------------------------------------------------------------------
 * Method to set the minimum and maximum values for the scale
 */

void
ScaleC::SetRange(const ValueC min, const ValueC max)
{
   if ( (float)max <= (float)min ) return;

   minValue = min;
   maxValue = max;
   valRangeInv = 1.0/(maxValue - minValue);

   if ( !deferred ) Draw();
}

/*----------------------------------------------------------------------
 * Method to set the current value
 */

void
ScaleC::SetValue(const ValueC val)
{
   value = val;
   if ( !deferred ) Draw();
}

/*----------------------------------------------------------------------
 * Methods to set the requested color
 */

void
ScaleC::SetColor(ScaleC::ScaleColorAttr attr, Pixel color)
{
   if ( colors[attr] == color ) return;

   colors[attr]     = color;
   colorNames[attr] = ColorName(da, color);

   switch (attr) {

      case (BACKGROUND):
	 XtVaSetValues(da, XmNbackground, color, NULL);

      default:
	 if ( !deferred ) Draw();
	 break;

   } // End switch color attribute
}

void
ScaleC::SetColor(ScaleC::ScaleColorAttr attr, const char *name)
{
   Pixel	color;
   if ( PixelValue(da, name, &color) ) SetColor(attr, color);
}

/*----------------------------------------------------------------------
 * Method to return the requested pixel value
 */

Pixel
ScaleC::GetColor(ScaleC::ScaleColorAttr attr) const
{
   return colors[attr];
}

/*----------------------------------------------------------------------
 * Method to return the requested color name
 */

StringC
ScaleC::GetColorName(ScaleC::ScaleColorAttr attr) const
{
   return colorNames[attr];
}

/*-----------------------------------------------------------------------
 *  Methods to return the min and max values
 */

void
ScaleC::GetRange(ValueC *min, ValueC *max) const
{
   *min = minValue;
   *max = maxValue;
}

void
ScaleC::GetRange(StringC *min, StringC *max) const
{
   ValueC	tmp(formatVal);
   tmp = minValue;
   *min = (StringC)tmp;
   tmp = maxValue;
   *max = (StringC)tmp;
}

void
ScaleC::GetRange(int *min, int *max) const
{
   *min = (int)minValue;
   *max = (int)maxValue;
}

void
ScaleC::GetRange(long *min, long *max) const
{
   *min = (long)minValue;
   *max = (long)maxValue;
}

void
ScaleC::GetRange(float *min, float *max) const
{
   *min = minValue;
   *max = maxValue;
}

/*----------------------------------------------------------------------
 * Method to return a string representation of the current value
 */

StringC
ScaleC::ValueString() const
{
   ValueC	tmp(formatVal);
   tmp = value;
   return tmp;
}

/*----------------------------------------------------------------------
 * Method to copy the attributes of another scale
 */

ScaleC&
ScaleC::operator=(const ScaleC& that)
{
   marginWd              = that.marginWd;
   marginHt              = that.marginHt;
   prefSize              = that.prefSize;
   barShadowType         = that.barShadowType;
   barShadowThickness    = that.barShadowThickness;
   troughShadowType      = that.troughShadowType;
   troughShadowThickness = that.troughShadowThickness;
   orientation           = that.orientation;
   labelOffset           = that.labelOffset;
   formatVal		 = that.formatVal;
   minValue		 = that.minValue;
   maxValue		 = that.maxValue;
   valRangeInv		 = that.valRangeInv;

   for (int i=0; i<COLOR_ATTR_COUNT; i++) {
      colors[i]     = that.colors[i];
      colorNames[i] = that.colorNames[i];
   }
   XtVaSetValues(da, XmNbackground, colors[BACKGROUND], NULL);

   if ( !deferred ) Draw();

   return *this;

} // End ScaleC operator=

/*----------------------------------------------------------------------
 * Method to write resources to a file
 */

void
ScaleC::Write(FILE *fp, const char *prefix)
{
//
// Create next level prefix
//
   StringC	prefix2 = prefix; prefix2 += "\t";

//
// Write data
//
   fprintf(fp, "%s{SCALE\n", prefix);

   WriteResource(fp, prefix2 + "background",	colorNames[BACKGROUND]);
   WriteResource(fp, prefix2 + "barColor",	colorNames[BAR_COLOR]);
   WriteResource(fp, prefix2 + "troughColor",	colorNames[TROUGH_COLOR]);
   WriteResource(fp, prefix2 + "valueColor",	colorNames[VALUE_COLOR]);
   WriteResource(fp, prefix2 + "labelColor",	colorNames[LABEL_COLOR]);
   WriteResource(fp, prefix2 + "markColor",	colorNames[MARK_COLOR]);
   WriteResource(fp, prefix2 + "barTopShadowColor",colorNames[BAR_TOP_SHADOW]);
   WriteResource(fp, prefix2 + "barBottomShadowColor",
						colorNames[BAR_BOTTOM_SHADOW]);
   WriteResource(fp, prefix2 + "troughTopShadowColor",
						colorNames[TROUGH_TOP_SHADOW]);
   WriteResource(fp, prefix2 + "troughBottomShadowColor",
					      colorNames[TROUGH_BOTTOM_SHADOW]);

   WriteOrientation(fp, prefix2 + "orientation",	orientation);
   WriteResource   (fp, prefix2 + "value",		value);
   WriteResource   (fp, prefix2 + "minValue",		minValue);
   WriteResource   (fp, prefix2 + "maxValue",		maxValue);
   WriteResource   (fp, prefix2 + "outputFormat",	formatVal.FormatName());
   WriteResource   (fp, prefix2 + "decimalPlaces",	formatVal.Precision());
   WriteResource   (fp, prefix2 + "marks",		markList);
   WriteResource   (fp, prefix2 + "troughSize",		prefSize);
   WriteShadowType (fp, prefix2 + "barShadowType",	barShadowType);
   WriteResource   (fp, prefix2 + "barShadowThickness",	barShadowThickness);
   WriteShadowType (fp, prefix2 + "troughShadowType",	troughShadowType);
   WriteResource   (fp, prefix2 + "troughShadowThickness",troughShadowThickness);
//   WriteResource(fp, prefix2 + "font",		fontName);
   WriteResource   (fp, prefix2 + "labelOffset",	labelOffset);
   WriteResource   (fp, prefix2 + "marginWidth",	marginWd);
   WriteResource   (fp, prefix2 + "marginHeight",	marginHt);

   fprintf(fp, "%sSCALE}\n", prefix);

} // End ScaleC Write

/*----------------------------------------------------------------------
 * Method to read resources from a file
 */

int
ScaleC::Read(FILE *fp, WorkingBoxC *wb)
{
   StringC		line;
   static RegexC	*pair = NULL;
   static RegexC	*end  = NULL;

   if ( !pair ) {
      end  = new RegexC("[ \t]*SCALE}[ \t]*$");
      pair = new RegexC("[ \t]*\\([^:]+\\):[ \t]*\\(.*\\)");  // rsrc: val
   }

//
// Read resources until next "}" line
//
   StringListC	rsrcList;
   StringListC	valueList;
   rsrcList.AllowDuplicates(TRUE);
   valueList.AllowDuplicates(TRUE);

   line.Clear();
   int	status = line.GetLine(fp);
   while ( status != EOF && !end->match(line) && (!wb || !wb->Cancelled()) ) {

      if ( pair->match(line) ) {
	 StringC	tmp = line((*pair)[1]);
	 tmp.toLower();
	 rsrcList.append(tmp);
	 tmp = line((*pair)[2]);
	 valueList.append(tmp);
      }

      line.Clear();
      status = line.GetLine(fp);
   }

//
// Extract resources from resource string
//
   Defer(True);
   while ( rsrcList.size() > 0 && (!wb || !wb->Cancelled()) ) {

      StringC	*rsrc = rsrcList[0];
      StringC	*rval = valueList[0];
      StringC	tmp;
      int	index;

      if      ( *rsrc == "marginwidth"  ) marginWd    = atoi(*rval);
      else if ( *rsrc == "marginheight" ) marginHt    = atoi(*rval);
//      else if ( *rsrc == "font"         ) fontName    = *rval;
      else if ( *rsrc == "troughsize"   ) prefSize    = atoi(*rval);
      else if ( *rsrc == "labeloffset"  ) labelOffset = atoi(*rval);
      else if ( *rsrc == "value"        ) value       = atof(*rval);

      else if ( *rsrc == "minvalue" || *rsrc == "maxvalue" ) {

	 if ( *rsrc == "minvalue" ) {
	    minValue = atof(*rval);
	 } else {
	    tmp = "minvalue";
	    index = rsrcList.indexOf(tmp);
	    if ( index != rsrcList.NULL_INDEX ) {
		minValue = atoi(*valueList[index]);
		rsrcList.remove(index);
		valueList.remove(index);
	    }
	 }

	 if ( *rsrc == "maxvalue" ) {
	    maxValue = atof(*rval);
	 } else {
	    tmp = "maxvalue";
	    index = rsrcList.indexOf(tmp);
	    if ( index != rsrcList.NULL_INDEX ) {
		maxValue = atoi(*valueList[index]);
		rsrcList.remove(index);
		valueList.remove(index);
	    }
	 }

	 valRangeInv = 1.0/(maxValue - minValue);

      } // End if resource is min or max value

      else if ( *rsrc == "outputformat"  ) formatVal.SetFormat(*rval);
      else if ( *rsrc == "decimalplaces" ) formatVal.SetPrecision(atoi(*rval));

      else if ( *rsrc == "background"        ) SetColor(BACKGROUND,     *rval);
      else if ( *rsrc == "barcolor"          ) SetColor(BAR_COLOR,      *rval);
      else if ( *rsrc == "troughcolor"       ) SetColor(TROUGH_COLOR,   *rval);
      else if ( *rsrc == "valuecolor"        ) SetColor(VALUE_COLOR,    *rval);
      else if ( *rsrc == "labelcolor"        ) SetColor(LABEL_COLOR,    *rval);
      else if ( *rsrc == "markcolor"         ) SetColor(MARK_COLOR,     *rval);
      else if ( *rsrc == "bartopshadowcolor" ) SetColor(BAR_TOP_SHADOW, *rval);
      else if ( *rsrc == "barbottomshadowcolor" )
					 SetColor(BAR_BOTTOM_SHADOW,    *rval);
      else if ( *rsrc == "troughtopshadowcolor" )
					 SetColor(TROUGH_TOP_SHADOW,    *rval);
      else if ( *rsrc == "troughbottomshadowcolor" )
					 SetColor(TROUGH_BOTTOM_SHADOW, *rval);

      else if ( *rsrc == "barshadowthickness"  )
					      barShadowThickness = atoi(*rval);
      else if ( *rsrc == "troughshadowthickness" )
					   troughShadowThickness = atoi(*rval);

      else if ( *rsrc == "barshadowtype" ) {

	 XrmValue	from, to;
	 unsigned char	result;
	 from.addr = (XPointer)(char *)*rval;
	 from.size = strlen(*rval) + 1;
	 to.addr	= (XPointer)&result;
	 to.size	= sizeof(unsigned char);
	 if ( XtConvertAndStore(da, XmRString, &from, XmRShadowType, &to) )
	    barShadowType = result;

      } else if ( *rsrc == "troughshadowtype" ) {

	 XrmValue	from, to;
	 unsigned char	result;
	 from.addr = (XPointer)(char *)*rval;
	 from.size = strlen(*rval) + 1;
	 to.addr	= (XPointer)&result;
	 to.size	= sizeof(unsigned char);
	 if ( XtConvertAndStore(da, XmRString, &from, XmRShadowType, &to) )
	    troughShadowType = result;

      } else if ( *rsrc == "orientation" ) {

	 XrmValue	from, to;
	 unsigned char	result;
	 from.addr = (XPointer)(char *)*rval;
	 from.size = strlen(*rval) + 1;
	 to.addr	= (XPointer)&result;
	 to.size	= sizeof(unsigned char);
	 if ( XtConvertAndStore(da, XmRString, &from, XtROrientation, &to) )
	    orientation = result;

      } else if ( *rsrc == "marks" ) {

	 static RegexC	*word = NULL;
	 if ( !word ) word = new RegexC("[^ \t]+");

	 markList.removeAll();
	 while ( word->search(*rval) >= 0 ) {
	    float	mark = atof((*rval)((*word)[0]));
	    markList.append(mark);
	    (*rval)((*word)[0]) = "";
	 }
      }

//
// Remove current entry
//
      rsrcList.remove((int)0);
      valueList.remove((int)0);
   }

   Defer(False);
   return status;

} // End ScaleC Read
