/*
 * $Id: HalTreeNodeC.C,v 1.1 1998/06/24 01:29:07 lang Exp $
 *
 * Copyright (c) 1993 HAL Computer Systems International, Ltd.
 * 
 *          HAL COMPUTER SYSTEMS INTERNATIONAL, LTD.
 *                  1315 Dell Avenue
 *                  Campbell, CA  95008
 *
 * Author: Greg Hilton
 * Contributors: Tom Lang, Frank Bieser, and others
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * http://www.gnu.org/copyleft/gpl.html
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#include "HalAppC.h" 
#include "HalTreeNodeC.h"
#include "HalTreeC.h"
#include "rsrc.h"
#include "WidgetListC.h"

#include <X11/Intrinsic.h>
#include <X11/IntrinsicP.h>
#include <X11/CoreP.h>
#include <Xm/Xm.h>

#ifdef debug
#define dprintf(a) printf a
#else
#define dprintf(a)
#endif

// =====================================================================
// The constructor for a tree node.
// =====================================================================
HalTreeNodeC::HalTreeNodeC (HalTreeC* t)
{
//
// Initialize the data for this node.
//
   x        		= 0;	// virtual x position of the node.
   y        		= 0;	// virtual y position of the node.
   wd        		= 0;
   ht        		= 0;
   regWd        	= 0;
   regHt        	= 0;
   subWd        	= 0;
   subHt        	= 0;
   parent    	     	= NULL;
   tree      	     	= t;
   lineColor            = tree->LineColor();
   lineWidth            = tree->LineWidth();
   lineEtchColor        = tree->LineEtchColor();
   lineType             = tree->LineType();
   numChildrenShown     = 0;
   widget		= NULL;
   children 		= new HalTreeNodeListC;

   inTree         	= 0;
   show  	        = 0;
   autoDelete		= 1;
   selected		= 0;
   picked		= 0;       // for dragging/region select
   highlighted		= 0;
   deleting		= 0;
   opened		= 0;
   mapped		= 0;
   compFunc		= NULL;
} 


// =====================================================================
// This method sets the widget as the "node" widget, the widget
// may be NULL if the user would like to do their own drawing.
// =====================================================================
void
HalTreeNodeC::SetWidget(Widget w) 
{
   if ( widget ) {
      if ( autoDelete ) {
         XtRemoveCallback(widget, XmNdestroyCallback,
		          (XtCallbackProc)DoDestroy, (XtPointer)this);
      }
      XtRemoveEventHandler(widget, StructureNotifyMask, FALSE,
                           (XtEventHandler)HandleResize, (XtPointer)this);
   }

   widget = w;

   if ( widget ) {
      if ( autoDelete ) {
         XtAddCallback(widget, XmNdestroyCallback,
		       (XtCallbackProc)DoDestroy, (XtPointer)this);
      }
      XtAddEventHandler(widget, StructureNotifyMask, FALSE,
                        (XtEventHandler)HandleResize, (XtPointer)this);
      tree->hasWidgetNodes = TRUE;
   }
   CalculateSize();
}


// =====================================================================
// =====================================================================
void
HalTreeNodeC::SetAutoDelete(Boolean val) 
{
   if ( val )
      autoDelete = 1;
   else {
      if ( autoDelete && widget ) {
         XtRemoveCallback(widget, XmNdestroyCallback,
		          (XtCallbackProc)DoDestroy, (XtPointer)this);
      }
      autoDelete = 0;
   }
}



// =====================================================================
// This is the default node method used to determine if the button press
// should be analyzed if the node is a widget based node.  Otherwise, the
// user should override this...
// =====================================================================
int
HalTreeNodeC::AllowPick(int, int)
{
  return (True);
} 


// =====================================================================
// This is the default node method used to calculate the size of
// this node if the node is a widget based node.  Otherwise the
// user should override this...
// =====================================================================
void
HalTreeNodeC::CalculateSize()
{
   wd = 0;
   ht = 0;
   if ( widget ) {
      int bw2 = (int)widget->core.border_width * 2;
      wd = (int)widget->core.width + bw2;
      ht = (int)widget->core.height + bw2;
   }
}


// =====================================================================
// This is used to "re-parent" a node to a different parent.
// =====================================================================
void
HalTreeNodeC::SetParent(HalTreeNodeC* new_parent)
{
   if ( new_parent != parent ) {
      if ( parent )     parent->children->remove(this);
      if ( new_parent ) new_parent->children->append(this);
      parent = new_parent;
   }
   if ( Shown() ) {
      tree->changed = 1;
      tree->Draw();
   }
}


// =====================================================================
// This routine changes the index of the node and in affect moves the
// node to the desired position in the tree.
// =====================================================================
void
HalTreeNodeC::SetPositionIndex(int pos)
{
   if ( parent ) {
      if ( pos >= 0 && pos < parent->NumChildren() && 
           (*parent->children)[pos] != this )
      {
         parent->children->remove(this);
         parent->children->insert(this, pos);
         if ( Shown() )
            tree->Draw();
      }
   }
}


// =====================================================================
// This routine is used to actually draw the widget at its
// current location.
// =====================================================================
void
HalTreeNodeC::Draw()
{
   if ( widget ) {
      int pos_x = x - tree->world_x;
      int pos_y = y - tree->world_y;
      tree->busy++;
      XtMoveWidget(widget, pos_x, pos_y);
      if ( !XtIsManaged(widget) ) {
	 XtManageChild(widget);
	 CalculateSize();
      }
      XtMapWidget(widget);
      tree->busy--;
      mapped = 1;
   }
}


// =====================================================================
// This routine is used to erase the widget.
// =====================================================================
void
HalTreeNodeC::Erase()
{
   tree->busy++;
   if ( widget ) {
      if ( XtIsManaged(widget) ) {
         XtUnmapWidget(widget);
         mapped = 0;
         //SKB XtMoveWidget(widget, 0,0);
      }
   }
   tree->busy--;
}


// =====================================================================
// =====================================================================
void
HalTreeNodeC::ShowDescendants()
{
   ShowChildren(MAXINT);
}


// =====================================================================
// This routine is used to show the children of a node.  It can be used
// to recursively show all the descandants.
// =====================================================================
void
HalTreeNodeC::ShowChildren(int num_levels)
{
   if ( num_levels <= 0 || NumChildren() <= 0 ) return;

   tree->Defer(True);

   int	count = NumChildren();
   for (int i=0; i<count; i++) {
      HalTreeNodeC	*child = (*children)[i];
      if ( !child->Shown() ) {
	 child->Show(0);
      }
      child->ShowChildren(num_levels-1);
   }

   tree->Defer(False);

} // End ShowChildren


// =====================================================================
// This routine is used to hide the children of a particular node.
// Walk the children of this node checking for managed
// children. We need to unmanage those children (and their children...)
// =====================================================================
void
HalTreeNodeC::HideChildren()
{
   tree->Defer(True);

   int	count = NumChildren();
   for (int i=0; i<count; i++) {
      HalTreeNodeC	*child = (*children)[i];
      if ( child->Shown() ) {
	 child->Hide();
      }
   }

   tree->Defer(False);

} // End HideChildren


// =====================================================================
// =====================================================================
void
HalTreeNodeC::Show(int num_levels)
{
   tree->Defer(True);
   tree->busy++;
   if ( widget ) {
      if ( !XtIsManaged(widget) ) {
         tree->changed = True;
         XtManageChild(widget);
      }
   }
   if ( !show ) {
      CalculateSize();
      if ( parent ) parent->numChildrenShown++;
      tree->numNodesShown++;
      tree->changed = True;
      show = 1;
   }
   ShowChildren(num_levels);
   tree->busy--;
   tree->Defer(False);
}


// =====================================================================
// =====================================================================
void
HalTreeNodeC::Hide()
{
//
// Erase this node and its children.
//
   tree->Defer(True);
   HideChildren();
   Erase();

   if ( show ) {
      if ( parent ) parent->numChildrenShown--;
      tree->numNodesShown--;
      tree->changed = True;
      show = 0;
   }
   tree->Defer(False);
}


// =====================================================================
// The destructor for the tree node.
// =====================================================================
HalTreeNodeC::~HalTreeNodeC()
{
   deleting = True;

//
// See if we need to delete the widget or just the callbacks.
//
   if ( widget ) {
      XtRemoveCallback(widget, XmNdestroyCallback,
		       (XtCallbackProc)DoDestroy, (XtPointer)this);
      XtRemoveEventHandler(widget, StructureNotifyMask, FALSE,
                     (XtEventHandler)HandleResize, (XtPointer)this);
      if ( autoDelete ) {
         XtDestroyWidget(widget);
         widget = NULL;
      }
   }

   tree->RemoveNode(this);

//
// Delete the node list.
//
   delete this->children;
}


// =====================================================================
// This routine is called if the widget in the tree node is being
// deleted.
// =====================================================================
void
HalTreeNodeC::DoDestroy( Widget, HalTreeNodeC* node, XtPointer)
{
   if ( !node->deleting ) {
      delete node;
   }
}


// =====================================================================
// This routine will return a list of all the siblings of a node.
// =====================================================================
HalTreeNodeListC&
HalTreeNodeC::Siblings()
{
   static HalTreeNodeListC mySiblings;
   mySiblings.removeAll();
   if ( parent ) {
      mySiblings = *parent->children;
      mySiblings.remove(this);
   }
   return mySiblings;
}


// =====================================================================
// This routine will hide the siblings of the node.
// =====================================================================
void
HalTreeNodeC::HideSiblings()
{
   if ( parent ) {
      int count = parent->children->size();
      if ( count > 1 ) {
         tree->Defer(True);
         for ( register int i=0; i<count; i++ ) {
	    HalTreeNodeC	*sib = (*parent->children)[i];
            if ( sib != this ) sib->Hide();
         }
         tree->Defer(False);
      }
   }
}


// =====================================================================
// This routine is used to show all the nodes which have the same
// parent as this one.
// =====================================================================
void
HalTreeNodeC::ShowSiblings()
{
   if ( parent ) {
      int count = parent->NumChildren();

      if ( count > 1 ) {
         tree->Defer(True);
         for ( register int i=0; i<count; i++ ) {
	    HalTreeNodeC	*sib = (*parent->children)[i];
            if ( sib != this ) sib->Show();
         }
         tree->Defer(False);
      }
   }
}


// =====================================================================
// =====================================================================
void
HalTreeNodeC::DeleteChildren()
{
   HideChildren();

   for ( register int i=NumChildren()-1; i>=0; i--)
      delete (*children)[i];
}


// =====================================================================
// This sets the default line color for new nodes.
// =====================================================================
void
HalTreeNodeC::SetLineColor(Pixel color)
{
   if ( lineColor != color ) {
      lineColor = color;
   }
}


// =====================================================================
// This sets the default line etch color for new nodes.
// =====================================================================
void
HalTreeNodeC::SetLineEtchColor(Pixel color)
{
   if ( lineEtchColor != color ) {
      lineEtchColor = color;
   }
}


// =====================================================================
// This sets the default line type color for new nodes.
// =====================================================================
void
HalTreeNodeC::SetLineType(unsigned char line_type)
{
   if ( lineType != line_type ) {
      lineType = line_type;
   }
}


// =====================================================================
// This sets the default line width color for new nodes.
// =====================================================================
void
HalTreeNodeC::SetLineWidth(Dimension line_width)
{
   if ( lineWidth != line_width ) {
      lineWidth = line_width;
   }
}


// =====================================================================
// This sets the default line width color for new nodes.
// =====================================================================
char*
HalTreeNodeC::NodeName() const
{
   if ( widget ) {
      return(XtName(widget));
   }
   else {
      return ("");
   }
}

//=====================================================================
//
//=====================================================================
char*
HalTreeNodeC::DragString(XEvent*)
{
   return NodeName();
}


//=====================================================================
// This callback automatically updates the tree if the dimensions of
// the node if the widget changes sizes.
//=====================================================================
void
HalTreeNodeC::HandleResize(Widget, HalTreeNodeC *This, XEvent*, Boolean*)
{
   dprintf(("***** Entering HalTreeNodeC HandleResize *********\n"));
   int old_wd = This->wd;
   int old_ht = This->ht;

   This->CalculateSize();

   if ( old_wd != This->wd || old_ht != This->ht ) {
      This->tree->Draw(TRUE);
   }
   dprintf(("***** Leaving HalTreeNodeC HandleResize *********\n"));
}

int
HalTreeNodeC::NumChildren()
{
   if ( children )
      return children->size();
   else
      return 0;
}

int
HalTreeNodeC::compare(const HalTreeNodeC &node) const
{
  if (!compFunc) return 0;
  HalTreeNodeC *ta = (HalTreeNodeC*)this;
  HalTreeNodeC *tb = (HalTreeNodeC*)&node;
  return (*compFunc)(&ta, &tb);
}

// EOF
