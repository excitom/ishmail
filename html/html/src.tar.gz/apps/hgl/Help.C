/*
 * $Id: Help.C,v 1.1 1998/06/24 01:29:07 lang Exp $
 *
 * Copyright (c) 1992 HAL Computer Systems International, Ltd.
 * 
 *          HAL COMPUTER SYSTEMS INTERNATIONAL, LTD.
 *                  1315 Dell Avenue
 *                  Campbell, CA  95008
 *
 * Author: Greg Hilton
 * Contributors: Tom Lang, Frank Bieser, and others
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * http://www.gnu.org/copyleft/gpl.html
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#include <stdio.h>

// These two are needed only for getBoolean (see below)... 
#include <X11/IntrinsicP.h>
#include <X11/CoreP.h>

#include <Xm/Text.h>
#include <Xm/MessageB.h>
#include <Xm/Form.h>
#include <Xm/PushB.h>
#include <Xm/List.h>
#include <Xm/Label.h>
#include <Xm/ScrollBar.h>

#include "Help.h"

#ifdef OLIAS
#include "hgl/olias.h"
#endif

#define NULL_HELPCARD "__HaL__DefaultHelpcard__"

#if 0
typedef struct _helpcardResourceValues {
  String helpcard;
} helpcardResourceValues;

static XtResource helpcardResources[] = {
  {
    "helpcard",
    "Helpcard",
    XtRString, sizeof( String ),
    XtOffsetOf( helpcardResourceValues, helpcard ),
    XtRString, NULL_HELPCARD
  }
};
#endif

Help::Help() {};

#ifdef HELP_PREVIEW
Help::Help( const char *yourAppName, const Widget yourAppShell,
	    const char *helpdbfilename )
{
  init( yourAppName, yourAppShell, helpdbfilename );
}
#else
Help::Help( const char *yourAppName, const Widget yourAppShell,
	    const XrmDatabase db )
{
  init( yourAppName, yourAppShell, db );
}
#endif

Help::~Help()
{
  for( int i = 0; i < _dbCount; i++ ) {
    delete _db[ i ];
  }
  delete []_db;
//  cout << "deleting help object" << endl;
}

void Help::helpcardCB( Widget w, XtPointer clientData, XtPointer )
{
  ( ( Help * )clientData )->displayHelpcard( w );
}

int Help::iconifyHelpDialog()
{
//  cout << "Trying to iconify help dialog..." << endl;

  Widget dialogShell = XtParent( _helpDialog );
  if ( ! XIconifyWindow( XtDisplay( dialogShell ), XtWindow( dialogShell ),
			 XScreenNumberOfScreen( XtScreen( dialogShell ) ) ) ) {
    cerr << "Your window manager does not accept the WM_CHANGE_STATE property."
	 << endl;
    return 0;
  }

  return 1;
}

// Callback for Help Dialog action buttons.
void Help::helpDialogCB( const Widget w, const Help *help,
			 const XmAnyCallbackStruct *cbs )
{
#ifdef OLIAS
  static OliasDisplayEvent event;
  int status;
#endif

  switch( cbs->reason ) {
    case XmCR_OK:
#ifdef hal_demo
      exit( 1 );
#else
      XtUnmanageChild( w );
#endif
      break;
    case XmCR_CANCEL:  // OLIAS...
//      cout << "Locator: " << help->_locator << endl;
#ifdef OLIAS
      event.type = OLIAS_DISPLAY_EVENT;
/*
      char *env = getenv( "OLIAS_INFOBASE" );
      if( env && *env )
	event.infobase = env;
      else {
	cout << "Your 'OLIAS_INFOBASE' env variable is not set." << endl
	     << "Defaulting to 'baseD'." << endl;
*/
// As of A16, 'infobase' isn't needed, but still has to be set...
	event.infobase = "baseD";
/*
      }
*/
      event.locator = ( char * )( help->_locator );
      status = olias_send_event( XtParent( w ), ( OliasEvent * )&event );
      if( status != OLIAS_SUCCESS ) {
 	cerr << "Error trying to display OLIAS.  Status=" << status << endl;
	help->displayErrorMsg( NULL, NULL );
      }
#endif
      break;
    case XmCR_HELP:
      XtManageChild( help->_helpHelpDialog );
      break;
    default:
      cerr << "Bad reason in helpDialogCB" << endl;
    }
}

// Callback for Help Index Dialog action buttons.
void Help::indexDialogCB( const Widget w, const Help *help,
			  const XmAnyCallbackStruct *cbs )
{
  switch( cbs->reason ) {
    case XmCR_OK:
      XtUnmanageChild( w );
      break;
    case XmCR_HELP:
      XtManageChild( help->_indexHelpDialog );
      break;
    default:
      cerr << "Bad reason in indexDialogCB" << endl;
    }
}

// Callback for Help Index Dialog View button.
void Help::indexViewCB( const Widget, Help *help,
			const XmPushButtonCallbackStruct *cbs )
{
  int *pos_list, pos;
  
  switch( cbs->reason ) {
    case XmCR_ACTIVATE:
      XmListGetSelectedPos( help->_indexScrollList, &pos_list, &pos );
      help->showDialog( help->_db[ 0 ]->titlesCards()[ *pos_list - 1 ] );
      delete pos_list;
      break;
    default:
      cerr << "Bad reason in indexViewCB" << endl;
    }
}

// Callback for Help Index Dialog Next button.
void Help::indexNextCB( const Widget, Help *help,
			const XmPushButtonCallbackStruct *cbs )
{
  int *pos_list, pos;
  register int n, vcount, middle;
  Arg args[ 1 ];
  
  switch( cbs->reason ) {
    case XmCR_ACTIVATE:
      XmListGetSelectedPos( help->_indexScrollList, &pos_list, &pos );
      XmListSelectPos( help->_indexScrollList, *pos_list + 1, True );
      help->showDialog( help->_db[ 0 ]->titlesCards()[ *pos_list ] );
      // Now, scroll if necessary...
      n = vcount = 0;
      XtSetArg( args[ n ], XmNvisibleItemCount, &vcount ); n++;
      XtGetValues( help->_indexScrollList, args, n );
      middle = vcount / 2;
      if( ( ( *pos_list + 1 ) > middle ) &&
	  ( ( *pos_list + middle ) <= help->_db[ 0 ]->numHelpcards() ) ) {
        XmListSetBottomPos( help->_indexScrollList, *pos_list + middle + 1 );
      }
      delete pos_list;
      break;
    default:
      cerr << "Bad reason in indexViewCB" << endl;
    }
}

// Callback for Help Index Dialog Prev button.
void Help::indexPrevCB( const Widget, Help *help,
			const XmPushButtonCallbackStruct *cbs )
{
  int *pos_list, pos;
  register int n, vcount, middle;
  Arg args[ 1 ];
  
  switch( cbs->reason ) {
    case XmCR_ACTIVATE:
      XmListGetSelectedPos( help->_indexScrollList, &pos_list, &pos );
      XmListSelectPos( help->_indexScrollList, *pos_list - 1, True );
      help->showDialog( help->_db[ 0 ]->titlesCards()[ *pos_list - 2 ] );
      // Now, scroll if necessary...
      n = vcount = 0;
      XtSetArg( args[ n ], XmNvisibleItemCount, &vcount ); n++;
      XtGetValues( help->_indexScrollList, args, n );
      middle = vcount / 2;
      if( ( ( *pos_list - 1 ) > middle ) &&
	  ( ( *pos_list - 1 + middle ) < help->_db[ 0 ]->numHelpcards() ) ) {
        XmListSetPos( help->_indexScrollList, *pos_list - middle - 1 );
      }
      delete pos_list;
      break;
    default:
      cerr << "Bad reason in indexViewCB" << endl;
    }
}

void Help::displayHelpIndex()
{
  XtManageChild( _indexDialog );
  XmListSelectPos( _indexScrollList, 1, False );
//  showDialog( _db[ 0 ]->titlesCards()[ 0 ] );
}

// Callback for help index scroll list.
void Help::indexScrollListCB( const Widget, Help *help,
			      const XmListCallbackStruct *cbs )
{
  XtSetSensitive( help->_indexView, True );
  switch( cbs->reason ) {
    case XmCR_BROWSE_SELECT:
      if( cbs->item_position > 1 )
	XtSetSensitive( help->_indexPrev, True );
      else
	XtSetSensitive( help->_indexPrev, False );
      if( cbs->item_position < help->_db[ 0 ]->numHelpcards() )
	XtSetSensitive( help->_indexNext, True );
      else
	XtSetSensitive( help->_indexNext, False );
      break;
    case XmCR_DEFAULT_ACTION:
//      cout << "Item position: " << cbs->item_position << endl;
//      char *ret;
//      XmStringGetLtoR( cbs->item, XmFONTLIST_DEFAULT_TAG, &ret );
//      cout << "Item: " << ret << endl;
//      help->showDialog( ret );
      help->showDialog( help->_db[ 0 ]->
			titlesCards()[ ( cbs->item_position ) - 1 ] );
      break;
    default:
      cerr << "Bad reason in indexScrollListCB." << endl;
    }
}

#ifdef HELP_PREVIEW
int Help::init( const char *yourAppName, const Widget yourAppShell,
		const char *helpdbfilename )
#else
int Help::init( const char *yourAppName, const Widget yourAppShell,
		const XrmDatabase db )
#endif
{
  Arg args[ 15 ];
  register int n;

  _appShell = yourAppShell;

  _helpDialog = _text = _title = NULL;
  _indexDialog = _indexScrollList = NULL;
  _indexView = _indexNext = _indexPrev = NULL;
  _helpHelpDialog = _indexHelpDialog = NULL;
  _errorDialog = NULL;
  _returnStatus = 1;

  _firstTime = True;
#ifndef HELP_PREVIEW
  _appXrmDb = db;
#endif
  _dbCount = 0;

  Display *display = XtDisplay( yourAppShell );

#ifdef FISH
//
  // Need to test yourAppName, yourAppShell !! 
  // If db is NULL, we can get by...
// 

#ifdef HELP_PREVIEW
  _dbCount = 1;
  _db = new Db*[ _dbCount ];
  _db[ 0 ] = new Db;
  if( ! _db[ 0 ]->openFile( helpdbfilename, yourAppName, display ) ) {
    _returnStatus = 0;
    return( _returnStatus );
  }
#else
  char *defaultHelpDbFilename = ( char * )XtMalloc( strlen( yourAppName ) +
						    strlen( ".hlp" ) + 1 );
  sprintf( defaultHelpDbFilename, "%s.hlp", yourAppName );
  if ( _appXrmDb ) {
    char *type;
    XrmValue value;
    char *tmp = ( char * )XtMalloc( strlen( yourAppName ) +
				    strlen( ".helpcardDbFiles" ) + 1 );
    sprintf( tmp, "%s.helpcardDbFiles", yourAppName );
    if( XrmGetResource( _appXrmDb, tmp, tmp, &type, &value ) ) {
      if( *( value.addr ) == '\0' ) {
#if 0
	cout << "Your '.helpcardDbFiles:' resource is empty.  Using '"
	     << defaultHelpDbFilename
	     << "' for the name of your HelpCard database file." << endl;
#endif
	_dbCount = 1;
	_db = new Db*[ _dbCount ];
	_db[ 0 ] = new Db;
	return( _returnStatus = _db[ 0 ]->openFile( defaultHelpDbFilename,
						    yourAppName, display ) );
      } else {
// 	cout << "helpcardDbFiles = " << value.addr << endl;
	char *files = ( char * )XtMalloc( strlen( value.addr ) + 1 );
	strcpy( files, value.addr );
	char *file = strtok( files, " " );
// 	cout << "files = " << files << endl;
// 	cout << "first file = " << file << endl;
	_dbCount++;
	while( True ) {
	  file = strtok( NULL, " " );
	  if( file == NULL )
	    break;
// 	  cout << "files = " << files << endl;
// 	  cout << "another file = " << file << endl;
	  _dbCount++;
	}
	_db = new Db*[ _dbCount ];
	strcpy( files, value.addr );
	file = strtok( files, " " );
// 	cout << "files = " << files << endl;
// 	cout << "first file = " << file << endl;
	_db[ 0 ] = new Db;
	int retCode = _db[ 0 ]->openFile( file, yourAppName, display );
	for( n = 1; n < _dbCount; n++ ) {
	  file = strtok( NULL, " " );
// 	  cout << "files = " << files << endl;
// 	  cout << "another file = " file << endl;
	  _db[ n ] = new Db;
	  retCode = _db[ n ]->openFile( file, yourAppName, display );
	}
	XtFree( files );
	if( ! retCode ) {
	  XtFree( tmp );
	  _returnStatus = 0;
	  return( _returnStatus );
	}
      }
    } else {
      cout << "Your '.helpcardDbFiles:' resource is missing.  Using '"
	   << defaultHelpDbFilename
	   << "' for the name of your HelpCard database file." << endl;
      _dbCount = 1;
      _db = new Db*[ _dbCount ];
      _db[ 0 ] = new Db;
      return( _returnStatus = _db[ 0 ]->openFile( defaultHelpDbFilename,
						  yourAppName, display ) );
    }
    XtFree( tmp );
  } else {
    cout << "You called Help::init with a NULL resource database." << endl
	 << "Thus, there is no way to read your '.helpcardDbFiles:' resource."
	 << endl << "Using '" << defaultHelpDbFilename
	 << "' for the name of your HelpCard database file." << endl;
    _dbCount = 1;
    _db = new Db*[ _dbCount ];
    _db[ 0 ] = new Db;
    return( _returnStatus = _db[ 0 ]->openFile( defaultHelpDbFilename,
						yourAppName, display ) );
  }

  XtFree( defaultHelpDbFilename );

#endif

#else // NOT FISH

   char	*defname = new char[strlen(yourAppName) + strlen(".hlp") + 1];
   sprintf(defname, "%s.hlp", yourAppName);

//
// Look up helpcardDbFiles resource
//
   XtResource	res;
   res.resource_name   = (String)"helpcardDbFiles";
   res.resource_class  = XtCString;
   res.resource_type   = XtRString;
   res.resource_size   = sizeof(String);
   res.resource_offset = 0;
   res.default_type    = XtRString;
   res.default_addr    = (XtPointer)defname;

   String       string;
   XtGetApplicationResources(yourAppShell, &string, &res, 1, NULL, 0);
   // cout <<"helpcardDbFiles: " <<string <<endl;

   char	*files = new char[strlen(string)+1];

//
// Count the number of databases
//
   strcpy(files, string);
   char	*start = files;
   char	*file = strtok(start, " ");
   while (file) {
      start = NULL;
      _dbCount++;
      file = strtok(start, " ");
   }

   int	openCount = 0;
   if ( _dbCount > 0 ) {

//
// Allocate the databases
//
      _db = new Db*[_dbCount];

//
// Loop for each database
//
      strcpy(files, string);
      start = files;
      file = strtok(start, " ");
      int	index = 0;
      while (file) {

	 start = NULL;
	 _db[index] = new Db;
	 // cout <<"Database file: " <<file <<endl;

	 if ( _db[index]->openFile(file, yourAppName, display) )
	    openCount++;
	 // else
	    // cout <<"Couldn't open: " <<file <<endl;

	 index++;
	 file = strtok(start, " ");
      }

   } // End if any file names

   delete files;

   if (!openCount) _returnStatus = 0;
   if (!_returnStatus) return(0);

#endif
  
  n = 0;
  XtSetArg( args[ n ], XmNautoUnmanage, False );  n++;
  XtSetArg( args[ n ], XmNdefaultPosition, False );  n++;
  XtSetArg( args[ n ], XmNtransient, False );  n++;
  _helpDialog = XmCreateTemplateDialog( _appShell, "helpcard", args, n );
  
  XtAddCallback( _helpDialog, XmNokCallback,
		( XtCallbackProc )helpDialogCB, this );
  XtAddCallback( _helpDialog, XmNcancelCallback,
		( XtCallbackProc )helpDialogCB, this );
  XtAddCallback( _helpDialog, XmNhelpCallback,
		( XtCallbackProc )helpDialogCB, this );

  Widget form;

  n = 0;
  form = XmCreateForm( _helpDialog, "helpForm", args, n );
  XtManageChild( form );

  n = 0;
  XtSetArg( args[ n ], XmNtopAttachment, XmATTACH_FORM );  n++;
  XtSetArg( args[ n ], XmNleftAttachment, XmATTACH_FORM );  n++;
  Widget label = XmCreateLabel( form, "helpCardTitleLabel", args, n );
  XtManageChild( label );

  n = 0;
  XtSetArg( args[ n ], XmNtopAttachment, XmATTACH_FORM );  n++;
  XtSetArg( args[ n ], XmNleftAttachment, XmATTACH_WIDGET );  n++;
  XtSetArg( args[ n ], XmNleftWidget, label );  n++;
  XtSetArg( args[ n ], XmNleftOffset, 10 );  n++;
//  XtSetArg( args[ n ], XmNrightAttachment, XmATTACH_FORM );  n++;
  _title = XmCreateLabel( form, "helpCardTitle", args, n );
  XtManageChild( _title );
  
  n = 0;
  XtSetArg( args[ n ], XmNtopAttachment, XmATTACH_WIDGET );  n++;
  XtSetArg( args[ n ], XmNtopWidget, _title );  n++;
  XtSetArg( args[ n ], XmNtopOffset, 10 );  n++;
  XtSetArg( args[ n ], XmNleftAttachment, XmATTACH_FORM );  n++;
  XtSetArg( args[ n ], XmNrightAttachment, XmATTACH_FORM );  n++;
  XtSetArg( args[ n ], XmNbottomAttachment, XmATTACH_FORM );  n++;
  XtSetArg( args[ n ], XmNeditMode, XmMULTI_LINE_EDIT );  n++;
  XtSetArg( args[ n ], XmNeditable, False );  n++;
  XtSetArg( args[ n ], XmNscrollHorizontal, False );  n++;
  XtSetArg( args[ n ], XmNcursorPositionVisible, False );  n++;
  _text = XmCreateScrolledText( form, "helpText", args, n );
  XtManageChild(_text);

  n = 0;
  XtSetArg( args[ n ], XmNautoUnmanage, False );  n++;
  XtSetArg( args[ n ], XmNdefaultPosition, False );  n++;
  XtSetArg( args[ n ], XmNtransient, False );  n++;
  _indexDialog = XmCreateTemplateDialog( _appShell, "helpIndex", args, n );
  
  XtAddCallback( _indexDialog, XmNokCallback, ( XtCallbackProc )indexDialogCB,
		 ( XtPointer )this );
//  XtAddCallback( _indexDialog, XmNcancelCallback,
// 		 ( XtCallbackProc )indexDialogCB, ( XtPointer )this );
  XtAddCallback( _indexDialog, XmNhelpCallback,
		 ( XtCallbackProc )indexDialogCB, ( XtPointer )this );

#ifdef AIX
  Widget cancelWid = XmMessageBoxGetChild(_indexDialog, 
			XmDIALOG_CANCEL_BUTTON);
  if (cancelWid) {
    XtUnmanageChild(cancelWid);
  }
#endif
    
  n = 0;
//  XtSetArg( args[ n ], XmN, );  n++;
  form = XmCreateForm( _indexDialog, "indexForm", args, n );
  XtManageChild( form );

  register int total = _db[ 0 ]->numHelpcards();
  XmStringTable xm_strings =
    ( XmStringTable )XtMalloc( total * sizeof( XmString ) );
  for( register int m = 0; m < _db[ 0 ]->numHelpcards(); m++ ) {
    xm_strings[ m ] = XmStringCreateLocalized( _db[ 0 ]->titles()[ m ] );
  }
  
  n = 0;
  XtSetArg( args[ n ], XmNtopAttachment, XmATTACH_FORM );  n++;
  XtSetArg( args[ n ], XmNleftAttachment, XmATTACH_FORM );  n++;
//  XtSetArg( args[ n ], XmNrightAttachment, XmATTACH_POSITION );  n++;
//  XtSetArg( args[ n ], XmNrightPosition, 90 );  n++;
  XtSetArg( args[ n ], XmNbottomAttachment, XmATTACH_FORM );  n++;
  XtSetArg( args[ n ], XmNitemCount, total );  n++;
  XtSetArg( args[ n ], XmNitems, xm_strings );  n++;
  _indexScrollList = XmCreateScrolledList( form, "indexScrollList", args, n );
  XtManageChild( _indexScrollList );
  XtAddCallback( _indexScrollList, XmNdefaultActionCallback,
		 ( XtCallbackProc )indexScrollListCB, ( XtPointer )this );
  XtAddCallback( _indexScrollList, XmNbrowseSelectionCallback,
		 ( XtCallbackProc )indexScrollListCB, ( XtPointer )this );

  for( n = 0; n < total; n++ ) {
    XmStringFree( xm_strings[ n ] );
  }
  XmStringFree( ( XmString )xm_strings );
    
  n = 0;
/*
  XtSetArg( args[ n ], XmNtopAttachment, XmATTACH_FORM );  n++;
  XtSetArg( args[ n ], XmNleftAttachment, XmATTACH_POSITION );  n++;
  XtSetArg( args[ n ], XmNleftPosition, 90 );  n++;
  XtSetArg( args[ n ], XmNrightAttachment, XmATTACH_FORM );  n++;
  XtSetArg( args[ n ], XmNbottomAttachment, XmATTACH_POSITION );  n++;
  XtSetArg( args[ n ], XmNbottomPosition, 33 );  n++;
*/
  _indexView = XmCreatePushButton( form, "indexView", args, n );
  XtManageChild( _indexView );
  XtAddCallback( _indexView, XmNactivateCallback,
		 ( XtCallbackProc )indexViewCB, ( XtPointer )this );
  n = 0;
/*
  XtSetArg( args[ n ], XmNtopAttachment, XmATTACH_WIDGET );  n++;
  XtSetArg( args[ n ], XmNtopWidget, _indexView );  n++;
  XtSetArg( args[ n ], XmNleftAttachment, XmATTACH_WIDGET );  n++;
  XtSetArg( args[ n ], XmNleftWidget, _indexScrollList );  n++;
  XtSetArg( args[ n ], XmNrightAttachment, XmATTACH_FORM );  n++;
  XtSetArg( args[ n ], XmNbottomAttachment, XmATTACH_POSITION );  n++;
  XtSetArg( args[ n ], XmNbottomPosition, 66 );  n++;
*/
  _indexNext = XmCreatePushButton( form, "indexNext", args, n );
  XtManageChild( _indexNext );
  XtAddCallback( _indexNext, XmNactivateCallback,
		 ( XtCallbackProc )indexNextCB, ( XtPointer )this );
  n = 0;
/*
  XtSetArg( args[ n ], XmNtopAttachment, XmATTACH_WIDGET );  n++;
  XtSetArg( args[ n ], XmNtopWidget, _indexNext );  n++;
  XtSetArg( args[ n ], XmNleftAttachment, XmATTACH_WIDGET );  n++;
  XtSetArg( args[ n ], XmNleftWidget, _indexScrollList );  n++;
  XtSetArg( args[ n ], XmNrightAttachment, XmATTACH_FORM );  n++;
  XtSetArg( args[ n ], XmNbottomAttachment, XmATTACH_POSITION );  n++;
  XtSetArg( args[ n ], XmNbottomPosition, 99 );  n++;
*/
  _indexPrev = XmCreatePushButton( form, "indexPrev", args, n );
  XtManageChild( _indexPrev );
  XtAddCallback( _indexPrev, XmNactivateCallback,
		 ( XtCallbackProc )indexPrevCB, ( XtPointer )this );

  XtSetSensitive( _indexPrev, False );
  
  // Create a Motif Info Dialog to use for the Help Dialog's "Help" button.
  n = 0;
  _helpHelpDialog = XmCreateInformationDialog( _helpDialog, "helpHelpDialog",
					       args, n );
  XtUnmanageChild( XmMessageBoxGetChild( _helpHelpDialog,
					 XmDIALOG_CANCEL_BUTTON ) );
  XtUnmanageChild( XmMessageBoxGetChild( _helpHelpDialog,
					 XmDIALOG_HELP_BUTTON ) );

  // Create a Motif Info Dialog to use for the Index Dialog's "Help" button.
  n = 0;
  _indexHelpDialog = XmCreateInformationDialog( _indexDialog,
						"indexHelpDialog", args, n );
  XtUnmanageChild( XmMessageBoxGetChild( _indexHelpDialog,
					 XmDIALOG_CANCEL_BUTTON ) );
  XtUnmanageChild( XmMessageBoxGetChild( _indexHelpDialog,
					 XmDIALOG_HELP_BUTTON ) );

  // Create an error dialog to use for handling errors...
  n = 0;
  XtSetArg( args[ n ], XmNdialogStyle, XmDIALOG_FULL_APPLICATION_MODAL );  n++;
  _errorDialog = XmCreateErrorDialog( _helpDialog, "helpErrorDialog", args, n);
  XtUnmanageChild( XmMessageBoxGetChild( _errorDialog,
					 XmDIALOG_CANCEL_BUTTON ) );
  // Remove this if we want a Help button... 
  XtUnmanageChild( XmMessageBoxGetChild( _errorDialog, XmDIALOG_HELP_BUTTON ));
  // Add this if HaL decides to have a Help button on Error dialogs... 
//  XtAddCallback( _errorDialog, XmNhelpCallback, errorDialogCB, this );

  return( _returnStatus );
}

/*
typedef struct _helpcardResourceValues {
  String helpcard;
} helpcardResourceValues;

static XtResource helpcardResources[] = {
  {
    "helpcard",
    "Helpcard",
    XtRString, sizeof( String ),
    XtOffsetOf( helpcardResourceValues, helpcard ),
    XtRString, NULL_HELPCARD
  }
};
*/

char *Help::findHelpcard( const Widget w, const char *resourceName )
{
   XtResource	res;
   res.resource_name   = (resourceName ? (String)resourceName : "helpcard");
   res.resource_class  = XtCString;
   res.resource_type   = XtRString;
   res.resource_size   = sizeof(String);
   res.resource_offset = 0;
   res.default_type    = XtRString;
   res.default_addr    = NULL_HELPCARD;

   char		*wname = XtName(w);	// Just for gdb
   String	string;
   XtGetApplicationResources(w, &string, &res, 1, NULL, 0);

   if ( strcmp(string, NULL_HELPCARD)==0 ) {	// Not found

      if ( XtParent(w) != NULL )
	 return findHelpcard(XtParent(w), resourceName);
      else
	 return NULL;

   } else {
      return string;
   }

#if 0
  helpcardResourceValues hrv;

  char	*wname = XtName(w);
  if( resourceName ) {
    helpcardResources[0].resource_name = ( char * )resourceName;
    helpcardResources[0].resource_class = ( char * )resourceName;
  }
  XtGetApplicationResources( w, &hrv,
			    helpcardResources, XtNumber( helpcardResources ),
			    NULL, 0 );
//  cout << "helpcard: " << hrv.helpcard << endl;

  // If did not find one, try ancestors... 
  if( ! strcmp( hrv.helpcard, NULL_HELPCARD ) ) {
    if( XtParent( w ) != NULL ) {
//      cout << "Trying parent..." << endl;
      findHelpcard( XtParent( w ), resourceName );
    } else
      return( NULL );
  } else {
//    cout << hrv.helpcard << endl;
    char *card = ( char * )XtMalloc( strlen( hrv.helpcard ) + 1 );
    strcpy( card, hrv.helpcard );
    return( card );
  }
#endif
  
}

//**********************************************************
//
// removeOliasButton
//
//**********************************************************
void Help::removeOliasButton()
{
  Arg args[ 1 ];
  int n;

//
// get the Olias button and remove it from the dialog, if there is one.
//
  if ( _helpDialog ) {
    XtUnmanageChild( XmMessageBoxGetChild(_helpDialog, XmDIALOG_CANCEL_BUTTON) );
  }

//
// fix up the text in the help on help dialog, if there is one.
//
  if ( _helpHelpDialog ) {
    String title= "Press the \"OK\" button if you want to close the Help Dialog.";
    XmString helpHelpString = XmStringCreateLocalized( title );
    n = 0;
    XtSetArg( args[ n ], XmNmessageString, helpHelpString );  n++;
    XtSetValues( _helpHelpDialog, args, n );
    XmStringFree( helpHelpString );
  }
}

int Help::displayHelpcard( const Widget w, const char *resourceName )
{
  if( ! w ) {
    //cout << "Help::displayHelpcard called with NULL" << endl;
    return( 0 );
  }

  char *helpcard = NULL;
  
  // Recursively look for a helpcard... 
  if( helpcard = findHelpcard( w, resourceName ) ) {
//    cout << helpcard << endl;
    int status = showDialog( helpcard );
    return( status );
  } else {
// Changed from cerr to cout due to OLIAS bug #11369.  KJF
    //cout << "No helpcard to display for widget: " << XtName( w ) << endl;
    XmTextSetString(_text, "No helpcard available for widget: ");
    XmTextInsert(_text, XmTextGetLastPosition(_text), XtName(w));
    XtManageChild(_helpDialog);
    XMapRaised(XtDisplay(_helpDialog), XtWindow(XtParent(_helpDialog)));
    return( 0 );
  }
}

int Help::displayHelpcard( const char *helpcardResourceString )
{
  if ( _appXrmDb ) {
    char *type;
    XrmValue value;
    
    if( XrmGetResource( _appXrmDb, helpcardResourceString,
			helpcardResourceString, &type, &value ) ) {
//      cout << "Value of helpcard resource '" << helpcardResourceString
// 	   << "' is: " << value.addr << endl;
      return( showDialog( value.addr ) );
    } else {
      cout << "Error in function 'displayHelpcard', specified resource '"
	   << helpcardResourceString << "' does not exist." << endl;
      return( 0 );
    }
  } else {
    cout << "Error using function 'displayHelpcard', no Xrm database." << endl;
    return( 0 );
  }
}

/*---------------------------------------------------------------
 *  Return the value of a boolean custom resource
 *
 * KJF: Borrowed from hgl/src/rsrc.[Ch] so libhelp.a would NOT be
 *      dependent on libhgl.a, then I renamed it from get_boolean
 *      to getBoolean just to be safe...
 *
 */

static Boolean
getBoolean(Widget w, const char *rsrc, Boolean def)
{
   String	wname  = XtName(w);
   String	wclass = (XtClass(w))->core_class.class_name;

   XtResource	res;
   res.resource_name   = (String)rsrc;
   res.resource_class  = XtCBoolean;
   res.resource_type   = XtRBoolean;
   res.resource_size   = sizeof(Boolean);
   res.resource_offset = 0;
   res.default_type    = XtRBoolean;
   res.default_addr    = (XtPointer)&def;

   Boolean	value;
   XtGetSubresources(w, &value, wname, wclass, &res, 1, NULL, 0);
   return value;

} // End getBoolean

// !! 'w' is not currently being used !! 
int Help::showDialog( const char *cardName, const Widget /* w */ )
{
  register int n;
  Window root, child;
  int rootX, rootY, winX, winY;
  unsigned int keys_buttons;
  Arg args[ 10 ];
  char *textBuf, title[ 81 ];
  
// Not a very good test?!?!?
  if ( strcmp( cardName, NULL_HELPCARD ) ) {
    for( n = 0; n < _dbCount; n++ ) {
      if( _db[ n ]->getCard( cardName, &_locator, title, &textBuf ) )
	break;
    }
    //if( textBuf == NULL )
      //cout << "Helpcard not found in any of the database files." << endl;
// I don't think this can ever happend any more... 
// Besides, 'w' isn't even needed by this function!! 
  } else {
    textBuf = NULL;
//    cerr << "No 'helpcard' resource specified for widget: " << XtName( w )
// 	 << endl;
  }

//  cout << "textBuf: " << textBuf << endl;
  
  if ( textBuf == NULL ) {
    //cout << "No help for specified widget." << endl;
    XmTextSetString(_text, "No helpcard available.");
    //return( 0 );
  } else {
    XmTextSetString( _text, textBuf );
    XtFree( textBuf );
    XmString xm_title = XmStringCreateLocalized( title );
    n = 0;
    XtSetArg( args[ n ], XmNlabelString, xm_title );  n++;
    XtSetValues( _title, args, n );
    XmStringFree( xm_title );
  }
  
  XtManageChild( _helpDialog );
#ifdef HELP_PREVIEW
  XtManageChild( _indexDialog );
#endif
  
// The first time it's displayed, we'll position it at the cursor.
// Otherwise, leave it where the user ( may have ) moved it to...
//  if ( ( _firstTime == True ) && ( w != NULL ) ) {
#ifndef hal_demo
  if ( ( _firstTime == True ) &&
       ( ! getBoolean( _appShell, "interactivePlacement", False ) ) ) {
    _firstTime = False;
//   XmUpdateDisplay( _helpDialog );
    
    // Careful: use 'w' or '_helpDialog' ??  'w' will surely be mapped !
    // XtWindow( _helpDialog ) might fail... ??
//    XQueryPointer( XtDisplay( w ), XtWindow( w ), &root, &child,
    XQueryPointer( XtDisplay( _appShell ), XtWindow( _appShell ), &root,
		   &child, &rootX, &rootY, &winX, &winY, &keys_buttons );

//    printf( "rootX, rootY, winX, winY = %d, %d, %d, %d\n",
//	   rootX, rootY, winX, winY );

    // Don't allow help dialog to be mostly off screen.
    // This is kind-of a kludge...
    if( rootX > 600 )
      rootX = 512;

    n = 0;
    XtSetArg( args[ n ], XmNx, rootX );  n++;
    XtSetArg( args[ n ], XmNy, rootY );  n++;
    XtSetValues( _helpDialog, args, n );
  }
#endif

  // Raise it to the top, in case it got buried.
  XMapRaised( XtDisplay( XtParent( _helpDialog ) ),
	      XtWindow( XtParent( _helpDialog ) ) );

  return( 1 );
}

// Callback for error dialog.
static void errorDialogCB( Widget, XtPointer clientData, XtPointer callData )
{
  XmAnyCallbackStruct *cbs = ( XmAnyCallbackStruct * )callData;

  Help *help = ( Help * )clientData;

  switch( cbs->reason ) {
    case XmCR_HELP:
// ?? 
      break;
    default:
      cerr << "Bad reason in errorDialogCB." << endl;
    }
}

void Help::displayErrorMsg( const char * /*msg*/,
			    const char * /*helpcardName*/ ) const
{
  XtManageChild( _errorDialog );
}
