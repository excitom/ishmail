/*
 * $Id: TreeLayoutC.h,v 1.1 1998/06/24 01:29:07 lang Exp $
 *
 * Copyright (c) 1993 HAL Computer Systems International, Ltd.
 * 
 *          HAL COMPUTER SYSTEMS INTERNATIONAL, LTD.
 *                  1315 Dell Avenue
 *                  Campbell, CA  95008
 *
 * Author: Greg Hilton
 * Contributors: Tom Lang, Frank Bieser, and others
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * http://www.gnu.org/copyleft/gpl.html
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#ifndef _TreeLayoutC_h_
#define _TreeLayoutC_h_

#include <X11/Xlib.h>
#include <Xm/Xm.h>
#include "LayoutC.h"

class HalTreeNodeC;
class LayoutC;

// =====================================================================
class TreeLayoutC : public LayoutC
{
//
// The private parts.
//
   private:
      LayoutDirT	layoutDir;
      Boolean		stepMode;
      Boolean		lineBreak;
      Boolean		compressed;
      int		compressOffset;
      int*              compressBounds;     // running level position.
      int*              depthBounds;        // pixel area for each levels
      int	        depthBoundsCnt;     // pixel area for each levels
      int               numLevels;          // number of levels in tree.

//
// The private methods.
//
   private:
      void	ArrangeSubTree(HalTreeNodeC*, int, int, int);
      void	ComputeNodeRegion(HalTreeNodeC*, int);
      void	Draw(HalTreeNodeC*, int);
      void	InitDimensions(int);
      void	PositionNode (HalTreeNodeC*, int);
      void	CompressNode (HalTreeNodeC*, int*, int);
      void	CompressTree ();

//
// The constructors & destructor.
//
   public:
      TreeLayoutC(HalTreeC*, char* name = "treeLayout");
     ~TreeLayoutC();

//
// The public methods.
//
   public:
      void            Draw();
      void            Redraw();
      void	      SetLayoutDir(LayoutDirT);
      void            SetLineBreak(Boolean);
      void            SetStepMode(Boolean);
      void            SetCompressed(Boolean);
      inline int      IsHorizontal() { return(layoutDir == LEFT_TO_RIGHT ||
				              layoutDir == RIGHT_TO_LEFT); }

      MEMBER_QUERY ( LayoutDirT,	LayoutDir, 	    layoutDir);
      MEMBER_QUERY ( Boolean,		LineBreak, 	    lineBreak);
      MEMBER_QUERY ( Boolean,		StepMode, 	    stepMode);
      MEMBER_QUERY ( Boolean,		Compressed, 	    compressed);
};

#endif
