/*
 * $Id: FormatModC.C,v 1.1 1998/06/24 01:29:07 lang Exp $
 *
 * Copyright (c) 1992 HAL Computer Systems International, Ltd.
 * 
 *          HAL COMPUTER SYSTEMS INTERNATIONAL, LTD.
 *                  1315 Dell Avenue
 *                  Campbell, CA  95008
 *
 * Author: Greg Hilton
 * Contributors: Tom Lang, Frank Bieser, and others
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * http://www.gnu.org/copyleft/gpl.html
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#include "FormatModC.h"
#include "rsrc.h"
#include "WArgList.h"
#include "StringC.h"

#include <Xm/Form.h>
#include <Xm/Frame.h>
#include <Xm/Label.h>
#include <Xm/RowColumn.h>
#include <Xm/TextF.h>
#include <Xm/ToggleB.h>

/*----------------------------------------------------------------------
 * Method to build the format form
 */

FormatModC::FormatModC(Widget parent, const char *name, ArgList argv,
		       Cardinal argc)
{
   WArgList	args;

//
// Create widget hierarchy
//
//   form
//	Label		label
//	Frame		frame
//	TextField	precisTF
//	Label		precisLabel
//
   form = XmCreateForm(parent, (char *)name, argv, argc);

   int	ltOffset = get_int("FormatModC", form, "labelTextOffset", 0);

   StringC	wname = "formatModLabel";
   label = XmCreateLabel(form, wname, 0,0);

   Dimension	wd;
   XtVaGetValues(label, XmNwidth, &wd, NULL);

   wname = "formatModFrame";
   args.Reset();
   args.LeftAttachment(XmATTACH_FORM, wd + ltOffset);
   frame = XmCreateFrame(form, wname, ARGS);

   args.Reset();
   args.TopAttachment(XmATTACH_OPPOSITE_WIDGET, frame);
   args.BottomAttachment(XmATTACH_OPPOSITE_WIDGET, frame);
   args.RightAttachment(XmATTACH_WIDGET, frame, ltOffset);
   XtSetValues(label, ARGS);

   wname = "formatModPrecisTF";
   args.Reset();
   args.LeftAttachment(XmATTACH_WIDGET, frame);
   precisTF = XmCreateTextField(form, wname, ARGS);

   wname = "formatModPrecisLabel";
   args.Reset();
   args.TopAttachment(XmATTACH_OPPOSITE_WIDGET, precisTF);
   args.BottomAttachment(XmATTACH_OPPOSITE_WIDGET, precisTF);
   args.LeftAttachment(XmATTACH_WIDGET, precisTF);
   precisLabel = XmCreateLabel(form, wname, ARGS);

//
// Create frame hierarchy
//
//   frame
//	RowColumn	radioBox
//
   wname = "formatModRadioBox";
   args.Reset();
   args.Orientation(XmHORIZONTAL);
   args.RadioBehavior(True);
   radioBox = XmCreateRowColumn(frame, wname, ARGS);

//
// Create radioBox hierarchy
//
//   radioBox
//	ToggleButton	intTB
//	ToggleButton	hexTB
//	ToggleButton	floatTB
//
   wname = "formatModIntTB";
   args.Reset();
   args.UserData((XtPointer)ValueC::INT);
   intTB	  = XmCreateToggleButton(radioBox, wname, ARGS);

   wname = "formatModHexTB";
   args.UserData((XtPointer)ValueC::HEX);
   hexTB	  = XmCreateToggleButton(radioBox, wname, ARGS);

   wname = "formatModFloatTB";
   args.UserData((XtPointer)ValueC::FLOAT);
   floatTB = XmCreateToggleButton(radioBox, wname, ARGS);

   XtAddCallback(intTB, XmNvalueChangedCallback, (XtCallbackProc)SetFormat,
		 (XtPointer)this);
   XtAddCallback(hexTB, XmNvalueChangedCallback, (XtCallbackProc)SetFormat,
		 (XtPointer)this);
   XtAddCallback(floatTB, XmNvalueChangedCallback, (XtCallbackProc)SetFormat,
		 (XtPointer)this);

//
// Manage widgets
//
   Widget	list[4];
   list[0] = intTB;
   list[1] = hexTB;
   list[2] = floatTB;
   XtManageChildren(list, 3);	// radioBox children

   XtManageChild(radioBox);	// frame child

   list[0] = label;
   list[1] = frame;
   list[2] = precisTF;
   list[3] = precisLabel;
   XtManageChildren(list, 4);	// form children

//
// Initialize
//
   XmToggleButtonSetState(intTB, True, True);

} // End FormatModC FormatModC

/*---------------------------------------------------------------
 *  Callback routine to handle press of toggle button
 */

void
FormatModC::SetFormat(Widget w, FormatModC *fm,
		      XmToggleButtonCallbackStruct *tb)
{
   if ( !tb->set ) return;

   XtPointer	ptr;
   XtVaGetValues(w, XmNuserData, &ptr, NULL);

   fm->format = (ValueC::ValueFormat)ptr;
   XtSetSensitive(fm->precisLabel, fm->format == ValueC::FLOAT);
}

/*---------------------------------------------------------------
 *  Method to return the precision
 */

int
FormatModC::Precision()
{
   char *cs = XmTextFieldGetString(precisTF);
   int	precis = atoi(cs);
   XtFree(cs);

   return precis;
}

/*---------------------------------------------------------------
 *  Method to apply the current settings to the given value
 */

void
FormatModC::Apply(ValueC& val)
{
   char	*cs = XmTextFieldGetString(precisTF);
   int	precis = atoi(cs);
   XtFree(cs);

   val.SetFormat(format, precis);
}

/*---------------------------------------------------------------
 *  Method to initialize the settings based on the given value
 */

void
FormatModC::Init(const ValueC& val)
{
   Init(val.Format(), val.Precision());
}

/*---------------------------------------------------------------
 *  Method to initialize the settings based on the given parameters
 */

void
FormatModC::Init(ValueC::ValueFormat f, int p)
{
   init.precis = p;
   StringC	pstr;
   pstr += init.precis;
   XmTextFieldSetString(precisTF, pstr);

   init.format = format = f;
   Widget	tb;
   switch (format) {
      case (ValueC::INT):	tb = intTB;	break;
      case (ValueC::HEX):	tb = hexTB;	break;
      case (ValueC::FLOAT):	tb = floatTB;	break;
   }
   XmToggleButtonSetState(tb, True, True);

} // End FormatModC Init

/*---------------------------------------------------------------
 *  Method to reset the settings to the initial state
 */

void
FormatModC::Reset()
{
   StringC	pstr;
   pstr += init.precis;
   XmTextFieldSetString(precisTF, pstr);

   format = init.format;
   Widget	tb;
   switch (format) {
      case (ValueC::INT):	tb = intTB;	break;
      case (ValueC::HEX):	tb = hexTB;	break;
      case (ValueC::FLOAT):	tb = floatTB;	break;
   }
   XmToggleButtonSetState(tb, True, True);

} // End FormatModC Reset
