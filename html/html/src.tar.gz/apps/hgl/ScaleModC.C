/*
 * $Id: ScaleModC.C,v 1.1 1998/06/24 01:29:07 lang Exp $
 *
 * Copyright (c) 1992 HAL Computer Systems International, Ltd.
 * 
 *          HAL COMPUTER SYSTEMS INTERNATIONAL, LTD.
 *                  1315 Dell Avenue
 *                  Campbell, CA  95008
 *
 * Author: Greg Hilton
 * Contributors: Tom Lang, Frank Bieser, and others
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * http://www.gnu.org/copyleft/gpl.html
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#include "ScaleModC.h"
#include "FormatModC.h"
#include "ShadowModC.h"
#include "OrientModC.h"
#include "ColorModC.h"
#include "WArgList.h"
#include "rsrc.h"

#include <Xm/Form.h>
#include <Xm/Frame.h>
#include <Xm/Label.h>
#include <Xm/TextF.h>
#include <Xm/RowColumn.h>

ScaleModC::ScaleModC(Widget parent, const char *name, ArgList argv,
		     Cardinal argc) : ModFormC(parent, name, argv, argc)
{
   WArgList	args;
   StringC	wname;

   scale = NULL;

//
// Create the paramForm hierarchy
//
//   paramForm
//      Label		minLabel
//      TextField	minTF
//      Label		maxLabel
//      TextField	maxTF
//      FormatModC	formatForm
//      ShadowModC	barShadowForm
//      ShadowModC	troughShadowForm
//      OrientModC	orientForm
//      Label		sizeLabel
//      TextField	sizeTF
//      Label		pixelLabel
//
   int	ltOffset = get_int("ScaleModC", paramForm, "labelTextOffset");

   wname = "minLabel";
   minLabel = XmCreateLabel(paramForm, wname, 0,0);

   wname = "minTF";
   args.Reset();
   args.LeftAttachment(XmATTACH_FORM);
   minTF = XmCreateTextField(paramForm, wname, ARGS);

   wname = "maxLabel";
   maxLabel = XmCreateLabel(paramForm, wname, 0,0);

   wname = "maxTF";
   args.Reset();
   args.LeftAttachment(XmATTACH_WIDGET, minTF);
   maxTF = XmCreateTextField(paramForm, wname, ARGS);

   wname = "formatMod";
   args.Reset();
   args.TopAttachment(XmATTACH_WIDGET, minTF);
   formatForm = new FormatModC(paramForm, wname, ARGS);

   wname = "barShadowMod";
   args.Reset();
   args.TopAttachment(XmATTACH_WIDGET, *formatForm);
   barShadowForm = new ShadowModC(paramForm, wname, ARGS);

   wname = "troughShadowMod";
   args.Reset();
   args.TopAttachment(XmATTACH_WIDGET, *barShadowForm);
   troughShadowForm = new ShadowModC(paramForm, wname, ARGS);

   wname = "orientationMod";
   args.Reset();
   args.TopAttachment(XmATTACH_WIDGET, *troughShadowForm);
   orientForm = new OrientModC(paramForm, wname, ARGS);

   wname = "sizeLabel";
   sizeLabel = XmCreateLabel(paramForm, wname, 0,0);

   wname = "sizeTF";
   args.Reset();
   args.TopAttachment(XmATTACH_WIDGET, *orientForm);
   args.LeftAttachment(XmATTACH_FORM);
   sizeTF = XmCreateTextField(paramForm, wname, ARGS);

   wname = "pixelLabel";
   args.Reset();
   args.LeftAttachment  (XmATTACH_WIDGET,          sizeTF);
   args.TopAttachment   (XmATTACH_OPPOSITE_WIDGET, sizeTF);
   args.BottomAttachment(XmATTACH_OPPOSITE_WIDGET, sizeTF);
   pixelLabel = XmCreateLabel(paramForm, wname, ARGS);

//
// Get maximum label width
//
   Dimension	wd, max_wd;
   args.Reset();
   args.Add(XmNwidth, &wd);
   XtGetValues(minLabel,                      ARGS); max_wd = wd;
   XtGetValues(formatForm->Label(),           ARGS); if (wd>max_wd) max_wd = wd;
   XtGetValues(barShadowForm->TypeLabel(),    ARGS); if (wd>max_wd) max_wd = wd;
   XtGetValues(troughShadowForm->TypeLabel(), ARGS); if (wd>max_wd) max_wd = wd;
   XtGetValues(orientForm->Label(),           ARGS); if (wd>max_wd) max_wd = wd;
   XtGetValues(sizeLabel,                     ARGS); if (wd>max_wd) max_wd = wd;

   args.Reset();
   args.LeftAttachment(XmATTACH_FORM, max_wd + ltOffset);
   XtSetValues(minTF,                         ARGS);
   XtSetValues(formatForm->Frame(),           ARGS);
   XtSetValues(barShadowForm->TypeFrame(),    ARGS);
   XtSetValues(troughShadowForm->TypeFrame(), ARGS);
   XtSetValues(orientForm->Frame(),           ARGS);
   XtSetValues(sizeTF,                        ARGS);

//
// Attach labels
//
   args.Reset();
   args.TopAttachment(XmATTACH_OPPOSITE_WIDGET,    minTF);
   args.BottomAttachment(XmATTACH_OPPOSITE_WIDGET, minTF);
   args.RightAttachment(XmATTACH_WIDGET,           minTF);
   XtSetValues(minLabel, ARGS);

   args.TopWidget(sizeTF);
   args.BottomWidget(sizeTF);
   args.RightWidget(sizeTF);
   XtSetValues(sizeLabel, ARGS);

//
// Position max label and text
//
   args.Reset();
   args.Add(XmNwidth, &max_wd);
   XtGetValues(maxLabel, ARGS);

   args.Reset();
   args.LeftAttachment(XmATTACH_WIDGET, minTF, max_wd + ltOffset);
   XtSetValues(maxTF, ARGS);

   args.Reset();
   args.LeftAttachment  (XmATTACH_NONE);
   args.RightAttachment (XmATTACH_WIDGET,          maxTF);
   args.TopAttachment   (XmATTACH_OPPOSITE_WIDGET, maxTF);
   args.BottomAttachment(XmATTACH_OPPOSITE_WIDGET, maxTF);
   XtSetValues(maxLabel, ARGS);

//
// Create the colorRC hierarchy
//
//   colorRC
//      ColorModC	backgroundForm
//      ColorModC	digitBackgroundForm
//      ColorModC	digitForegroundForm
//      ColorModC	topShadowForm
//      ColorModC	bottomShadowForm
//
   wname = "backgroundMod";
   colorForm[ScaleC::BACKGROUND]           = new ColorModC(colorRC, wname, 0,0);
   wname = "barColorMod";
   colorForm[ScaleC::BAR_COLOR]            = new ColorModC(colorRC, wname, 0,0);
   wname = "troughColorMod";
   colorForm[ScaleC::TROUGH_COLOR]         = new ColorModC(colorRC, wname, 0,0);
   wname = "valueColorMod";
   colorForm[ScaleC::VALUE_COLOR]          = new ColorModC(colorRC, wname, 0,0);
   wname = "labelColorMod";
   colorForm[ScaleC::LABEL_COLOR]          = new ColorModC(colorRC, wname, 0,0);
   wname = "markColorMod";
   colorForm[ScaleC::MARK_COLOR]           = new ColorModC(colorRC, wname, 0,0);
   wname = "barTopShadowColorMod";
   colorForm[ScaleC::BAR_TOP_SHADOW]       = new ColorModC(colorRC, wname, 0,0);
   wname = "barBottomShadowColorMod";
   colorForm[ScaleC::BAR_BOTTOM_SHADOW]    = new ColorModC(colorRC, wname, 0,0);
   wname = "troughTopShadowColorMod";
   colorForm[ScaleC::TROUGH_TOP_SHADOW]    = new ColorModC(colorRC, wname, 0,0);
   wname = "troughBottomShadowColorMod";
   colorForm[ScaleC::TROUGH_BOTTOM_SHADOW] = new ColorModC(colorRC, wname, 0,0);

//
// Manage children
//
   Widget	list[11];
   list[0] = *colorForm[ScaleC::BACKGROUND];
   list[1] = *colorForm[ScaleC::BAR_COLOR];
   list[2] = *colorForm[ScaleC::TROUGH_COLOR];
   list[3] = *colorForm[ScaleC::VALUE_COLOR];
   list[4] = *colorForm[ScaleC::LABEL_COLOR];
   list[5] = *colorForm[ScaleC::MARK_COLOR];
   list[6] = *colorForm[ScaleC::BAR_TOP_SHADOW];
   list[7] = *colorForm[ScaleC::BAR_BOTTOM_SHADOW];
   list[8] = *colorForm[ScaleC::TROUGH_TOP_SHADOW];
   list[9] = *colorForm[ScaleC::TROUGH_BOTTOM_SHADOW];
   XtManageChildren(list, 10);	// colorRC children

   list[ 0] = minLabel;
   list[ 1] = minTF;
   list[ 2] = maxLabel;
   list[ 3] = maxTF;
   list[ 4] = *formatForm;
   list[ 5] = *barShadowForm;
   list[ 6] = *troughShadowForm;
   list[ 7] = *orientForm;
   list[ 8] = sizeLabel;
   list[ 9] = sizeTF;
   list[10] = pixelLabel;
   XtManageChildren(list, 11);	// paramForm children

} // End ScaleModC ScaleModC

/*---------------------------------------------------------------
 *  Destructor
 */

ScaleModC::~ScaleModC()
{
   delete formatForm;
   delete barShadowForm;
   delete troughShadowForm;
   delete orientForm;
   for (int i=0; i<ScaleC::COLOR_ATTR_COUNT; i++) delete colorForm[i];
}

/*---------------------------------------------------------------
 *  Method to apply scale changes
 */

void
ScaleModC::Apply(ScaleC& s)
{
   s.Defer(True);

//
// Set the range
//
   char	*cs = XmTextFieldGetString(minTF);
   float	minVal = atof(cs);
   XtFree(cs);

   cs = XmTextFieldGetString(maxTF);
   float	maxVal = atof(cs);
   XtFree(cs);

   s.SetRange(minVal, maxVal);

//
// Set the numeric format
//
   ValueC	formVal;
   formatForm->Apply(formVal);

   s.SetOutputFormat(formVal.Format());
   s.SetPrecision(formVal.Precision());

//
// Set the shadow attributes
//
   s.SetBarShadowType(barShadowForm->Type());
   s.SetBarShadowThickness(barShadowForm->Thickness());
   s.SetTroughShadowType(troughShadowForm->Type());
   s.SetTroughShadowThickness(troughShadowForm->Thickness());

//
// Set the orientation
//
   s.SetOrientation(orientForm->Type());

//
// Set the preferred size
//
   cs = XmTextFieldGetString(sizeTF);
   int	prefSize = atoi(cs);
   XtFree(cs);
   s.SetTroughSize(prefSize);

//
// Set the colors
//
   for (int i=0; i<ScaleC::COLOR_ATTR_COUNT; i++) {
      ColorModC	*cm = colorForm[i];
      if ( cm->Changed() ) {
	 s.SetColor((ScaleC::ScaleColorAttr)i, cm->Value());
      }
   }

   s.Defer(False);
   s.Draw();

   return;

} // End ScaleModC Apply

/*---------------------------------------------------------------
 *  Method to initialize the settings based on the given scale
 */

void
ScaleModC::Init(ScaleC& s)
{
   s.GetRange(&init.minVal, &init.maxVal);
   formatForm->Init(s.OutputFormat(), s.Precision());
   barShadowForm->Init(s.BarShadowType(), s.BarShadowThickness());
   troughShadowForm->Init(s.TroughShadowType(),
			  s.TroughShadowThickness());
   orientForm->Init(s.Orientation());
   init.prefSize = s.TroughSize();

//
// Initialize the fields
//
   XmTextFieldSetString(minTF, (char *)(StringC)init.minVal);
   XmTextFieldSetString(maxTF, (char *)(StringC)init.maxVal);
   StringC	str;
   str += init.prefSize;
   XmTextFieldSetString(sizeTF, str);

//
// Initialize the colors
//
   for (int i=0; i<ScaleC::COLOR_ATTR_COUNT; i++) {
      colorForm[i]->Init(s.GetColor((ScaleC::ScaleColorAttr)i));
   }

   scale = &s;

} // End ScaleModC Init

/*---------------------------------------------------------------
 *  Method to reset the fields to their initial values
 */

void
ScaleModC::Reset()
{
   XmTextFieldSetString(minTF, (char *)(StringC)init.minVal);
   XmTextFieldSetString(maxTF, (char *)(StringC)init.maxVal);

   formatForm->Reset();
   barShadowForm->Reset();
   troughShadowForm->Reset();
   orientForm->Reset();

   StringC	str;
   str += init.prefSize;
   XmTextFieldSetString(sizeTF, str);

//
// Initialize the colors
//
   for (int i=0; i<ScaleC::COLOR_ATTR_COUNT; i++) colorForm[i]->Reset();

   if ( autoApply ) {
      scale->Defer(True);
      scale->SetRange(init.minVal, init.maxVal);
      scale->SetOutputFormat(formatForm->Format());
      scale->SetPrecision(formatForm->Precision());
      scale->SetBarShadowType(barShadowForm->Type());
      scale->SetBarShadowThickness(barShadowForm->Thickness());
      scale->SetTroughShadowType(troughShadowForm->Type());
      scale->SetTroughShadowThickness(troughShadowForm->Thickness());
      scale->SetOrientation(orientForm->Type());
      scale->SetTroughSize(init.prefSize);
      for (int i=0; i<ScaleC::COLOR_ATTR_COUNT; i++)
	 scale->SetColor((ScaleC::ScaleColorAttr)i, colorForm[i]->Value());
      scale->Defer(False);
      scale->Draw();
   }

} // End ScaleModC Reset

/*---------------------------------------------------------------
 *  Method to add the callbacks needed to support auto update
 */

void
ScaleModC::EnableAutoApply()
{
   if ( autoApply ) return;

#define AddValueChanged(W,C) \
   XtAddCallback(W, XmNvalueChangedCallback, \
	         (XtCallbackProc)(C), (XtPointer)this)

#define AddActivate(W,C) \
   XtAddCallback(W, XmNactivateCallback, \
	         (XtCallbackProc)(C), (XtPointer)this)

#define AddColorActivate(COL,C) \
   AddActivate(colorForm[ScaleC::COL]->TextField(), C)

//
// Add auto-update callbacks
//
   AddActivate     (minTF,                         ChangeRange);
   AddActivate     (maxTF,                         ChangeRange);
   AddValueChanged (formatForm->IntTB(),           ChangeFormat);
   AddValueChanged (formatForm->HexTB(),           ChangeFormat);
   AddValueChanged (formatForm->FloatTB(),         ChangeFormat);
   AddActivate     (formatForm->PrecisTF(),        ChangeFormatPrecis);
   AddValueChanged (barShadowForm->InTB(),         ChangeBarShadow);
   AddValueChanged (barShadowForm->OutTB(),        ChangeBarShadow);
   AddValueChanged (barShadowForm->EtchInTB(),     ChangeBarShadow);
   AddValueChanged (barShadowForm->EtchOutTB(),    ChangeBarShadow);
   AddActivate     (barShadowForm->ThickTF(),      ChangeBarShadowThick);
   AddValueChanged (troughShadowForm->InTB(),      ChangeTroughShadow);
   AddValueChanged (troughShadowForm->OutTB(),     ChangeTroughShadow);
   AddValueChanged (troughShadowForm->EtchInTB(),  ChangeTroughShadow);
   AddValueChanged (troughShadowForm->EtchOutTB(), ChangeTroughShadow);
   AddActivate     (troughShadowForm->ThickTF(),   ChangeTroughShadowThick);
   AddValueChanged (orientForm->VerticalTB(),      ChangeOrient);
   AddValueChanged (orientForm->HorizontalTB(),    ChangeOrient);
   AddActivate     (sizeTF,                        ChangeTroughSize);
   AddColorActivate(BACKGROUND,                    ChangeBackground);
   AddColorActivate(BAR_COLOR,                     ChangeBarColor);
   AddColorActivate(TROUGH_COLOR,                  ChangeTroughColor);
   AddColorActivate(VALUE_COLOR,                   ChangeValueColor);
   AddColorActivate(LABEL_COLOR,                   ChangeLabelColor);
   AddColorActivate(MARK_COLOR,                    ChangeMarkColor);
   AddColorActivate(BAR_TOP_SHADOW,                ChangeBarTopShadow);
   AddColorActivate(BAR_BOTTOM_SHADOW,             ChangeBarBottomShadow);
   AddColorActivate(TROUGH_TOP_SHADOW,             ChangeTroughTopShadow);
   AddColorActivate(TROUGH_BOTTOM_SHADOW,          ChangeTroughBottomShadow);

} // End ScaleModC EnableAutoApply

/*---------------------------------------------------------------
 *  Method to remove the callbacks needed to support auto update
 */

void
ScaleModC::DisableAutoApply()
{
   if ( !autoApply ) return;

#define RemoveValueChanged(W,C) \
   XtRemoveCallback(W, XmNvalueChangedCallback, \
	            (XtCallbackProc)(C), (XtPointer)this)

#define RemoveActivate(W,C) \
   XtRemoveCallback(W, XmNactivateCallback, \
	            (XtCallbackProc)(C), (XtPointer)this)

#define RemoveColorActivate(COL,C) \
   RemoveActivate(colorForm[ScaleC::COL]->TextField(), C)

//
// Remove auto-update callbacks
//
   RemoveActivate     (minTF,                         ChangeRange);
   RemoveActivate     (maxTF,                         ChangeRange);
   RemoveValueChanged (formatForm->IntTB(),           ChangeFormat);
   RemoveValueChanged (formatForm->HexTB(),           ChangeFormat);
   RemoveValueChanged (formatForm->FloatTB(),         ChangeFormat);
   RemoveActivate     (formatForm->PrecisTF(),        ChangeFormatPrecis);
   RemoveValueChanged (barShadowForm->InTB(),         ChangeBarShadow);
   RemoveValueChanged (barShadowForm->OutTB(),        ChangeBarShadow);
   RemoveValueChanged (barShadowForm->EtchInTB(),     ChangeBarShadow);
   RemoveValueChanged (barShadowForm->EtchOutTB(),    ChangeBarShadow);
   RemoveActivate     (barShadowForm->ThickTF(),      ChangeBarShadowThick);
   RemoveValueChanged (troughShadowForm->InTB(),      ChangeTroughShadow);
   RemoveValueChanged (troughShadowForm->OutTB(),     ChangeTroughShadow);
   RemoveValueChanged (troughShadowForm->EtchInTB(),  ChangeTroughShadow);
   RemoveValueChanged (troughShadowForm->EtchOutTB(), ChangeTroughShadow);
   RemoveActivate     (troughShadowForm->ThickTF(),   ChangeTroughShadowThick);
   RemoveValueChanged (orientForm->VerticalTB(),      ChangeOrient);
   RemoveValueChanged (orientForm->HorizontalTB(),    ChangeOrient);
   RemoveActivate     (sizeTF,                        ChangeTroughSize);
   RemoveColorActivate(BACKGROUND,                    ChangeBackground);
   RemoveColorActivate(BAR_COLOR,                     ChangeBarColor);
   RemoveColorActivate(TROUGH_COLOR,                  ChangeTroughColor);
   RemoveColorActivate(VALUE_COLOR,                   ChangeValueColor);
   RemoveColorActivate(LABEL_COLOR,                   ChangeLabelColor);
   RemoveColorActivate(MARK_COLOR,                    ChangeMarkColor);
   RemoveColorActivate(BAR_TOP_SHADOW,                ChangeBarTopShadow);
   RemoveColorActivate(BAR_BOTTOM_SHADOW,             ChangeBarBottomShadow);
   RemoveColorActivate(TROUGH_TOP_SHADOW,             ChangeTroughTopShadow);
   RemoveColorActivate(TROUGH_BOTTOM_SHADOW,          ChangeTroughBottomShadow);

} // End ScaleModC DisableAutoApply

void
ScaleModC::ChangeRange(Widget, ScaleModC *sm, XtPointer)
{
   if ( XmTextFieldGetLastPosition(sm->minTF) == 0 ||
        XmTextFieldGetLastPosition(sm->maxTF) == 0 ) return;

   char *cs = XmTextFieldGetString(sm->minTF);
   float	min = atof(cs);
   XtFree(cs);

   cs = XmTextFieldGetString(sm->maxTF);
   float	max = atof(cs);
   XtFree(cs);

   if ( min >= max ) return;

   sm->scale->SetRange(min, max);
}

void
ScaleModC::ChangeFormat(Widget, ScaleModC *sm, XmToggleButtonCallbackStruct *tb)
{
   if ( tb->set )
      sm->scale->SetOutputFormat(sm->formatForm->Format());
}

void
ScaleModC::ChangeFormatPrecis(Widget, ScaleModC *sm, XtPointer)
{
   sm->scale->SetPrecision(sm->formatForm->Precision());
}

void
ScaleModC::ChangeBarShadow(Widget, ScaleModC *sm,
			   XmToggleButtonCallbackStruct *tb)
{
   if ( tb->set )
      sm->scale->SetBarShadowType(sm->barShadowForm->Type());
}

void
ScaleModC::ChangeBarShadowThick(Widget, ScaleModC *sm, XtPointer)
{
   sm->scale->SetBarShadowThickness(sm->barShadowForm->Thickness());
}

void
ScaleModC::ChangeTroughShadow(Widget, ScaleModC *sm,
			      XmToggleButtonCallbackStruct *tb)
{
   if ( tb->set )
      sm->scale->SetTroughShadowType(sm->troughShadowForm->Type());
}

void
ScaleModC::ChangeTroughShadowThick(Widget, ScaleModC *sm, XtPointer)
{
   sm->scale->SetTroughShadowThickness(sm->troughShadowForm->Thickness());
}

void
ScaleModC::ChangeOrient(Widget, ScaleModC *sm, XtPointer)
{
   sm->scale->SetOrientation(sm->orientForm->Type());
}

void
ScaleModC::ChangeTroughSize(Widget, ScaleModC *sm, XtPointer)
{
   if ( XmTextFieldGetLastPosition(sm->sizeTF) == 0 ) return;

   char *cs = XmTextFieldGetString(sm->sizeTF);
   int	size = atoi(cs);
   XtFree(cs);

   sm->scale->SetTroughSize(size);
}

void
ScaleModC::ChangeBackground(Widget, ScaleModC *sm, XtPointer)
{
   sm->ChangeColor(ScaleC::BACKGROUND);
}

void
ScaleModC::ChangeBarColor(Widget, ScaleModC *sm, XtPointer)
{
   sm->ChangeColor(ScaleC::BAR_COLOR);
}

void
ScaleModC::ChangeTroughColor(Widget, ScaleModC *sm, XtPointer)
{
   sm->ChangeColor(ScaleC::TROUGH_COLOR);
}

void
ScaleModC::ChangeValueColor(Widget, ScaleModC *sm, XtPointer)
{
   sm->ChangeColor(ScaleC::VALUE_COLOR);
}

void
ScaleModC::ChangeLabelColor(Widget, ScaleModC *sm, XtPointer)
{
   sm->ChangeColor(ScaleC::LABEL_COLOR);
}

void
ScaleModC::ChangeMarkColor(Widget, ScaleModC *sm, XtPointer)
{
   sm->ChangeColor(ScaleC::MARK_COLOR);
}

void
ScaleModC::ChangeBarTopShadow(Widget, ScaleModC *sm, XtPointer)
{
   sm->ChangeColor(ScaleC::BAR_TOP_SHADOW);
}

void
ScaleModC::ChangeBarBottomShadow(Widget, ScaleModC *sm, XtPointer)
{
   sm->ChangeColor(ScaleC::BAR_BOTTOM_SHADOW);
}

void
ScaleModC::ChangeTroughTopShadow(Widget, ScaleModC *sm, XtPointer)
{
   sm->ChangeColor(ScaleC::TROUGH_TOP_SHADOW);
}

void
ScaleModC::ChangeTroughBottomShadow(Widget, ScaleModC *sm, XtPointer)
{
   sm->ChangeColor(ScaleC::TROUGH_BOTTOM_SHADOW);
}

void
ScaleModC::ChangeColor(ScaleC::ScaleColorAttr color)
{
   ColorModC		*cm = colorForm[color];

   if ( cm->Changed() ) scale->SetColor(color, cm->Value());
}
