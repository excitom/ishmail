/*
 * $Id: HistogramModC.h,v 1.1 1998/06/24 01:29:07 lang Exp $
 *
 * Copyright (c) 1992 HAL Computer Systems International, Ltd.
 * 
 *          HAL COMPUTER SYSTEMS INTERNATIONAL, LTD.
 *                  1315 Dell Avenue
 *                  Campbell, CA  95008
 *
 * Author: Greg Hilton
 * Contributors: Tom Lang, Frank Bieser, and others
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * http://www.gnu.org/copyleft/gpl.html
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#ifndef _HistogramModC_h_
#define _HistogramModC_h_

#include "HistogramC.h"
#include "ModFormC.h"
#include "ValueC.h"

#include <Xm/Xm.h>

class FormatModC;
class ShadowModC;
class OrientModC;
class ColorModC;

class HistogramModC : public ModFormC {

   ShadowModC	*shadowForm;
   ShadowModC	*barShadowForm;
   Widget	tick1LenLabel;
   Widget	tick1LenTF;
   Widget	tick2LenLabel;
   Widget	tick2LenTF;
   Widget	margWdLabel;
   Widget	margWdTF;
   Widget	margHtLabel;
   Widget	margHtTF;
   OrientModC	*orientForm;
   Widget	maxCountLabel;
   Widget	maxCountTF;
   Widget	valFrame;
   Widget	valTitle;
   Widget	valForm;
   FormatModC	*formatForm;
   Widget	bucketWdLabel;
   Widget	bucketWdTF;
   Widget	visCountLabel;
   Widget	visCountTF;
   Widget	valTick1SpaceLabel;
   Widget	valTick1SpaceTF;
   Widget	valTick2SpaceLabel;
   Widget	valTick2SpaceTF;
   Widget	cntFrame;
   Widget	cntTitle;
   Widget	cntForm;
   Widget	compressFrame;
   Widget	compressRC;
   Widget	showZeroTB;
   Widget	compressTB;
   Widget	cntTick1SpaceLabel;
   Widget	cntTick1SpaceTF;
   Widget	grid1TB;
   Widget	cntTick2SpaceLabel;
   Widget	cntTick2SpaceTF;
   Widget	grid2TB;
   ColorModC	*colorForm[HistogramC::COLOR_ATTR_COUNT];
   HistogramC	*histogram;

//
// Initial values
//
   struct {
      int		tick1Len;
      int		tick2Len;
      Dimension		marginWd;
      Dimension		marginHt;
      int		maxCount;
      ValueC		bucketWd;
      int		visCount;
      ValueC		valTick1Space;
      ValueC		valTick2Space;
      Boolean		compress;
      int		cntTick1Space;
      int		cntTick2Space;
      Boolean		grid1;
      Boolean		grid2;
   } init;

//
// Auto apply callbacks
//
   void		EnableAutoApply();
   void 	DisableAutoApply();
   void 	ChangeColor(HistogramC::HistogramColorAttr);

   static void	ChangeShadow	     (Widget, HistogramModC*,
                                      XmToggleButtonCallbackStruct*);
   static void	ChangeShadowThick    (Widget, HistogramModC*, XtPointer);
   static void	ChangeBarShadow	     (Widget, HistogramModC*,
                                      XmToggleButtonCallbackStruct*);
   static void	ChangeBarShadowThick (Widget, HistogramModC*, XtPointer);
   static void	ChangeTickLength     (Widget, HistogramModC*, XtPointer);
   static void	ChangeMargin         (Widget, HistogramModC*, XtPointer);
   static void	ChangeOrient         (Widget, HistogramModC*, XtPointer);
   static void	ChangeMaxCount       (Widget, HistogramModC*, XtPointer);
   static void	ChangeFormat	     (Widget, HistogramModC*,
                                      XmToggleButtonCallbackStruct*);
   static void	ChangeFormatPrecis   (Widget, HistogramModC*, XtPointer);
   static void	ChangeBucketWidth    (Widget, HistogramModC*, XtPointer);
   static void	ChangeVisCount       (Widget, HistogramModC*, XtPointer);
   static void	ChangeValTickSpace   (Widget, HistogramModC*, XtPointer);
   static void	ChangeCompress       (Widget, HistogramModC*,
				      XmToggleButtonCallbackStruct*);
   static void	ChangeCntTickSpace   (Widget, HistogramModC*, XtPointer);
   static void	ChangeGrid           (Widget, HistogramModC*,
				      XmToggleButtonCallbackStruct*);
   static void	ChangeBackground     (Widget, HistogramModC*, XtPointer);
   static void	ChangeChartColor     (Widget, HistogramModC*, XtPointer);
   static void	ChangeBarColor       (Widget, HistogramModC*, XtPointer);
   static void	ChangeBarBorderColor (Widget, HistogramModC*, XtPointer);
   static void	ChangeAxisColor      (Widget, HistogramModC*, XtPointer);
   static void	ChangeLabelColor     (Widget, HistogramModC*, XtPointer);
   static void	ChangeTickColor      (Widget, HistogramModC*, XtPointer);
   static void	ChangeGridColor      (Widget, HistogramModC*, XtPointer);
   static void	ChangeMarkColor      (Widget, HistogramModC*, XtPointer);
   static void	ChangeTopShadow      (Widget, HistogramModC*, XtPointer);
   static void	ChangeBottomShadow   (Widget, HistogramModC*, XtPointer);
   static void	ChangeBarTopShadow   (Widget, HistogramModC*, XtPointer);
   static void	ChangeBarBottomShadow(Widget, HistogramModC*, XtPointer);

public:

// Methods

   HistogramModC(Widget, const char*, ArgList argv=NULL, Cardinal argc=0);
   ~HistogramModC();

   MEMBER_QUERY(ShadowModC&, ShadowForm,                *shadowForm)
   MEMBER_QUERY(ShadowModC&, BarShadowForm,             *barShadowForm)
   MEMBER_QUERY(Widget,      MajorTickLengthLabel,       tick1LenLabel)
   MEMBER_QUERY(Widget,      MajorTickLengthTF,          tick1LenTF)
   MEMBER_QUERY(Widget,      MinorTickLengthLabel,       tick2LenLabel)
   MEMBER_QUERY(Widget,      MinorTickLengthTF,          tick2LenTF)
   MEMBER_QUERY(Widget,      MarginWidthLabel,           margWdLabel)
   MEMBER_QUERY(Widget,      MarginWidthTF,              margWdTF)
   MEMBER_QUERY(Widget,      MarginHeightLabel,          margHtLabel)
   MEMBER_QUERY(Widget,      MarginHeightTF,             margHtTF)
   MEMBER_QUERY(OrientModC&, OrientForm,                *orientForm)
   MEMBER_QUERY(Widget,      MaximumValueLabel,          maxCountLabel)
   MEMBER_QUERY(Widget,      MaximumValueTF,             maxCountTF)
   MEMBER_QUERY(Widget,      ValueAxisFrame,             valFrame)
   MEMBER_QUERY(Widget,      ValueAxisTitle,             valTitle)
   MEMBER_QUERY(Widget,      ValueAxisForm,              valForm)
   MEMBER_QUERY(FormatModC&, FormatForm,                *formatForm)
   MEMBER_QUERY(Widget,      BucketWidthLabel,           bucketWdLabel)
   MEMBER_QUERY(Widget,      BucketWidthTF,              bucketWdTF)
   MEMBER_QUERY(Widget,      VisibleBucketLabel,         visCountLabel)
   MEMBER_QUERY(Widget,      VisibleBucketTF,            visCountTF)
   MEMBER_QUERY(Widget,      MajorValueTickSpacingLabel, valTick1SpaceLabel)
   MEMBER_QUERY(Widget,      MajorValueTickSpacingTF,    valTick1SpaceTF)
   MEMBER_QUERY(Widget,      MinorValueTickSpacingLabel, valTick2SpaceLabel)
   MEMBER_QUERY(Widget,      MinorValueTickSpacingTF,    valTick2SpaceTF)
   MEMBER_QUERY(Widget,      CountAxisFrame,             cntFrame)
   MEMBER_QUERY(Widget,      CountAxisTitle,             cntTitle)
   MEMBER_QUERY(Widget,      CountAxisForm,              cntForm)
   MEMBER_QUERY(Widget,      CountCompressFrame,         compressFrame)
   MEMBER_QUERY(Widget,      CountCompressRadioBox,      compressRC)
   MEMBER_QUERY(Widget,      CountShowZeroTB,            showZeroTB)
   MEMBER_QUERY(Widget,      CountCompressTB,            compressTB)
   MEMBER_QUERY(Widget,      MajorCountTickSpacingLabel, cntTick1SpaceLabel)
   MEMBER_QUERY(Widget,      MajorCountTickSpacingTF,    cntTick1SpaceTF)
   MEMBER_QUERY(Widget,      MajorGridTB,                grid1TB)
   MEMBER_QUERY(Widget,      MinorCountTickSpacingLabel, cntTick2SpaceLabel)
   MEMBER_QUERY(Widget,      MinorCountTickSpacingTF,    cntTick2SpaceTF)
   MEMBER_QUERY(Widget,      MinorGridTB,                grid2TB)

   void		Apply(HistogramC&);
   void		Init(HistogramC&);
   void		Reset();
};

#endif // _HistogramModC_h_
