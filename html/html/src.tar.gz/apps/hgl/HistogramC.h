/*
 * $Id: HistogramC.h,v 1.1 1998/06/24 01:29:07 lang Exp $
 *
 * Copyright (c) 1992 HAL Computer Systems International, Ltd.
 * 
 *          HAL COMPUTER SYSTEMS INTERNATIONAL, LTD.
 *                  1315 Dell Avenue
 *                  Campbell, CA  95008
 *
 * Author: Greg Hilton
 * Contributors: Tom Lang, Frank Bieser, and others
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * http://www.gnu.org/copyleft/gpl.html
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#ifndef _HistogramC_h_
#define _HistogramC_h_

#include "GraphC.h"
#include "ValueC.h"
#include "IntListC.h"
#include "FloatListC.h"
#include "StringListC.h"

#include <Xm/Xm.h>

class WorkingBoxC;

//----------------------------------------------------------------------------
// Class definition
//
//   The histogram consists of 2 axes: the count axis and the value/bucket axis
//   When the orientation is vertical, the count axis will be drawn as X and
//      the value/bucket axis will be drawn as Y.
//   When the orientation is horzontal, the count axis will be drawn as Y and
//      the value/bucket axis will be drawn as X.
//

class HistogramC : public GraphC {

public:

   enum HistogramColorAttr {
      BACKGROUND = 0,
      CHART_COLOR,
      BAR_COLOR,
      BAR_BORDER_COLOR,
      AXIS_COLOR,
      LABEL_COLOR,
      TICK_COLOR,
      GRID_COLOR,
      MARK_COLOR,
      TOP_SHADOW,
      BOTTOM_SHADOW,
      BAR_TOP_SHADOW,
      BAR_BOTTOM_SHADOW,
      COLOR_ATTR_COUNT
   };

protected:

   Widget		form;
   Widget		scrollBar;

//
// Drawing attributes
//
   Pixel		colors[COLOR_ATTR_COUNT];
   StringC		colorNames[COLOR_ATTR_COUNT];
   XFontStruct		*font;
   unsigned char	shadowType;
   Dimension		shadowThickness;
   unsigned char	barShadowType;
   Dimension		barShadowThickness;
   float		bucketWidth;		// In value units
   Boolean		compress;		// Show 0 on count axis or not
   int			labelOffset;
   int			majorTickLen;
   int			minorTickLen;
   int			majorCountTickSpace;	// In count units
   int			minorCountTickSpace;
   float		majorValueTickSpace;	// In value units
   float		minorValueTickSpace;
   Boolean		majorGridVis;		// Count axis only
   Boolean		minorGridVis;
   unsigned char	orientation;		// Vertical or Horizontal
   unsigned		visCount;		// # of buckets displayed
   unsigned		maxValues;		// Maximum # of values stored

   FloatListC		valueList;		// Data set
   IntListC		countMarkList;		// Marks on count axis
   FloatListC		valueMarkList;		// Marks on value axis

   float		minValue;		// On value axis
   float		maxValue;
   float		valRangeInv;
   int			minIndex;		// First visible bucket
   int			maxIndex;		// Last visible bucket
   int			minCount;		// Smallest bucket
   int			maxCount;		// Largest bucket
   float		countRangeInv;
   IntListC		bucketList;		// List of counts
   StringListC		labelList;		// Bucket labels.  Present only
						// if buckets are filled by the
						// user
   ValueC		countFormat;		// INT or HEX
   ValueC		valueFormat;
   Dimension		scrollBarSpan;		// Width or Height
   Boolean		userBuckets;		// True if user filled buckets

//
// Callbacks and event handlers
//
   static void		ScrollCB(Widget, HistogramC*,
				 XmScrollBarCallbackStruct*);

//
// Private methods
//
   Widget		BuildWidgets(Widget, const char*, ArgList, Cardinal);
   void			DecrementBucket(float);
   void			DrawHorizontal();
   void			DrawVertical();
   void			IncrementBucket(float);
   float		NormalizeValue(float);
   float		NormalizeCount(int);
   void			RefillBuckets();

public:

//
// Cast to widget
//
   inline operator	Widget() const		{ return form;		}

//
// Constructor and destructor
//
   HistogramC(Widget parent, const char *name, ArgList argv=NULL,
	      Cardinal argc=0);
   virtual	~HistogramC();

//
// Assignment from another histogram
//
   HistogramC&		operator=(const HistogramC&);

//
// Read from and write to a file
//
   int			Read(FILE*, WorkingBoxC *wb=NULL);
   void			Write(FILE*, const char *prefix="");
   
//
// Methods to modify the strip chart
//
   void			AddCountMark(int);
   void			AddValue(const ValueC);
   void			AddValueMark(const ValueC);
   void			Draw();
   void			SetBarShadowThickness(Dimension);
   void			SetBarShadowType(unsigned char);
   void			SetBucketWidth(const ValueC);
   void			SetBuckets(const IntListC&, const StringListC&);
   void			SetColor(HistogramC::HistogramColorAttr, Pixel);
   void			SetColor(HistogramC::HistogramColorAttr, const char *);
   void			SetCountCompress(Boolean);
   void			SetCountFormat(ValueC::ValueFormat);
   void			SetCountMarks(const IntListC&);
   void			SetCountTickSpacing(int, int);
   void			SetGridVis(Boolean, Boolean);
   void			SetLabelOffset(int);
   void			SetMargins(Dimension, Dimension);
   void			SetMaximumValueCount(unsigned);
   void			SetOrientation(unsigned char);
   void			SetShadowThickness(Dimension);
   void			SetShadowType(unsigned char);
   void			SetTickLength(int, int);
   void			SetValueFormat(ValueC::ValueFormat);
   void			SetValueMarks(const IntListC&);
   void			SetValueMarks(const FloatListC&);
   void			SetValuePrecision(int);
   void			SetValueTickSpacing(const ValueC, const ValueC);
   void			SetValues(const IntListC&);
   void			SetValues(const FloatListC&);
   void			SetVisibleBucketCount(unsigned);

//
// Methods to query the strip chart
//
   MEMBER_QUERY(Widget,         Form,                   form);
   MEMBER_QUERY(Widget,         ScrollBar,              scrollBar);
   MEMBER_QUERY(Dimension,	BarShadowThickness,	barShadowThickness)
   MEMBER_QUERY(unsigned char,	BarShadowType,		barShadowType)
   MEMBER_QUERY(float,		BucketWidth,		bucketWidth)
   MEMBER_QUERY(Boolean,	CountCompress,		compress)
   MEMBER_QUERY(int,		LabelOffset,		labelOffset)
   MEMBER_QUERY(unsigned,	MaximumValueCount,	maxValues)
   MEMBER_QUERY(unsigned char,	Orientation,		orientation)
   MEMBER_QUERY(Dimension,	ShadowThickness,	shadowThickness)
   MEMBER_QUERY(unsigned char,	ShadowType,		shadowType)
   PTR_QUERY   (FloatListC&,	ValueList,		valueList)
   MEMBER_QUERY(int,		ValuePrecision,		valueFormat.Precision())
   MEMBER_QUERY(unsigned,	VisibleBucketCount,	visCount)
   MEMBER_QUERY(ValueC::ValueFormat,     CountFormat,   countFormat.Format())
   MEMBER_QUERY(ValueC::ValueFormat,     ValFormat,     valueFormat.Format())

   Pixel		GetColor    (HistogramC::HistogramColorAttr) const;
   StringC		GetColorName(HistogramC::HistogramColorAttr) const;
   void			GetCountTickSpacing(StringC*, StringC*) const;
   void			GetCountTickSpacing(int*, int*) const;
   void			GetGridVis(Boolean*, Boolean*) const;
   void			GetMargins(Dimension*, Dimension*) const;
   void			GetTickLength(int*, int*) const;
   void			GetValueTickSpacing(int*, int*) const;
   void			GetValueTickSpacing(long*, long*) const;
   void			GetValueTickSpacing(float*, float*) const;
   void			GetValueTickSpacing(ValueC*, ValueC*) const;
   void			GetValueTickSpacing(StringC*, StringC*) const;
   inline GraphType	Type() const { return HISTOGRAM; }
};

#endif // _HistogramC_h_
