/*
 * $Id: NumericFieldC.C,v 1.1 1998/06/24 01:29:07 lang Exp $
 *
 * Copyright (c) 1992 HAL Computer Systems International, Ltd.
 * 
 *          HAL COMPUTER SYSTEMS INTERNATIONAL, LTD.
 *                  1315 Dell Avenue
 *                  Campbell, CA  95008
 *
 * Author: Greg Hilton
 * Contributors: Tom Lang, Frank Bieser, and others
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * http://www.gnu.org/copyleft/gpl.html
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#include <values.h>

#include "NumericFieldC.h"
#include "WArgList.h"
#include "HalAppC.h"

// #define Dprintf(a) printf a
#define Dprintf(a)

// =====================================================================
// The constructor for the integer, no value checking version.
// =====================================================================
NumericFieldC::NumericFieldC(Widget parent, char* name, Arg *args, Cardinal argcnt)
{
   Build(parent,name,args,argcnt);

   min 	     = MINFLOAT;
   max 	     = MAXFLOAT;
   format    = NumericFieldC::INT;
   precis    = 0;
   textPos   = 0;
   checkMin  = False;
   checkMax  = False;
   checkPrec = False;
   InitValue();
}


// =====================================================================
// The constructor for integer with value checking min & max.
// =====================================================================
NumericFieldC::NumericFieldC(Widget parent, char* name, Arg *args, Cardinal argcnt,
		             int min_val, int max_val )
{
   Build(parent,name,args,argcnt);

   min 	     = (float)min_val;
   max 	     = (float)max_val;
   format    = NumericFieldC::INT;
   precis    = 0;
   textPos   = 0;
   checkMin  = True;
   checkMax  = True;
   checkPrec = False;
   InitValue();
}



// =====================================================================
// The constructor for hexidecimal with value checking min & max.
// =====================================================================
NumericFieldC::NumericFieldC(Widget parent, char* name, Arg *args, Cardinal argcnt,
		             unsigned int min_val, unsigned int max_val )
{
   Build(parent,name,args,argcnt);

   min 	     = (float)min_val;
   max 	     = (float)max_val;
   format    = NumericFieldC::HEX;
   precis    = 0;
   textPos   = 0;
   checkMin  = True;
   checkMax  = True;
   checkPrec = False;
   InitValue();
}


// =====================================================================
// This is the constructor for a float field with value checking but
// no precision checking.
// =====================================================================
NumericFieldC::NumericFieldC(Widget parent, char* name, Arg *args, Cardinal argcnt,
		             float min_val, float max_val )
{
   Build(parent,name,args,argcnt);

   min 	     = min_val;
   max 	     = max_val;
   precis    = 6;
   textPos   = 0;
   format    = NumericFieldC::FLOAT;
   checkMin  = True;
   checkMax  = True;
   checkPrec = False;
   InitValue();
}


// =====================================================================
// The constructor for a float value with value & precision checking.
// =====================================================================
NumericFieldC::NumericFieldC(Widget parent, char* name,
			     Arg *args, Cardinal argcnt,
		             float min_val, float max_val, int prec )
{
   Build(parent,name,args,argcnt);

//
// Set the values.
//
   min 	     = min_val;
   max 	     = max_val;
   precis    = prec;
   format    = NumericFieldC::FLOAT;
   checkMin  = True;
   checkMax  = True;
   checkPrec = True;
   InitValue();
}


// =====================================================================
// =====================================================================
NumericFieldC::~NumericFieldC()
{
   if ( halApp->xRunning && XtIsWidget(textField) )
      XtDestroyWidget(textField);
}


// =====================================================================
// =====================================================================
void
NumericFieldC::Build(Widget parent, char* name, Arg* args, Cardinal argcnt)
{
   textField = XmCreateTextField(parent,name,args,argcnt);

   XtAddCallback(textField, XmNactivateCallback,
		 (XtCallbackProc)DoCheckValue, (XtPointer)this);
   XtAddCallback(textField, XmNvalueChangedCallback,
		 (XtCallbackProc)DoProcessInput, (XtPointer)this);
}


// =====================================================================
// =====================================================================
void
NumericFieldC::InitValue()
{
//
// See if the user set the field with input arguments.
//
   char *str = XmTextFieldGetString(textField);
   if ( !*str )
   {
      if ( min <= 0.0 && max >= 0.0 )
         SetValue((float)0.0);
      else
         SetValue(min);
   }
   XtFree(str);

   textPos = XmTextFieldGetInsertionPosition(textField);
   if ( format == NumericFieldC::HEX && textPos < 2 )
   {
      textPos = 2;
      XmTextFieldSetInsertionPosition(textField, textPos);
   }
}


// =====================================================================
// =====================================================================
void
NumericFieldC::SetValue(char* str)
{
   XtRemoveCallback(textField, XmNvalueChangedCallback,
  		    (XtCallbackProc)DoProcessInput, (XtPointer)this);

   XmTextFieldSetString(textField,str);

   XmTextFieldSetInsertionPosition(textField,textPos);
   XtAddCallback(textField, XmNvalueChangedCallback,
  		 (XtCallbackProc)DoProcessInput, (XtPointer)this);
}


// =====================================================================
// This is actually used to set the value of the textfield.
// =====================================================================
void
NumericFieldC::SetValue(float new_value)
{
//
// Check the range of the value is so desired.
//
   if ( (checkMin && new_value < min) ||
        (checkMax && new_value > max) ) return;

   XtRemoveCallback(textField, XmNvalueChangedCallback,
  		    (XtCallbackProc)DoProcessInput, (XtPointer)this);

   value = new_value;

//
// Set the value string in the textfield.
//
   char str[256];
   switch ( format )
   {
      case NumericFieldC::INT:
         sprintf(str, "%ld", (long)(value + ((value>0.0) ? 0.5 : -0.5)));
         break;

      case NumericFieldC::HEX:
         sprintf(str, "0x%lX", (long)(value + ((value>0.0) ? 0.5 : -0.5)));
         break;
   
      case NumericFieldC::FLOAT:
         sprintf(str, "%.*f", precis, value);
         break;
   }

   int len = strlen(str);
   if ( textPos > len )
      textPos = len;
      
   XmTextFieldSetString(textField,str);
   XmTextFieldSetInsertionPosition(textField,textPos);

   XtAddCallback(textField, XmNvalueChangedCallback,
  		 (XtCallbackProc)DoProcessInput, (XtPointer)this);
}


// =====================================================================
// =====================================================================
void
NumericFieldC::DoProcessInput(Widget, NumericFieldC* nf, XtPointer)
{
   nf->ProcessInput();

}


// =====================================================================
// =====================================================================
void
NumericFieldC::SetFormat(enum Format fmt)
{
   if ( fmt != format )
   {
      format = fmt;
      SetValue((float)value);
   }
}


// =====================================================================
// =====================================================================
void
NumericFieldC::SetFormat(enum Format fmt, int prec)
{
   precis = prec;
   format = fmt;
   SetValue((float)value);
}


// =====================================================================
// This routine makes sure the input is correct, but does not do any
// value checking.
// =====================================================================
void
NumericFieldC::ProcessInput()
{
   XtRemoveCallback(textField, XmNvalueChangedCallback,
  		    (XtCallbackProc)DoProcessInput, (XtPointer)this);

   switch ( format )
   {
      case NumericFieldC::HEX:
	 ProcessHexInput();
	 break;

      case NumericFieldC::FLOAT:
	 ProcessFloatInput();
	 break;

      case NumericFieldC::INT:
      default:
	 ProcessIntInput();
	 break;
   }

   XtAddCallback(textField, XmNvalueChangedCallback,
  		 (XtCallbackProc)DoProcessInput, (XtPointer)this);

}


// =====================================================================
// This routine makes sure the input is correct.
// =====================================================================
void
NumericFieldC::CheckValue()
{
//
// This will be called if we change the value so turn it off.
//
   XtRemoveCallback(textField, XmNvalueChangedCallback,
  		    (XtCallbackProc)DoProcessInput, (XtPointer)this);

//
// Check for a null entry.
//
   char* str = XmTextFieldGetString(textField);
   if ( !*str )
   {
      if ( min <= 0 && max >= 0 )
	 SetValue((float)0);
      else
	 SetValue(min);
   }
   else
   {
//
//    See if we need to check the range of the value.
//
      if ( checkMin && value < min )
	 SetValue(min);
      else if ( checkMax && value > max )
	 SetValue(max);
   }
   XtFree(str);

//
// Add the process input callback back.
//
   XtAddCallback(textField, XmNvalueChangedCallback,
                 (XtCallbackProc)DoProcessInput, (XtPointer)this);
}


// =====================================================================
// =====================================================================
Boolean
NumericFieldC::ProcessFloatInput()
{
//
// Get the string to check.
//
   char* str = XmTextFieldGetString(textField);
   textPos   = XmTextFieldGetInsertionPosition(textField);
   int   len = strlen(str);

   int decimal_pos = -1;
   int post_decimal_chars = 0;

//
// Make sure all the characters are good.
//
   Boolean changed = False;
   for (register int i=0; i<len; i++)
   {
      Boolean bad_char = False;
      char c = str[i];
      switch ( c )
      {
	 case '-':
            if ( i!=0 || min >= 0.0 )
	       bad_char = True;
	    break;

         case '+':
            if ( i!=0 || max < 0.0 )
	       bad_char = True;
	    break;

         case '.':
	    if ( decimal_pos > -1 )
	       bad_char = True;
	    else
	       decimal_pos = i;
	    break;

	 default:
	    if ( !isdigit(str[i]) )
	       bad_char = True;
	    break;
      }

      if ( bad_char )
      {
	 changed = True;
	 for ( register int j=i; j<len; j++)
	    str[j] = str[j+1];
	 i--;	// gotta check the same position since the char has changed
	 len--;
      }

//
//    Check the precision if we have previously encountered a decimal.
//
      if ( checkPrec && decimal_pos > -1 )
      {
	 if ( post_decimal_chars > precis )
	 {
//
//          Cut off the "extra" precisions and we're done.
//
	    str[i] = '\0';
	    changed = True;
	    i = len;
	 }
	 post_decimal_chars++;
      }
   }

//
// Set the value.
//
   value = atof(str);

   if ( changed )
   {
      XmTextFieldSetString(textField, str);
      if ( textPos > len )
	 textPos = len;
      else
         textPos--;
      XmTextFieldSetInsertionPosition(textField, textPos);
   }

   XtFree(str);

   return changed;

} // end ProcessFloatInput()


// =====================================================================
// =====================================================================
Boolean
NumericFieldC::ProcessHexInput()
{
   Dprintf(("************************\n"));
   Dprintf(("Entering ProcessHexInput\n"));

//
// Get the current string in the textfield and check it.
//
   char* tmp = XmTextFieldGetString(textField);
   int   len = strlen(tmp);
   Dprintf(("  len: %d str: %s\n", len, tmp));

   textPos   = XmTextFieldGetInsertionPosition(textField);
   Dprintf(("  textPos: %d\n", textPos));

   char *str = new char[len+3];
   strcpy(str, tmp);
   XtFree(tmp);

   register int i;
   Boolean changed = False;

//
// Make sure the string contains a "0x" in the front of it.
//
   if ( str[0] != '0' )
   {
      Dprintf((" inserting a 0\n"));
      for ( i=len; i>=0; i--)
         str[i+1] = str[i];
      len++;
      str[0] = '0';
      changed = True;
      Dprintf((" str after 0 insertion: <%s>\n", str));
   }
   if ( str[1] != 'x' && str[1] != 'X' )
   {
      Dprintf((" inserting an x\n"));
      for ( i=len; i>=1; i--)
         str[i+1] = str[i];
      len++;
      str[1] = 'x';
      changed = True;
      Dprintf((" str after x insertion: <%s>\n", str));
   }


//
// Make sure all the rest of the characters are good.
//
   for (i=0; i<len; i++)
   {
      Boolean bad_char = False;
      switch ( str[i] )
      {
	 case 'a':
	 case 'A':
	 case 'b':
	 case 'B':
	 case 'c':
	 case 'C':
	 case 'd':
	 case 'D':
	 case 'e':
	 case 'E':
	 case 'f':
	 case 'F':
	    break;

	 case 'x':
	 case 'X':
	    if ( i != 1 )
	       bad_char = True;
            break;

	 default:
	    if ( !isdigit(str[i]) )
	       bad_char = True;
	    break;
      }

      if ( bad_char )
      {
	 changed = True;
	 for ( register int j=i; j<len; j++)
	    str[j] = str[j+1];
	 i--;	// gotta check the same position since the char has changed
	 len--;
         Dprintf(("string after change: <%s>\n", str));
      }
   }
   Dprintf(("string after check: <%s>\n", str));

//
// Set the value.
//
   long lval;
   sscanf(str,"0x%x", &lval);
   value = (float)lval;

   if ( changed )
   {
      XmTextFieldSetString(textField, str);
      if ( textPos > len )
	 textPos = len;
      else
	 textPos--;
      XmTextFieldSetInsertionPosition(textField, textPos);
   }

   if ( textPos < 2 )
   {
      textPos = 2;
      XmTextFieldSetInsertionPosition(textField, textPos);
   }

   delete str;

   Dprintf(("Leaving ProcessHexInput\n"));
   Dprintf(("************************\n"));
   return changed;

} // end ProcessHexInput()


// =====================================================================
// =====================================================================
Boolean
NumericFieldC::ProcessIntInput()
{
//
// Check the string....
//
   char* str = XmTextFieldGetString(textField);
   textPos   = XmTextFieldGetInsertionPosition(textField);
   int   len = strlen(str);

//
// Make sure all the characters are good.
//
   Boolean changed = False;
   for (register int i=0; i<len; i++)
   {
      Boolean bad_char = False;
      switch ( str[i] )
      {
	 case '-':
            if ( i!=0 || min >= 0.0 )
	       bad_char = True;
	    break;

         case '+':
            if ( i!=0 || max < 0.0 )
	       bad_char = True;
	    break;

	 default:
            if ( !isdigit(str[i]) )
	       bad_char = True;
	    break;
      }
      if ( bad_char )
      {
	 changed = True;
	 for ( register int j=i; j<len; j++)
	    str[j] = str[j+1];
	 i--;	// gotta check the same position since the char has changed
	 len--;
      }
   }

   value = atoi(str);

   if ( changed )
   {
      XmTextFieldSetString(textField, str);
      if ( textPos > len )
	 textPos = len;
      else
	 textPos--;
      XmTextFieldSetInsertionPosition(textField, textPos);
   }

   XtFree(str);

   return changed;

} // end ProcessIntInput()


// =====================================================================
// =====================================================================
void
NumericFieldC::SetMin(float v)
{
   min = v;
   if ( checkMin )
      CheckValue();
}


// =====================================================================
// =====================================================================
void
NumericFieldC::SetMax(float v)
{
   max = v;
   if ( checkMax )
      CheckValue();
}


// =====================================================================
// =====================================================================
void
NumericFieldC::CheckMin(Boolean b)
{
   if ( b && !checkMin )
   {
      checkMin = b;
      SetMin(value);
   }
   else
      checkMin = b;
}


// =====================================================================
// =====================================================================
void
NumericFieldC::CheckMax(Boolean b)
{
   if ( b && !checkMax )
   {
      checkMax = b;
      SetMax(value);
   }
   else
      checkMax = b;
}


// =====================================================================
// =====================================================================
void
NumericFieldC::CheckPrecision(Boolean b)
{
   if ( b && !checkPrec )
   {
      checkPrec = b;
      CheckValue();
   }
}


// =====================================================================
// =====================================================================
void
NumericFieldC::SetPrecision(int prec)
{
   if ( prec != precis  && prec >= 0 )
   {
      precis = prec;
      CheckValue();
   }
}


// =====================================================================
// =====================================================================
void
NumericFieldC::DoCheckValue(Widget, NumericFieldC* nf, XtPointer)
{
   nf->CheckValue();
}
