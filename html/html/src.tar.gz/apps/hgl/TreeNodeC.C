/*
 * $Id: TreeNodeC.C,v 1.1 1998/06/24 01:29:07 lang Exp $
 *
 * Copyright (c) 1992 HAL Computer Systems International, Ltd.
 * 
 *          HAL COMPUTER SYSTEMS INTERNATIONAL, LTD.
 *                  1315 Dell Avenue
 *                  Campbell, CA  95008
 *
 * Author: Greg Hilton
 * Contributors: Tom Lang, Frank Bieser, and others
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * http://www.gnu.org/copyleft/gpl.html
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

# include <stream.h>
# include <Xm/Frame.h>
# include <Xm/Form.h>
# include <Xm/Label.h>
# include <Xm/ArrowB.h>
# include "TreeNodeC.h"

TreeNodeC::TreeNodeC (char *name, char *value, TreeC &tree, TreeNodeC *treeParent):
	  TreeItemC (tree, treeParent) {
    //
    //  Initialize the state variables
    //
    _expanded = False;
    _selected = False;
    _parentPruned = False;
    _childrenShown = False;
    _lastPressTime = (Time) 0;

    //
    //  Create the Widget hierarchy. Create the expand form, but don't manage
    //  it. This allows the user to create all of the widgets for this form now,
    //  and have them show up only when the expand button is pressed.
    //
    _widget = XtVaCreateManagedWidget (name, xmFrameWidgetClass, tree,
	    XmNmarginWidth, 0,
	    XmNmarginHeight, 0,
	    NULL);
    _topForm = XtVaCreateManagedWidget ("topForm", xmFormWidgetClass, _widget, NULL);
    _baseForm = XtVaCreateManagedWidget ("baseForm", xmFormWidgetClass, _topForm,
	    XmNtopAttachment, XmATTACH_FORM,
	    XmNleftAttachment, XmATTACH_FORM,
	    XmNrightAttachment, XmATTACH_FORM,
	    NULL);
    _childButton = XtVaCreateManagedWidget ("childButton",
	    xmArrowButtonWidgetClass, _baseForm,
	    XmNtopAttachment, XmATTACH_FORM,
	    XmNbottomAttachment, XmATTACH_FORM,
	    XmNrightAttachment, XmATTACH_FORM,
	    XmNarrowDirection, XmARROW_RIGHT,
	    XmNshadowThickness, 0,
	    NULL);
    XmString xmstr = XmStringCreateSimple (value);
    if (treeParent) {
	_parentButton = XtVaCreateManagedWidget ("parentButton",
		xmArrowButtonWidgetClass, _baseForm,
		XmNleftAttachment, XmATTACH_FORM,
		XmNtopAttachment, XmATTACH_FORM,
		XmNbottomAttachment, XmATTACH_FORM,
		XmNarrowDirection, XmARROW_LEFT,
		XmNshadowThickness, 0,
		NULL);
	_label = XtVaCreateManagedWidget ("label", xmLabelWidgetClass, _baseForm,
		XmNleftAttachment, XmATTACH_WIDGET,
		XmNleftWidget, _parentButton,
		XmNrightAttachment, XmATTACH_WIDGET,
		XmNrightWidget, _childButton,
		XmNtopAttachment, XmATTACH_FORM,
		XmNbottomAttachment, XmATTACH_FORM,
		XmNlabelString, xmstr,
		NULL);
    } else {
	_label = XtVaCreateManagedWidget ("label", xmLabelWidgetClass, _baseForm,
		XmNleftAttachment, XmATTACH_FORM,
		XmNrightAttachment, XmATTACH_WIDGET,
		XmNrightWidget, _childButton,
		XmNtopAttachment, XmATTACH_FORM,
		XmNbottomAttachment, XmATTACH_FORM,
		XmNlabelString, xmstr,
		NULL);
    }
    XmStringFree (xmstr);
    _expandForm = XtVaCreateWidget ("expandForm", xmFormWidgetClass, _topForm,
	    XmNtopAttachment, XmATTACH_WIDGET,
	    XmNtopWidget, _baseForm,
	    XmNbottomAttachment, XmATTACH_FORM,
	    XmNleftAttachment, XmATTACH_FORM,
	    XmNrightAttachment, XmATTACH_FORM,
	    NULL);
    _realizeExpandForm = (XtIsRealized (_topForm)) ? True : False;

    initialize ();
    _realParent = treeParent;

    //
    //  Add the callbacks...
    //
    if (treeParent) {
	XtAddCallback (_parentButton, XmNactivateCallback,
		(XtCallbackProc) parentCB, (XtPointer) this);
    }
    XtAddCallback (_childButton, XmNactivateCallback,
		(XtCallbackProc) childrenCB, (XtPointer) this);

    //
    //  Add the event handlers...
    //
    XtAddEventHandler (_label, ButtonPressMask, False, (XtEventHandler) selectCB, (XtPointer) this);
}

TreeNodeC::~TreeNodeC () {
}

void
TreeNodeC::parentCB (Widget, TreeNodeC *obj, XtPointer) {
    if (obj->_treeParent->visible()) {
	obj->parentHide ();
	obj->hideParent ();
    } else {
	obj->parentShow ();
	obj->showParent ();
    }
}

void
TreeNodeC::childrenCB (Widget, TreeNodeC *obj, XtPointer) {
    if (obj->_childrenShown) {
	obj->childrenHide ();
	obj->hideChildren();
    } else {
	obj->childrenShow ();
	obj->showChildren();
    }
    obj->_childrenShown = !(obj->_childrenShown);
}

void
TreeNodeC::selectCB (Widget w, TreeNodeC *obj, XButtonPressedEvent *event, Boolean *) {
    if (event->button != Button1)
	return;

    //
    //  See if we have a double click of the mouse -- meaning we have
    //  to do an expand or "unexpand" (contract).
    //
    Time lpt = obj->_lastPressTime;
    Time et = event->time;
    Time mct = XtGetMultiClickTime (XtDisplay (w));
    if (lpt && et > lpt && et - lpt <= ((mct == 200) ? 500 : mct)) {
	//
	//  We have a double click. Do the appropriate (un)expand operation
	//  and reset the last click time.
	//
	if (obj->_expanded) {
	    XtUnmanageChild (obj->_expandForm);
	} else {
	    if (obj->_realizeExpandForm) {
		XtRealizeWidget (obj->_expandForm);
		obj->_realizeExpandForm = False;
	    }
	    XtManageChild (obj->_expandForm);
	}
	obj->_expanded = !(obj->_expanded);
	obj->tree().layout ();
	obj->_lastPressTime = (Time) 0;
    } else {
	//
	//  Not a double-click. Just need to save the last click time.
	//
	obj->_lastPressTime = et;
    }
    //
    //  In either case, we need to toggle the select state.
    //
    Pixel bg, fg;
    XtVaGetValues (w, XmNforeground, &fg, XmNbackground, &bg, NULL);
    XtVaSetValues (w, XmNforeground, bg, XmNbackground, fg, NULL);
    obj->_selected = !(obj->_selected);
    if (!obj->_selected)
	obj->unselect ();
    else
	obj->select ();
}

void
TreeNodeC::shown () {
    _parentPruned = (_realParent && !XtIsManaged (*_realParent)) ? True : False;
}

void
TreeNodeC::hidden () {
    _childrenShown = False;
    if (_realParent)
	_realParent->childHidden (this);
}

void
TreeNodeC::destroyed () {
}

void
TreeNodeC::childHidden (TreeNodeC *) {
    _childrenShown = False;
}
